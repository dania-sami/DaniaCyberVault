import argparse
import socket

def enumerate_subdomains(domain: str, wordlist_path: str, timeout: float = 1.5):
    found = []
    with open(wordlist_path) as f:
        for line in f:
            sub = line.strip()
            if not sub or sub.startswith("#"):
                continue
            host = f"{sub}.{domain}"
            try:
                socket.setdefaulttimeout(timeout)
                ip = socket.gethostbyname(host)
                found.append((host, ip))
            except socket.gaierror:
                continue
            except Exception:
                continue
    return found

def main():
    parser = argparse.ArgumentParser(description="Subdomain Enumeration Tool by Dania")
    parser.add_argument("--domain", required=True, help="Base domain, for example: example.com")
    parser.add_argument("--wordlist", required=True, help="Path to wordlist file")
    args = parser.parse_args()

    print(f"[+] Starting subdomain scan for {args.domain}")
    results = enumerate_subdomains(args.domain, args.wordlist)

    if not results:
        print("[+] No subdomains found with this wordlist.")
        return

    print("[+] Found:")
    for host, ip in results:
        print(f"    {host} -> {ip}")

if __name__ == "__main__":
    main()
