# Subdomain Enumeration Tool

Hi, I am Dania and this is a small subdomain enumeration script I use when I am doing recon on targets that I own or have permission to test.

The idea is simple: I give it a base domain and a wordlist. The script tries `word.domain` for each entry and prints the subdomains that actually resolve.

## Features

- Simple CLI interface
- Uses Python's built in DNS resolution
- Includes a small default wordlist so it works out of the box
- Clean output that is easy to copy into notes

## Usage

With the included wordlist:

```bash
python sub_enum.py --domain example.com --wordlist common_subdomains.txt
```

Example output:

```text
[+] Starting subdomain scan for example.com
[+] Found:
    www.example.com
    mail.example.com
    vpn.example.com
```

Like my other projects, I only use this on domains where I have clear permission to test.
