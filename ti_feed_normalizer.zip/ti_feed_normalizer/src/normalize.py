from __future__ import annotations

from pathlib import Path
from typing import List

import pandas as pd
import xml.etree.ElementTree as ET


BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
OUT_DIR = BASE_DIR / "output"
OUT_DIR.mkdir(parents=True, exist_ok=True)


def load_csv_feed(path: Path, source: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    df = df.rename(
        columns={
            "value": "indicator",
            "indicator": "indicator",
            "ioc": "indicator",
            "type": "type",
            "severity": "severity",
        }
    )
    if "type" not in df.columns:
        df["type"] = "unknown"
    if "severity" not in df.columns:
        df["severity"] = "low"
    df["source"] = source
    return df[["indicator", "type", "source", "severity"]]


def load_json_feed(path: Path, source: str) -> pd.DataFrame:
    df = pd.read_json(path)
    df = df.rename(
        columns={
            "indicator": "indicator",
            "ioc": "indicator",
            "kind": "type",
            "sev": "severity",
        }
    )
    if "type" not in df.columns:
        df["type"] = "unknown"
    if "severity" not in df.columns:
        df["severity"] = "medium"
    df["source"] = source
    return df[["indicator", "type", "source", "severity"]]


def load_xml_feed(path: Path, source: str) -> pd.DataFrame:
    tree = ET.parse(path)
    root = tree.getroot()
    rows = []
    for item in root.findall(".//item"):
        indicator = item.findtext("indicator") or item.findtext("value") or ""
        itype = item.findtext("type") or "unknown"
        sev = item.findtext("severity") or "low"
        rows.append(
            {
                "indicator": indicator.strip(),
                "type": itype.strip(),
                "source": source,
                "severity": sev.strip(),
            }
        )
    return pd.DataFrame(rows)


def severity_rank(sev: str) -> int:
    order = {"low": 0, "medium": 1, "high": 2}
    return order.get(str(sev).lower(), 0)


def main() -> None:
    feeds: List[pd.DataFrame] = []

    csv_path = DATA_DIR / "feed_csv.csv"
    if csv_path.exists():
        feeds.append(load_csv_feed(csv_path, "feed_csv"))

    json_path = DATA_DIR / "feed_json.json"
    if json_path.exists():
        feeds.append(load_json_feed(json_path, "feed_json"))

    xml_path = DATA_DIR / "feed_xml.xml"
    if xml_path.exists():
        feeds.append(load_xml_feed(xml_path, "feed_xml"))

    if not feeds:
        print("No feeds found in data/.")
        return

    df = pd.concat(feeds, ignore_index=True)
    df = df.dropna(subset=["indicator"])
    df = df[df["indicator"].astype(str).str.len() > 0]

    df["sev_rank"] = df["severity"].apply(severity_rank)
    df = df.sort_values("sev_rank", ascending=False)
    df = df.drop_duplicates(subset=["indicator"], keep="first")
    df = df.drop(columns=["sev_rank"])

    out_path = OUT_DIR / "normalized_feed.csv"
    df.to_csv(out_path, index=False)
    print(f"Normalised feed written to {out_path}")


if __name__ == "__main__":
    main()
