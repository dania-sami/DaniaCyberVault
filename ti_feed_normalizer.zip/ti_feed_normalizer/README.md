# Threat Intelligence Feed Normalizer

Hi, I am Dania Sami 👋

TI feeds come in every possible format: CSV, JSON, XML, each with different
field names and levels of quality. For a defender, the first challenge is
often just **making them consistent**.

This project is my **Threat Intelligence Feed Normalizer**:

- loads multiple sample feeds (CSV, JSON, XML)
- maps them into one unified schema
- deduplicates indicators
- exports a clean, normalised CSV

It is small, but it demonstrates exactly how I think as a security engineer
who also cares about data quality.

---

## Unified schema

All feeds are normalised into:

- `indicator`  (IP, domain, URL, hash)
- `type`       (`ip`, `domain`, `url`, `hash`)
- `source`     (which feed it came from)
- `severity`   (`low`, `medium`, `high`)

The script also drops duplicates, keeping the "highest" severity when the
same indicator appears in multiple feeds.

---

## How to run

```bash
cd ti_feed_normalizer

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt
```

Then:

```bash
python -m src.normalize
```

This will:

- read the three sample feeds under `data/`
- normalise and merge them
- write the result to `output/normalized_feed.csv`

You can open that file directly in any CSV viewer or feed it into other tools.

---

## Project structure

```text
ti_feed_normalizer/
  ├─ README.md
  ├─ requirements.txt
  ├─ data/
  │    ├─ feed_csv.csv
  │    ├─ feed_json.json
  │    └─ feed_xml.xml
  ├─ output/
  │    └─ normalized_feed.csv   # generated
  └─ src/
       ├─ __init__.py
       └─ normalize.py
```

---

## Why I built this

Threat intelligence is only useful if it can actually flow into SIEMs,
firewalls and EDRs. This project shows that I can:

- parse multiple formats (CSV/JSON/XML)
- design a reasonable common schema
- deduplicate and clean the data in a reproducible way
