
import json, argparse

def load_graph(path):
    with open(path,"r",encoding="utf-8") as f:
        return json.load(f)

def dfs(start, graph, path, visited, results, maxd=6):
    if len(path)>maxd: return
    results.append(path.copy())
    for nxt in graph.get(path[-1],[]):
        if nxt not in visited:
            visited.add(nxt)
            path.append(nxt)
            dfs(start, graph, path, visited, results, maxd)
            path.pop()
            visited.remove(nxt)

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--graph",default="trust_graph.json")
    p.add_argument("--start",required=True)
    p.add_argument("--out",default="lm_paths.md")
    a=p.parse_args()
    g=load_graph(a.graph)
    if a.start not in g:
        raise SystemExit("start not in graph")
    res=[]
    dfs(a.start,g,[a.start],{a.start},res)
    with open(a.out,"w",encoding="utf-8") as f:
        f.write("# Lateral movement paths\n\n")
        for pth in res:
            if len(pth)>1:
                f.write("* " + " → ".join(pth)+"\n")
    print("Wrote",a.out)

if __name__=="__main__":
    main()
