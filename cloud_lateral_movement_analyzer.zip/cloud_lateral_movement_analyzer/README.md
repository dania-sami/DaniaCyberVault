# Cloud Lateral Movement Analyzer – Dania

Hi

I am Dania and this analyzer reads a JSON description of identities  roles  and trust relationships and then searches for lateral movement paths

It focuses on

* chains of assume role and delegation
* jumps from low privilege to admin like roles
* short human readable path explanations

The result is a Markdown report and a Graphviz DOT graph that make it easier to talk about lateral movement without needing access to a live tenant
