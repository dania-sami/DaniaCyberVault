"""
Cloud Lateral Movement Analyzer – Dania

Offline graph exploration of cloud style identities and roles.

Input JSON example:

{
  "identities": [
    {"id": "user.alice", "kind": "user"},
    {"id": "role.support", "kind": "role", "is_admin": false},
    {"id": "role.admin", "kind": "role", "is_admin": true}
  ],
  "edges": [
    {"src": "user.alice", "dst": "role.support", "type": "assume_role"},
    {"src": "role.support", "dst": "role.admin", "type": "assume_role"}
  ]
}
"""

import argparse
import json
from dataclasses import dataclass
from typing import List, Dict, Tuple, Set


@dataclass
class Identity:
    id: str
    kind: str  # user, role, service
    is_admin: bool


@dataclass
class Edge:
    src: str
    dst: str
    type: str  # assume_role, delegation, group_membership


def load_graph(path: str):
    with open(path, "r", encoding="utf-8") as f:
        raw = json.load(f)
    ids = {
        item["id"]: Identity(
            id=item["id"],
            kind=item.get("kind", "unknown"),
            is_admin=bool(item.get("is_admin", False)),
        )
        for item in raw.get("identities", [])
    }
    edges = [Edge(src=e["src"], dst=e["dst"], type=e.get("type", "link")) for e in raw.get("edges", [])]
    return ids, edges


def build_adj(edges: List[Edge]) -> Dict[str, List[Edge]]:
    adj: Dict[str, List[Edge]] = {}
    for e in edges:
        adj.setdefault(e.src, []).append(e)
    return adj


def find_paths_to_admin(identities: Dict[str, Identity], edges: List[Edge], max_depth: int = 5):
    adj = build_adj(edges)
    admin_nodes = {i.id for i in identities.values() if i.is_admin}
    results: List[List[Edge]] = []

    starts = [i.id for i in identities.values() if not i.is_admin]

    def dfs(node: str, path_edges: List[Edge], visited: Set[str], depth: int):
        if depth > max_depth:
            return
        if node in admin_nodes and path_edges:
            results.append(list(path_edges))
            return
        for e in adj.get(node, []):
            if e.dst in visited:
                continue
            visited.add(e.dst)
            path_edges.append(e)
            dfs(e.dst, path_edges, visited, depth + 1)
            path_edges.pop()
            visited.remove(e.dst)

    for start in starts:
        dfs(start, [], {start}, 0)

    return results


def write_dot(identities: Dict[str, Identity], edges: List[Edge], path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        f.write("digraph lateral {\n")
        f.write("  rankdir=LR;\n")
        for ident in identities.values():
            color = "#c8e6c9" if ident.is_admin else "#e8f0fe"
            label = f"{ident.id}\\n{ident.kind}"
            f.write(f'  "{ident.id}" [shape=box,style="filled,rounded",fillcolor="{color}",label="{label}"];\n')
        for e in edges:
            f.write(f'  "{e.src}" -> "{e.dst}" [label="{e.type}"];\n')
        f.write("}\n")


def write_report(identities: Dict[str, Identity], paths: List[List[Edge]], path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        f.write("# Cloud lateral movement report\n\n")
        admin_nodes = [i.id for i in identities.values() if i.is_admin]
        f.write(f"* Admin identities: {', '.join(admin_nodes) if admin_nodes else 'none'}\n")
        f.write(f"* Found {len(paths)} distinct paths to admin.\n\n")

        for idx, edges in enumerate(paths, start=1):
            f.write(f"## Path {idx}\n\n")
            if not edges:
                continue
            start = edges[0].src
            end = edges[-1].dst
            f.write(f"* From: `{start}`\n")
            f.write(f"* To: `{end}`\n")
            f.write("* Hops:\n")
            for e in edges:
                f.write(f"  * `{e.src}` --({e.type})-> `{e.dst}`\n")
            f.write("\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's cloud lateral movement analyzer")
    parser.add_argument("--graph", default="example_graph.json", help="Identities and edges JSON")
    parser.add_argument("--out-prefix", default="lateral", help="Output prefix")
    args = parser.parse_args()

    identities, edges = load_graph(args.graph)
    paths = find_paths_to_admin(identities, edges)
    dot_path = f"{args.out_prefix}_graph.dot"
    md_path = f"{args.out_prefix}_report.md"
    write_dot(identities, edges, dot_path)
    write_report(identities, paths, md_path)

    print(f"Found {len(paths)} paths to admin roles.")
    print(f"Wrote DOT to {dot_path} and report to {md_path}")


if __name__ == "__main__":
    main()
