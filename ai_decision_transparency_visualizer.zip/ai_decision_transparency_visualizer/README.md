# AI Decision Transparency Visualizer – Dania

Hi

I am Dania and this project is my way of making model decisions less mysterious for security teams

It reads a small JSON file with decisions and feature contributions and then creates

* a Graphviz file that links decisions together
* a short Markdown summary that shows which features pushed each decision

The idea is to have something light and readable that I can plug into a pipeline or use in an incident review to explain why a model said yes or no
