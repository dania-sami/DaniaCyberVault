"""
AI Decision Transparency Visualizer – Dania

Reads a JSON file of model decisions with feature contributions
and writes:

* a Graphviz DOT graph linking decisions
* a Markdown summary of top features per decision
"""

import argparse
import json
from dataclasses import dataclass
from typing import List, Dict, Optional


@dataclass
class FeatureContribution:
    name: str
    value: float
    contribution: float


@dataclass
class Decision:
    id: str
    model: str
    outcome: str
    score: float
    parent_id: Optional[str]
    features: List[FeatureContribution]


def load_decisions(path: str) -> List[Decision]:
    with open(path, "r", encoding="utf-8") as f:
        raw = json.load(f)

    decisions: List[Decision] = []
    for item in raw:
        feats = [
            FeatureContribution(
                name=str(f.get("name")),
                value=float(f.get("value", 0.0)),
                contribution=float(f.get("contribution", 0.0)),
            )
            for f in item.get("features", [])
        ]
        decisions.append(
            Decision(
                id=str(item.get("id")),
                model=str(item.get("model", "")),
                outcome=str(item.get("outcome", "")),
                score=float(item.get("score", 0.0)),
                parent_id=item.get("parent_id"),
                features=feats,
            )
        )
    return decisions


def write_dot(decisions: List[Decision], path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        f.write("digraph decisions {\n")
        f.write('  rankdir=LR;\n')
        f.write('  node [shape=box, style="rounded,filled", fillcolor="#e8f0fe"];\n')

        for d in decisions:
            top_feats = sorted(d.features, key=lambda x: abs(x.contribution), reverse=True)[:3]
            feat_str = ", ".join(f"{ft.name} ({ft.contribution:+.2f})" for ft in top_feats)
            label = f"{d.id}\\nmodel={d.model}\\noutcome={d.outcome}\\nscore={d.score:.2f}\\n{feat_str}"
            f.write(f'  "{d.id}" [label="{label}"];\n')

        for d in decisions:
            if d.parent_id:
                f.write(f'  "{d.parent_id}" -> "{d.id}";\n')

        f.write("}\n")


def write_markdown(decisions: List[Decision], path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        f.write("# Decision transparency summary\n\n")
        if not decisions:
            f.write("No decisions were found in the input file.\n")
            return

        for d in decisions:
            f.write(f"## Decision {d.id}\n\n")
            f.write(f"* Model: `{d.model}`\n")
            f.write(f"* Outcome: `{d.outcome}` (score {d.score:.2f})\n")
            if d.parent_id:
                f.write(f"* Parent decision: `{d.parent_id}`\n")
            f.write("\n")
            if not d.features:
                f.write("No feature contributions were provided.\n\n")
                continue
            f.write("Top feature contributions:\n\n")
            top_feats = sorted(d.features, key=lambda x: abs(x.contribution), reverse=True)[:5]
            for ft in top_feats:
                f.write(f"* `{ft.name}` value {ft.value} → contribution {ft.contribution:+.3f}\n")
            f.write("\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's AI decision transparency visualizer")
    parser.add_argument("--decisions", required=True, help="Path to JSON file with decisions")
    parser.add_argument("--out-prefix", default="decisions", help="Prefix for output files")
    args = parser.parse_args()

    decisions = load_decisions(args.decisions)
    dot_path = f"{args.out_prefix}_graph.dot"
    md_path = f"{args.out_prefix}_summary.md"

    write_dot(decisions, dot_path)
    write_markdown(decisions, md_path)

    print(f"Wrote Graphviz DOT to {dot_path}")
    print(f"Wrote Markdown summary to {md_path}")


if __name__ == "__main__":
    main()
