
"""
Decision Transparency Visualizer – Dania
Takes a small model decision dump (weights, inputs) and draws a .dot graph
"""

import json
import argparse


def load(path):
    with open(path,"r") as f: 
        return json.load(f)

def make_dot(data, out_path):
    with open(out_path,"w") as f:
        f.write("digraph decision {\n")
        f.write('  node [shape=box];\n')
        f.write(f'  start [label="Model Decision"];\n')
        for feat,val in data["inputs"].items():
            w=data["weights"].get(feat,0)
            f.write(f'  "{feat}" [label="{feat}\\nvalue={val}\\nweight={w}"];\n')
            f.write(f'  start -> "{feat}";\n')
        f.write(f'  result [label="Prediction: {data["prediction"]}"];\n')
        for feat in data["inputs"]:
            f.write(f'  "{feat}" -> result;\n')
        f.write("}\n")


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--decision",required=True)
    p.add_argument("--out",default="decision.dot")
    a=p.parse_args()

    data=load(a.decision)
    make_dot(data,a.out)
    print("Wrote",a.out)

if __name__=="__main__":
    main()
