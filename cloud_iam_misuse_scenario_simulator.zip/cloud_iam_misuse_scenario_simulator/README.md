# Cloud IAM Misuse Scenario Simulator – Dania

Hi

I am Dania and this project is my small story based simulator for IAM mistakes in the cloud

It reads a JSON file with IAM scenarios and then walks through

* what the misconfiguration looks like
* how an attacker could abuse it step by step
* what simple controls would break the path

The output is a short Markdown story you can use in study sessions or interviews to talk clearly about IAM risk without touching real cloud resources
