"""
Cloud IAM Misuse Scenario Simulator – Dania

This tool does not talk to any cloud provider.
It only reads scenario descriptions from a local JSON file
and turns them into story like walkthroughs.
"""

import argparse
import json
from dataclasses import dataclass
from typing import List, Dict, Optional


@dataclass
class Step:
    id: int
    actor: str
    action: str
    goal: str


@dataclass
class Control:
    name: str
    description: str
    breaks_steps: List[int]


@dataclass
class Scenario:
    id: str
    title: str
    summary: str
    context: str
    steps: List[Step]
    controls: List[Control]


def load_scenarios(path: str) -> Dict[str, Scenario]:
    with open(path, "r", encoding="utf-8") as f:
        raw = json.load(f)
    scenarios: Dict[str, Scenario] = {}
    for item in raw:
        steps = [
            Step(
                id=int(s["id"]),
                actor=str(s["actor"]),
                action=str(s["action"]),
                goal=str(s["goal"]),
            )
            for s in item.get("steps", [])
        ]
        controls = [
            Control(
                name=str(c["name"]),
                description=str(c["description"]),
                breaks_steps=[int(x) for x in c.get("breaks_steps", [])],
            )
            for c in item.get("controls", [])
        ]
        sc = Scenario(
            id=str(item["id"]),
            title=str(item["title"]),
            summary=str(item.get("summary", "")),
            context=str(item.get("context", "")),
            steps=steps,
            controls=controls,
        )
        scenarios[sc.id] = sc
    return scenarios


def render_scenario_md(s: Scenario) -> str:
    lines: List[str] = []
    lines.append(f"# {s.title}\n")
    if s.summary:
        lines.append(s.summary + "\n")
    if s.context:
        lines.append("**Context**\n")
        lines.append(s.context + "\n")

    lines.append("## Attack path steps\n")
    for st in s.steps:
        lines.append(f"{st.id}. **{st.actor}** – {st.action}  _(goal: {st.goal})_")
    lines.append("")

    lines.append("## Controls that would break the path\n")
    if not s.controls:
        lines.append("No controls were provided for this scenario.\n")
    else:
        for c in s.controls:
            steps_str = ", ".join(str(x) for x in c.breaks_steps) if c.breaks_steps else "n/a"
            lines.append(f"* **{c.name}** – {c.description}  _(breaks steps: {steps_str})_")
    lines.append("")
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's Cloud IAM Misuse Scenario Simulator")
    parser.add_argument("--scenarios", default="example_scenarios.json", help="JSON file with IAM scenarios")
    parser.add_argument("--scenario-id", help="ID of a single scenario to render")
    parser.add_argument("--out", default="scenario_story.md", help="Output Markdown path")
    args = parser.parse_args()

    scenarios = load_scenarios(args.scenarios)
    if args.scenario_id:
        if args.scenario_id not in scenarios:
            raise SystemExit(f"Scenario {args.scenario_id} not found in {args.scenarios}")
        selected = [scenarios[args.scenario_id]]
    else:
        selected = list(scenarios.values())

    parts: List[str] = []
    for sc in selected:
        parts.append(render_scenario_md(sc))
    text = "\n\n---\n\n".join(parts)

    with open(args.out, "w", encoding="utf-8") as f:
        f.write(text)

    print(f"Wrote scenario story to {args.out}")


if __name__ == "__main__":
    main()
