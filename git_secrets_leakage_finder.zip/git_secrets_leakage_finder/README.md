# Git Secrets Leakage Finder

Hi, I am Dania Sami 👋

Accidentally committing API keys or credentials into a repository is one of the
most common and dangerous developer mistakes.

This project is my **Git secrets leakage finder**:

- scans a directory (for example a cloned repo)
- uses regex patterns plus a simple entropy check
- prints possible secrets with file name and line number
- writes a small report to `reports/findings.txt`

It is deliberately lightweight so it can be run locally or in CI.

---

## What this tool detects

In `src/patterns.py` I define simple patterns for:

- common API key formats
- obvious `password=` assignments
- tokens (long alphanumeric strings)
- AWS-style access keys (very simplified)

It also calculates the **Shannon entropy** of candidate strings and only
keeps high-entropy ones to reduce noise.

---

## How to run

You need Python 3.10+.

```bash
python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt   # stdlib only, so this is instant
```

### Scan the current directory

```bash
python -m src.scan --path .
```

### Scan a specific repo

```bash
python -m src.scan --path /path/to/my/repo
```

The tool will:

- print findings in the terminal
- write them into `reports/findings.txt`

---

## Project structure

```text
git_secrets_leakage_finder/
  ├─ README.md
  ├─ requirements.txt
  ├─ reports/
  │    └─ findings.txt          # generated
  └─ src/
       ├─ __init__.py
       ├─ config.py
       ├─ patterns.py
       └─ scan.py
```

---

## Why I built this

Secret scanning is now expected in modern pipelines. This tool lets me show
that I can:

- design patterns for secret detection
- combine them with entropy-based filtering
- build developer-focused security tooling that is easy to integrate
