import re

API_KEY = re.compile(r"(?i)(api_key|apikey|api-key|x-api-key)[:=]['\"]?([A-Za-z0-9_\-]{16,})")
PASSWORD = re.compile(r"(?i)(password|pwd)\s*[:=]\s*['\"]([^'\"]{6,})['\"]")
GENERIC_TOKEN = re.compile(r"['\"]([A-Za-z0-9_\-]{24,})['\"]")
AWS_ACCESS_KEY = re.compile(r"AKIA[0-9A-Z]{16}")
