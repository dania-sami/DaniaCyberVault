from __future__ import annotations

import argparse
import math
import os
from pathlib import Path
from typing import List, Tuple

from .config import REPORT_FILE
from . import patterns


def shannon_entropy(s: str) -> float:
    if not s:
        return 0.0
    freq = {}
    for ch in s:
        freq[ch] = freq.get(ch, 0) + 1
    ent = 0.0
    length = len(s)
    for c in freq.values():
        p = c / length
        ent -= p * math.log2(p)
    return ent


def find_secrets_in_line(line: str) -> List[Tuple[str, str]]:
    findings: List[Tuple[str, str]] = []

    for name, regex in [
        ("API_KEY", patterns.API_KEY),
        ("PASSWORD", patterns.PASSWORD),
        ("GENERIC_TOKEN", patterns.GENERIC_TOKEN),
        ("AWS_ACCESS_KEY", patterns.AWS_ACCESS_KEY),
    ]:
        for m in regex.finditer(line):
            candidate = m.group(m.lastindex or 0)
            if not candidate:
                continue
            if shannon_entropy(candidate) < 3.5 and name != "PASSWORD":
                continue
            findings.append((name, candidate))
    return findings


def scan_path(path: Path) -> List[str]:
    results: List[str] = []
    for root, dirs, files in os.walk(path):
        # skip .git and venv etc.
        dirs[:] = [d for d in dirs if d not in {".git", ".svn", "venv", ".venv", "__pycache__"}]
        for fname in files:
            full = Path(root) / fname
            try:
                text = full.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue
            for lineno, line in enumerate(text.splitlines(), start=1):
                for kind, value in find_secrets_in_line(line):
                    msg = f"{full}:{lineno}: [{kind}] {value}"
                    results.append(msg)
    return results


def main() -> None:
    parser = argparse.ArgumentParser(description="Git secrets leakage finder")
    parser.add_argument("--path", type=str, default=".", help="Directory to scan")
    args = parser.parse_args()

    base = Path(args.path).resolve()
    print(f"Scanning for secrets in {base} ...")
    findings = scan_path(base)

    if not findings:
        print("No potential secrets found.")
        REPORT_FILE.write_text("No potential secrets found.\n", encoding="utf-8")
        return

    print("Potential secrets found:")
    for f in findings:
        print(f)

    REPORT_FILE.write_text("\n".join(findings) + "\n", encoding="utf-8")
    print(f"Report written to {REPORT_FILE}")


if __name__ == "__main__":
    main()
