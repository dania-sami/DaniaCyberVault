# Data Leak Pattern Hunter – Dania’s repo safety scanner

Hi

I am Dania and this project is my small helper for catching data leak patterns inside source repositories

It is not meant to be a full blown enterprise SAST product
It is intentionally small and explainable
so I can walk someone through the logic in an interview and also actually use it on my own projects

The idea is simple

* I point the tool at a local git checkout or any code directory
* It walks the files and looks for several classes of risky patterns
  * obvious tokens and keys using regular expressions
  * suspicious logging calls that mention secrets or passwords
  * debug style endpoints in web code
* It scores each finding by how risky it looks
* It then writes
  * a JSON file with all raw findings for automation
  * a Markdown report that I can read like a human

## What it looks for

Right now the hunter focuses on a few practical categories

### 1 Hard coded tokens and keys

Using simple regular expressions it tries to match things like

* api_key
* token
* bearer
* secret
* private key blocks
* hex looking values that are very long

and avoids some obvious safe things like CSS colours or short numbers

### 2 Suspicious logging of sensitive data

For lines that look like logging calls (log info debug print etc)
it checks if the line also contains words such as

* password
* secret
* token
* cookie
* session

If yes it is flagged as a possible data leak through logs

### 3 Debug or admin endpoints

For web style files (for example .py .js .ts)
it searches for route like definitions that include

* debug
* admin
* test
* internal

and flags them so I can manually review whether they are protected

## How I run it

I usually test first on the included examples folder

1 Optional create and activate a virtual environment

   python3 -m venv venv
   source venv_bin_activate

2 Install requirements

   pip install -r requirements.txt

   The project uses only the Python standard library
   This file just keeps the structure familiar

3 Run the hunter against the small demo repo layout

   python data_leak_hunter.py \
       --root examples_demo_repo \
       --out-prefix runs_demo

This will produce

* runs_demo_findings.json
* runs_demo_report.md

The report groups findings by file and category
shows me the line number and a shortened snippet
and gives each finding a simple score like Low Medium or High

After that I can point it at my own local repositories

   python data_leak_hunter.py \
       --root path_to_my_repo \
       --out-prefix runs_my_repo

## Why I built this

I wanted something that sits between manual grepping and huge scanning platforms

With this project I can talk about

* how to design regexes for secrets without going too crazy
* how context around a match can reduce false positives
* why logging of secrets is such a common leak path
* how I would extend this with more languages and patterns over time

It is small enough that I actually run it on my own code
and rich enough to be an interesting piece in my cyber security portfolio

