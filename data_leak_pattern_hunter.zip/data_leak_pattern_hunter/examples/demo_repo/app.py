import logging

API_KEY = "1234567890abcdef1234567890abcdef"

def login(user, password):
    logging.info("User login attempt for user=%s password=%s", user, password)
    return True

def debug_route(app):
    @app.get("/debug/internal")
    def debug_internal():
        return "debug info"
