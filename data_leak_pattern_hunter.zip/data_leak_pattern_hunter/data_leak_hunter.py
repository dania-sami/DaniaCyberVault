"""
Data Leak Pattern Hunter – Dania's repo safety scanner

Walks a source directory
applies simple regex and context based checks
and reports potential data leak patterns
"""

import argparse
import json
import os
import re
from dataclasses import dataclass, asdict
from typing import List


@dataclass
class Finding:
    file_path: str
    line_no: int
    category: str
    severity: str
    message: str
    line_snippet: str


SECRET_WORDS = [
    "api_key",
    "apikey",
    "auth_token",
    "access_token",
    "secret",
    "client_secret",
    "password",
    "passwd",
    "private_key",
    "pkcs8",
    "ssh-rsa",
]

LOG_WORDS = [
    "log(",
    "logger.",
    "logging.",
    "console.log",
    "print(",
]

SENSITIVE_WORDS = [
    "password",
    "secret",
    "token",
    "cookie",
    "session",
    "auth",
]

DEBUG_WORDS = [
    "debug",
    "admin",
    "test",
    "internal",
]

HEX_LONG_RE = re.compile(r"\b[0-9a-fA-F]{32,}\b")
PRIVATE_KEY_RE = re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----")


def is_code_file(path: str) -> bool:
    _, ext = os.path.splitext(path)
    return ext in {".py", ".js", ".ts", ".java", ".go", ".rb", ".php", ".cs", ".env", ".txt"}


def scan_file(path: str, root: str) -> List[Finding]:
    findings: List[Finding] = []
    rel_path = os.path.relpath(path, root)

    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()
    except OSError:
        return findings

    for idx, line in enumerate(lines, start=1):
        stripped = line.strip()
        if not stripped:
            continue

        lower = stripped.lower()

        # 1  Direct secret words and long hex
        for w in SECRET_WORDS:
            if w in lower:
                severity = "High" if "password" in w or "private_key" in w or "secret" in w else "Medium"
                findings.append(
                    Finding(
                        file_path=rel_path,
                        line_no=idx,
                        category="hard_coded_secret",
                        severity=severity,
                        message=f"Suspicious secret word '{w}' in code",
                        line_snippet=stripped[:200],
                    )
                )
                break

        if PRIVATE_KEY_RE.search(stripped):
            findings.append(
                Finding(
                    file_path=rel_path,
                    line_no=idx,
                    category="hard_coded_private_key",
                    severity="High",
                    message="Private key block detected in file",
                    line_snippet=stripped[:200],
                )
            )

        if HEX_LONG_RE.search(stripped):
            findings.append(
                Finding(
                    file_path=rel_path,
                    line_no=idx,
                    category="long_hex_value",
                    severity="Medium",
                    message="Long hex like value found which could be a token",
                    line_snippet=stripped[:200],
                )
            )

        # 2  Suspicious logging
        if any(log_word in lower for log_word in LOG_WORDS) and any(
            sens in lower for sens in SENSITIVE_WORDS
        ):
            findings.append(
                Finding(
                    file_path=rel_path,
                    line_no=idx,
                    category="logging_sensitive_data",
                    severity="Medium",
                    message="Log statement appears to include sensitive data",
                    line_snippet=stripped[:200],
                )
            )

        # 3  Debug endpoints  simple heuristic
        if any(word in lower for word in DEBUG_WORDS) and ("route" in lower or "get(" in lower or "post(" in lower):
            findings.append(
                Finding(
                    file_path=rel_path,
                    line_no=idx,
                    category="debug_or_admin_endpoint",
                    severity="Low",
                    message="Potential debug or admin style endpoint definition",
                    line_snippet=stripped[:200],
                )
            )

    return findings


def walk_root(root: str) -> List[str]:
    files: List[str] = []
    for dirpath, dirnames, filenames in os.walk(root):
        # skip some noisy directories
        dirnames[:] = [d for d in dirnames if d not in {".git", "node_modules", "dist", "build", "__pycache__"}]
        for name in filenames:
            full = os.path.join(dirpath, name)
            if is_code_file(full):
                files.append(full)
    return files


def write_json(findings: List[Finding], path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump([asdict(fnd) for fnd in findings], f, indent=2, ensure_ascii=False)


def write_report(findings: List[Finding], path: str) -> None:
    by_file: dict = {}
    for fnd in findings:
        by_file.setdefault(fnd.file_path, []).append(fnd)

    with open(path, "w", encoding="utf-8") as f:
        f.write("# Data leak pattern hunter report\n\n")
        if not findings:
            f.write("No suspicious patterns were found with the current rules.\n")
            return

        f.write(f"Total findings: {len(findings)}\n\n")
        for file_path, items in sorted(by_file.items()):
            f.write(f"## {file_path}\n\n")
            for fnd in items:
                f.write(f"* Line {fnd.line_no}  [{fnd.category}]  {fnd.severity}\n")
                f.write(f"  - {fnd.message}\n")
                f.write("  - `")
                f.write(fnd.line_snippet.replace("`", "'"))
                f.write("`\n")
            f.write("\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's data leak pattern hunter")
    parser.add_argument("--root", required=True, help="Root directory of source code to scan")
    parser.add_argument(
        "--out-prefix",
        default="data_leak",
        help="Prefix for output files (default data_leak)",
    )
    args = parser.parse_args()

    files = walk_root(args.root)
    all_findings: List[Finding] = []
    for fpath in files:
        all_findings.extend(scan_file(fpath, args.root))

    json_path = f"{args.out_prefix}_findings.json"
    md_path = f"{args.out_prefix}_report.md"

    write_json(all_findings, json_path)
    write_report(all_findings, md_path)

    print(f"Scanned {len(files)} files and wrote {len(all_findings)} findings.")
    print(f"JSON output: {json_path}")
    print(f"Markdown report: {md_path}")


if __name__ == "__main__":
    main()
