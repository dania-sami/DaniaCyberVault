import os, re, json, argparse
from dataclasses import dataclass, asdict

@dataclass
class Finding:
    file: str
    line_no: int
    context: str
    match: str
    rule: str

PATTERNS = {
    "api_key": re.compile(r"(api[_-]?key\s*=\s*['\"][A-Za-z0-9_\-]{10,}") ,
    "token": re.compile(r"(token\s*=\s*['\"][A-Za-z0-9_\-]{10,})"),
    "debug_endpoint": re.compile(r"(\/debug\/[A-Za-z0-9_\-]+)"),
    "password_literal": re.compile(r"(password\s*=\s*['\"])"),
    "env_dump": re.compile(r"os\.environ"),
}

def scan_file(path: str):
    findings=[]
    with open(path,"r",encoding="utf-8",errors="ignore") as f:
        lines=f.readlines()
    for i,line in enumerate(lines):
        for name,pat in PATTERNS.items():
            if pat.search(line):
                ctx = "".join(lines[max(0,i-1):min(len(lines),i+2)])
                findings.append(Finding(path,i+1,ctx.strip(),line.strip(),name))
    return findings

def scan_folder(folder: str):
    all_findings=[]
    for root,_,files in os.walk(folder):
        for file in files:
            if file.endswith((".py",".js",".ts",".env",".config",".json")):
                p=os.path.join(root,file)
                all_findings.extend(scan_file(p))
    return all_findings

def write_report(findings,out):
    with open(out,"w",encoding="utf-8") as f:
        f.write("# Data Leak Hunter Report\n\n")
        if not findings:
            f.write("No issues found.\n")
            return
        for fd in findings:
            f.write(f"## {fd.file} line {fd.line_no}\n")
            f.write(f"* Rule: **{fd.rule}**\n")
            f.write("```\n"+fd.context+"\n```\n\n")

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--path",required=True)
    ap.add_argument("--out",default="report.md")
    ap.add_argument("--json",default="results.json")
    a=ap.parse_args()

    findings=scan_folder(a.path)
    write_report(findings,a.out)
    with open(a.json,"w") as f: json.dump([asdict(fd) for fd in findings],f,indent=2)

if __name__=="__main__":
    main()
