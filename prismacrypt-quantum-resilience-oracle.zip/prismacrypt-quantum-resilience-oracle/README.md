
# PrismaCrypt Quantum Resilience Oracle

I built PrismaCrypt as my small lab for thinking clearly about quantum
pressure on cryptographic schemes.

This project does not pretend to implement real quantum algorithms or give
formal proofs. Instead it offers a transparent scoring model that lets me
compare different schemes under different hypothetical quantum attack
scenarios.

It is a reasoning tool, not a proof system.

## What PrismaCrypt does

* defines a few scheme profiles for example
  * `rsa_2048`
  * `ecc_p256`
  * `kyber_like_768`
  * `dilithium_like_3`
* defines several attack scenarios such as
  * `near_term_faulty_qubits`
  * `scaled_fault_tolerant_qc`
  * `adversarial_breakthrough_model`
* combines scheme and scenario to estimate
  * effective bits of security under that model
  * a resilience score between zero and one hundred
  * a risk band label
  * a human readable explanation

All the maths behind it is deliberately simple and visible in `engine.py` so I
can walk anyone through the assumptions in a few minutes.

## Project layout

```text
prismacrypt-quantum-resilience-oracle
└── backend
    ├── prismacrypt_oracle
    │   ├── __init__.py
    │   ├── engine.py  Scheme and scenario model plus scoring logic
    │   └── main.py    FastAPI HTTP API
    ├── requirements.txt
    └── example_requests.http
```

## How I run it locally

From the backend folder

```bash
python -m venv .venv
source .venv/bin/activate        # On Windows I use .venv\Scripts\activate
pip install -r requirements.txt
uvicorn prismacrypt_oracle.main:app --reload --port 9807
```

Then I open

* http://localhost:9807/docs to experiment with schemes and scenarios

## Example conversations I build with this

First I see what schemes the oracle knows about

```bash
curl http://localhost:9807/schemes
```

Then I inspect the available quantum scenarios

```bash
curl http://localhost:9807/scenarios
```

Now I can ask a concrete question for example

> How does a lattice style KEM look under a scaled fault tolerant quantum
> computer compared to classic RSA.

```bash
curl -X POST http://localhost:9807/evaluate   -H "Content-Type: application/json"   -d '{
    "scheme": "kyber_like_768",
    "scenario": "scaled_fault_tolerant_qc"
  }'
```

and

```bash
curl -X POST http://localhost:9807/evaluate   -H "Content-Type: application/json"   -d '{
    "scheme": "rsa_2048",
    "scenario": "adversarial_breakthrough_model"
  }'
```

The responses give me

* an effective bits estimate
* a resilience score
* a risk band
* a narrative that explains how the number came together

This is exactly the kind of material I like to use when discussing migration
plans or when I want to show how I think about post quantum risk in a
structured but honest way.

## Future directions

If I want to grow PrismaCrypt I can

* add more scheme profiles based on emerging standards
* adjust scenario parameters as research evolves
* connect it to a real benchmarking lab for performance comparisons
* plug the outputs into a dashboard for crypto inventory and planning

Right now this version already captures how I reason about quantum impact on
crypto and how I communicate those trade offs.
