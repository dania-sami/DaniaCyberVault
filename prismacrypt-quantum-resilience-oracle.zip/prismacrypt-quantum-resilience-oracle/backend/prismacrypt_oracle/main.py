
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import List

from .engine import QuantumOracle, SchemeProfile, AttackScenario, ResilienceReport


oracle = QuantumOracle()


class SchemeOut(BaseModel):
    name: str
    family: str
    security_bits_classical: int
    relative_q_attack_cost: float
    key_size_bytes: int
    ciphertext_size_bytes: int


class ScenarioOut(BaseModel):
    name: str
    description: str
    quantum_speedup_factor: float
    noise_tolerance: float


class EvaluateIn(BaseModel):
    scheme: str = Field(..., example="kyber_like_768")
    scenario: str = Field(..., example="scaled_fault_tolerant_qc")


class EvaluateOut(BaseModel):
    scheme: str
    scenario: str
    effective_bits: float
    resilience_score: float
    risk_band: str
    explanation: str


app = FastAPI(
    title="PrismaCrypt Quantum Resilience Oracle",
    version="0.1.0",
    description="My reasoning lab for exploring hypothetical quantum pressure on different crypto schemes.",
)


@app.get("/schemes", response_model=List[SchemeOut])
def schemes() -> List[SchemeOut]:
    out: List[SchemeOut] = []
    for s in oracle.list_schemes():
        out.append(
            SchemeOut(
                name=s.name,
                family=s.family,
                security_bits_classical=s.security_bits_classical,
                relative_q_attack_cost=s.relative_q_attack_cost,
                key_size_bytes=s.key_size_bytes,
                ciphertext_size_bytes=s.ciphertext_size_bytes,
            )
        )
    return out


@app.get("/scenarios", response_model=List[ScenarioOut])
def scenarios() -> List[ScenarioOut]:
    out: List[ScenarioOut] = []
    for sc in oracle.list_scenarios():
        out.append(
            ScenarioOut(
                name=sc.name,
                description=sc.description,
                quantum_speedup_factor=sc.quantum_speedup_factor,
                noise_tolerance=sc.noise_tolerance,
            )
        )
    return out


@app.post("/evaluate", response_model=EvaluateOut)
def evaluate(payload: EvaluateIn) -> EvaluateOut:
    try:
        rep: ResilienceReport = oracle.evaluate(payload.scheme, payload.scenario)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return EvaluateOut(
        scheme=rep.scheme,
        scenario=rep.scenario,
        effective_bits=rep.effective_bits,
        resilience_score=rep.resilience_score,
        risk_band=rep.risk_band,
        explanation=rep.explanation,
    )
