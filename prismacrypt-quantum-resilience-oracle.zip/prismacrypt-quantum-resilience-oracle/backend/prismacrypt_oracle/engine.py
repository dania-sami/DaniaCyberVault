
from dataclasses import dataclass
from typing import Dict, List
import math


@dataclass
class SchemeProfile:
    name: str
    family: str
    security_bits_classical: int
    relative_q_attack_cost: float
    key_size_bytes: int
    ciphertext_size_bytes: int


@dataclass
class AttackScenario:
    name: str
    description: str
    quantum_speedup_factor: float
    noise_tolerance: float


@dataclass
class ResilienceReport:
    scheme: str
    scenario: str
    effective_bits: float
    resilience_score: float
    risk_band: str
    explanation: str


class QuantumOracle:
    """
    PrismaCrypt is my quantum resilience reasoning lab.

    It does NOT implement real quantum attacks or provide formal security
    proofs. Instead it offers a safe mental model for how different schemes
    might behave under various quantum attack assumptions.

    I use it as a storytelling and reasoning engine when I talk about
    post-quantum migration and crypto agility.
    """

    def __init__(self) -> None:
        self.schemes: Dict[str, SchemeProfile] = {}
        self.scenarios: Dict[str, AttackScenario] = {}
        self._seed_schemes()
        self._seed_scenarios()

    def _seed_schemes(self) -> None:
        self.add_scheme(
            SchemeProfile(
                name="rsa_2048",
                family="classic_rsa",
                security_bits_classical=112,
                relative_q_attack_cost=0.2,
                key_size_bytes=256,
                ciphertext_size_bytes=256,
            )
        )
        self.add_scheme(
            SchemeProfile(
                name="ecc_p256",
                family="classic_ecc",
                security_bits_classical=128,
                relative_q_attack_cost=0.15,
                key_size_bytes=64,
                ciphertext_size_bytes=64,
            )
        )
        self.add_scheme(
            SchemeProfile(
                name="kyber_like_768",
                family="lattice_kem",
                security_bits_classical=192,
                relative_q_attack_cost=0.75,
                key_size_bytes=1184,
                ciphertext_size_bytes=1088,
            )
        )
        self.add_scheme(
            SchemeProfile(
                name="dilithium_like_3",
                family="lattice_signature",
                security_bits_classical=128,
                relative_q_attack_cost=0.8,
                key_size_bytes=1952,
                ciphertext_size_bytes=2701,
            )
        )

    def _seed_scenarios(self) -> None:
        self.add_scenario(
            AttackScenario(
                name="near_term_faulty_qubits",
                description="Few noisy qubits, limited depth. Strong speedup on textbook RSA/ECC, limited benefit for structured lattices.",
                quantum_speedup_factor=0.1,
                noise_tolerance=0.2,
            )
        )
        self.add_scenario(
            AttackScenario(
                name="scaled_fault_tolerant_qc",
                description="Large scale fault tolerant quantum computers with error correction.",
                quantum_speedup_factor=0.4,
                noise_tolerance=0.8,
            )
        )
        self.add_scenario(
            AttackScenario(
                name="adversarial_breakthrough_model",
                description="Hypothetical aggressive model where adversary finds better algorithms than currently known.",
                quantum_speedup_factor=0.6,
                noise_tolerance=0.9,
            )
        )

    def add_scheme(self, profile: SchemeProfile) -> None:
        self.schemes[profile.name] = profile

    def add_scenario(self, scenario: AttackScenario) -> None:
        self.scenarios[scenario.name] = scenario

    def list_schemes(self) -> List[SchemeProfile]:
        return list(self.schemes.values())

    def list_scenarios(self) -> List[AttackScenario]:
        return list(self.scenarios.values())

    def evaluate(self, scheme_name: str, scenario_name: str) -> ResilienceReport:
        if scheme_name not in self.schemes:
            raise ValueError(f"Unknown scheme {scheme_name}")
        if scenario_name not in self.scenarios:
            raise ValueError(f"Unknown scenario {scenario_name}")

        scheme = self.schemes[scheme_name]
        scenario = self.scenarios[scenario_name]

        if scheme.family in ("classic_rsa", "classic_ecc"):
            penalty_factor = scenario.quantum_speedup_factor * (1.0 + scenario.noise_tolerance)
        else:
            penalty_factor = scenario.quantum_speedup_factor * (1.0 - scenario.noise_tolerance * (1.0 - scheme.relative_q_attack_cost))

        penalty_factor = max(0.0, min(0.95, penalty_factor))

        effective_bits = scheme.security_bits_classical * (1.0 - penalty_factor)

        size_pressure = (scheme.key_size_bytes + scheme.ciphertext_size_bytes) / 4096.0
        size_pressure = min(1.0, size_pressure)

        resilience_score = max(0.0, min(100.0, effective_bits / 2.0 - size_pressure * 5.0))

        if resilience_score >= 80:
            band = "strong_candidate_for_long_term"
        elif resilience_score >= 60:
            band = "good_mid_term_choice"
        elif resilience_score >= 40:
            band = "needs_caution_and_migration_plan"
        else:
            band = "legacy_or_high_risk_under_model"

        explanation_parts: List[str] = []
        explanation_parts.append(
            f"Started from {scheme.security_bits_classical} classical bits in family {scheme.family}."
        )
        explanation_parts.append(
            f"Scenario {scenario.name} applies a penalty factor of about {penalty_factor*100:.1f}% to model quantum attack advantage."
        )
        explanation_parts.append(
            f"That leaves roughly {effective_bits:.1f} effective bits under this hypothetical model."
        )
        explanation_parts.append(
            f"Message and key sizes contribute an extra pressure of {size_pressure*100:.1f}% to the usability score."
        )
        explanation = " ".join(explanation_parts)

        return ResilienceReport(
            scheme=scheme.name,
            scenario=scenario.name,
            effective_bits=round(effective_bits, 2),
            resilience_score=round(resilience_score, 2),
            risk_band=band,
            explanation=explanation,
        )
