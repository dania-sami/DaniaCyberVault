"""PrismaCrypt Quantum Resilience Oracle backend package."""
