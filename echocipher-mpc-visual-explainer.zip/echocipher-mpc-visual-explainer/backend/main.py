
from fastapi import FastAPI
app=FastAPI(title="echocipher-mpc-visual-explainer")
@app.get("/status")
def status():
    return {"project":"echocipher-mpc-visual-explainer","status":"working"}
