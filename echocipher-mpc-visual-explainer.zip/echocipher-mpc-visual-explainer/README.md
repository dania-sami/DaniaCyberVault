# echocipher-mpc-visual-explainer
I built echocipher-mpc-visual-explainer as a simple working prototype.
Run it and check /status.
