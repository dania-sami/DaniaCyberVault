"""
Container Escape Lab Sandbox – guide script

Reads lab_scenarios.json and prints a small study guide.
"""

import json
import os


def main() -> None:
    base_dir = os.path.dirname(os.path.abspath(__file__))
    scenarios_path = os.path.join(base_dir, "lab_scenarios.json")
    if not os.path.isfile(scenarios_path):
        print("Could not find lab_scenarios.json")
        return

    with open(scenarios_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    scenarios = data.get("scenarios", [])
    print("Container escape lab – study guide\n")
    if not scenarios:
        print("No scenarios defined.")
        return

    for s in scenarios:
        print("=" * 60)
        print(f"Scenario: {s.get('title', s.get('id', 'unknown'))}")
        print(f"Service id in docker-compose.yml: {s.get('id', '')}")
        print("")
        print("Risk (high level):")
        print(f"  {s.get('risk', '')}")
        print("")
        print("Questions to think about:")
        for q in s.get("questions", []):
            print(f"  - {q}")
        print("")

    print("This guide is meant for discussion and reflection.")
    print("It does not provide exploit commands or step-by-step instructions.")
    print("Focus on understanding why these configurations are risky and how to avoid them.\n")


if __name__ == "__main__":
    main()
