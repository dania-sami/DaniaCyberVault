# Container Escape Lab Sandbox – Dania’s misconfiguration playground

Hi

I am Dania and this is a tiny sandbox repository I use to think about container escape risks in a safe way

Real container escapes are a complex topic
and I do not want to ship any real exploit chains here
Instead this project focuses on **recognising dangerous patterns** in configuration
and guiding someone through questions like:

* why is this container running privileged
* why does it have access to the Docker socket
* why does it mount the host filesystem read‑write

So the repo contains:

* a `docker-compose.yml` with intentionally misconfigured example services
* a small `lab_scenarios.json` file describing the risks in plain language
* a helper script `lab_guide.py` that prints out the scenarios as a study guide

It is designed to be talked through in an interview or study session
not to be launched on random infrastructure

## What the compose file shows

The `docker-compose.yml` includes a few “bad idea” examples such as:

* a service running with `privileged: true`
* a service that mounts `/var/run/docker.sock`
* a service that mounts the host root filesystem under `/host` (read only in this demo)

Each one is labelled clearly in comments so it is obvious that this is not a recommended setup.

If I run this locally on my own machine
I treat it purely as a teaching environment
never on a shared or sensitive host.

## The lab guide

The `lab_guide.py` script reads `lab_scenarios.json` and prints out:

* the name of each misconfigured service
* what the risky setting is
* questions to ask myself (or a student) about impact and mitigation

It does **not** print exploit commands
The whole point is to build intuition for “this configuration smells dangerous”
so that in real life I do not create it in the first place.

Run it like this:

    python lab_guide.py

and it will show a short, interview‑friendly summary of each scenario.

## How I use this in learning and interviews

This repo is handy for:

* walking through container basics with other students
* demonstrating that I recognise common misconfigurations in Docker setups
* discussing mitigations like dropping capabilities, avoiding host mounts and using rootless containers

With this project I can show that I:

* understand at a high level why privileged containers and host mounts are risky
* can read and reason about Docker Compose configuration
* focus on safe, educational setups rather than sharing exploit recipes

It is deliberately small and fully transparent
so it fits nicely into a bigger story about container security in my portfolio.
