import argparse
import hashlib
import json
import os
from typing import Dict

def hash_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()

def build_snapshot(folder: str) -> Dict[str, str]:
    snapshot = {}
    for root, dirs, files in os.walk(folder):
        for name in files:
            full = os.path.join(root, name)
            rel = os.path.relpath(full, folder)
            try:
                snapshot[rel] = hash_file(full)
            except (OSError, PermissionError):
                continue
    return snapshot

def do_baseline(path: str, output: str):
    snap = build_snapshot(path)
    with open(output, "w") as f:
        json.dump(snap, f, indent=2)
    print(f"[+] Baseline written to {output} with {len(snap)} files")

def do_check(path: str, baseline_path: str):
    with open(baseline_path) as f:
        baseline = json.load(f)
    current = build_snapshot(path)

    added = sorted(set(current.keys()) - set(baseline.keys()))
    missing = sorted(set(baseline.keys()) - set(current.keys()))
    changed = sorted(
        rel for rel in baseline.keys() & current.keys()
        if baseline[rel] != current[rel]
    )

    if added:
        print("[+] Files added:")
        for rel in added:
            print(f"    {rel}")
        print()
    if changed:
        print("[+] Files changed:")
        for rel in changed:
            print(f"    {rel}")
        print()
    if missing:
        print("[+] Files missing:")
        for rel in missing:
            print(f"    {rel}")
        print()
    if not (added or missing or changed):
        print("[+] No changes detected compared to baseline.")

def main():
    parser = argparse.ArgumentParser(description="File Integrity Monitor by Dania")
    parser.add_argument("--mode", choices=["baseline", "check"], required=True, help="baseline or check")
    parser.add_argument("--path", required=True, help="Folder to monitor")
    parser.add_argument("--output", help="Output JSON path for baseline mode")
    parser.add_argument("--baseline", help="Baseline JSON path for check mode")
    args = parser.parse_args()

    if args.mode == "baseline":
        if not args.output:
            parser.error("--output is required in baseline mode")
        do_baseline(args.path, args.output)
    else:
        if not args.baseline:
            parser.error("--baseline is required in check mode")
        do_check(args.path, args.baseline)

if __name__ == "__main__":
    main()
