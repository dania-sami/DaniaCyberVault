# File Integrity Monitor (Hash Based)

This is a small file integrity monitor I built to practise thinking about tampering and change detection.

The idea is simple:

- In **baseline mode**, the script walks a directory and records SHA-256 hashes of all files into a JSON file.
- In **check mode**, it recomputes the hashes and compares them with the baseline.
- It then tells me which files are new, which changed and which disappeared.

## Usage

Create a baseline:

```bash
python file_integrity_monitor.py --mode baseline --path sample_folder --output baseline.json
```

Check against the baseline later:

```bash
python file_integrity_monitor.py --mode check --path sample_folder --baseline baseline.json
```

Example output (shortened):

```text
[+] Files added:
    logs/new.log

[+] Files changed:
    config/app.cfg

[+] Files missing:
    tmp/old.tmp
```

This is great for explaining how file integrity monitoring works in a simple way.
