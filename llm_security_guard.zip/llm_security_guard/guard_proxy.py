"""
LLM Security Guard – Dania's safety wrapper

A tiny HTTP reverse proxy that sits in front of an LLM style API

It inspects prompts and responses
blocks or warns on risky behaviour
and keeps a JSONL log of what happened
"""

import argparse
import json
import logging
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib import request, error
from datetime import datetime
from typing import List, Dict, Any, Tuple


LOG_PATH = "guard_log.jsonl"


def now_iso() -> str:
    return datetime.utcnow().isoformat() + "Z"


def prompt_checks(prompt: str) -> Tuple[str, List[str]]:
    """
    Run simple checks on the user prompt

    Returns a decision and a list of reasons

    decision is one of
    - allow
    - block
    """
    reasons: List[str] = []
    lower = prompt.lower()

    # classic prompt injection markers
    if "ignore previous instructions" in lower or "disregard the previous instructions" in lower:
        reasons.append("prompt_injection_pattern")

    if "system prompt" in lower or "system message" in lower:
        reasons.append("system_prompt_request")

    if "show me the policy" in lower or "reveal your guidelines" in lower:
        reasons.append("policy_leak_request")

    if "tool" in lower and "list" in lower and "access" in lower:
        reasons.append("tool_listing_request")

    if not reasons:
        return "allow", []

    # for now any match leads to a block
    return "block", reasons


def response_checks(response_text: str) -> Tuple[str, List[str]]:
    """
    Run simple checks on the model response

    Returns a decision and reasons

    decision is one of
    - ok
    - warn
    - block
    """
    reasons: List[str] = []
    lower = response_text.lower()

    # signs of leaking internal prompts or policies
    if "as a language model" in lower and "system prompt" in lower:
        reasons.append("system_prompt_leak")

    if "the following safety policies apply" in lower:
        reasons.append("policy_leak")

    # naive secret detection
    if "api key" in lower or "private key" in lower or "-----begin" in lower:
        reasons.append("possible_secret")

    # signs that the model agreed to ignore safety
    if "i will ignore all previous instructions" in lower or "now operating without restrictions" in lower:
        reasons.append("ignored_safety_notice")

    if not reasons:
        return "ok", []

    if any(r in {"possible_secret", "ignored_safety_notice"} for r in reasons):
        return "block", reasons

    return "warn", reasons


def log_event(event: Dict[str, Any]) -> None:
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(event, ensure_ascii=False) + "\n")


class GuardHandler(BaseHTTPRequestHandler):
    upstream_url: str = ""
    timeout_s: float = 20.0

    def _send_json(self, code: int, payload: Dict[str, Any]) -> None:
        body = json.dumps(payload).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self) -> None:
        if self.path.rstrip("/") != "/chat":
            self._send_json(404, {"error": "Unknown path"})
            return

        length = int(self.headers.get("Content-Length", "0") or "0")
        try:
            raw = self.rfile.read(length).decode("utf-8")
            data = json.loads(raw) if raw else {}
        except Exception:
            self._send_json(400, {"error": "Invalid JSON"})
            return

        prompt = str(data.get("input", ""))
        metadata = data.get("metadata", {})
        client_ip = self.client_address[0]

        prompt_decision, prompt_reasons = prompt_checks(prompt)

        event_base = {
            "timestamp": now_iso(),
            "client_ip": client_ip,
            "prompt": prompt[:200],
            "metadata": metadata,
        }

        if prompt_decision == "block":
            event = {
                **event_base,
                "action": "blocked_prompt",
                "reasons": prompt_reasons,
            }
            log_event(event)
            reply = {
                "output": "For safety reasons I am not going to send this request to the underlying model.",
                "guard_action": "blocked_prompt",
                "guard_reasons": prompt_reasons,
            }
            self._send_json(200, reply)
            return

        # Forward to upstream
        try:
            upstream_payload = json.dumps(data).encode("utf-8")
            req = request.Request(
                self.upstream_url,
                data=upstream_payload,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with request.urlopen(req, timeout=self.timeout_s) as resp:
                upstream_body = resp.read().decode("utf-8", errors="replace")
                status_code = resp.getcode()
        except error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace")
            event = {
                **event_base,
                "action": "http_error",
                "http_status": e.code,
                "error_body": body[:2000],
            }
            log_event(event)
            self._send_json(
                502,
                {
                    "error": "Upstream HTTP error",
                    "http_status": e.code,
                },
            )
            return
        except Exception as e:
            event = {
                **event_base,
                "action": "upstream_exception",
                "error": str(e),
            }
            log_event(event)
            self._send_json(
                502,
                {
                    "error": "Could not reach upstream model",
                },
            )
            return

        # Try to parse upstream response as JSON
        try:
            upstream_json = json.loads(upstream_body)
            model_text = str(
                upstream_json.get("output")
                or upstream_json.get("response")
                or upstream_json.get("answer")
                or upstream_body
            )
        except Exception:
            upstream_json = None
            model_text = upstream_body

        resp_decision, resp_reasons = response_checks(model_text)

        if resp_decision == "block":
            action = "blocked_response"
            out_text = "The upstream response looked unsafe so the guard blocked it."
        else:
            out_text = model_text
            action = "allowed" if resp_decision == "ok" else "allowed_with_warning"

        event = {
            **event_base,
            "action": action,
            "prompt_decision": prompt_decision,
            "prompt_reasons": prompt_reasons,
            "response_decision": resp_decision,
            "response_reasons": resp_reasons,
            "upstream_status": status_code,
            "response_snippet": model_text[:400],
        }
        log_event(event)

        reply = {
            "output": out_text,
            "guard_action": action,
            "guard_prompt_reasons": prompt_reasons,
            "guard_response_reasons": resp_reasons,
        }
        self._send_json(200, reply)


def run_server(upstream_url: str, listen_host: str, listen_port: int, timeout_s: float) -> None:
    GuardHandler.upstream_url = upstream_url
    GuardHandler.timeout_s = timeout_s

    server_address = (listen_host, listen_port)
    httpd = HTTPServer(server_address, GuardHandler)
    logging.info("LLM Security Guard listening on %s:%d", listen_host, listen_port)
    logging.info("Forwarding to upstream: %s", upstream_url)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        logging.info("Shutting down guard")
        httpd.server_close()


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's LLM Security Guard wrapper")
    parser.add_argument(
        "--upstream-url",
        required=True,
        help="The upstream LLM HTTP endpoint to forward allowed requests to.",
    )
    parser.add_argument(
        "--listen-host",
        default="127.0.0.1",
        help="Host interface to listen on (default: 127.0.0.1).",
    )
    parser.add_argument(
        "--listen-port",
        type=int,
        default=8081,
        help="Port to listen on (default: 8081).",
    )
    parser.add_argument(
        "--timeout",
        type=float,
        default=20.0,
        help="Timeout in seconds when talking to the upstream model (default: 20).",
    )
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="[%(asctime)s] %(message)s")
    run_server(args.upstream_url, args.listen_host, args.listen_port, args.timeout)


if __name__ == "__main__":
    main()
