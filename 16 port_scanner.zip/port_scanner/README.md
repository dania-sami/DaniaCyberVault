# Simple Network Port Scanner

I built this project to learn how basic network scanning works and to see which services are open on a host in a responsible way.

The tool scans a range of TCP ports on a target host and prints which ports are open, together with a small banner when available.

---

## What this tool does

- Takes a target host (IP or domain)
- Scans a configurable range of TCP ports
- Uses multiple worker threads for faster scanning
- Tries to grab a short service banner from open ports
- Prints a summary of open ports at the end

It is a small learning version of what more advanced scanners do, and is meant only for systems that you own or have permission to test.

---

## Project structure

```text
port_scanner/
  README.md
  requirements.txt
  scanner.py
```

---

## Installation

```bash
python3 -m venv venv
source venv/bin/activate          # Windows  venv\Scripts\activate
pip install -r requirements.txt
```

(The script only uses the Python standard library. The requirements file is there to keep the workflow similar to other projects.)

---

## Usage

Basic scan on common ports:

```bash
python scanner.py scan example.com
```

Custom port range and workers:

```bash
python scanner.py scan 192.168.0.10 --start 1 --end 2000 --workers 200
```

Example output:

```text
[info] Scanning host example.com ports 20-1024 with 100 workers
[open] 22/tcp   banner: SSH-2.0-OpenSSH_8.9p1
[open] 80/tcp   banner: HTTP/1.1 400 Bad Request
[open] 443/tcp  banner: (no banner)
[info] Scan finished. Open ports found: 3
```

---

## Responsible use

Please only scan:

- machines you own
- lab or test environments
- systems where you have clear permission

The goal is to understand how port scanning works, not to disturb or attack other systems.
