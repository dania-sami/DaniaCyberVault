import argparse
import socket
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from typing import List


DEFAULT_TIMEOUT = 1.0
DEFAULT_WORKERS = 100


@dataclass
class ScanResult:
    port: int
    is_open: bool
    banner: str = ""


def scan_port(host: str, port: int, timeout: float = DEFAULT_TIMEOUT) -> ScanResult:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(timeout)
    try:
        result = sock.connect_ex((host, port))
        if result == 0:
            banner = ""
            try:
                sock.sendall(b"\r\n")
                data = sock.recv(128)
                if data:
                    banner = data.decode(errors="ignore").strip()
            except Exception:
                banner = ""
            finally:
                sock.close()
            return ScanResult(port=port, is_open=True, banner=banner)
        else:
            return ScanResult(port=port, is_open=False)
    except Exception:
        return ScanResult(port=port, is_open=False)
    finally:
        try:
            sock.close()
        except Exception:
            pass


def scan_host(host: str, start_port: int, end_port: int, workers: int) -> List[ScanResult]:
    print(f"[info] Scanning host {host} ports {start_port}-{end_port} with {workers} workers")
    open_results: List[ScanResult] = []

    with ThreadPoolExecutor(max_workers=workers) as executor:
        future_to_port = {
            executor.submit(scan_port, host, port): port
            for port in range(start_port, end_port + 1)
        }
        for future in as_completed(future_to_port):
            res = future.result()
            if res.is_open:
                open_results.append(res)
                banner_info = f"banner: {res.banner}" if res.banner else "banner: (no banner)"
                print(f"[open] {res.port}/tcp  {banner_info}")

    print(f"[info] Scan finished. Open ports found: {len(open_results)}")
    return open_results


def main():
    parser = argparse.ArgumentParser(description="Simple TCP port scanner (learning tool)")
    subparsers = parser.add_subparsers(dest="command", required=True)

    scan_parser = subparsers.add_parser("scan", help="Scan a host for open TCP ports")
    scan_parser.add_argument("host", help="Target host (IP or domain)")
    scan_parser.add_argument("--start", type=int, default=20, help="Start port (default 20)")
    scan_parser.add_argument("--end", type=int, default=1024, help="End port (default 1024)")
    scan_parser.add_argument("--workers", type=int, default=DEFAULT_WORKERS, help="Number of worker threads")

    args = parser.parse_args()

    if args.command == "scan":
        if args.start < 1 or args.end > 65535 or args.start > args.end:
            raise SystemExit("Invalid port range")
        scan_host(args.host, args.start, args.end, args.workers)


if __name__ == "__main__":
    main()
