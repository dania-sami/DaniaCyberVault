# Risk Based Log Anomaly Studio – Dania

Hi

I am Dania and this studio is a light way for me to explore log anomalies by type and host

It learns a simple baseline of which event types are common and then highlights rare or new patterns with a small risk score

The output is a Markdown view that I can use as a starting point for deeper hunting
