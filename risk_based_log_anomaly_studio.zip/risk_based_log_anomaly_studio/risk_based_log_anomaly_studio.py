"""
Risk-Based Log Anomaly Studio – Dania

Reads JSONL logs of the form:

{"ts": "...", "host": "host1", "event_type": "process_start", "message": "..."}

Finds rare event types per host and global new event types.
"""

import argparse
import json
from dataclasses import dataclass, asdict
from typing import List, Dict
from collections import Counter


@dataclass
class LogEvent:
    ts: str
    host: str
    event_type: str
    message: str


@dataclass
class Anomaly:
    ts: str
    host: str
    event_type: str
    message: str
    reason: str
    score: int


def load_logs(path: str) -> List[LogEvent]:
    events: List[LogEvent] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            events.append(
                LogEvent(
                    ts=obj.get("ts", ""),
                    host=obj.get("host", "unknown"),
                    event_type=obj.get("event_type", "unknown"),
                    message=obj.get("message", ""),
                )
            )
    return events


def analyse(events: List[LogEvent]) -> List[Anomaly]:
    anomalies: List[Anomaly] = []

    global_counts = Counter(e.event_type for e in events)
    by_host: Dict[str, List[LogEvent]] = {}
    for e in events:
        by_host.setdefault(e.host, []).append(e)

    for host, evs in by_host.items():
        host_counts = Counter(e.event_type for e in evs)
        for e in evs:
            reason_parts = []
            score = 0
            # rare globally
            if global_counts[e.event_type] == 1:
                reason_parts.append("event_type_seen_once_globally")
                score += 3
            elif global_counts[e.event_type] <= 3:
                reason_parts.append("event_type_rare_globally")
                score += 2

            # rare for host
            if host_counts[e.event_type] == 1:
                reason_parts.append("event_type_rare_for_host")
                score += 2

            # crude message heuristic
            low = e.message.lower()
            if any(w in low for w in ["failed", "denied", "error", "suspicious"]):
                reason_parts.append("error_like_message")
                score += 1

            if score > 0:
                anomalies.append(
                    Anomaly(
                        ts=e.ts,
                        host=e.host,
                        event_type=e.event_type,
                        message=e.message,
                        reason=", ".join(reason_parts),
                        score=score,
                    )
                )

    anomalies.sort(key=lambda a: a.score, reverse=True)
    return anomalies


def write_outputs(anomalies: List[Anomaly], md_path: str, json_path: str) -> None:
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump([asdict(a) for a in anomalies], f, indent=2)

    with open(md_path, "w", encoding="utf-8") as f:
        f.write("# Risk based log anomaly studio report\n\n")
        f.write(f"* Total anomalies: {len(anomalies)}\n\n")
        for a in anomalies:
            f.write(f"- {a.ts}  {a.host}  [{a.event_type}] score={a.score}  reasons={a.reason}\n")
            f.write(f"  message: {a.message}\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's risk based log anomaly studio")
    parser.add_argument("--logs", default="example_logs.jsonl", help="Logs in JSONL format")
    parser.add_argument("--out-prefix", default="log_anomaly", help="Output prefix")
    args = parser.parse_args()

    events = load_logs(args.logs)
    anomalies = analyse(events)
    md_path = f"{args.out_prefix}_report.md"
    json_path = f"{args.out_prefix}_anomalies.json"
    write_outputs(anomalies, md_path, json_path)
    print(f"Analysed {len(events)} events  anomalies={len(anomalies)}")
    print(f"Wrote report to {md_path}")


if __name__ == "__main__":
    main()
