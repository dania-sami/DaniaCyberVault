import argparse
import csv

def compare_versions(current: str, latest: str) -> bool:
    c_parts = [int(p) for p in current.split(".") if p.isdigit()]
    l_parts = [int(p) for p in latest.split(".") if p.isdigit()]
    length = max(len(c_parts), len(l_parts))
    c_parts += [0] * (length - len(c_parts))
    l_parts += [0] * (length - len(l_parts))
    return c_parts >= l_parts

def check_patches(path: str):
    print(f"[+] Patch status for {path}\n")
    with open(path, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            system = row.get("system", "")
            software = row.get("software", "")
            version = row.get("version", "0")
            latest = row.get("latest_version", "0")
            up_to_date = compare_versions(version, latest)
            if not up_to_date:
                print(f"    {system} - {software}: current={version}, latest={latest} (update recommended)")

def main():
    parser = argparse.ArgumentParser(description="Patch Level Tracker by Dania")
    parser.add_argument("--csv", required=True, help="CSV with system,software,version,latest_version")
    args = parser.parse_args()
    check_patches(args.csv)

if __name__ == "__main__":
    main()
