# Patch Level Tracker

This is a small script I use to keep a simple view of patch levels across systems.

It reads a CSV file with:

- `system`
- `software`
- `version`
- `latest_version`

The script compares `version` to `latest_version` and flags systems that are behind.

## Files

- `patch_tracker.py` – main script
- `demo_patches.csv` – example data

## Usage

```bash
python patch_tracker.py --csv demo_patches.csv
```
