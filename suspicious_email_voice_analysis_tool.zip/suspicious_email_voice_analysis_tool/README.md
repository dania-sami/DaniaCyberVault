# Suspicious Email Voice Analysis Tool – Dania

Hi

I am Dania and this tool focuses on the emotional tone of phishing style emails

It scores each email for urgency fear pressure and reward language and then marks which ones feel manipulative

This is not a classifier  it is more like a coach that helps me explain why an email feels off to a non technical person
