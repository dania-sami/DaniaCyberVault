"""
Suspicious Email Voice Analysis Tool – Dania

Analyses plain text emails for emotionally manipulative language patterns.
"""

import argparse
import json
from dataclasses import dataclass, asdict
from typing import List


URGENCY_WORDS = [
    "immediately",
    "urgent",
    "asap",
    "right now",
    "today",
    "last chance",
    "act now",
]

FEAR_WORDS = [
    "suspend",
    "closed",
    "locked",
    "lose access",
    "penalty",
    "violation",
    "breach",
]

REWARD_WORDS = [
    "win",
    "reward",
    "prize",
    "bonus",
    "gift",
    "jackpot",
]

PRESSURE_WORDS = [
    "do not tell",
    "confidential",
    "only you",
    "secret",
    "must obey",
    "immediately respond",
]


@dataclass
class Email:
    id: str
    subject: str
    body: str


@dataclass
class EmailVoiceScore:
    id: str
    subject: str
    urgency_score: int
    fear_score: int
    reward_score: int
    pressure_score: int
    total_score: int
    flags: List[str]


def load_emails(path: str) -> List[Email]:
    emails: List[Email] = []
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    for obj in data:
        emails.append(
            Email(
                id=str(obj.get("id", "")),
                subject=obj.get("subject", ""),
                body=obj.get("body", ""),
            )
        )
    return emails


def score_email(email: Email) -> EmailVoiceScore:
    text = (email.subject + " " + email.body).lower()

    def count_hits(words):
        c = 0
        for w in words:
            if w in text:
                c += 1
        return c

    urgency = count_hits(URGENCY_WORDS)
    fear = count_hits(FEAR_WORDS)
    reward = count_hits(REWARD_WORDS)
    pressure = count_hits(PRESSURE_WORDS)

    total = urgency + fear + reward + pressure
    flags: List[str] = []
    if urgency:
        flags.append("urgency_language")
    if fear:
        flags.append("fear_or_threats")
    if reward:
        flags.append("unusual_rewards")
    if pressure:
        flags.append("secrecy_or_pressure")

    return EmailVoiceScore(
        id=email.id,
        subject=email.subject,
        urgency_score=urgency,
        fear_score=fear,
        reward_score=reward,
        pressure_score=pressure,
        total_score=total,
        flags=flags,
    )


def analyse_emails(emails: List[Email]) -> List[EmailVoiceScore]:
    scores = [score_email(e) for e in emails]
    scores.sort(key=lambda s: s.total_score, reverse=True)
    return scores


def write_outputs(scores: List[EmailVoiceScore], md_path: str, json_path: str) -> None:
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump([asdict(s) for s in scores], f, indent=2)

    with open(md_path, "w", encoding="utf-8") as f:
        f.write("# Suspicious email voice analysis report\n\n")
        f.write(f"* Analysed emails: {len(scores)}\n\n")
        for s in scores:
            f.write(f"## {s.id} – {s.subject}\n\n")
            f.write(f"* Total score: {s.total_score}\n")
            f.write(f"* Urgency: {s.urgency_score}  Fear: {s.fear_score}  Reward: {s.reward_score}  Pressure: {s.pressure_score}\n")
            if s.flags:
                f.write(f"* Flags: {', '.join(s.flags)}\n")
            f.write("\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's suspicious email voice analysis tool")
    parser.add_argument("--emails", default="example_emails.json", help="Emails JSON list")
    parser.add_argument("--out-prefix", default="email_voice", help="Output prefix")
    args = parser.parse_args()

    emails = load_emails(args.emails)
    scores = analyse_emails(emails)
    md_path = f"{args.out_prefix}_report.md"
    json_path = f"{args.out_prefix}_scores.json"
    write_outputs(scores, md_path, json_path)
    print(f"Analysed {len(emails)} emails and wrote report to {md_path}")


if __name__ == "__main__":
    main()
