import argparse
import socket
import threading
import queue
from datetime import datetime

def guess_service(port: int) -> str:
    common = {
        20: "ftp-data",
        21: "ftp",
        22: "ssh",
        23: "telnet",
        25: "smtp",
        53: "dns",
        80: "http",
        110: "pop3",
        143: "imap",
        443: "https",
        3389: "rdp",
    }
    return common.get(port, "")

def scan_port(target: str, port: int, timeout: float = 0.5) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(timeout)
        try:
            result = sock.connect_ex((target, port))
            return result == 0
        except OSError:
            return False

def worker(target: str, q: "queue.Queue[int]", results: list):
    while True:
        try:
            port = q.get_nowait()
        except queue.Empty:
            return
        if scan_port(target, port):
            service = guess_service(port)
            if service:
                results.append((port, service))
            else:
                results.append((port, ""))
        q.task_done()

def main():
    parser = argparse.ArgumentParser(description="Advanced TCP Port Scanner by Dania")
    parser.add_argument("--target", required=True, help="Target IP or hostname")
    parser.add_argument("--start-port", type=int, default=1, help="Start of port range (default 1)")
    parser.add_argument("--end-port", type=int, default=1024, help="End of port range (default 1024)")
    parser.add_argument("--threads", type=int, default=100, help="Number of worker threads (default 100)")
    args = parser.parse_args()

    target = args.target
    start_port = max(1, args.start_port)
    end_port = min(65535, args.end_port)
    num_threads = max(1, args.threads)

    print(f"[+] Starting scan on {target}")
    print(f"[+] Port range: {start_port}-{end_port}")
    print(f"[+] Threads: {num_threads}")
    print(f"[+] Started at {datetime.now()}\n")

    # Resolve target
    try:
        target_ip = socket.gethostbyname(target)
        print(f"[+] Resolved {target} to {target_ip}\n")
    except socket.gaierror:
        print("[-] Could not resolve target host")
        return

    q: "queue.Queue[int]" = queue.Queue()
    for port in range(start_port, end_port + 1):
        q.put(port)

    results = []
    threads = []

    for _ in range(num_threads):
        t = threading.Thread(target=worker, args=(target_ip, q, results))
        t.daemon = True
        t.start()
        threads.append(t)

    q.join()

    # Wait for all threads to finish cleanly
    for t in threads:
        t.join(timeout=0.1)

    results.sort(key=lambda x: x[0])

    if results:
        print("\n[+] Open ports:")
        for port, service in results:
            if service:
                print(f"    {port:5d}  open  ({service})")
            else:
                print(f"    {port:5d}  open")
    else:
        print("\n[+] No open ports found in this range.")

    print(f"\n[+] Finished at {datetime.now()}")

if __name__ == "__main__":
    main()
