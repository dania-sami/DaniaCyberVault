# Advanced TCP Port Scanner

Hi, I am Dania and this is a small but powerful network security project I built to practice real scanning logic in Python.

This tool lets me scan a target and quickly see which TCP ports are open. It supports custom port ranges and uses threads to make the scan fast but still easy to understand.

## Features

- Simple command line usage
- Custom port range (default 1 to 1024)
- Multi threaded scanning for speed
- Basic service guess using common port numbers
- Clean, readable code that is easy to extend

## How I use it

I use this scanner on my own machines and test environments to:
- See what services are exposed
- Double check that only the ports I expect are open
- Practice thinking like both an attacker and a defender

## Usage

```bash
python scanner.py --target 192.168.1.10 --start-port 1 --end-port 1024 --threads 200
```

### Arguments

- `--target`      IP or hostname to scan (required)
- `--start-port`  Start of port range (default 1)
- `--end-port`    End of port range (default 1024)
- `--threads`     Number of worker threads (default 100)

Example:

```bash
python scanner.py --target scanme.nmap.org --start-port 1 --end-port 1024
```

## Important note

This project is for learning and defensive security. I only scan systems that I own or where I have clear permission.
