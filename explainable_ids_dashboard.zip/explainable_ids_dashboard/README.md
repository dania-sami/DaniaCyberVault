# Explainable Intrusion Detection Dashboard

Hi, I am Dania 👋

This project is a tiny **explainable IDS lab**:

- I train a Random Forest on synthetic network/host features.
- I expose a small Flask app to inspect predictions.
- For each example, I show the **top contributing features** using feature importances.

It is a simple but powerful way to talk about **explainable detection**.

## How to run

```bash
cd explainable_ids_dashboard

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt

# Train the IDS model
python -m src.train

# Start the dashboard
python -m src.app
```

Then open `http://127.0.0.1:5000` in your browser and explore samples.
