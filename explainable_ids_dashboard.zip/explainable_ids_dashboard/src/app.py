from __future__ import annotations

from pathlib import Path

import joblib
import pandas as pd
from flask import Flask, render_template_string, request

BASE_DIR = Path(__file__).resolve().parent.parent
MODELS_DIR = BASE_DIR / "models"

bundle = joblib.load(MODELS_DIR / "ids_model.joblib")
model = bundle["model"]
feature_names = bundle["feature_names"]
X_test: pd.DataFrame = bundle["X_test"]
y_test: pd.Series = bundle["y_test"]

app = Flask(__name__)

TEMPLATE = """<!doctype html>
<html>
  <head>
    <title>Explainable IDS Dashboard</title>
    <style>
      body { font-family: system-ui, sans-serif; margin: 20px; }
      table { border-collapse: collapse; }
      th, td { padding: 6px 10px; border: 1px solid #ddd; }
      .badge { padding: 2px 6px; border-radius: 4px; color: white; font-size: 0.8rem; }
      .ok { background-color: #2e7d32; }
      .alert { background-color: #c62828; }
    </style>
  </head>
  <body>
    <h1>Explainable Intrusion Detection (Demo)</h1>
    <p>Sample index: {{ idx }} / {{ total-1 }}</p>

    <form method="get">
      <label>Sample index:
        <input type="number" name="idx" min="0" max="{{ total-1 }}" value="{{ idx }}">
      </label>
      <button type="submit">Inspect</button>
    </form>

    <h2>Features</h2>
    <table>
      <tr><th>Feature</th><th>Value</th></tr>
      {% for name, val in features.items() %}
      <tr><td>{{ name }}</td><td>{{ "%.2f"|format(val) }}</td></tr>
      {% endfor %}
    </table>

    <h2>Prediction</h2>
    <p>
      True label:
      {% if true_label == 1 %}
        <span class="badge alert">attack</span>
      {% else %}
        <span class="badge ok">normal</span>
      {% endif %}
      &nbsp;&nbsp;
      Predicted:
      {% if pred_label == 1 %}
        <span class="badge alert">attack</span>
      {% else %}
        <span class="badge ok">normal</span>
      {% endif %}
    </p>

    <h2>Top contributing features (by importance)</h2>
    <table>
      <tr><th>Feature</th><th>Importance</th></tr>
      {% for name, imp in top_feats %}
      <tr><td>{{ name }}</td><td>{{ "%.3f"|format(imp) }}</td></tr>
      {% endfor %}
    </table>

    <p style="margin-top: 20px; font-size: 0.9rem; color: #555;">
      This is a simplified demo using Random Forest feature importances,
      not a full SHAP/LIME implementation, but it illustrates how I think
      about explainable detection.
    </p>
  </body>
</html>
"""


@app.route("/")
def index():
    try:
        idx = int(request.args.get("idx", "0"))
    except ValueError:
        idx = 0
    idx = max(0, min(idx, len(X_test) - 1))

    row = X_test.iloc[idx]
    true_label = int(y_test.iloc[idx])
    pred_label = int(model.predict([row.values])[0])

    importances = model.feature_importances_
    pairs = list(zip(feature_names, importances))
    pairs.sort(key=lambda x: x[1], reverse=True)
    top_feats = pairs[:5]

    return render_template_string(
        TEMPLATE,
        idx=idx,
        total=len(X_test),
        features=row.to_dict(),
        true_label=true_label,
        pred_label=pred_label,
        top_feats=top_feats,
    )


def main() -> None:
    app.run(debug=True)


if __name__ == "__main__":
    main()
