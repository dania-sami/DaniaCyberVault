from __future__ import annotations

from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
MODELS_DIR = BASE_DIR / "models"

for d in (DATA_DIR, MODELS_DIR):
    d.mkdir(parents=True, exist_ok=True)


def generate_synthetic_ids_data(n: int = 400) -> pd.DataFrame:
    rng = np.random.RandomState(42)
    src_bytes = rng.exponential(scale=300, size=n)
    dst_bytes = rng.exponential(scale=500, size=n)
    failed_logins = rng.poisson(lam=0.5, size=n)
    is_scan = rng.binomial(1, p=0.1, size=n)
    dst_port = rng.choice([22, 80, 443, 3389, 53], size=n, p=[0.2, 0.4, 0.2, 0.1, 0.1])

    y = (
        (failed_logins >= 3)
        | ((is_scan == 1) & (dst_port == 22))
        | ((src_bytes > 600) & (dst_bytes < 50))
    ).astype(int)

    df = pd.DataFrame(
        {
            "src_bytes": src_bytes,
            "dst_bytes": dst_bytes,
            "failed_logins": failed_logins,
            "is_scan": is_scan,
            "dst_port": dst_port,
            "label": y,
        }
    )
    return df


def main() -> None:
    data_path = DATA_DIR / "ids_data.csv"
    if not data_path.exists():
        df = generate_synthetic_ids_data()
        df.to_csv(data_path, index=False)
    else:
        df = pd.read_csv(data_path)

    X = df.drop(columns=["label"])
    y = df["label"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, random_state=42, stratify=y
    )

    clf = RandomForestClassifier(
        n_estimators=100, random_state=42, max_depth=5
    )
    clf.fit(X_train, y_train)

    y_pred = clf.predict(X_test)
    print("Validation report:")
    print(classification_report(y_test, y_pred))

    bundle = {
        "model": clf,
        "feature_names": list(X.columns),
        "X_test": X_test.reset_index(drop=True),
        "y_test": y_test.reset_index(drop=True),
    }
    joblib.dump(bundle, MODELS_DIR / "ids_model.joblib")
    print(f"Saved model bundle to {MODELS_DIR/'ids_model.joblib'}")


if __name__ == "__main__":
    main()
