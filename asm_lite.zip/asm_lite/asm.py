
import argparse
import socket
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Dict, List, Tuple

import requests
from bs4 import BeautifulSoup  # type: ignore

WORDLIST_DEFAULT = "wordlist.txt"
COMMON_PORTS = [22, 80, 443, 8080, 8443]
TIMEOUT = 3.0


def resolve_host(host: str) -> str | None:
    try:
        return socket.gethostbyname(host)
    except Exception:
        return None


def scan_port(host: str, port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(TIMEOUT)
        result = s.connect_ex((host, port))
        return result == 0


def http_probe(scheme: str, host: str) -> Dict:
    url = f"{scheme}://{host}"
    info = {
        "url": url,
        "status": None,
        "title": "",
        "headers": {},
        "issues": [],
    }
    try:
        resp = requests.get(url, timeout=TIMEOUT, verify=False)  # nosec - learning lab
        info["status"] = resp.status_code
        info["headers"] = {k.lower(): v for k, v in resp.headers.items()}
        soup = BeautifulSoup(resp.text, "html.parser")
        title = soup.title.string.strip() if soup.title and soup.title.string else ""
        info["title"] = title
        # simple checks
        h = info["headers"]
        if "content-security-policy" not in h:
            info["issues"].append("Missing Content-Security-Policy")
        if scheme == "https" and "strict-transport-security" not in h:
            info["issues"].append("Missing Strict-Transport-Security")
        if "x-frame-options" not in h:
            info["issues"].append("Missing X-Frame-Options")
        if "login" in url or "admin" in url:
            if resp.status_code != 200:
                info["issues"].append(f"Login/admin endpoint returned non-200 status ({resp.status_code})")
    except Exception as e:
        info["issues"].append(f"HTTP request failed: {e.__class__.__name__}")
    return info


def build_report(domain: str, hosts_data: Dict[str, Dict], template: str, out_path: Path) -> None:
    summary_rows_html = []
    host_sections_html = []

    for host, data in hosts_data.items():
        open_ports = data.get("open_ports", [])
        http_info = data.get("http", [])
        findings = data.get("findings", [])

        ports_badges = " ".join(f'<span class="badge-port">{p}</span>' for p in open_ports) or "–"
        http_count = len(http_info)
        findings_tags = []
        for f in findings:
            cls = "tag-warn" if "Missing" in f or "HTTP only" in f else "tag-info"
            findings_tags.append(f'<span class="tag {cls}">{f}</span>')
        findings_html = " ".join(findings_tags) or "<span class='tag tag-good'>No obvious issues</span>"

        summary_rows_html.append(
            f"<tr><td>{host}</td><td>{ports_badges}</td><td>{http_count}</td><td>{findings_html}</td></tr>"
        )

        # Host section
        section_parts = [f'<div class="host-block"><h3>{host}</h3>']
        section_parts.append("<table><tr><th>URL</th><th>Status</th><th>Title</th><th>Issues</th></tr>")
        for h in http_info:
            issues_tags = []
            for issue in h.get("issues", []):
                cls = "tag-warn" if "Missing" in issue or "failed" in issue else "tag-info"
                issues_tags.append(f'<span class="tag {cls}">{issue}</span>')
            issues_html = " ".join(issues_tags) or "<span class='tag tag-good'>No obvious issues</span>"
            section_parts.append(
                f"<tr><td>{h['url']}</td><td>{h['status']}</td><td>{h['title']}</td><td>{issues_html}</td></tr>"
            )
        section_parts.append("</table></div>")
        host_sections_html.append("\n".join(section_parts))

    html = template.replace("{{domain}}", domain)
    html = html.replace("{{summary_rows}}", "\n".join(summary_rows_html))
    html = html.replace("{{host_sections}}", "\n".join(host_sections_html))

    out_path.write_text(html, encoding="utf-8")
    print(f"[info] Report written to {out_path}")


def main():
    parser = argparse.ArgumentParser(description="Attack Surface Mapping Tool (ASM Lite)")
    parser.add_argument("domain", help="Root domain to scan (e.g. example.com)")
    parser.add_argument("--wordlist", default=WORDLIST_DEFAULT, help="Subdomain wordlist file")
    parser.add_argument(
        "--output",
        default=None,
        help="Path to HTML report (default reports/<domain>_report.html)",
    )
    args = parser.parse_args()

    domain = args.domain.strip()
    wordlist_path = Path(args.wordlist)
    if not wordlist_path.is_file():
        raise SystemExit(f"Wordlist file not found: {wordlist_path}")

    words = [w.strip() for w in wordlist_path.read_text(encoding="utf-8").splitlines() if w.strip()]
    candidates = sorted({domain} | {f"{w}.{domain}" for w in words})

    print(f"[info] Resolving hosts for domain={domain} (candidates={len(candidates)})")

    hosts_resolved: Dict[str, str] = {}
    for host in candidates:
        ip = resolve_host(host)
        if ip:
            hosts_resolved[host] = ip

    if not hosts_resolved:
        print("[warn] No hosts resolved. Exiting.")
        return

    print(f"[info] Resolved {len(hosts_resolved)} hosts:")

    for h, ip in hosts_resolved.items():
        print(f"  {h} -> {ip}")

    hosts_data: Dict[str, Dict] = {h: {"ip": ip, "open_ports": [], "http": [], "findings": []} for h, ip in hosts_resolved.items()}

    # Port scan
    print("[info] Scanning ports...")
    with ThreadPoolExecutor(max_workers=20) as executor:
        futures = {}
        for host in hosts_resolved.keys():
            for port in COMMON_PORTS:
                futures[executor.submit(scan_port, host, port)] = (host, port)
        for fut in as_completed(futures):
            host, port = futures[fut]
            try:
                is_open = fut.result()
            except Exception:
                is_open = False
            if is_open:
                hosts_data[host]["open_ports"].append(port)
                print(f"[open] {host}:{port}")

    # HTTP probing
    print("[info] Probing HTTP/S on discovered hosts...")
    for host, data in hosts_data.items():
        ports = data["open_ports"]
        http_ports = [p for p in ports if p in (80, 443, 8080, 8443)]
        http_infos = []
        for port in http_ports:
            if port in (80, 8080):
                scheme = "http"
            else:
                scheme = "https"
            target_host = host if port in (80, 443) else f"{host}:{port}"
            info = http_probe(scheme, target_host)
            http_infos.append(info)
        data["http"] = http_infos

        # simple findings
        if 80 in ports and 443 not in ports:
            data["findings"].append("HTTP only, no HTTPS on this host")
        for h in http_infos:
            for issue in h.get("issues", []):
                if issue not in data["findings"]:
                    data["findings"].append(issue)

    template_path = Path("report_template.html")
    if not template_path.is_file():
        raise SystemExit(f"Report template not found: {template_path}")

    template = template_path.read_text(encoding="utf-8")
    reports_dir = Path("reports")
    reports_dir.mkdir(exist_ok=True)
    out_path = Path(args.output) if args.output else reports_dir / f"{domain}_report.html"
    build_report(domain, hosts_data, template, out_path)


if __name__ == "__main__":
    main()
