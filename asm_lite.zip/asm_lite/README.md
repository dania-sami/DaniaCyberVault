
# Attack Surface Mapping Tool (ASM Lite)

Hi, I am Dania and I built this project to get closer to how real attack surface management tools work on the internet.

Instead of just running a port scan, I wanted one small tool that can:

- discover subdomains for a given root domain
- scan common ports on those hosts
- grab basic HTTP information (title, status, security headers)
- run a few simple misconfiguration checks
- generate an HTML report I can open in a browser

It is a compact, student-friendly version of an ASM engine.

---

## What this project does

Given a root domain like `example.com`, the tool:

1. Tries a wordlist of common subdomains (e.g. `www`, `api`, `dev`, `test`, `admin` etc.).  
2. For each discovered host, it:
   - scans a small set of common ports (22, 80, 443, 8080, 8443)
   - for HTTP/S ports, performs a GET request
   - captures:
     - HTTP status code
     - page title
     - key security headers (CSP, HSTS, X-Frame-Options, etc.)

3. Runs misconfiguration checks, for example:
   - HTTP service without HTTPS
   - missing security headers
   - non-200 responses on login or admin paths

4. Generates a self-contained HTML report in `reports/` that includes:
   - a summary table of hosts and open ports
   - details of HTTP endpoints and their findings
   - a small list of “findings” per host

For real offensive work you would use more advanced tools, but this project shows that I understand the basic workflow of attack surface discovery and analysis.

---

## Project structure

```text
asm_lite/
  README.md
  requirements.txt
  asm.py              # main CLI
  wordlist.txt        # common subdomains
  report_template.html
  reports/
```

---

## Installation

```bash
python3 -m venv venv
source venv/bin/activate           # Windows  venv\Scripts\activate
pip install -r requirements.txt
```

---

## Usage

Run a scan against a domain you are allowed to test.

```bash
python asm.py example.com
```

This will:

- try the built-in subdomains for `example.com`
- scan ports on each resolved host
- attempt HTTP requests to `http://host` and `https://host` where relevant
- generate an HTML report at:

- `reports/example.com_report.html`

You can also change the wordlist or output file:

```bash
python asm.py example.com --wordlist wordlist.txt --output reports/custom_report.html
```

---

## Example findings (conceptually)

The report may include entries like:

- `api.example.com:443` — HTTPS with HSTS and CSP present (good)  
- `dev.example.com:80` — HTTP only, no security headers, potential target for testing or staging  
- `admin.example.com:80` — HTTP login page without HTTPS (high risk in real life)  

Each HTTP endpoint is annotated with:

- status code
- title
- presence/absence of common security headers

---

## Misconfiguration checks implemented

Right now the tool includes the following simple checks:

- HTTP service on port 80 with no matching 443 service for the same host
- Missing `Content-Security-Policy`
- Missing `Strict-Transport-Security`
- Missing `X-Frame-Options`
- Login-like paths (URL containing `login` or `admin`) that do not return 200 OK

All checks are intentionally simple but reflect real world security hygiene.

---

## How I see this project

For me this project is a way to show that I:

- understand the steps of attack surface mapping
- can combine DNS-style discovery, port scanning and HTTP inspection
- and can turn raw results into a readable HTML report

It is small enough to run from the command line, but expressive enough to talk about in detail during interviews or applications.
