# Zero Trust AI API Gateway – Dania

Hi

I am Dania and this mini gateway is my zero trust front door for AI style APIs

It runs a small HTTP server that expects a client id and token and then applies

* identity bound auth
* simple per client rate limiting
* basic prompt content checks

If a request passes the checks it hits a tiny echo style backend
The point is to show how I think about protecting AI endpoints  not to be a full production gateway
