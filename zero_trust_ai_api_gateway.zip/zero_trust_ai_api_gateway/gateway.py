"""
Zero Trust AI API Gateway – Dania

Small educational HTTP gateway that:

* checks client id and token
* enforces per client rate limiting
* applies basic prompt content checks
* forwards allowed requests to a dummy backend

This is for local demos and learning  not production traffic.
"""

import argparse
import json
import time
from http.server import HTTPServer, BaseHTTPRequestHandler
from typing import Dict, Any, List, Tuple


class Policy:
    def __init__(self, data: Dict[str, Any]) -> None:
        self.allowed_tokens: Dict[str, str] = data.get("allowed_tokens", {})
        self.rate_limit_per_window: int = int(data.get("rate_limit_per_window", 10))
        self.window_seconds: int = int(data.get("window_seconds", 60))
        self.max_prompt_length: int = int(data.get("max_prompt_length", 2000))
        self.forbidden_patterns: List[str] = [p.lower() for p in data.get("forbidden_patterns", [])]


def load_policy(path: str) -> Policy:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return Policy(data)


class GatewayState:
    def __init__(self) -> None:
        # client_id -> list of timestamps
        self.request_times: Dict[str, List[float]] = {}

    def record_and_check_rate(self, client_id: str, rate: int, window: int) -> Tuple[bool, int]:
        now = time.time()
        times = self.request_times.get(client_id, [])
        # drop old timestamps
        times = [t for t in times if now - t <= window]
        allowed = len(times) < rate
        if allowed:
            times.append(now)
        self.request_times[client_id] = times
        return allowed, len(times)


def dummy_backend(prompt: str) -> Dict[str, Any]:
    # In a real setup this would call an AI model.
    # Here we just echo part of the prompt.
    snippet = prompt[:120]
    return {
        "reply": f"echo: {snippet}",
        "length": len(prompt),
    }


class GatewayHandler(BaseHTTPRequestHandler):
    policy: Policy = None  # type: ignore
    state: GatewayState = None  # type: ignore

    def _send_json(self, code: int, payload: Dict[str, Any]) -> None:
        body = json.dumps(payload).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self) -> None:
        if self.path != "/v1/chat":
            self._send_json(404, {"error": "not_found"})
            return

        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length)
        try:
            data = json.loads(raw.decode("utf-8"))
        except Exception:
            self._send_json(400, {"error": "invalid_json"})
            return

        client_id = str(data.get("client_id", ""))
        token = str(data.get("token", ""))
        prompt = str(data.get("prompt", ""))

        # Identity and token check
        expected_client = self.policy.allowed_tokens.get(token)
        if expected_client is None or expected_client != client_id:
            self._send_json(401, {"error": "unauthorized"})
            return

        # Rate limit
        allowed, count = self.state.record_and_check_rate(
            client_id,
            self.policy.rate_limit_per_window,
            self.policy.window_seconds,
        )
        if not allowed:
            self._send_json(429, {"error": "rate_limited", "details": f"too many requests for {client_id}"})
            return

        # Prompt length check
        if len(prompt) > self.policy.max_prompt_length:
            self._send_json(400, {"error": "prompt_too_long"})
            return

        # Simple forbidden pattern check
        lower_prompt = prompt.lower()
        for pat in self.policy.forbidden_patterns:
            if pat in lower_prompt:
                self._send_json(400, {"error": "forbidden_content", "pattern": pat})
                return

        # All checks passed  call backend
        backend_resp = dummy_backend(prompt)
        self._send_json(200, {"ok": True, "data": backend_resp})

    # Silence default logging a bit
    def log_message(self, fmt: str, *args: Any) -> None:
        # You can uncomment next line to see logs
        # super().log_message(fmt, *args)
        pass


def run_server(host: str, port: int, policy_path: str) -> None:
    policy = load_policy(policy_path)
    state = GatewayState()
    handler_class = GatewayHandler
    handler_class.policy = policy
    handler_class.state = state

    server = HTTPServer((host, port), handler_class)
    print(f"Zero trust AI API gateway listening on http://{host}:{port}")
    print("POST /v1/chat with JSON: {\"client_id\": \"alice\", \"token\": \"token_alice\", \"prompt\": \"hello\"}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down gateway...")
        server.server_close()


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's zero trust AI API gateway")
    parser.add_argument("--host", default="127.0.0.1", help="Bind host")
    parser.add_argument("--port", type=int, default=8000, help="Bind port")
    parser.add_argument("--policy", default="policy_example.json", help="Policy JSON file")
    args = parser.parse_args()

    run_server(args.host, args.port, args.policy)


if __name__ == "__main__":
    main()
