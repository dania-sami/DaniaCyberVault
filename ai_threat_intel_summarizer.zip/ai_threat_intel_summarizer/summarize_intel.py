
from pathlib import Path
from typing import List

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans

DATA_DIR = Path("data")


SEVERITY_BASE = {
    "Low": 10,
    "Medium": 30,
    "High": 60,
    "Critical": 80,
}


def compute_risk_score(row, cluster_severity_mean: float) -> float:
    base = SEVERITY_BASE.get(str(row["severity"]), 20)
    boost = 0
    if row["type"] in ("cve", "malware"):
        boost += 10
    boost += min(cluster_severity_mean, 20)
    score = base + boost
    return float(max(0, min(100, score)))


def main():
    path = DATA_DIR / "intel_feed.csv"
    if not path.is_file():
        raise SystemExit(f"Intel file not found. Run generate_intel.py first ({path}).")

    df = pd.read_csv(path)
    if df.empty:
        raise SystemExit("Intel file is empty.")

    text_series = (df["title"].fillna("") + " " + df["description"].fillna("")).astype(str)

    vectorizer = TfidfVectorizer(stop_words="english", max_features=2000)
    X = vectorizer.fit_transform(text_series)

    n_clusters = min(6, max(2, len(df) // 30))
    model = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    clusters = model.fit_predict(X)

    df["cluster"] = clusters

    # compute severity mean per cluster
    sev_numeric = df["severity"].map(SEVERITY_BASE).fillna(20)
    df["_sev_numeric"] = sev_numeric
    cluster_stats = df.groupby("cluster")["_sev_numeric"].mean().to_dict()

    risk_scores: List[float] = []
    for idx, row in df.iterrows():
        cluster_mean = cluster_stats.get(row["cluster"], 20.0)
        risk_scores.append(compute_risk_score(row, cluster_mean))
    df["risk_score"] = risk_scores
    df.drop(columns=["_sev_numeric"], inplace=True)

    out_csv = DATA_DIR / "intel_enriched.csv"
    df.to_csv(out_csv, index=False)
    print(f"[info] Enriched intel written to {out_csv}")

    # build cluster summaries
    terms = np.array(vectorizer.get_feature_names_out())
    summary_lines = []
    summary_lines.append("# Cluster summaries\n")
    for cl in sorted(df["cluster"].unique()):
        subset = df[df["cluster"] == cl]
        if subset.empty:
            continue
        # top keywords
        mask = subset.index.values
        X_cl = X[mask]
        centroid = X_cl.mean(axis=0)
        centroid = np.asarray(centroid).ravel()
        top_idx = centroid.argsort()[::-1][:8]
        top_terms = [terms[i] for i in top_idx if centroid[i] > 0]

        avg_score = subset["risk_score"].mean()
        max_sev = subset["severity"].value_counts().idxmax()
        summary_lines.append(f"## Cluster {cl}")
        summary_lines.append(f"- items: {len(subset)}")
        summary_lines.append(f"- most common severity: {max_sev}")
        summary_lines.append(f"- mean risk score: {avg_score:.1f}")
        if top_terms:
            summary_lines.append(f"- top keywords: {', '.join(top_terms)}")
        # include 2 example titles
        examples = subset.sort_values("risk_score", ascending=False).head(2)["title"].tolist()
        for i, t in enumerate(examples, start=1):
            summary_lines.append(f"- example {i}: {t}")
        summary_lines.append("")

    out_md = DATA_DIR / "cluster_summary.md"
    out_md.write_text("\n".join(summary_lines), encoding="utf-8")
    print(f"[info] Cluster summaries written to {out_md}")


if __name__ == "__main__":
    main()
