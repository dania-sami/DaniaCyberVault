
from pathlib import Path
import random
import csv
from datetime import datetime, timedelta

DATA_DIR = Path("data")


def main():
    random.seed(42)
    DATA_DIR.mkdir(exist_ok=True)

    types = ["cve", "ip", "domain", "malware", "hash"]
    severities = ["Low", "Medium", "High", "Critical"]
    sources = ["VendorFeed", "OpenSource", "Internal", "GovAdvisory"]
    base_titles = {
        "cve": "Vulnerability in {product} allows {impact}",
        "ip": "Suspicious IP observed contacting {product} service",
        "domain": "Potential phishing domain targeting {brand} users",
        "malware": "New malware family {name} observed in the wild",
        "hash": "File hash associated with {name} campaign",
    }
    products = ["web server", "VPN gateway", "email system", "database", "SSO portal"]
    impacts = ["remote code execution", "privilege escalation", "information disclosure", "authentication bypass"]
    brands = ["banking", "cloud", "university", "healthcare", "retail"]
    malware_names = ["ShadowFox", "BlueMist", "NightRider", "SilverRat", "CrimsonLock"]

    now = datetime.utcnow()
    rows = []
    for i in range(200):
        t = random.choice(types)
        sev = random.choices(severities, weights=[1, 3, 3, 1])[0]
        src = random.choice(sources)
        days_ago = random.randint(0, 30)
        first_seen = (now - timedelta(days=days_ago)).strftime("%Y-%m-%d")

        if t == "cve":
            product = random.choice(products)
            impact = random.choice(impacts)
            title = base_titles[t].format(product=product, impact=impact)
            description = f"A vulnerability affecting the {product} component may allow {impact}. Exploitation could lead to compromise of affected systems."
        elif t == "ip":
            product = random.choice(products)
            title = base_titles[t].format(product=product)
            description = f"Threat telemetry has observed this IP contacting {product} endpoints. Activity includes repeated connection attempts and scanning behaviour."
        elif t == "domain":
            brand = random.choice(brands)
            title = base_titles[t].format(brand=brand)
            description = f"The domain appears to mimic {brand} branding and has been linked to credential harvesting campaigns."
        elif t == "malware":
            name = random.choice(malware_names)
            title = base_titles[t].format(name=name)
            description = f"{name} is a malware family observed in recent campaigns, showing capabilities such as persistence, credential theft and data exfiltration."
        else:
            name = random.choice(malware_names)
            title = base_titles[t].format(name=name)
            description = f"The file hash has been seen in {name} campaigns and may indicate presence of malware on the host."

        indicator_value = f"placeholder-{i}"

        rows.append(
            {
                "id": i + 1,
                "type": t,
                "indicator": indicator_value,
                "title": title,
                "description": description,
                "severity": sev,
                "source": src,
                "first_seen": first_seen,
            }
        )

    out_path = DATA_DIR / "intel_feed.csv"
    fieldnames = ["id", "type", "indicator", "title", "description", "severity", "source", "first_seen"]
    with out_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for r in rows:
            writer.writerow(r)

    print(f"[info] Wrote {len(rows)} synthetic intel items to {out_path}")


if __name__ == "__main__":
    main()
