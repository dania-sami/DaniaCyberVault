
# AI Powered Threat Intelligence Summarizer

Hi, I am Dania and I built this project to experiment with how threat intelligence platforms turn a lot of noisy data into something a human analyst can actually read.

Instead of only listing indicators, this tool tries to:
- cluster similar items together
- assign a simple risk score
- generate short summaries for each cluster

It is like a tiny student version of a threat intelligence feed processor.

---

## What this project does

The workflow is simple:

1. **Generate synthetic threat intel data**  
   I simulate a small feed of mixed indicators and reports in `data/intel_feed.csv` with fields such as:
   - type (cve, ip, domain, malware, hash)
   - title
   - description
   - severity
   - source
   - first_seen

2. **Cluster and enrich**  
   A script uses TF–IDF and KMeans clustering on the text fields (title + description).  
   It then:
   - assigns a cluster to each item
   - calculates a simple numeric `risk_score`
   - produces a short summary per cluster based on top keywords and the most severe items

3. **Output**  
   The tool writes:
   - `data/intel_enriched.csv` — with cluster and risk_score for each row
   - `data/cluster_summary.md` — human readable summaries for each cluster

This gives me a realistic way to talk about AI assisted threat intel analysis.

---

## Project structure

```text
ai_threat_intel_summarizer/
  README.md
  requirements.txt
  generate_intel.py       # create synthetic threat intel feed
  summarize_intel.py      # cluster, score and summarise
  data/
```

---

## Installation

```bash
python3 -m venv venv
source venv/bin/activate           # Windows  venv\Scripts\activate
pip install -r requirements.txt
```

---

## Step 1  Generate synthetic threat intel

```bash
python generate_intel.py
```

This will create `data/intel_feed.csv` with mixed indicators and severities.

---

## Step 2  Cluster and summarise

```bash
python summarize_intel.py
```

The script will:

- load `data/intel_feed.csv`
- vectorise the text with TF–IDF
- run KMeans clustering
- compute a simple risk score for each row
- write:
  - `data/intel_enriched.csv`
  - `data/cluster_summary.md`

You will also see a short console summary of the clusters.

---

## Risk scoring (simplified)

The `risk_score` is not a real world metric, but it uses ideas that are common in threat intel work:

- each severity level (Low/Medium/High/Critical) is mapped to a base numeric value
- items about CVEs and malware families get a small boost
- items that appear in clusters with many high severity entries are treated as more important

The result is a 0–100 style score that can be used to sort the feed by “important first”.

---

## How I see this project

I wanted something that shows:

- I can work with text data from security
- I understand basic NLP ideas (TF–IDF, clustering)
- I can compute simple, transparent risk scores
- and I think like someone building tools for analysts, not just scripts for myself

It is intentionally compact and easy to read so it can grow into a more serious threat intelligence helper in the future.
