"""
Endpoint Behavior Drift Detector – Dania

Compares baseline.json and current.json with structure:

{
  "hosts": [
    {
      "id": "host1",
      "processes": ["proc1", "proc2"],
      "listening_ports": [22, 443],
      "autoruns": ["item1", "item2"]
    }
  ]
}
"""

import argparse
import json
from dataclasses import dataclass, asdict
from typing import List, Dict


@dataclass
class HostSnapshot:
    id: str
    processes: List[str]
    listening_ports: List[int]
    autoruns: List[str]


@dataclass
class HostDrift:
    host: str
    new_processes: List[str]
    new_ports: List[int]
    new_autoruns: List[str]


def load_snapshot(path: str) -> Dict[str, HostSnapshot]:
    with open(path, "r", encoding="utf-8") as f:
        raw = json.load(f)
    snaps: Dict[str, HostSnapshot] = {}
    for h in raw.get("hosts", []):
        snap = HostSnapshot(
            id=h["id"],
            processes=list(h.get("processes", [])),
            listening_ports=list(h.get("listening_ports", [])),
            autoruns=list(h.get("autoruns", [])),
        )
        snaps[snap.id] = snap
    return snaps


def compare_snapshots(baseline: Dict[str, HostSnapshot], current: Dict[str, HostSnapshot]) -> List[HostDrift]:
    drifts: List[HostDrift] = []
    for host_id, cur in current.items():
        base = baseline.get(host_id)
        if not base:
            drifts.append(
                HostDrift(
                    host=host_id,
                    new_processes=cur.processes,
                    new_ports=cur.listening_ports,
                    new_autoruns=cur.autoruns,
                )
            )
            continue

        new_procs = sorted(set(cur.processes) - set(base.processes))
        new_ports = sorted(set(cur.listening_ports) - set(base.listening_ports))
        new_autos = sorted(set(cur.autoruns) - set(base.autoruns))

        if new_procs or new_ports or new_autos:
            drifts.append(
                HostDrift(
                    host=host_id,
                    new_processes=new_procs,
                    new_ports=new_ports,
                    new_autoruns=new_autos,
                )
            )
    return drifts


def write_outputs(drifts: List[HostDrift], md_path: str, json_path: str) -> None:
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump([asdict(d) for d in drifts], f, indent=2)

    with open(md_path, "w", encoding="utf-8") as f:
        f.write("# Endpoint behaviour drift report\n\n")
        f.write(f"* Hosts with drift: {len(drifts)}\n\n")
        for d in drifts:
            f.write(f"## {d.host}\n\n")
            if d.new_processes:
                f.write("* New processes:\n")
                for p in d.new_processes:
                    f.write(f"  * {p}\n")
            if d.new_ports:
                f.write("* New listening ports:\n")
                for p in d.new_ports:
                    f.write(f"  * {p}\n")
            if d.new_autoruns:
                f.write("* New autorun entries:\n")
                for a in d.new_autoruns:
                    f.write(f"  * {a}\n")
            if not (d.new_processes or d.new_ports or d.new_autoruns):
                f.write("No drift detected.\n")
            f.write("\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's endpoint behaviour drift detector")
    parser.add_argument("--baseline", default="baseline.json", help="Baseline snapshot JSON")
    parser.add_argument("--current", default="current.json", help="Current snapshot JSON")
    parser.add_argument("--out-prefix", default="endpoint_drift", help="Output prefix")
    args = parser.parse_args()

    baseline = load_snapshot(args.baseline)
    current = load_snapshot(args.current)
    drifts = compare_snapshots(baseline, current)
    md_path = f"{args.out_prefix}_report.md"
    json_path = f"{args.out_prefix}_drifts.json"
    write_outputs(drifts, md_path, json_path)
    print(f"Found drift on {len(drifts)} hosts.")
    print(f"Wrote report to {md_path}")


if __name__ == "__main__":
    main()
