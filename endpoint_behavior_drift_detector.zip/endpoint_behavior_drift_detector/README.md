# Endpoint Behavior Drift Detector – Dania

Hi

I am Dania and this detector compares baseline endpoint behaviour with a newer snapshot

It looks at

* new processes
* new listening ports
* new autorun entries

The result is a short Markdown report that highlights what changed on each host so it is easier to spot suspicious drift
