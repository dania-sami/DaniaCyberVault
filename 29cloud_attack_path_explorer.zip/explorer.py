import json, argparse, networkx as nx

def load_env(path):
    with open(path) as f: return json.load(f)

def build_graph(env):
    G=nx.DiGraph()
    for r in env["resources"]: G.add_node(r["name"], type=r["type"])
    for a in env["access"]:
        G.add_edge(a["from"], a["to"], perm=a["perm"])
    return G

def find_paths(G):
    sensitive=[n for n,d in G.nodes(data=True) if d.get("type")=="sensitive"]
    exposed=[n for n,d in G.nodes(data=True) if d.get("type")=="exposed"]
    results=[]
    for e in exposed:
        for s in sensitive:
            try:
                p=nx.shortest_path(G,e,s)
                results.append(p)
            except:
                pass
    return results

def write_report(paths,out):
    with open(out,"w") as f:
        f.write("# Attack Path Report

")
        if not paths:
            f.write("No reachable paths found
")
            return
        for p in paths:
            f.write(" -> ".join(p)+"

")

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--config",required=True)
    ap.add_argument("--out",default="report.md")
    a=ap.parse_args()
    env=load_env(a.config)
    G=build_graph(env)
    paths=find_paths(G)
    write_report(paths,a.out)

if __name__=="__main__":
    main()
