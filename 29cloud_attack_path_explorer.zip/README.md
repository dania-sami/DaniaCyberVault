# Cloud Attack Path Explorer

Hi

This is a small project that reads a simplified cloud export (roles, resources, permissions)
and builds a graph showing how an attacker could move from an exposed asset to sensitive data.

It is not a full CSPM tool, just a clean project to show understanding of IAM graphs.

## How to run

python explorer.py --config examples/cloud_env.json --out report.md
