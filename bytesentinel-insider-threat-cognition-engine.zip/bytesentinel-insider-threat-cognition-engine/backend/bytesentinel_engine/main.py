
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Dict, List

from .engine import ByteSentinelBrain, ActorProfile, InsiderAssessment


brain = ByteSentinelBrain()


class ActorIn(BaseModel):
    actor_id: str = Field(..., example="user-123")
    meta: Dict[str, str] = Field(default_factory=dict)
    metrics: Dict[str, float] = Field(
        default_factory=dict,
        description=(
            "Metrics like curiosity_exploration_score, privilege_edge_probing_score, "
            "off_hours_activity_score, data_staging_score, exfiltration_signal_score, "
            "organisational_stress_factor"
        ),
    )


class ActorOut(BaseModel):
    id: int
    actor_id: str
    meta: Dict[str, str]
    metrics: Dict[str, float]


class AssessmentOut(BaseModel):
    profile_id: int
    actor_id: str
    risk_score: float
    stage_label: str
    reasons: List[str]


app = FastAPI(
    title="ByteSentinel Insider Threat Cognition Engine",
    version="0.1.0",
    description="My high level reasoning engine for insider threat style behaviour patterns.",
)


@app.post("/actors", response_model=ActorOut)
def register_actor(payload: ActorIn) -> ActorOut:
    prof: ActorProfile = brain.register_actor(
        actor_id=payload.actor_id,
        meta=payload.meta,
        metrics=payload.metrics,
    )
    return ActorOut(
        id=prof.id,
        actor_id=prof.actor_id,
        meta=prof.meta,
        metrics=prof.metrics,
    )


@app.post("/assess", response_model=AssessmentOut)
def assess(profile_id: int) -> AssessmentOut:
    if profile_id not in brain.profiles:
        raise HTTPException(status_code=404, detail="Actor profile not found")
    res: InsiderAssessment = brain.assess(profile_id)
    return AssessmentOut(
        profile_id=res.profile_id,
        actor_id=res.actor_id,
        risk_score=res.risk_score,
        stage_label=res.stage_label,
        reasons=res.reasons,
    )
