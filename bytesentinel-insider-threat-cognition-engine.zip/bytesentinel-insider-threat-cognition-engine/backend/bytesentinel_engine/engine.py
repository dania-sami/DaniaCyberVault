
from dataclasses import dataclass
from typing import Dict, List


@dataclass
class ActorProfile:
    id: int
    actor_id: str
    meta: Dict[str, str]
    metrics: Dict[str, float]


@dataclass
class InsiderAssessment:
    profile_id: int
    actor_id: str
    risk_score: float
    stage_label: str
    reasons: List[str]


class ByteSentinelBrain:
    """
    ByteSentinel is my lab for thinking about insider threat patterns at a high
    level.

    It does not monitor real people. Instead it takes abstract metrics that
    represent behaviour patterns and turns them into a staged risk view.
    """

    def __init__(self) -> None:
        self._next_id = 1
        self.profiles: Dict[int, ActorProfile] = {}

    def register_actor(self, actor_id: str, meta: Dict[str, str], metrics: Dict[str, float]) -> ActorProfile:
        pid = self._next_id
        self._next_id += 1
        prof = ActorProfile(
            id=pid,
            actor_id=actor_id,
            meta=meta,
            metrics=metrics,
        )
        self.profiles[pid] = prof
        return prof

    def assess(self, profile_id: int) -> InsiderAssessment:
        prof = self.profiles[profile_id]
        m = prof.metrics
        reasons: List[str] = []
        risk = 0.0

        curiosity = float(m.get("curiosity_exploration_score", 0.0))
        privilege_edge = float(m.get("privilege_edge_probing_score", 0.0))
        off_hours = float(m.get("off_hours_activity_score", 0.0))
        data_staging = float(m.get("data_staging_score", 0.0))
        exfil_signals = float(m.get("exfiltration_signal_score", 0.0))
        stress_factor = float(m.get("organisational_stress_factor", 0.0))

        if curiosity > 0.6:
            risk += (curiosity - 0.6) * 20.0
            reasons.append("Unusual exploration of resources beyond normal scope.")
        if privilege_edge > 0.4:
            risk += (privilege_edge - 0.4) * 25.0
            reasons.append("Repeated activity near the edge of assigned privileges.")
        if off_hours > 0.5:
            risk += (off_hours - 0.5) * 20.0
            reasons.append("Notable access patterns during off hours.")
        if data_staging > 0.3:
            risk += (data_staging - 0.3) * 30.0
            reasons.append("Patterns that look like pre-exfiltration data staging.")
        if exfil_signals > 0.2:
            risk += (exfil_signals - 0.2) * 40.0
            reasons.append("Signals that resemble exfiltration attempts or dry runs.")
        if stress_factor > 0.5:
            risk += (stress_factor - 0.5) * 15.0
            reasons.append("Context shows elevated organisational stress which can increase risk.")

        risk = max(0.0, min(100.0, risk))

        if risk >= 80.0:
            stage = "active_exfiltration_likely"
        elif risk >= 60.0:
            stage = "staging_and_preparation"
        elif risk >= 40.0:
            stage = "heightened_watch"
        elif risk >= 20.0:
            stage = "mild_concerns"
        else:
            stage = "baseline_behaviour"

        if not reasons:
            reasons.append("Metrics do not indicate strong insider threat patterns under this model.")

        return InsiderAssessment(
            profile_id=prof.id,
            actor_id=prof.actor_id,
            risk_score=round(risk, 2),
            stage_label=stage,
            reasons=reasons,
        )
