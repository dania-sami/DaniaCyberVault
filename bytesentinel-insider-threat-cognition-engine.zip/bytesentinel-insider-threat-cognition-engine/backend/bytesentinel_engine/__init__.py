"""ByteSentinel Insider Threat Cognition Engine backend package."""
