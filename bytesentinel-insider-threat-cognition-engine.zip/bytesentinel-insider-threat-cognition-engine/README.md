
# ByteSentinel Insider Threat Cognition Engine

ByteSentinel is my lab project for thinking about insider threat patterns
in a careful, abstract way.

This engine is not wired into any real monitoring system. Instead it works
with anonymised style metrics that represent behaviour patterns and then
assigns a staged view of insider risk.

The idea is to have a safe, explainable model I can use in conversations
about detection strategy and early warning signals.

## What this project does

* registers abstract actor profiles with
  * an `actor_id` label
  * metadata such as department or role
  * metrics like
    * `curiosity_exploration_score`
    * `privilege_edge_probing_score`
    * `off_hours_activity_score`
    * `data_staging_score`
    * `exfiltration_signal_score`
    * `organisational_stress_factor`
* calculates
  * a risk score between zero and one hundred
  * a stage label, for example
    * `baseline_behaviour`
    * `mild_concerns`
    * `heightened_watch`
    * `staging_and_preparation`
    * `active_exfiltration_likely`
  * reasons that show which metrics drove the assessment

All logic is in `engine.py` and can be reviewed or adapted easily.

## Project layout

```text
bytesentinel-insider-threat-cognition-engine
└── backend
    ├── bytesentinel_engine
    │   ├── __init__.py
    │   ├── engine.py  Actor model and insider risk scoring
    │   └── main.py    FastAPI HTTP API
    ├── requirements.txt
    └── example_requests.http
```

## How I run it locally

From the backend folder

```bash
python -m venv .venv
source .venv/bin/activate        # On Windows I use .venv\Scripts\activate
pip install -r requirements.txt
uvicorn bytesentinel_engine.main:app --reload --port 9913
```

Then I open

* http://localhost:9913/docs to add profiles and run assessments

## A scenario I like to discuss

I define an actor profile that shows curiosity, some privilege edge probing,
off hours access and early data staging patterns.

```bash
curl -X POST http://localhost:9913/actors   -H "Content-Type: application/json"   -d '{
    "actor_id": "user-123",
    "meta": {
      "department": "engineering"
    },
    "metrics": {
      "curiosity_exploration_score": 0.7,
      "privilege_edge_probing_score": 0.5,
      "off_hours_activity_score": 0.6,
      "data_staging_score": 0.4,
      "exfiltration_signal_score": 0.25,
      "organisational_stress_factor": 0.6
    }
  }'
```

Then I ask ByteSentinel for an assessment

```bash
curl -X POST "http://localhost:9913/assess?profile_id=1"
```

The result gives me

* a risk score
* a stage label, likely `staging_and_preparation` in this case
* reasons that map directly to metrics like off hours activity and data staging

This is the level of explanation I want when I talk about designing truly
fair and transparent insider threat programmes.

## Future possibilities

If I want to extend ByteSentinel later I could

* connect it to simulated datasets
* explore different weighting for different environments
* build a small dashboard that shows actors by stage

Right now it already demonstrates how I think about insider patterns in an
explainable, non sensational way.
