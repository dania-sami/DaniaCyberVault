# Ransomware Behavior Sandbox (Simulated and Safe)

Hi, I am Dania Sami 👋

In this project I wanted to understand **how ransomware behaves** on a system
but in a **safe and simulated way**.

I do **not** run real malware. Instead I:

- simulate sequences of endpoint events that look like normal user activity
- simulate sequences that look like "ransomware style" behaviour
- extract simple behavioural features from those sequences
- train a small machine learning model that tries to classify
  *normal vs ransomware-like* behaviour

The focus is on **behaviour based detection**, not signatures, and everything
happens inside synthetic CSV data so it is safe to run anywhere.

> ⚠️ This project does not encrypt or touch any real files on disk.
> All "events" are simulated and stored as CSV in the `data/` folder.

---

## What this project does

1. **Simulates endpoint event sequences**

   `src/simulate_events.py` generates a dataset of event sequences and writes
   them to `data/events.csv`.

   Each sequence has an ID and events like:

   - open_file, write_file, rename_file
   - list_directory
   - spawn_process
   - connect_network

   Some sequences follow a pattern that is typical for normal users (a few
   document edits, browser usage). Some sequences look more like a simple
   ransomware scenario: many file modifications in a short time window plus
   suspicious process and network activity.

2. **Extracts behavioural features**

   `src/extract_features.py` turns raw event sequences into features such as:

   - number of files touched
   - ratio of write operations
   - number of distinct directories
   - presence of suspicious processes
   - presence of unusual network connections

3. **Trains a classifier**

   `src/train_detector.py` trains a small `RandomForestClassifier` on the
   extracted features to distinguish:

   - `label = normal`
   - `label = ransomware_like`

   The model is saved into `models/behaviour_detector.joblib`.

4. **Evaluates the model**

   `src/evaluate.py` loads the model and prints accuracy, precision and recall
   on a held out test set.

---

## Quick start

You need Python 3.10 or newer.

```bash
# 1. Create and activate a virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt
```

Then:

```bash
# 3. Generate synthetic event data
python -m src.simulate_events

# 4. Extract features
python -m src.extract_features

# 5. Train detector
python -m src.train_detector

# 6. Evaluate on held out test data
python -m src.evaluate
```

You will see printed metrics and you can inspect:

- `data/events.csv`          (raw simulated events)
- `data/features.csv`        (behavioural features)
- `models/behaviour_detector.joblib`
- `reports/metrics.txt`

---

## Project structure

```text
ransomware_behavior_sandbox/
  ├─ README.md
  ├─ requirements.txt
  ├─ data/
  │    ├─ events.csv           # generated
  │    └─ features.csv         # generated
  ├─ models/
  │    └─ behaviour_detector.joblib  # generated
  ├─ reports/
  │    └─ metrics.txt          # generated
  └─ src/
       ├─ __init__.py
       ├─ config.py
       ├─ simulate_events.py
       ├─ extract_features.py
       ├─ train_detector.py
       └─ evaluate.py
```

---

## How I would extend this

If I had more time and resources, I would:

- plug this into real endpoint telemetry (EDR / Sysmon style, with permissions)
- add more realistic process tree and network graph features
- visualise the behaviour of a sequence as a timeline
- test the model on unseen scenarios and adversarial modifications

For me this project is a way to show that I understand **ransomware as a
behavioural pattern** and that I can build basic detection logic in a safe
sandbox.
