from __future__ import annotations

import joblib
import pandas as pd
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split

from .config import FEATURES_FILE, MODELS_DIR


def main() -> None:
    df = pd.read_csv(FEATURES_FILE)
    X = df[
        [
            "total_events",
            "write_ratio",
            "rename_ratio",
            "bulk_write_ratio",
            "suspicious_proc",
            "external_c2",
            "distinct_paths",
        ]
    ]
    y = df["label"]

    _, X_test, _, y_test = train_test_split(
        X, y, test_size=0.3, random_state=42, stratify=y
    )

    model_path = MODELS_DIR / "behaviour_detector.joblib"
    clf = joblib.load(model_path)

    y_pred = clf.predict(X_test)
    print("Evaluation on held out test data:\n")
    print(classification_report(y_test, y_pred))


if __name__ == "__main__":
    main()
