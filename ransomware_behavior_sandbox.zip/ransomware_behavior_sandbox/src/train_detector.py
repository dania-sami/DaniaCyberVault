from __future__ import annotations

from pathlib import Path

import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

from .config import FEATURES_FILE, MODELS_DIR, REPORTS_DIR


def main() -> None:
    df = pd.read_csv(FEATURES_FILE)
    X = df[
        [
            "total_events",
            "write_ratio",
            "rename_ratio",
            "bulk_write_ratio",
            "suspicious_proc",
            "external_c2",
            "distinct_paths",
        ]
    ]
    y = df["label"]

    X_train, X_val, y_train, y_val = train_test_split(
        X, y, test_size=0.3, random_state=42, stratify=y
    )

    clf = RandomForestClassifier(
        n_estimators=100,
        random_state=42,
        class_weight="balanced",
    )
    clf.fit(X_train, y_train)
    val_acc = clf.score(X_val, y_val)

    model_path = MODELS_DIR / "behaviour_detector.joblib"
    joblib.dump(clf, model_path)

    metrics_path = REPORTS_DIR / "metrics.txt"
    metrics_path.write_text(f"Validation accuracy: {val_acc:.3f}\n", encoding="utf-8")

    print(f"Model trained and saved to {model_path}")
    print(f"Validation accuracy: {val_acc:.3f}")
    print(f"Metrics written to {metrics_path}")


if __name__ == "__main__":
    main()
