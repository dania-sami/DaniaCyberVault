from __future__ import annotations

import random
from datetime import datetime, timedelta

import pandas as pd

from .config import EVENTS_FILE


EVENT_TYPES_NORMAL = [
    "open_file",
    "read_file",
    "write_file",
    "save_document",
    "list_directory",
    "spawn_process",
    "connect_network",
]

EVENT_TYPES_RANSOM = [
    "open_file",
    "write_file",
    "rename_file",
    "bulk_write",
    "list_directory",
    "spawn_suspicious_process",
    "connect_external_c2",
]


def simulate_sequence(seq_id: int, start: datetime, kind: str) -> list[dict]:
    events: list[dict] = []
    current = start
    if kind == "normal":
        num_events = random.randint(10, 30)
        event_types = EVENT_TYPES_NORMAL
    else:
        num_events = random.randint(30, 60)
        event_types = EVENT_TYPES_RANSOM

    for _ in range(num_events):
        event_type = random.choice(event_types)
        current += timedelta(seconds=random.randint(1, 60))

        events.append(
            {
                "sequence_id": seq_id,
                "timestamp": current.isoformat(),
                "event_type": event_type,
                "path": f"/home/user/doc{random.randint(1, 20)}.txt",
                "process": "winword.exe" if event_type in {"open_file", "save_document"} else "simulated.exe",
            }
        )
    return events


def main() -> None:
    random.seed(42)
    all_events: list[dict] = []
    base_time = datetime(2025, 2, 1, 10, 0, 0)

    seq_id = 0
    # normal sequences
    for _ in range(80):
        seq_id += 1
        all_events.extend(simulate_sequence(seq_id, base_time, "normal"))

    # ransomware-like sequences
    for _ in range(40):
        seq_id += 1
        all_events.extend(simulate_sequence(seq_id, base_time, "ransom"))

    df = pd.DataFrame(all_events)
    df.to_csv(EVENTS_FILE, index=False)
    print(f"Wrote {len(df)} events to {EVENTS_FILE}")


if __name__ == "__main__":
    main()
