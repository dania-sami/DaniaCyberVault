from __future__ import annotations

import pandas as pd

from .config import EVENTS_FILE, FEATURES_FILE


def main() -> None:
    df = pd.read_csv(EVENTS_FILE, parse_dates=["timestamp"])

    # Label: assume top half of sequence_ids = normal, bottom half = ransomware_like
    max_seq = df["sequence_id"].max()
    pivot = max_seq // 2

    features = []

    for seq_id, group in df.groupby("sequence_id"):
        total_events = len(group)
        writes = (group["event_type"].str.contains("write")).sum()
        renames = (group["event_type"] == "rename_file").sum()
        bulk = (group["event_type"] == "bulk_write").sum()
        suspicious_proc = (group["event_type"] == "spawn_suspicious_process").sum()
        c2 = (group["event_type"] == "connect_external_c2").sum()
        distinct_paths = group["path"].nunique()

        label = "normal" if seq_id <= pivot else "ransomware_like"

        features.append(
            {
                "sequence_id": seq_id,
                "total_events": total_events,
                "write_ratio": writes / total_events if total_events else 0.0,
                "rename_ratio": renames / total_events if total_events else 0.0,
                "bulk_write_ratio": bulk / total_events if total_events else 0.0,
                "suspicious_proc": suspicious_proc,
                "external_c2": c2,
                "distinct_paths": distinct_paths,
                "label": label,
            }
        )

    feat_df = pd.DataFrame(features)
    feat_df.to_csv(FEATURES_FILE, index=False)
    print(f"Wrote features for {len(feat_df)} sequences to {FEATURES_FILE}")


if __name__ == "__main__":
    main()
