from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List

import yaml

SENSITIVE_KEYWORDS = ["admin", "user", "account", "payment", "card", "profile"]
HTTP_SCHEMES = ["http://"]


@dataclass
class Finding:
    severity: str
    location: str
    message: str

    def __str__(self) -> str:
        return f"[{self.severity}] {self.location}: {self.message}"


def load_spec(path: Path) -> Dict[str, Any]:
    text = path.read_text(encoding="utf-8")
    if path.suffix.lower() in (".yaml", ".yml"):
        return yaml.safe_load(text)
    return json.loads(text)


def check_servers(spec: Dict[str, Any]) -> List[Finding]:
    findings: List[Finding] = []
    servers = spec.get("servers", []) or []
    for idx, s in enumerate(servers):
        url = str(s.get("url", ""))
        if any(url.startswith(sc) for sc in HTTP_SCHEMES):
            findings.append(
                Finding(
                    severity="HIGH",
                    location=f"servers[{idx}]",
                    message=f"Server URL uses plain HTTP: {url}",
                )
            )
    return findings


def is_sensitive_path(path: str) -> bool:
    p = path.lower()
    return any(k in p for k in SENSITIVE_KEYWORDS)


def check_operations(spec: Dict[str, Any]) -> List[Finding]:
    findings: List[Finding] = []
    paths = spec.get("paths", {}) or {}
    global_security = spec.get("security")

    for path, ops in paths.items():
        if not isinstance(ops, dict):
            continue
        for method, op in ops.items():
            if method.lower() not in ("get", "post", "put", "patch", "delete"):
                continue
            if not isinstance(op, dict):
                continue

            loc = f"{method.upper()} {path}"

            # 1) Auth / security
            op_sec = op.get("security", global_security)
            if is_sensitive_path(path) and not op_sec:
                findings.append(
                    Finding(
                        severity="HIGH",
                        location=loc,
                        message="Sensitive endpoint has no security section (likely unauthenticated).",
                    )
                )

            # 2) Verbose 5xx responses
            responses = op.get("responses", {}) or {}
            for code, resp in responses.items():
                if str(code).startswith("5"):
                    desc = ""
                    if isinstance(resp, dict):
                        desc = str(resp.get("description", ""))
                    if any(word in desc.lower() for word in ("stack", "trace", "debug", "internal error")):
                        findings.append(
                            Finding(
                                severity="MEDIUM",
                                location=f"{loc} -> response {code}",
                                message="5xx response description looks verbose (may leak internals).",
                            )
                        )
                    elif not desc:
                        findings.append(
                            Finding(
                                severity="LOW",
                                location=f"{loc} -> response {code}",
                                message="5xx response without clear, generic description.",
                            )
                        )
    return findings


def main() -> None:
    parser = argparse.ArgumentParser(description="OpenAPI schema security linter")
    parser.add_argument("--file", type=str, required=True, help="Path to OpenAPI file (YAML or JSON)")
    args = parser.parse_args()

    path = Path(args.file)
    if not path.exists():
        print(f"File not found: {path}")
        return

    spec = load_spec(path)
    all_findings: List[Finding] = []
    all_findings.extend(check_servers(spec))
    all_findings.extend(check_operations(spec))

    if not all_findings:
        print("No obvious security issues found with current rules.")
        return

    print("OpenAPI Security Findings")
    print("=========================")
    for f in all_findings:
        print(str(f))


if __name__ == "__main__":
    main()
