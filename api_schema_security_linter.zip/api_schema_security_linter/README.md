# API Schema Security Linter (OpenAPI)

Hi, I am Dania 👋

This project is my **OpenAPI security linter**:

- I parse an OpenAPI spec (YAML or JSON).
- I look for insecure patterns:
  - HTTP (non-HTTPS) servers,
  - missing auth on sensitive endpoints,
  - 5xx error responses that look too verbose.

It is a clean, runnable demo of **API-first security thinking**.

## How to run

```bash
cd api_schema_security_linter

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt

# Lint the sample OpenAPI file
python -m src.lint_openapi --file data/example_openapi.yaml
```

You will get findings per endpoint with a simple severity and message.
