import argparse
import json

def analyse(cfg: dict):
    print("[+] Linux hardening report:")
    fw = cfg.get("has_firewall", False)
    print(f"    Firewall enabled              : {'ok' if fw else 'needs attention'}")

    pwd_auth = cfg.get("password_auth_disabled", False)
    print(f"    SSH password auth disabled    : {'ok' if pwd_auth else 'needs attention'}")

    root_ssh = cfg.get("root_ssh_login_disabled", False)
    print(f"    Root SSH login disabled       : {'ok' if root_ssh else 'needs attention'}")

    fail2ban = cfg.get("has_fail2ban", False)
    print(f"    Brute force protection        : {'ok' if fail2ban else 'needs attention'}")

    retention = cfg.get("log_retention_days", 0)
    status = 'ok' if retention >= 30 else 'needs attention'
    print(f"    Log retention (days >= 30)    : {status} (current: {retention})")

def main():
    parser = argparse.ArgumentParser(description="Linux Hardening Checklist Evaluator by Dania")
    parser.add_argument("--config", required=True, help="Path to JSON config file")
    args = parser.parse_args()
    with open(args.config) as f:
        cfg = json.load(f)
    analyse(cfg)

if __name__ == "__main__":
    main()
