# Linux Hardening Checklist Evaluator

This is a small config based tool I use to talk about server hardening in a concrete way.

It reads a JSON file with a few booleans and values like:

- `has_firewall`
- `password_auth_disabled`
- `root_ssh_login_disabled`
- `has_fail2ban`
- `log_retention_days`

The script prints a short report and marks each item as `ok` or `needs attention` based on a simple checklist.

## Files

- `linux_hardening_check.py` – main script
- `server_example.json` – example configuration

## Usage

```bash
python linux_hardening_check.py --config server_example.json
```
