import hashlib
import re

class Sanitizer:
    def hash_value(self, value: str) -> str:
        return hashlib.sha256(value.encode()).hexdigest()

    def mask_email(self, email: str) -> str:
        parts = email.split("@")
        if len(parts) != 2:
            return email
        user, domain = parts
        if len(user) <= 1:
            return "*" + "@" + domain
        return user[0] + "***@" + domain

    def sanitize(self, text: str) -> str:
        # Mask emails
        text = re.sub(
            r"([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+)",
            lambda m: self.mask_email(m.group(1)),
            text,
        )

        # Replace card numbers with truncated hash
        text = re.sub(
            r"\b[0-9]{13,16}\b",
            lambda m: self.hash_value(m.group(0))[:10],
            text,
        )
        return text
