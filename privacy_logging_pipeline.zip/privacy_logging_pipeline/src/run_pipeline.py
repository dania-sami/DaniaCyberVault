import json

from .config import RAW_LOGS, SANITIZED_LOGS, PRIVACY_REPORT
from .pii_detector import PIIDetector
from .sanitizer import Sanitizer


def main() -> None:
    detector = PIIDetector()
    sanitizer = Sanitizer()

    stats = {"email": 0, "phone": 0, "ip": 0, "card": 0, "token": 0}
    SANITIZED_LOGS.write_text("", encoding="utf-8")

    for line in RAW_LOGS.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        event = json.loads(line)
        msg = str(event.get("message", ""))

        found = detector.detect(msg)
        for kind in found:
            stats[kind] += 1

        event["message"] = sanitizer.sanitize(msg)
        with SANITIZED_LOGS.open("a", encoding="utf-8") as f:
            f.write(json.dumps(event) + "\n")

    lines = ["Privacy filtering summary:"]
    for k, v in stats.items():
        lines.append(f"{k}: {v}")
    PRIVACY_REPORT.write_text("\n".join(lines), encoding="utf-8")
    print(f"Sanitized logs written to {SANITIZED_LOGS}")
    print(f"Privacy report written to {PRIVACY_REPORT}")


if __name__ == "__main__":
    main()
