from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
REPORTS_DIR = BASE_DIR / "reports"

RAW_LOGS = DATA_DIR / "raw_logs.jsonl"
SANITIZED_LOGS = REPORTS_DIR / "sanitized_logs.jsonl"
PRIVACY_REPORT = REPORTS_DIR / "privacy_report.txt"
