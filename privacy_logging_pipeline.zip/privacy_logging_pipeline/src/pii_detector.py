import re

class PIIDetector:
    EMAIL = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
    PHONE = re.compile(r"\b\+?[0-9]{8,15}\b")
    IP = re.compile(r"\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b")
    CARD = re.compile(r"\b[0-9]{13,16}\b")
    TOKEN = re.compile(r"(?:api|auth|token|key)[:=][A-Za-z0-9]{10,}")

    def detect(self, text: str) -> list[str]:
        hits: list[str] = []
        for name, pattern in [
            ("email", self.EMAIL),
            ("phone", self.PHONE),
            ("ip", self.IP),
            ("card", self.CARD),
            ("token", self.TOKEN),
        ]:
            if pattern.search(text):
                hits.append(name)
        return hits
