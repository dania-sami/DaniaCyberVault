# Privacy-Friendly Security Logging Pipeline

Hi, I am Dania Sami 👋

I built this project because every company wants strong security monitoring,
but nobody wants their logs to become a privacy incident.

This is my **privacy-first security logging pipeline**. It takes raw application
or security logs, detects possible PII and sensitive values, and produces a
sanitised log stream that is safer to store and analyse.

I focused on three things:

- **Detection** – spot emails, phone numbers, card-like numbers, IPs and tokens.
- **Sanitisation** – mask or transform those values in a consistent way.
- **Transparency** – generate a small privacy report so a reviewer can see what
  types of data were cleaned.

The idea is simple but very close to what real SOC and platform teams need
when they send logs into SIEM or data lakes.

---

## What the pipeline does

1. **Reads raw logs**

   From `data/raw_logs.jsonl`. Each line is a JSON object with at least a
   `message` field. I ship a small example file so the project runs out of the box.

2. **Detects PII-like patterns**

   In `src/pii_detector.py` I use regular expressions to flag:

   - email addresses
   - phone numbers
   - IPv4 addresses
   - card-style long numbers
   - obvious API tokens (very simplified)

   This is intentionally transparent: no black box, just readable rules.

3. **Sanitises content**

   In `src/sanitizer.py` I apply simple transformations, for example:

   - mask email usernames (`john.doe@example.com` → `j***@example.com`)
   - replace card numbers with a truncated SHA256 hash

   The goal is that the log stays useful for analysis, but direct identifiers
   are removed or transformed.

4. **Writes safe logs and a privacy report**

   `src/run_pipeline.py` writes:

   - `reports/sanitized_logs.jsonl` – cleaned events
   - `reports/privacy_report.txt` – counts of each PII type detected

This is not a full DLP product, but it shows how I think about **privacy by
design** in security engineering.

---

## How to run

You need Python 3.10+ installed.

```bash
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

pip install -r requirements.txt

python -m src.run_pipeline
```

After running, check:

- `reports/sanitized_logs.jsonl`
- `reports/privacy_report.txt`

---

## Project structure

```text
privacy_logging_pipeline/
  ├─ README.md
  ├─ requirements.txt
  ├─ data/
  │    └─ raw_logs.jsonl
  ├─ reports/
  │    └─ (generated files)
  └─ src/
       ├─ __init__.py
       ├─ config.py
       ├─ pii_detector.py
       ├─ sanitizer.py
       └─ run_pipeline.py
```

---

## How I would extend this

If I was turning this into a bigger project I would:

- add configuration for which fields must never contain raw PII
- add support for structured JSON logs with field-level masking
- plug in a small test suite for GDPR-style requirements
- integrate this with my other security projects so all of them can output
  privacy-aware logs by default

For me this project shows that I care about both **security** and **privacy**,
which is exactly what modern organisations expect.
