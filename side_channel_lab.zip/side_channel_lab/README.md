
# Side Channel Attack Lab – AES S‑box Power Analysis (DPA)

Hi, I am Dania and I built this project to understand **side channel attacks** in a safe, controlled way.

Instead of touching real hardware, I simulate:

- AES S‑box operations on a single key byte
- power traces based on Hamming weight leakage plus noise
- a Differential Power Analysis (DPA) attack that recovers the secret key byte from the traces

This is my small “virtual oscilloscope” for learning power analysis.

---

## What this project does

There are two main scripts:

1. `generate_traces.py`  
   - chooses a fixed secret key byte  
   - generates random plaintext bytes  
   - applies AES S‑box to `plaintext[0] XOR key[0]`  
   - simulates a noisy power trace based on the Hamming weight of the S‑box output  
   - writes everything to `data/traces.csv`

2. `dpa_attack.py`  
   - loads `data/traces.csv`  
   - for each possible key guess 0..255:
     - re-computes hypothetical intermediate values
     - computes Hamming weight
     - correlates that with the measured power samples
   - finds the key guess with the highest absolute correlation
   - prints the recovered key byte and a small ranking of top candidates

---

## Project structure

```text
side_channel_lab/
  README.md
  requirements.txt
  generate_traces.py     # simulate AES S-box leakage
  dpa_attack.py          # run Differential Power Analysis
  data/
```

The implementation uses only the AES S‑box, not full AES, which is enough to understand DPA on the first round.

---

## Installation

```bash
python3 -m venv venv
source venv/bin/activate       # Windows  venv\Scripts\activate
pip install -r requirements.txt
```

---

## Step 1  Generate synthetic power traces

```bash
python generate_traces.py
```

This will:

- pick a random secret key byte
- generate (by default) 500 traces
- write them to `data/traces.csv`

Columns include:

- `plaintext_byte`
- `power_sample` (simulated leakage)
- `trace_id`
- `secret_key_byte` (for reference, so I can see if DPA worked)

---

## Step 2  Run the DPA attack

```bash
python dpa_attack.py
```

The script will:

- load all traces
- compute correlation for key guesses 0..255
- print the best guess and top candidates

Example style of output:

```text
[info] Loaded 500 traces from data/traces.csv
[info] Best key guess: 0x3a  (score 0.82)
Top 5 guesses:
  0x3a  corr=0.82
  0x7f  corr=0.21
  0x12  corr=0.18
  0xa4  corr=0.16
  0x5c  corr=0.15
[info] Real key byte was: 0x3a
```

This reproduces the core idea of power analysis on a single byte.

---

## Why I like this project

Side channel attacks are very common in hardware security research.

With this project I can show that I:

- understand the concept of leakage (Hamming weight model)
- can simulate traces in code
- can implement DPA using correlation
- and can explain how a single key byte can be recovered

It is a small but very clear hardware security learning lab I can talk about in detail.
