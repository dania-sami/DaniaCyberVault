
# LatticeWall Behavioral Crypto Leakage Detector

LatticeWall is my side channel thinking lab for cryptographic
implementations.

I am not streaming oscilloscope traces into this project. Instead I model
high level metrics that describe how an implementation looks from the outside
and then estimate how much side channel leakage pressure we might be under.

It is a reasoning engine, not a physical measurement tool.

## What this project does

* registers implementations with
  * name
  * algorithm family, for example `lattice_kem` or `classic_signature`
  * metadata like platform or build flags
  * numeric metrics such as
    * `timing_variance_score`
    * `cache_leakage_score`
    * `em_leakage_score`
    * `power_leakage_score`
    * `key_mixing_quality`
    * `masking_coverage`
* calculates
  * a leakage risk score between zero and one hundred
  * a band such as `very_low_leakage_risk` or `high_leakage_risk`
  * a `lattice_attack_surface` value between 0 and 1
  * narrative reasons explaining why

All scoring logic lives in `engine.py` and is intentionally easy to read.

## Project layout

```text
latticewall-behavioral-crypto-leakage-detector
└── backend
    ├── latticewall_engine
    │   ├── __init__.py
    │   ├── engine.py  Implementation model and leakage scoring
    │   └── main.py    FastAPI HTTP API
    ├── requirements.txt
    └── example_requests.http
```

## How I run it locally

From the backend folder

```bash
python -m venv .venv
source .venv/bin/activate        # On Windows I use .venv\Scripts\activate
pip install -r requirements.txt
uvicorn latticewall_engine.main:app --reload --port 9911
```

Then I open

* http://localhost:9911/docs to create implementations and run assessments

## Example scenario I like to talk through

I define an implementation profile that looks a bit leaky on caches and
power, with imperfect key mixing and limited masking.

```bash
curl -X POST http://localhost:9911/implementations   -H "Content-Type: application/json"   -d '{
    "name": "kyber_ref_impl_v1",
    "algorithm_family": "lattice_kem",
    "meta": {
      "platform": "embedded-test-board"
    },
    "metrics": {
      "timing_variance_score": 0.5,
      "cache_leakage_score": 0.7,
      "em_leakage_score": 0.4,
      "power_leakage_score": 0.6,
      "key_mixing_quality": 0.4,
      "masking_coverage": 0.2
    }
  }'
```

Then I ask LatticeWall for an assessment.

```bash
curl -X POST "http://localhost:9911/assess?impl_id=1"
```

The response gives me

* a leakage risk score
* a risk band
* a lattice attack surface estimate
* reasons that explicitly mention timing variance, cache leakage and masking

This is exactly the kind of structured explanation I want when I talk about
side channel hardening trade offs and potential connections to modern
cryptanalysis.

## Future directions

If I want to extend LatticeWall later I can

* plug in metrics produced by real measurement tools
* differentiate more clearly between algorithm families
* add simple visualisations for leakage vs masking

Even now this version already captures how I think about leakage behaviour in
a way that is safe to share and easy to discuss.
