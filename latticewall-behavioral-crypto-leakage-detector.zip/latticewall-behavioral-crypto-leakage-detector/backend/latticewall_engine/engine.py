
from dataclasses import dataclass
from typing import Dict, List


@dataclass
class ImplementationProfile:
    id: int
    name: str
    algorithm_family: str
    meta: Dict[str, str]
    metrics: Dict[str, float]


@dataclass
class LeakageAssessment:
    impl_id: int
    name: str
    algorithm_family: str
    leakage_risk: float
    band: str
    lattice_attack_surface: float
    reasons: List[str]


class LatticeWallBrain:
    """
    LatticeWall is my lab for thinking about side channel leakage and how it
    might feed into modern cryptanalysis.

    I am not running real timing or power traces here. Instead I work with
    clean, abstract metrics that describe how noisy or structured an
    implementation looks from the outside.
    """

    def __init__(self) -> None:
        self._next_id = 1
        self.impls: Dict[int, ImplementationProfile] = {}

    def register_implementation(
        self,
        name: str,
        algorithm_family: str,
        meta: Dict[str, str],
        metrics: Dict[str, float],
    ) -> ImplementationProfile:
        impl_id = self._next_id
        self._next_id += 1
        prof = ImplementationProfile(
            id=impl_id,
            name=name,
            algorithm_family=algorithm_family,
            meta=meta,
            metrics=metrics,
        )
        self.impls[impl_id] = prof
        return prof

    def assess(self, impl_id: int) -> LeakageAssessment:
        prof = self.impls[impl_id]
        m = prof.metrics
        reasons: List[str] = []
        leakage = 0.0

        timing_variance = float(m.get("timing_variance_score", 0.0))
        cache_leakage = float(m.get("cache_leakage_score", 0.0))
        em_leakage = float(m.get("em_leakage_score", 0.0))
        power_leakage = float(m.get("power_leakage_score", 0.0))
        key_mixing_quality = float(m.get("key_mixing_quality", 0.5))
        masking_coverage = float(m.get("masking_coverage", 0.0))

        if timing_variance > 0.4:
            leakage += (timing_variance - 0.4) * 60.0
            reasons.append("Observable timing variance above constant time expectations.")
        if cache_leakage > 0.3:
            leakage += (cache_leakage - 0.3) * 55.0
            reasons.append("Cache access pattern looks strongly key dependent.")
        if em_leakage > 0.3:
            leakage += (em_leakage - 0.3) * 50.0
            reasons.append("Electromagnetic signatures appear structured enough for template style attacks.")
        if power_leakage > 0.3:
            leakage += (power_leakage - 0.3) * 50.0
            reasons.append("Power consumption profiles leak intermediate state information.")

        if key_mixing_quality < 0.5:
            leakage += (0.5 - key_mixing_quality) * 40.0
            reasons.append("Key mixing quality is limited which can help attackers correlate observations.")
        if masking_coverage > 0.4:
            leakage -= (masking_coverage - 0.4) * 35.0
            reasons.append("Masking is used over a significant portion of the computation.")

        leakage = max(0.0, min(100.0, leakage))

        lattice_surface = (cache_leakage + em_leakage + power_leakage) / 3.0 * (1.0 - key_mixing_quality * 0.3)
        lattice_surface = max(0.0, min(1.0, lattice_surface))

        if leakage >= 80.0:
            band = "high_leakage_risk"
        elif leakage >= 60.0:
            band = "elevated_leakage_risk"
        elif leakage >= 40.0:
            band = "moderate_leakage_risk"
        elif leakage >= 20.0:
            band = "low_leakage_risk"
        else:
            band = "very_low_leakage_risk"

        if not reasons:
            reasons.append("Metrics do not show strong side channel leakage drivers under this model.")

        return LeakageAssessment(
            impl_id=prof.id,
            name=prof.name,
            algorithm_family=prof.algorithm_family,
            leakage_risk=round(leakage, 2),
            band=band,
            lattice_attack_surface=round(lattice_surface, 3),
            reasons=reasons,
        )
