
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Dict, List

from .engine import LatticeWallBrain, ImplementationProfile, LeakageAssessment


brain = LatticeWallBrain()


class ImplIn(BaseModel):
    name: str = Field(..., example="kyber_ref_impl_v1")
    algorithm_family: str = Field(..., example="lattice_kem")
    meta: Dict[str, str] = Field(default_factory=dict)
    metrics: Dict[str, float] = Field(
        default_factory=dict,
        description=(
            "Metrics like timing_variance_score, cache_leakage_score, em_leakage_score, "
            "power_leakage_score, key_mixing_quality, masking_coverage"
        ),
    )


class ImplOut(BaseModel):
    id: int
    name: str
    algorithm_family: str
    meta: Dict[str, str]
    metrics: Dict[str, float]


class LeakageOut(BaseModel):
    impl_id: int
    name: str
    algorithm_family: str
    leakage_risk: float
    band: str
    lattice_attack_surface: float
    reasons: List[str]


app = FastAPI(
    title="LatticeWall Behavioral Crypto Leakage Detector",
    version="0.1.0",
    description="My side channel leakage reasoning engine for cryptographic implementations.",
)


@app.post("/implementations", response_model=ImplOut)
def register_implementation(payload: ImplIn) -> ImplOut:
    prof: ImplementationProfile = brain.register_implementation(
        name=payload.name,
        algorithm_family=payload.algorithm_family,
        meta=payload.meta,
        metrics=payload.metrics,
    )
    return ImplOut(
        id=prof.id,
        name=prof.name,
        algorithm_family=prof.algorithm_family,
        meta=prof.meta,
        metrics=prof.metrics,
    )


@app.post("/assess", response_model=LeakageOut)
def assess(impl_id: int) -> LeakageOut:
    if impl_id not in brain.impls:
        raise HTTPException(status_code=404, detail="Implementation not found")
    res: LeakageAssessment = brain.assess(impl_id)
    return LeakageOut(
        impl_id=res.impl_id,
        name=res.name,
        algorithm_family=res.algorithm_family,
        leakage_risk=res.leakage_risk,
        band=res.band,
        lattice_attack_surface=res.lattice_attack_surface,
        reasons=res.reasons,
    )
