"""
Corporate Password Hygiene Analyzer – Dania's policy helper

Analyses a simulated password dump for:
- complexity
- reuse
- dictionary presence
- overlap with old breaches

Then proposes a new policy and simulates how many passwords would fail it.
"""

import argparse
import json
import os
import math
from collections import Counter, defaultdict
from dataclasses import dataclass, asdict
from typing import List, Dict, Set, Tuple


@dataclass
class AccountAnalysis:
    user_id: str
    department: str
    password: str
    length: int
    has_lower: bool
    has_upper: bool
    has_digit: bool
    has_symbol: bool
    dict_hit: bool
    breached_hit: bool
    reuse_count: int


def load_dump(path: str) -> List[Dict]:
    accounts: List[Dict] = []
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue
            if "password" not in obj:
                continue
            accounts.append(obj)
    return accounts


def load_simple_list(path: str) -> Set[str]:
    if not path or not os.path.isfile(path):
        return set()
    vals: Set[str] = set()
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            vals.add(line)
    return vals


def analyse_accounts(accounts: List[Dict], breaches: Set[str], dictionary: Set[str]) -> List[AccountAnalysis]:
    pwd_counts = Counter(acc.get("password", "") for acc in accounts)
    dict_lower = {w.lower() for w in dictionary}

    analysed: List[AccountAnalysis] = []
    for acc in accounts:
        pwd = str(acc.get("password", ""))
        user_id = str(acc.get("user_id", ""))
        dept = str(acc.get("department", "Unknown"))

        length = len(pwd)
        has_lower = any(c.islower() for c in pwd)
        has_upper = any(c.isupper() for c in pwd)
        has_digit = any(c.isdigit() for c in pwd)
        has_symbol = any(not c.isalnum() for c in pwd)

        lower_pwd = pwd.lower()
        dict_hit = False
        for w in dict_lower:
            if len(w) >= 4 and w in lower_pwd:
                dict_hit = True
                break

        breached_hit = pwd in breaches if pwd else False

        reuse = pwd_counts[pwd] if pwd else 0

        analysed.append(
            AccountAnalysis(
                user_id=user_id,
                department=dept,
                password=pwd,
                length=length,
                has_lower=has_lower,
                has_upper=has_upper,
                has_digit=has_digit,
                has_symbol=has_symbol,
                dict_hit=dict_hit,
                breached_hit=breached_hit,
                reuse_count=reuse,
            )
        )
    return analysed


def propose_policy(analysed: List[AccountAnalysis]) -> Dict:
    # Look at current distribution to propose something realistic
    lengths = [a.length for a in analysed]
    if not lengths:
        return {}
    median_len = sorted(lengths)[len(lengths)//2]
    # aim a bit higher than median but not crazy
    min_length = max(10, median_len + 2)

    # require at least 3 out of 4 types
    policy = {
        "min_length": min_length,
        "require_char_types": 3,
        "ban_dictionary_segments": True,
        "ban_known_breaches": True,
    }
    return policy


def check_policy(policy: Dict, a: AccountAnalysis) -> bool:
    """Return True if password passes policy."""
    if not policy:
        return True
    if a.length < policy.get("min_length", 0):
        return False
    types = sum(
        1
        for flag in (a.has_lower, a.has_upper, a.has_digit, a.has_symbol)
        if flag
    )
    if types < policy.get("require_char_types", 1):
        return False
    if policy.get("ban_dictionary_segments", False) and a.dict_hit:
        return False
    if policy.get("ban_known_breaches", False) and a.breached_hit:
        return False
    return True


def simulate_policy(policy: Dict, analysed: List[AccountAnalysis]) -> Tuple[int, int]:
    total = len(analysed)
    if total == 0:
        return 0, 0
    passed = sum(1 for a in analysed if check_policy(policy, a))
    return passed, total


def build_stats(analysed: List[AccountAnalysis]) -> Dict:
    stats: Dict[str, Dict] = {}

    def add_scope(name: str, subset: List[AccountAnalysis]):
        if not subset:
            stats[name] = {}
            return
        lengths = [a.length for a in subset]
        avg_len = sum(lengths) / len(lengths)

        complexity_counts = Counter()
        for a in subset:
            types = sum(
                1 for flag in (a.has_lower, a.has_upper, a.has_digit, a.has_symbol) if flag
            )
            complexity_counts[types] += 1

        reuse_counts = Counter(a.reuse_count for a in subset if a.reuse_count > 1)
        dict_hits = sum(1 for a in subset if a.dict_hit)
        breach_hits = sum(1 for a in subset if a.breached_hit)

        stats[name] = {
            "total_accounts": len(subset),
            "average_length": round(avg_len, 2),
            "complexity_distribution": dict(complexity_counts),
            "reuse_distribution": dict(reuse_counts),
            "dictionary_hits": dict_hits,
            "breach_hits": breach_hits,
        }

    add_scope("overall", analysed)

    # per department
    by_dept: Dict[str, List[AccountAnalysis]] = defaultdict(list)
    for a in analysed:
        by_dept[a.department].append(a)
    for dept, subset in by_dept.items():
        add_scope(f"department:{dept}", subset)

    return stats


def write_json(analysed: List[AccountAnalysis], stats: Dict, policy: Dict, passed: int, total: int, path: str) -> None:
    obj = {
        "accounts": [asdict(a) for a in analysed],
        "stats": stats,
        "policy": policy,
        "simulation": {
            "passed": passed,
            "total": total,
            "pass_rate": round(passed / total * 100.0, 2) if total else 0.0,
        },
    }
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2)


def write_report(stats: Dict, policy: Dict, passed: int, total: int, path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        f.write("# Password hygiene report\n\n")
        if not stats:
            f.write("No data was analysed.\n")
            return

        overall = stats.get("overall", {})
        f.write("## Overview\n\n")
        if overall:
            f.write(f"* Total accounts: {overall.get('total_accounts', 0)}\n")
            f.write(f"* Average length: {overall.get('average_length', 0)}\n")
            f.write(f"* Dictionary hits: {overall.get('dictionary_hits', 0)}\n")
            f.write(f"* Breach hits: {overall.get('breach_hits', 0)}\n")
        f.write("\n")

        f.write("### Complexity (number of character types)\n\n")
        if overall:
            for types, count in sorted(overall.get("complexity_distribution", {}).items()):
                f.write(f"* {types} type(s): {count}\n")
        f.write("\n")

        f.write("### Reuse\n\n")
        if overall and overall.get("reuse_distribution"):
            f.write("Passwords shared by multiple users:\n\n")
            for reuse_count, cnt in sorted(
                overall["reuse_distribution"].items(), key=lambda t: t[0], reverse=True
            ):
                f.write(f"* Reuse count {reuse_count}: {cnt} password(s)\n")
        else:
            f.write("No significant reuse detected beyond single users.\n")
        f.write("\n")

        f.write("## Proposed policy\n\n")
        if not policy:
            f.write("No policy could be proposed because there was no data.\n\n")
        else:
            f.write(f"* Minimum length: **{policy['min_length']}**\n")
            f.write(f"* Require at least **{policy['require_char_types']}** of: lower, upper, digit, symbol\n")
            if policy.get("ban_dictionary_segments", False):
                f.write("* Ban passwords containing obvious dictionary segments.\n")
            if policy.get("ban_known_breaches", False):
                f.write("* Ban passwords that appear in the old breach list.\n")
            f.write("\n")

        f.write("### Simulation\n\n")
        if total:
            rate = round(passed / total * 100.0, 2)
            f.write(f"* Passwords that would **pass** the new policy: {passed} of {total} (~{rate} percent)\n\n")
            f.write("If the pass rate is very low it means the policy may be too ambitious for a first rollout.\n")
        else:
            f.write("No accounts to simulate against.\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's corporate password hygiene analyzer")
    parser.add_argument("--dump", required=True, help="JSONL file with simulated password dump")
    parser.add_argument("--breaches", help="Optional file with old breached passwords (one per line)")
    parser.add_argument("--dictionary", help="Optional file with dictionary words (one per line)")
    parser.add_argument("--out-prefix", default="password_analysis", help="Prefix for output files")
    args = parser.parse_args()

    accounts = load_dump(args.dump)
    breaches = load_simple_list(args.breaches) if args.breaches else set()
    dictionary = load_simple_list(args.dictionary) if args.dictionary else set()

    analysed = analyse_accounts(accounts, breaches, dictionary)
    stats = build_stats(analysed)
    policy = propose_policy(analysed)
    passed, total = simulate_policy(policy, analysed)

    json_path = f"{args.out_prefix}_password_analysis.json"
    md_path = f"{args.out_prefix}_password_report.md"

    write_json(analysed, stats, policy, passed, total, json_path)
    write_report(stats, policy, passed, total, md_path)

    print(f"Wrote JSON analysis to {json_path}")
    print(f"Wrote Markdown report to {md_path}")


if __name__ == "__main__":
    main()
