# Corporate Password Hygiene Analyzer – Dania’s policy helper

Hi

I am Dania and this is a tool I built for test environments to think more clearly about password hygiene

Instead of just saying “our policy is weak”
I wanted to actually run numbers on a simulated password dump and see:

* how complex the current passwords really are
* how much reuse there is between users
* how much they overlap with old breaches or dictionary words
* what would happen if we introduced a stronger but still human friendly policy

This project is completely file based and uses only fake data
It is meant for learning and portfolio purposes not for scanning real production systems

## Input format

The analyzer expects a JSON lines file
Each line is one account with fields like:

{"user_id": "u001", "department": "Engineering", "password": "DaniaRocks2024"}

Fields:

* user_id      unique identifier for the user
* department   optional department name
* password     the current password in plain text (for simulated data only)

There is also an optional file with known breached passwords:

* old_breaches.txt   one password per line that represents passwords that showed up in older test breaches

I included a small sample dataset in `examples` so the tool runs out of the box.

## What the analyzer does

For each password it calculates:

* length
* whether it has lower, upper, digits, symbols
* whether it contains obvious dictionary segments from a small wordlist
* whether it appears in the `old_breaches.txt` list
* how many users share exactly the same password (reuse)

Then it:

1. Aggregates the results into stats per department and overall
2. Proposes a new *candidate policy* such as:
   * minimum length
   * required character types
   * “do not use” lists (dictionary + old breaches)
3. Simulates how many existing passwords would fail that policy
   so we can see the impact before deploying it

The output is:

* a machine readable JSON file with all analysed accounts
* a human readable Markdown report with stats and policy suggestions

## How I run it

1. Optional but nice: create a virtual environment

       python -m venv venv
       source venv/bin/activate

2. Install dependencies (standard library only – this is mostly a formality):

       pip install -r requirements.txt

3. Look at the example files:

   * `examples/password_dump_sample.jsonl`
   * `examples/old_breaches.txt`
   * `examples/dictionary_words.txt`

4. Run the analyzer:

       python password_analyzer.py \
           --dump examples/password_dump_sample.jsonl \
           --breaches examples/old_breaches.txt \
           --dictionary examples/dictionary_words.txt \
           --out-prefix runs_demo

This will create:

* `runs_demo_password_analysis.json`
* `runs_demo_password_report.md`

The report includes:

* overall complexity distribution
* password reuse stats
* dictionary and breach overlap
* a proposed updated policy and an estimate of how many users would need to change their password

## Why I built this

I wanted a realistic but safe way to talk about password hygiene in interviews

With this project I can show that I:

* understand the difference between “having a policy” and actually measuring it
* can evaluate complexity, reuse and dictionary presence in a transparent way
* can simulate the effect of new policies instead of just guessing
* know how to present the results in a way non‑security people can still understand

It is small enough to run on my laptop
but deep enough to have a proper discussion about corporate password hygiene and UX vs security.
