
# SentinelForge Hardware Probe

SentinelForge Hardware Probe is my project for talking about hardware and firmware trust in a clean and concrete way.

Most security discussions focus on applications and cloud accounts but I also care about what happens below the operating system. This project lets me show that without needing to handle real firmware images or low level tools.

Instead of scanning real devices SentinelForge accepts structured reports about a fleet and highlights problems like

* secure boot disabled
* firmware vendors that are not in an approved list
* missing or disabled TPM
* bootloader hashes that do not match a known good value

## What this project does

* exposes a small HTTP API using FastAPI
* lets me register known good bootloader hashes for each hardware model
* accepts device reports for an entire fleet in one call
* evaluates each device and creates findings with
  * severity
  * human readable explanation
  * specific remediation suggestion
* calculates an overall risk score for the fleet

This lets me speak about hardware integrity and supply chain concerns in a way that is visual and easy to reason about.

## Project layout

```text
sentinelforge-hardware-probe
└── backend
    ├── sentinelforge_probe
    │   ├── __init__.py
    │   ├── main.py    FastAPI HTTP API
    │   └── engine.py  Evaluation logic and scoring
    ├── requirements.txt
    └── example_requests.http
```

## How I run it locally

From the backend folder

```bash
python -m venv .venv
source .venv/bin/activate        # On Windows I use .venv\Scripts\activate
pip install -r requirements.txt
uvicorn sentinelforge_probe.main:app --reload --port 9950
```

Then I open

* http://localhost:9950/docs to try the endpoints

## Example scenario

First I register a known good bootloader hash for a hardware model

```bash
curl -X POST http://localhost:9950/known_boot   -H "Content-Type: application/json"   -d '{
    "model": "UltraBook X1",
    "bootloader_hash": "sha256:known_good_hash_value"
  }'
```

Then I send a small fleet report

```bash
curl -X POST http://localhost:9950/scan   -H "Content-Type: application/json"   -d '{
    "fleet_id": "engineering-fleet",
    "devices": [
      {
        "id": "laptop-001",
        "model": "UltraBook X1",
        "role": "developer",
        "tags": {"owner": "alice"},
        "firmware_version": "1.0.3",
        "firmware_vendor": "vendor_trusted_a",
        "secure_boot": false,
        "bootloader_hash": "sha256:changed_hash",
        "tpm_present": true,
        "tpm_enabled": true
      },
      {
        "id": "laptop-002",
        "model": "UltraBook X1",
        "role": "developer",
        "tags": {"owner": "bob"},
        "firmware_version": "1.0.3",
        "firmware_vendor": "some_random_vendor",
        "secure_boot": true,
        "bootloader_hash": "sha256:known_good_hash_value",
        "tpm_present": false,
        "tpm_enabled": false
      }
    ]
  }'
```

The response gives me

* an overall score for the fleet
* findings for each device that has a problem
* remediation text that I can use directly in a security review

Because the rules live in a single engine file the project stays transparent. I can open the file and explain every decision rule step by step.

## How I see this evolving

If I want to grow SentinelForge I can

* connect it to real inventory sources that export hardware reports
* track scores over time so I see whether fleet health is improving
* integrate with asset management to open tickets when the risk is too high
* build a small dashboard that highlights the most problematic models or teams

Even in this focused version the project shows that I think about security from silicon and firmware up to the applications and that I care about making recommendations that teams can actually act on.
