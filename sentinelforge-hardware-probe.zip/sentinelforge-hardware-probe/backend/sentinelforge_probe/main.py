
from fastapi import FastAPI
from pydantic import BaseModel, Field
from typing import Dict, List

from .engine import HardwareProbeBrain, DeviceReport, HWScanResult, HWFinding


brain = HardwareProbeBrain()


class DeviceIn(BaseModel):
    id: str = Field(..., example="laptop-001")
    model: str = Field(..., example="UltraBook X1")
    role: str = Field(..., example="developer")
    tags: Dict[str, str] = Field(default_factory=dict)
    firmware_version: str
    firmware_vendor: str
    secure_boot: bool
    bootloader_hash: str
    tpm_present: bool
    tpm_enabled: bool


class FleetScanIn(BaseModel):
    fleet_id: str = Field(..., example="engineering-fleet")
    devices: List[DeviceIn]


class FindingOut(BaseModel):
    id: int
    device_id: str
    severity: str
    title: str
    explanation: str
    remediation: str


class FleetScanOut(BaseModel):
    fleet_id: str
    score: float
    findings: List[FindingOut]


class KnownBootIn(BaseModel):
    model: str = Field(..., example="UltraBook X1")
    bootloader_hash: str = Field(..., example="sha256:abcd1234")


app = FastAPI(
    title="SentinelForge Hardware Probe",
    version="0.1.0",
    description="My hardware and firmware posture checker for lab style device reports.",
)


@app.post("/known_boot")
def register_known_boot(payload: KnownBootIn) -> Dict[str, str]:
    brain.register_known_bootloader(payload.model, payload.bootloader_hash)
    return {"status": "ok"}


@app.post("/scan", response_model=FleetScanOut)
def scan(payload: FleetScanIn) -> FleetScanOut:
    devices = [
        DeviceReport(
            id=d.id,
            model=d.model,
            role=d.role,
            tags=d.tags,
            firmware_version=d.firmware_version,
            firmware_vendor=d.firmware_vendor,
            secure_boot=d.secure_boot,
            bootloader_hash=d.bootloader_hash,
            tpm_present=d.tpm_present,
            tpm_enabled=d.tpm_enabled,
        )
        for d in payload.devices
    ]
    result: HWScanResult = brain.scan(payload.fleet_id, devices)
    return FleetScanOut(
        fleet_id=result.fleet_id,
        score=result.score,
        findings=[
            FindingOut(
                id=f.id,
                device_id=f.device_id,
                severity=f.severity,
                title=f.title,
                explanation=f.explanation,
                remediation=f.remediation,
            )
            for f in result.findings
        ],
    )
