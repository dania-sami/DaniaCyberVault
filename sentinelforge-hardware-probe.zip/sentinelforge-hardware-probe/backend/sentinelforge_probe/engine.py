
from dataclasses import dataclass
from typing import Dict, List


@dataclass
class DeviceReport:
    id: str
    model: str
    role: str
    tags: Dict[str, str]
    firmware_version: str
    firmware_vendor: str
    secure_boot: bool
    bootloader_hash: str
    tpm_present: bool
    tpm_enabled: bool


@dataclass
class HWFinding:
    id: int
    device_id: str
    severity: str
    title: str
    explanation: str
    remediation: str


@dataclass
class HWScanResult:
    fleet_id: str
    findings: List[HWFinding]
    score: float


class HardwareProbeBrain:
    """
    SentinelForge Hardware Probe is my way to talk about hardware and firmware
    trust in a clean lab friendly way.

    It does not read real firmware images. Instead it evaluates structured reports
    about devices and highlights
    * missing secure boot
    * suspicious or unapproved vendors
    * devices without TPM
    * bootloader hashes that do not match a known good value
    """

    def __init__(self) -> None:
        self._next_id = 1
        self.known_boot_hashes: Dict[str, str] = {}
        self.approved_vendors: List[str] = ["vendor_trusted_a", "vendor_trusted_b"]

    def register_known_bootloader(self, model: str, boot_hash: str) -> None:
        self.known_boot_hashes[model] = boot_hash

    def _new_find(self, device_id: str, severity: str, title: str, explanation: str, remediation: str) -> HWFinding:
        fid = self._next_id
        self._next_id += 1
        return HWFinding(
            id=fid,
            device_id=device_id,
            severity=severity,
            title=title,
            explanation=explanation,
            remediation=remediation,
        )

    def scan(self, fleet_id: str, devices: List[DeviceReport]) -> HWScanResult:
        findings: List[HWFinding] = []

        for d in devices:
            if not d.secure_boot:
                findings.append(
                    self._new_find(
                        device_id=d.id,
                        severity="high",
                        title="Secure boot is disabled",
                        explanation="The device reports that secure boot is not enabled.",
                        remediation="Enable secure boot in firmware settings and ensure only trusted bootloaders are allowed.",
                    )
                )

            if d.firmware_vendor.lower() not in self.approved_vendors:
                findings.append(
                    self._new_find(
                        device_id=d.id,
                        severity="medium",
                        title="Firmware vendor is not in the approved list",
                        explanation=f"The vendor {d.firmware_vendor} is not present in the list of approved vendors.",
                        remediation="Review this vendor and either add it to the approved list or replace the firmware.",
                    )
                )

            if not d.tpm_present or not d.tpm_enabled:
                findings.append(
                    self._new_find(
                        device_id=d.id,
                        severity="medium",
                        title="TPM is missing or disabled",
                        explanation="Trusted Platform Module is required for strong device identity and attestation.",
                        remediation="Ensure hardware includes TPM and enable it in firmware settings.",
                    )
                )

            known = self.known_boot_hashes.get(d.model)
            if known and known != d.bootloader_hash:
                findings.append(
                    self._new_find(
                        device_id=d.id,
                        severity="critical",
                        title="Bootloader hash does not match known good value",
                        explanation="The current bootloader hash differs from the recorded known good value.",
                        remediation="Investigate this device for possible tampering and reflash from a trusted image.",
                    )
                )

        score = 0.0
        for f in findings:
            if f.severity == "critical":
                score += 25.0
            elif f.severity == "high":
                score += 15.0
            elif f.severity == "medium":
                score += 7.0
            else:
                score += 3.0

        score = min(100.0, score)
        return HWScanResult(fleet_id=fleet_id, findings=findings, score=score)
