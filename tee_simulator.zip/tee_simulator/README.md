
# Trusted Execution Environment Simulator (Mini TEE Lab)

Hi, I am Dania and I built this project to practise the concepts behind **Trusted Execution Environments (TEEs)** without touching real hardware.

Instead of Intel SGX or ARM TrustZone, I created a small TEE model in Python that:

- measures an “enclave” application (hash of its code)
- stores a sealed secret that only this enclave measurement can access
- supports simple “secure operations” that run inside the simulated enclave
- can produce a basic attestation report with a nonce and measurement

This lets me talk about isolation, measurement, sealing and attestation in a practical way.

---

## What this project does

The main script is `tee.py` and it supports three modes:

1. **Init enclave**

   ```bash
   python tee.py init --app-path enclave_app.py
   ```

   - computes a SHA-256 hash (measurement) of `enclave_app.py`
   - creates `data/enclave_state.json` with:
     - `measurement`
     - a random `seal_key` (simulated root key)
     - an example `sealed_secret` bound to that measurement

2. **Run secure operation**

   ```bash
   python tee.py secure-op --app-path enclave_app.py --data "amount=100&currency=SEK"
   ```

   - re-computes the measurement of the app
   - checks it matches the stored measurement
   - if it matches, uses the sealed key to “process” the data
   - prints a simple signed response (HMAC) representing a secure computation

3. **Attest enclave**

   ```bash
   python tee.py attest --nonce 12345
   ```

   - prints a JSON attestation report with:
     - `measurement`
     - `nonce`
     - `signature` (HMAC using the seal key)
   - this simulates a remote verifier checking that the enclave is running the expected code

There is also a small `enclave_app.py` example included.

---

## Project structure

```text
tee_simulator/
  README.md
  requirements.txt
  tee.py              # main TEE simulator interface
  enclave_app.py      # example enclave "application"
  data/
```

---

## Installation

```bash
python3 -m venv venv
source venv/bin/activate       # Windows  venv\Scripts\activate
pip install -r requirements.txt
```

---

## Step 1  Initialise the enclave

```bash
python tee.py init --app-path enclave_app.py
```

This will create `data/enclave_state.json` with the initial measurement and a sealed secret.

---

## Step 2  Run a secure operation

```bash
python tee.py secure-op --app-path enclave_app.py --data "amount=250&currency=EUR"
```

You will see:

- the measurement being checked
- a simulated “secure operation” result with an HMAC
- confirmation that the operation was executed inside the simulated TEE context

---

## Step 3  Get an attestation report

```bash
python tee.py attest --nonce 987654
```

The script prints a JSON report to stdout with:

- `measurement`
- `nonce`
- `signature` (HMAC over measurement + nonce)

In a real system, a remote verifier would verify that signature and compare the measurement to a known good value.

---

## Why this project matters to me

TEEs are central to modern confidential computing.

With this project I can demonstrate that I:

- understand the concepts of measurement, sealing and attestation
- can model them in code in a clean, explainable way
- can talk about the trust assumptions and limitations

Even though the simulator is small, it is a great conversation starter for secure enclaves, confidential computing and hardware-assisted security.
