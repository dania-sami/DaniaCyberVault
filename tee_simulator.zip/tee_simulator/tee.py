
import argparse
import hashlib
import hmac
import json
import os
import secrets
from pathlib import Path

DATA_DIR = Path("data")
STATE_FILE = DATA_DIR / "enclave_state.json"

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            h.update(chunk)
    return h.hexdigest()

def load_state():
    if not STATE_FILE.is_file():
        raise SystemExit(f"Enclave state file not found. Run 'init' first ({STATE_FILE}).")
    with STATE_FILE.open("r", encoding="utf-8") as f:
        return json.load(f)

def save_state(state):
    DATA_DIR.mkdir(exist_ok=True)
    with STATE_FILE.open("w", encoding="utf-8") as f:
        json.dump(state, f, indent=2)

def init_enclave(app_path: Path):
    if not app_path.is_file():
        raise SystemExit(f"Enclave app file not found: {app_path}")
    measurement = sha256_file(app_path)
    seal_key = secrets.token_bytes(32)
    # example sealed secret (in real TEEs this would be encrypted with hardware keys)
    sealed_secret = secrets.token_hex(16)
    state = {
        "measurement": measurement,
        "seal_key": seal_key.hex(),
        "sealed_secret": sealed_secret,
    }
    save_state(state)
    print(f"[info] Enclave initialised.")
    print(f"[info] Measurement = {measurement}")
    print(f"[info] Sealed secret = {sealed_secret}")

def verify_measurement(app_path: Path, expected_measurement: str):
    if not app_path.is_file():
        raise SystemExit(f"Enclave app file not found: {app_path}")
    m = sha256_file(app_path)
    if m != expected_measurement:
        raise SystemExit(
            f"[error] Measurement mismatch. Expected {expected_measurement}, got {m}. "
            "Enclave code seems modified."
        )
    print("[info] Measurement verified. Enclave code matches expected state.")

def secure_operation(app_path: Path, data: str):
    state = load_state()
    verify_measurement(app_path, state["measurement"])
    seal_key = bytes.fromhex(state["seal_key"])
    sealed_secret = state["sealed_secret"]

    # Simulate a secure computation as an HMAC over the input data and sealed secret
    msg = f"data={data}&sealed_secret={sealed_secret}".encode("utf-8")
    tag = hmac.new(seal_key, msg, hashlib.sha256).hexdigest()
    print("[info] Secure operation executed inside simulated enclave context.")
    print("[result]")
    print(json.dumps({"input": data, "sealed_secret_used": True, "hmac": tag}, indent=2))

def attest(nonce: str):
    state = load_state()
    measurement = state["measurement"]
    seal_key = bytes.fromhex(state["seal_key"])
    payload = f"measurement={measurement}&nonce={nonce}".encode("utf-8")
    signature = hmac.new(seal_key, payload, hashlib.sha256).hexdigest()
    report = {
        "measurement": measurement,
        "nonce": nonce,
        "signature": signature,
    }
    print(json.dumps(report, indent=2))

def main():
    parser = argparse.ArgumentParser(description="Trusted Execution Environment (TEE) Simulator")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_init = sub.add_parser("init", help="initialise enclave with app measurement")
    p_init.add_argument("--app-path", required=True, help="Path to enclave application file (e.g. enclave_app.py)")

    p_sec = sub.add_parser("secure-op", help="run a secure operation in the enclave")
    p_sec.add_argument("--app-path", required=True, help="Path to enclave application file (e.g. enclave_app.py)")
    p_sec.add_argument("--data", required=True, help="Input data string for the secure operation")

    p_att = sub.add_parser("attest", help="produce an attestation report")
    p_att.add_argument("--nonce", required=True, help="Nonce provided by remote verifier")

    args = parser.parse_args()
    DATA_DIR.mkdir(exist_ok=True)

    if args.cmd == "init":
        init_enclave(Path(args.app_path))
    elif args.cmd == "secure-op":
        secure_operation(Path(args.app_path), args.data)
    elif args.cmd == "attest":
        attest(args.nonce)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
