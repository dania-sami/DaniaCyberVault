
from dataclasses import dataclass
from typing import Dict, List


@dataclass
class EnvironmentProfile:
    id: int
    name: str
    meta: Dict[str, str]
    metrics: Dict[str, float]


@dataclass
class PropagationAssessment:
    env_id: int
    name: str
    outbreak_risk: float
    band: str
    reasons: List[str]


class VulnCastBrain:
    """
    VulnCast is my outbreak style reasoning engine for zero day propagation.

    It takes high level metrics about an environment and estimates how a future
    zero day might move through it in the first wave.
    """

    def __init__(self) -> None:
        self._next_id = 1
        self.envs: Dict[int, EnvironmentProfile] = {}

    def register_env(self, name: str, meta: Dict[str, str], metrics: Dict[str, float]) -> EnvironmentProfile:
        eid = self._next_id
        self._next_id += 1
        env = EnvironmentProfile(
            id=eid,
            name=name,
            meta=meta,
            metrics=metrics,
        )
        self.envs[eid] = env
        return env

    def assess(self, env_id: int) -> PropagationAssessment:
        env = self.envs[env_id]
        m = env.metrics
        reasons: List[str] = []
        risk = 0.0

        internet_exposure = float(m.get("internet_exposure_ratio", 0.0))
        patch_delay = float(m.get("avg_patch_delay_days", 0.0))
        lateral_exposure = float(m.get("lateral_exposure_score", 0.0))
        shared_dependency = float(m.get("shared_dependency_score", 0.0))
        legacy_fraction = float(m.get("legacy_system_fraction", 0.0))
        identity_flatness = float(m.get("identity_flatness_score", 0.0))

        if internet_exposure > 0.3:
            inc = (internet_exposure - 0.3) * 60.0
            risk += inc
            reasons.append(f"High ratio of internet facing assets ({internet_exposure:.2f}).")
        if patch_delay > 7.0:
            inc = min(30.0, (patch_delay - 7.0) * 1.5)
            risk += inc
            reasons.append(f"Slow average patch delay of {patch_delay:.1f} days.")
        if lateral_exposure > 0.5:
            inc = (lateral_exposure - 0.5) * 50.0
            risk += inc
            reasons.append("Lateral movement is relatively easy according to exposure score.")
        if shared_dependency > 0.4:
            inc = (shared_dependency - 0.4) * 50.0
            risk += inc
            reasons.append("Many systems depend on the same critical components.")
        if legacy_fraction > 0.2:
            inc = (legacy_fraction - 0.2) * 40.0
            risk += inc
            reasons.append("Significant fraction of the estate runs legacy systems.")
        if identity_flatness > 0.4:
            inc = (identity_flatness - 0.4) * 40.0
            risk += inc
            reasons.append("Identity model is quite flat, which helps attackers escalate.")

        risk = max(0.0, min(100.0, risk))

        if risk >= 80.0:
            band = "outbreak_very_likely"
        elif risk >= 60.0:
            band = "outbreak_likely_without_strong_controls"
        elif risk >= 40.0:
            band = "outbreak_possible_in_some_segments"
        elif risk >= 20.0:
            band = "outbreak_unlikely_but_possible"
        else:
            band = "outbreak_unlikely_under_current_assumptions"

        if not reasons:
            reasons.append("Metrics do not show strong drivers for rapid zero day propagation.")

        return PropagationAssessment(
            env_id=env.id,
            name=env.name,
            outbreak_risk=round(risk, 2),
            band=band,
            reasons=reasons,
        )
