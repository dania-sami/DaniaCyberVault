
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Dict, List

from .engine import VulnCastBrain, EnvironmentProfile, PropagationAssessment


brain = VulnCastBrain()


class EnvIn(BaseModel):
    name: str = Field(..., example="core-enterprise-environment")
    meta: Dict[str, str] = Field(default_factory=dict)
    metrics: Dict[str, float] = Field(
        default_factory=dict,
        description=(
            "Metrics like internet_exposure_ratio, avg_patch_delay_days, "
            "lateral_exposure_score, shared_dependency_score, "
            "legacy_system_fraction, identity_flatness_score"
        ),
    )


class EnvOut(BaseModel):
    id: int
    name: str
    meta: Dict[str, str]
    metrics: Dict[str, float]


class PropagationOut(BaseModel):
    env_id: int
    name: str
    outbreak_risk: float
    band: str
    reasons: List[str]


app = FastAPI(
    title="VulnCast Zero-Day Propagation Atlas",
    version="0.1.0",
    description="My engine for reasoning about zero day outbreak risk across an environment.",
)


@app.post("/envs", response_model=EnvOut)
def register_env(payload: EnvIn) -> EnvOut:
    env: EnvironmentProfile = brain.register_env(
        name=payload.name,
        meta=payload.meta,
        metrics=payload.metrics,
    )
    return EnvOut(
        id=env.id,
        name=env.name,
        meta=env.meta,
        metrics=env.metrics,
    )


@app.post("/assess", response_model=PropagationOut)
def assess(env_id: int) -> PropagationOut:
    if env_id not in brain.envs:
        raise HTTPException(status_code=404, detail="Environment not found")
    res: PropagationAssessment = brain.assess(env_id)
    return PropagationOut(
        env_id=res.env_id,
        name=res.name,
        outbreak_risk=res.outbreak_risk,
        band=res.band,
        reasons=res.reasons,
    )
