
# VulnCast Zero-Day Propagation Atlas

VulnCast is my outbreak style thinking tool for zero day vulnerabilities.

When a new vulnerability appears, the most important question is often not
only "are we affected" but "if an attacker uses it, how far could they get
before we notice".

VulnCast takes a set of environment level metrics and turns them into an
estimate for how a hypothetical zero day might propagate in the first wave.

## What this project does

* lets me register environment profiles with
  * a name
  * metadata
  * numeric metrics such as
    * `internet_exposure_ratio`
    * `avg_patch_delay_days`
    * `lateral_exposure_score`
    * `shared_dependency_score`
    * `legacy_system_fraction`
    * `identity_flatness_score`
* calculates an outbreak risk score between zero and one hundred
* assigns a band such as
  * `outbreak_unlikely_under_current_assumptions`
  * `outbreak_unlikely_but_possible`
  * `outbreak_possible_in_some_segments`
  * `outbreak_likely_without_strong_controls`
  * `outbreak_very_likely`
* returns reasons that make it clear why the score ended up there

The scoring model is intentionally simple and lives in `engine.py` so that I
can explain every step and refine it as I learn more.

## Project layout

```text
vulncast-zero-day-propagation-atlas
└── backend
    ├── vulncast_atlas
    │   ├── __init__.py
    │   ├── engine.py  Environment model and outbreak risk scoring
    │   └── main.py    FastAPI HTTP API
    ├── requirements.txt
    └── example_requests.http
```

## How I run it locally

From the backend folder

```bash
python -m venv .venv
source .venv/bin/activate        # On Windows I use .venv\Scripts\activate
pip install -r requirements.txt
uvicorn vulncast_atlas.main:app --reload --port 9904
```

Then I open

* http://localhost:9904/docs to create environments and assess risk

## Example environment I use in discussions

I register an environment profile with realistic but not perfect metrics.

```bash
curl -X POST http://localhost:9904/envs   -H "Content-Type: application/json"   -d '{
    "name": "core-enterprise-environment",
    "meta": {
      "region": "eu"
    },
    "metrics": {
      "internet_exposure_ratio": 0.45,
      "avg_patch_delay_days": 21,
      "lateral_exposure_score": 0.7,
      "shared_dependency_score": 0.6,
      "legacy_system_fraction": 0.3,
      "identity_flatness_score": 0.5
    }
  }'
```

Then I ask VulnCast to assess it.

```bash
curl -X POST "http://localhost:9904/assess?env_id=1"
```

The response gives me

* an outbreak risk score
* a band, likely `outbreak_likely_without_strong_controls`
* reasons that mention internet exposure, slow patching and lateral exposure

This is exactly the view I need when I try to prioritise investments and
explain zero day risk to non technical stakeholders.

## Possible future work

VulnCast could be extended with

* integration to real CMDB / asset data
* per segment and per application views
* simple visualisations of propagation scenarios

Even in its current form it is a strong conceptual tool and shows how I think
about dynamic risk instead of static vulnerability lists.
