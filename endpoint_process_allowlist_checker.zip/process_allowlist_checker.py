import argparse
import csv
import json
from collections import defaultdict

def load_allowlist(path: str):
    with open(path) as f:
        data = json.load(f)
    return set(data.get("allowed", []))

def check_processes(csv_path: str, allowlist_path: str):
    allowed = load_allowlist(allowlist_path)
    unknown = defaultdict(set)

    with open(csv_path, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            host = row.get("host", "unknown")
            proc = row.get("process_name", "").strip()
            if not proc:
                continue
            if proc not in allowed:
                unknown[host].add(proc)

    for host, procs in unknown.items():
        print(f"[+] Host: {host}")
        for p in sorted(procs):
            print(f"    not in allowlist: {p}")
        print()

def main():
    parser = argparse.ArgumentParser(description="Endpoint Process Allowlist Checker by Dania")
    parser.add_argument("--csv", required=True, help="CSV with host,process_name")
    parser.add_argument("--allowlist", required=True, help="JSON with allowed process names")
    args = parser.parse_args()
    check_processes(args.csv, args.allowlist)

if __name__ == "__main__":
    main()
