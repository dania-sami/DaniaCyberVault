# Endpoint Process Allowlist Checker

This project is a small script that compares a list of running processes against a simple allowlist.

Instead of talking to a real endpoint, I keep it file based:

- A CSV file with `host`, `process_name`
- A JSON file with allowed process names

The script prints processes that are not on the allowlist for each host. It is a simple way to show the idea of application control and allowlisting.

## Files

- `process_allowlist_checker.py` – main script
- `allowed_processes.json` – example allowlist
- `demo_processes.csv` – example process list

## Usage

```bash
python process_allowlist_checker.py --csv demo_processes.csv --allowlist allowed_processes.json
```
