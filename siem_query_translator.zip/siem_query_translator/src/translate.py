from __future__ import annotations

import argparse
import re
from typing import Dict


def detect_time_window(text: str) -> Dict[str, str]:
    if "last 24 hours" in text or "past 24 hours" in text:
        return {"window": "24h"}
    if "last 7 days" in text or "past 7 days" in text:
        return {"window": "7d"}
    if "last hour" in text:
        return {"window": "1h"}
    return {"window": "24h"}


def main() -> None:
    parser = argparse.ArgumentParser(description="Natural language to SIEM query translator (rule-based)")
    parser.add_argument("--text", type=str, required=True, help="Natural language description")
    args = parser.parse_args()

    raw = args.text.strip()
    text = raw.lower()

    ctx: Dict[str, str] = {}
    ctx.update(detect_time_window(text))

    ip_match = re.search(r"(\d+\.\d+\.\d+\.\d+)", text)
    if ip_match:
        ctx["ip"] = ip_match.group(1)

    domain_match = re.search(r"([a-z0-9\-]+\.[a-z]{2,})", text)
    if domain_match and "ip" not in ctx:
        ctx["domain"] = domain_match.group(1)

    if "failed login" in text or "failed logins" in text or "logon failure" in text:
        ctx["scenario"] = "failed_logins"
    elif "successful login" in text or "successful logins" in text:
        ctx["scenario"] = "successful_logins"
    elif "dns" in text:
        ctx["scenario"] = "dns_queries"
    elif "http 500" in text or "500 errors" in text:
        ctx["scenario"] = "http_500"
    else:
        ctx["scenario"] = "generic"

    window = ctx.get("window", "24h")
    ip = ctx.get("ip")
    domain = ctx.get("domain")
    scenario = ctx["scenario"]

    if scenario == "failed_logins":
        kql = f"SecurityEvent | where EventID in (4625) | where TimeGenerated > ago({window})"
        spl = f'index=security EventID=4625 earliest=-{window}'
        if ip:
            kql += f" | where IpAddress == '{ip}'"
            spl += f' src_ip="{ip}"'
    elif scenario == "successful_logins":
        kql = f"SecurityEvent | where EventID in (4624) | where TimeGenerated > ago({window})"
        spl = f'index=security EventID=4624 earliest=-{window}'
        if ip:
            kql += f" | where IpAddress == '{ip}'"
            spl += f' src_ip="{ip}"'
    elif scenario == "dns_queries":
        kql = f"DnsEvents | where TimeGenerated > ago({window})"
        spl = f'index=dns earliest=-{window}'
        if domain:
            kql += f" | where QueryName contains '{domain}'"
            spl += f' query="{domain}"'
    elif scenario == "http_500":
        kql = f'AppRequests | where TimeGenerated > ago({window}) | where ResultCode == 500'
        spl = f'index=web status=500 earliest=-{window}'
    else:
        kql = f"/* generic search */ SecurityEvent | where TimeGenerated > ago({window})"
        spl = f"search index=* earliest=-{window}"

    print(f"Input: {raw}")
    print("
KQL-like query:")
    print(kql)
    print("
Splunk-like query:")
    print(spl)


if __name__ == "__main__":
    main()
