# AI-Style Query Translator for SIEM (Rule-Based)

Hi, I am Dania Sami 👋

One of the most fun ideas in security is:  
“Can I just talk to my SIEM in natural language?”

For this portfolio project, I built a small **AI-style query translator** that
takes a natural language description and outputs example queries in:

- a KQL-like syntax
- a Splunk-style syntax

It is implemented with rule-based parsing, but structured in a way that
could later be replaced by a language model. For now, it is:

- 100% local
- deterministic
- very easy to understand

---

## What this tool supports

It currently handles simple patterns such as:

- "failed logins last 24 hours"
- "successful logins from IP 1.2.3.4"
- "dns queries for example.com"
- "http 500 errors in the last 7 days"

Internally it:

- normalises the text
- recognises concepts (logon failure, time window, IPs, domains)
- maps them into query templates

---

## How to run

```bash
cd siem_query_translator

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt   # stdlib only
```

Translate a query:

```bash
python -m src.translate --text "failed logins last 24 hours"
```

You will see both:

- a KQL-like query
- a Splunk-like query

Try more:

```bash
python -m src.translate --text "http 500 errors in the last 7 days"
python -m src.translate --text "successful logins from ip 10.0.0.5"
python -m src.translate --text "dns queries for example.com"
```

---

## Project structure

```text
siem_query_translator/
  ├─ README.md
  ├─ requirements.txt
  └─ src/
       ├─ __init__.py
       └─ translate.py
```

---

## Why I built this

This project lets me talk about:

- how SIEM queries are structured
- how to translate vague intent into concrete filters
- how an LLM-powered assistant *could* be integrated into detection workflows

Even though it is rule-based, the design is intentionally "AI friendly".
