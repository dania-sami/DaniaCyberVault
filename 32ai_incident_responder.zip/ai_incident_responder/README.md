# AI Assisted Incident Responder

Hi, I am Dania Sami 👋

In this project I wanted to build something that feels close to what real
security operations teams are experimenting with right now.

**AI Assisted Incident Responder** is a small framework where I:

* collect security style logs from different sources
* normalise them into a simple event format
* slice them by time window and suspected incident
* send them through an AI assistant
* receive an incident summary, affected assets and triage checklist

The goal is not to replace a full SIEM or SOAR platform. The goal is to show
that I understand how to structure logs, design prompts and use AI to assist
the human incident responder.

> ⚠️ This project is for learning and demo use. It uses synthetic logs in the
> `data/` folder and a small text based workflow. It is read only and does not
> change any system.

---

## What this tool does

At a high level the tool:

1. **Loads and normalises logs**

   Under `data/` there are small synthetic CSV files that simulate:

   * firewall logs
   * endpoint detection logs
   * authentication logs

   The loader converts them into a unified event structure with fields like
   timestamp, source, host, severity and message.

2. **Builds an incident view**

   From the command line I can say:

   ```bash
   python -m src.summarize --since "2025-02-01 10:00" --until "2025-02-01 13:00"
   ```

   The tool filters events into that window and sorts them by time. This slice
   becomes the context for one potential incident.

3. **Sends the context to an AI assistant**

   The core of the project is in `src/ai_client.py`. It has two modes:

   * if an `OPENAI_API_KEY` is present it calls a real model through the
     `openai` Python package
   * if there is no API key it falls back to a simple rule based summariser
     so the project still runs everywhere

   The AI is prompted to act as an **incident responder** and to return:

   * a short incident summary
   * a list of affected hosts and users
   * a recommended triage checklist in plain text

4. **Writes a structured report**

   The result is printed in the terminal and also written to a text file in
   `reports/` with:

   * metadata about the time window and number of events
   * the AI produced summary
   * the list of affected assets
   * the triage checklist

This is a compact but realistic blueprint for how AI can sit on top of log
data and help human analysts.

---

## Quick start

You need Python 3.10 or newer.

```bash
# 1. Create and activate a virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt
```

If you want to use a real AI model through the OpenAI package:

```bash
export OPENAI_API_KEY="your_key_here"  # on macOS and Linux
# or set the variable in your shell profile
```

Then run:

```bash
# basic example using the sample logs
python -m src.summarize --since "2025-02-01 10:00" --until "2025-02-01 13:00"
```

This will print an incident style summary and also write it into the `reports/`
folder.

If you do not set `OPENAI_API_KEY` the code will still run. In that case it
uses a simple local summariser that looks at severities and hosts to build a
basic summary. This keeps the project easy to run during reviews.

---

## Project structure

```text
ai_incident_responder/
  ├─ README.md
  ├─ requirements.txt
  ├─ data/
  │    ├─ firewall_logs.csv
  │    ├─ endpoint_logs.csv
  │    └─ auth_logs.csv
  ├─ src/
  │    ├─ __init__.py
  │    ├─ config.py
  │    ├─ log_loader.py
  │    ├─ ai_client.py
  │    └─ summarize.py
  └─ reports/
```

* `config.py` holds basic paths and time parsing helpers
* `log_loader.py` knows how to read and normalise the sample logs
* `ai_client.py` wraps the AI call and the offline fallback mode
* `summarize.py` is the command line entry point

---

## How I would extend this

If I turn this into a larger research or company project I would:

* connect it to real SIEM or data lake sources instead of CSV files
* add small templates for common incident types like brute force login or
  lateral movement
* experiment with function calling style outputs and structured JSON for
  triage checklists
* integrate it with my mini SIEM project so that every alert can be passed
  through this AI assistant as part of the alert workflow

For me this project is a way to show that I can think like a **DFIR engineer**
and a **machine learning engineer** at the same time and that I care about
helping humans, not replacing them.
