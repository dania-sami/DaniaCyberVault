from __future__ import annotations

import argparse
from pathlib import Path

from rich import print

from .ai_client import AIClient
from .config import REPORT_DIR, TimeWindow, parse_time
from .log_loader import filter_events, load_all_events


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "AI Assisted Incident Responder: build an incident view for a given time window "
            "and generate a human friendly summary with an AI helper."
        )
    )
    parser.add_argument(
        "--since",
        type=str,
        default=None,
        help='Start of time window, for example "2025-02-01 10:00".',
    )
    parser.add_argument(
        "--until",
        type=str,
        default=None,
        help='End of time window, for example "2025-02-01 13:00".',
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    window = TimeWindow(since=parse_time(args.since), until=parse_time(args.until))

    print("[bold blue]Loading events from sample logs...[/bold blue]")
    events = load_all_events()
    filtered = filter_events(events, window)
    print(f"Total events loaded: {len(events)}")
    print(f"Events in selected window: {len(filtered)}")

    client = AIClient()
    summary = client.summarize_incident(filtered)

    print()
    print("[bold green]Incident summary[/bold green]")
    print(summary.summary)
    print()
    print("[bold]Affected hosts[/bold]")
    if summary.affected_hosts:
        for h in summary.affected_hosts:
            print(f"  • {h}")
    else:
        print("  (none extracted)")

    print()
    print("[bold]Likely users[/bold]")
    if summary.likely_users:
        for u in summary.likely_users:
            print(f"  • {u}")
    else:
        print("  (none extracted)")

    print()
    print("[bold]Triage checklist[/bold]")
    for step in summary.triage_steps:
        print(f"  • {step}")

    # Write simple text report
    report_path = REPORT_DIR / "incident_summary.txt"
    with report_path.open("w", encoding="utf-8") as f:
        f.write("Incident summary\n")
        f.write(summary.summary + "\n\n")
        f.write("Affected hosts\n")
        for h in summary.affected_hosts:
            f.write(f"- {h}\n")
        if not summary.affected_hosts:
            f.write("(none extracted)\n")
        f.write("\nLikely users\n")
        for u in summary.likely_users:
            f.write(f"- {u}\n")
        if not summary.likely_users:
            f.write("(none extracted)\n")
        f.write("\nTriage checklist\n")
        for step in summary.triage_steps:
            f.write(f"- {step}\n")

    print()
    print(f"[bold green]Report written to {report_path}[/bold green]")


if __name__ == "__main__":
    main()
