from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional

import pandas as pd

from .config import DATA_DIR, TimeWindow


@dataclass
class Event:
    timestamp: datetime
    source: str
    host: str
    severity: str
    message: str
    raw: dict


def _load_csv(path, source: str) -> List[Event]:
    df = pd.read_csv(path, parse_dates=["timestamp"])
    events: List[Event] = []
    for _, row in df.iterrows():
        events.append(
            Event(
                timestamp=row["timestamp"].to_pydatetime(),
                source=source,
                host=str(row.get("host", "unknown")),
                severity=str(row.get("severity", "info")),
                message=str(row.get("message", "")),
                raw=row.to_dict(),
            )
        )
    return events


def load_all_events() -> List[Event]:
    events: List[Event] = []
    events += _load_csv(DATA_DIR / "firewall_logs.csv", source="firewall")
    events += _load_csv(DATA_DIR / "endpoint_logs.csv", source="endpoint")
    events += _load_csv(DATA_DIR / "auth_logs.csv", source="auth")
    events.sort(key=lambda e: e.timestamp)
    return events


def filter_events(events: List[Event], window: TimeWindow) -> List[Event]:
    result: List[Event] = []
    for e in events:
        if window.since and e.timestamp < window.since:
            continue
        if window.until and e.timestamp > window.until:
            continue
        result.append(e)
    return result
