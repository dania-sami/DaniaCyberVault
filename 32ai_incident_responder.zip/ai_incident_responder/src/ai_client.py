from __future__ import annotations

import os
from dataclasses import dataclass
from typing import List, Tuple

from pydantic import BaseModel

from .config import now_utc_str
from .log_loader import Event


class IncidentSummary(BaseModel):
    summary: str
    affected_hosts: List[str]
    likely_users: List[str]
    triage_steps: List[str]


@dataclass
class AIClientConfig:
    model: str = "gpt-4o-mini"
    temperature: float = 0.2


class AIClient:
    def __init__(self, config: AIClientConfig | None = None) -> None:
        self.config = config or AIClientConfig()
        self.api_key = os.getenv("OPENAI_API_KEY")

        # Lazy import to avoid hard dependency at import time
        self._openai = None
        if self.api_key:
            try:
                import openai

                openai.api_key = self.api_key
                self._openai = openai
            except Exception:
                self._openai = None

    def _build_prompt(self, events: List[Event]) -> str:
        header = (
            "You are acting as an experienced incident responder in a security "
            "operations team. You will receive a chronological list of log events "
            "from multiple sources. Based on these events you must write:
"
            "1. A short plain language incident summary with timeline.
"
            "2. A list of affected hosts and any users mentioned.
"
            "3. A practical triage checklist with concrete actions.

"
            "Events:
"
        )
        lines = []
        for e in events:
            lines.append(
                f"[{e.timestamp.isoformat()}] source={e.source} host={e.host} "
                f"severity={e.severity} message={e.message}"
            )
        return header + "
".join(lines)

    def _parse_llm_text(self, text: str) -> IncidentSummary:
        # Very simple heuristic parser for bullet like outputs
        summary_lines: List[str] = []
        triage_steps: List[str] = []
        affected_hosts: List[str] = []
        likely_users: List[str] = []

        section = "summary"
        for raw_line in text.splitlines():
            line = raw_line.strip()
            lower = line.lower()
            if not line:
                continue
            if "triage" in lower and "step" in lower:
                section = "triage"
                continue
            if "affected host" in lower or "assets" in lower:
                section = "hosts"
                continue
            if "user" in lower and "suspicious" in lower:
                section = "users"
                continue

            if section == "summary":
                summary_lines.append(line)
            elif section == "triage":
                triage_steps.append(line.lstrip("-•* "))
            elif section == "hosts":
                affected_hosts.append(line.lstrip("-•* "))
            elif section == "users":
                likely_users.append(line.lstrip("-•* "))

        if not triage_steps:
            triage_steps = [
                "Isolate suspected hosts from the network if possible.",
                "Collect full logs from firewall, endpoint and authentication systems.",
                "Reset credentials for any suspicious user accounts.",
                "Document timeline and notify the appropriate stakeholders.",
            ]

        return IncidentSummary(
            summary=" ".join(summary_lines) or text[:500],
            affected_hosts=affected_hosts or [],
            likely_users=likely_users or [],
            triage_steps=triage_steps,
        )

    def summarize_incident(self, events: List[Event]) -> IncidentSummary:
        if not events:
            return IncidentSummary(
                summary="No events in the selected time window. Nothing to analyse.",
                affected_hosts=[],
                likely_users=[],
                triage_steps=[],
            )

        if not self.api_key or self._openai is None:
            return self._fallback_summary(events)

        prompt = self._build_prompt(events)

        try:
            resp = self._openai.ChatCompletion.create(
                model=self.config.model,
                temperature=self.config.temperature,
                messages=[
                    {"role": "system", "content": "You are a calm and precise incident responder."},
                    {"role": "user", "content": prompt},
                ],
            )
            text = resp["choices"][0]["message"]["content"]
        except Exception as e:
            text = (
                f"LLM call failed at {now_utc_str()} with error: {e}. "
                "Falling back to simple summary."
            )
            return self._fallback_summary(events, extra_prefix=text)

        return self._parse_llm_text(text)

    def _fallback_summary(self, events: List[Event], extra_prefix: str | None = None) -> IncidentSummary:
        # Simple heuristic: look at severities and hosts
        hosts: set[str] = set()
        users: set[str] = set()
        high_events: List[Event] = []
        for e in events:
            hosts.add(e.host)
            if "user" in e.message.lower():
                users.add(e.message)
            if str(e.severity).lower() in {"high", "critical"} or "failed" in e.message.lower():
                high_events.append(e)

        if high_events:
            first = high_events[0]
            last = high_events[-1]
            summary = (
                f"Detected {len(high_events)} high or suspicious events between "
                f"{first.timestamp.isoformat()} and {last.timestamp.isoformat()} "
                f"affecting hosts {', '.join(sorted(hosts))}."
            )
        else:
            first = events[0]
            last = events[-1]
            summary = (
                f"Observed {len(events)} events between {first.timestamp.isoformat()} and "
                f"{last.timestamp.isoformat()} with no clearly critical spikes."
            )

        if extra_prefix:
            summary = extra_prefix + "\n" + summary

        triage_steps = [
            "Review high severity events in detail and confirm whether they represent real attacks.",
            "Check authentication failures for possible brute force or password spraying.",
            "Look for lateral movement signs such as logons from unusual hosts.",
            "If needed, increase logging around the affected hosts and users.",
        ]

        return IncidentSummary(
            summary=summary,
            affected_hosts=sorted(hosts),
            likely_users=sorted(users),
            triage_steps=triage_steps,
        )
