from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Optional


BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
REPORT_DIR = BASE_DIR / "reports"
REPORT_DIR.mkdir(parents=True, exist_ok=True)


@dataclass
class TimeWindow:
    since: Optional[datetime] = None
    until: Optional[datetime] = None


def parse_time(value: str | None) -> Optional[datetime]:
    if value is None:
        return None
    # Simple flexible parser for "YYYY-mm-dd HH:MM"
    return datetime.fromisoformat(value)


def now_utc_str() -> str:
    return datetime.utcnow().isoformat() + "Z"
