import argparse
import os
from datetime import datetime, timedelta

def check_backups(path: str, max_age_days: int):
    if not os.path.isdir(path):
        print("[-] Path is not a directory")
        return

    backups = []
    for name in os.listdir(path):
        full = os.path.join(path, name)
        if os.path.isfile(full):
            mtime = os.path.getmtime(full)
            backups.append((name, mtime))

    if not backups:
        print("[+] No backup files found.")
        return

    backups.sort(key=lambda x: x[1], reverse=True)
    print("[+] Backups:")
    for name, mtime in backups:
        dt = datetime.fromtimestamp(mtime)
        print(f"    {name}  {dt.isoformat(sep=' ', timespec='seconds')}")

    newest_name, newest_mtime = backups[0]
    newest_dt = datetime.fromtimestamp(newest_mtime)
    age = datetime.now() - newest_dt
    print()
    print(f"[+] Newest backup: {newest_name} ({newest_dt.isoformat(sep=' ', timespec='seconds')})")
    print(f"[+] Age: {age.days} day(s)")

    if age > timedelta(days=max_age_days):
        print("[!] Warning: newest backup is older than max-age-days threshold")

def main():
    parser = argparse.ArgumentParser(description="Backup Verification Tool by Dania")
    parser.add_argument("--path", required=True, help="Path to backup folder")
    parser.add_argument("--max-age-days", type=int, default=7, help="Max acceptable age in days")
    args = parser.parse_args()
    check_backups(args.path, args.max_age_days)

if __name__ == "__main__":
    main()
