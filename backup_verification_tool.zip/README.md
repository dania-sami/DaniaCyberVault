# Backup Verification Tool

This is a small script I use to think about backup hygiene from a security and reliability point of view.

Given a directory with backup files, it:

- Lists backups sorted by modification time
- Highlights the newest backup
- Warns if the newest backup is older than a threshold (for example 7 days)

This is good for talking about disaster recovery and backup freshness.

## Usage

```bash
python backup_verify.py --path backups --max-age-days 7
```

The script does not modify any files, it just reports what it sees.
