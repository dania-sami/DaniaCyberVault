
# Honeypot Network with Automated Intelligence Extraction

Hi, I am Dania and I built this project to explore **honeypots** and how to turn raw attacker traffic into useful intelligence.

Instead of deploying real services, I simulate:

- multiple honey services (SSH, HTTP, DB)
- attacker sessions with commands, URLs and payloads
- automatic classification of attacker behaviour

The goal is to go from logs to “what type of attacker is this and what are they trying to do?”

---

## What this project does

The main script is `honeypot_lab.py`. It:

1. Generates a demo dataset `data/honeypot_sessions.csv` with columns:
   - `session_id`
   - `src_ip`
   - `service` (ssh, http, db)
   - `raw_input`
   - `timestamp`
2. Classifies each session into categories:
   - `scanner`
   - `brute_force`
   - `exploit_attempt`
   - `malware_download`
3. Extracts simple intelligence:
   - top attacker IPs per category
   - most common tools and paths (e.g. `/wp-login.php`, `wget http://...`)
4. Writes results to:
   - `data/honeypot_sessions_labeled.csv`
   - and prints a human readable summary.

---

## Project structure

```text
honeypot_intel_lab/
  README.md
  requirements.txt
  honeypot_lab.py
  data/
```

I use only the standard library so it is easy to run anywhere.

---

## Installation

```bash
python3 -m venv venv
source venv/bin/activate            # Windows  venv\Scripts\activate
pip install -r requirements.txt
```

---

## Usage

```bash
python honeypot_lab.py demo
```

You will see:

- how many sessions were generated
- a table of counts per behaviour category
- top source IPs per category

You can then open the CSV files in any tool to inspect the raw inputs.

---

## Why this project matters to me

Honeypots are a powerful way to learn about attackers without risking production systems.

With this project I can show that I:

- understand typical attacker behaviour patterns
- can extract useful labels and statistics
- can describe how defenders turn “noise” into intelligence

It’s a small but complete end to end honeypot analysis pipeline.
