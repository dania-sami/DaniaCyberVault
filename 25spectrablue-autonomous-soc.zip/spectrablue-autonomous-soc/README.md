
# SpectraBlue Autonomous SOC

SpectraBlue Autonomous SOC is a small tier one security operations assistant.

It takes raw alerts from tools such as firewalls SIEM or EDR and automatically

* calculates a priority score
* chooses an action ignore monitor investigate or escalate
* generates short human readable reasons
* proposes concrete next steps like a mini runbook

This lets you demonstrate what an autonomous SOC helper could look like without needing an entire SIEM deployment.

## Project layout

```text
spectrablue-autonomous-soc
└── backend
    ├── spectrablue_soc
    │   ├── __init__.py
    │   ├── main.py     FastAPI app
    │   ├── engine.py   Triage brain
    │   └── store.py    In memory store
    ├── requirements.txt
    └── example_requests.http
```

## Running the backend

From the backend folder

```bash
python -m venv .venv
source .venv/bin/activate        # On Windows use .venv\Scripts\activate
pip install -r requirements.txt
uvicorn spectrablue_soc.main:app --reload --port 9500
```

The API will be reachable at

* http://localhost:9500
* interactive docs at http://localhost:9500/docs

## Using SpectraBlue

You send a list of alerts to the service and receive triage results.

Example

```bash
curl -X POST http://localhost:9500/alerts   -H "Content-Type: application/json"   -d '[
    {
      "source": "ids",
      "category": "lateral_movement",
      "severity": "high",
      "asset_criticality": "critical",
      "description": "Possible lateral movement from host WIN-DC-01 which is a domain controller in a production subnet."
    },
    {
      "source": "siem",
      "category": "bruteforce",
      "severity": "medium",
      "asset_criticality": "medium",
      "description": "Multiple failed login attempts detected on a web server from a single external IP address."
    }
  ]'
```

The response contains for each alert

* alert id
* priority score between zero and one hundred
* chosen action ignore monitor investigate or escalate
* reasons that explain how the score was built
* suggested next steps

You can also ask for all triaged alerts so far

```bash
curl http://localhost:9500/alerts
```

## How the triage brain works

The SocBrain in engine.py uses

* severity for a base score
* asset criticality as a multiplier
* extra boosts for sensitive categories like lateral movement or ransomware
* keyword hints in the description for example failed login domain controller public facing

From the final score it chooses an action

* ignore under twenty
* monitor between twenty and forty
* investigate between forty and seventy
* escalate above seventy

Each action comes with a small runbook for example collect logs or isolate host so that the output is immediately usable by an analyst or could be wired into automation later.

## Ideas for extending this project

You can extend SpectraBlue in many directions

* persist alerts and triage results in a database
* add mapping from categories to MITRE ATT and CK techniques
* connect to a ticketing system to open incidents when action is escalate
* plug it into a SIEM pipeline so that it receives live alerts
* train a machine learning model on historical incidents to adjust the scoring

As it stands this prototype already demonstrates autonomous decision making in a SOC context which is a strong topic for modern security portfolios.
