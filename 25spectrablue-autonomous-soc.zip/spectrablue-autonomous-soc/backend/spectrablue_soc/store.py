
from typing import Dict, List
from dataclasses import dataclass
from datetime import datetime
import itertools

from .engine import Alert, SocBrain, TriageResult


@dataclass
class SocStore:
    alerts: Dict[int, Alert]
    triage_results: Dict[int, TriageResult]
    id_counter: itertools.count
    brain: SocBrain


store = SocStore(
    alerts={},
    triage_results={},
    id_counter=itertools.count(start=1),
    brain=SocBrain(),
)


def add_alert(
    source: str,
    category: str,
    severity: str,
    asset_criticality: str,
    description: str,
    timestamp: datetime,
) -> TriageResult:
    alert_id = next(store.id_counter)
    alert = Alert(
        id=alert_id,
        source=source,
        category=category,
        severity=severity,              # type: ignore[arg-type]
        asset_criticality=asset_criticality,  # type: ignore[arg-type]
        description=description,
        timestamp=timestamp,
    )
    store.alerts[alert_id] = alert
    result = store.brain.triage(alert)
    store.triage_results[alert_id] = result
    return result


def list_triaged() -> List[TriageResult]:
    return list(store.triage_results.values())
