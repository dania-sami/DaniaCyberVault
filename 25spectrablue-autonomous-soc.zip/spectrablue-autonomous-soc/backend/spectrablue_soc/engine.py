
from dataclasses import dataclass
from datetime import datetime
from typing import List, Literal


Severity = Literal["low", "medium", "high", "critical"]
Action = Literal["ignore", "monitor", "investigate", "escalate"]


@dataclass
class Alert:
    id: int
    source: str
    category: str
    severity: Severity
    asset_criticality: Severity
    description: str
    timestamp: datetime


@dataclass
class TriageResult:
    alert_id: int
    priority_score: float
    action: Action
    reasons: List[str]
    suggested_steps: List[str]


class SocBrain:
    """
    Simple autonomous tier one SOC brain.

    It takes raw alerts and turns them into actionable triage output
    with a priority score and a small runbook.
    """

    def triage(self, alert: Alert) -> TriageResult:
        reasons: List[str] = []

        base = {
            "low": 10.0,
            "medium": 30.0,
            "high": 60.0,
            "critical": 80.0,
        }[alert.severity]

        reasons.append(f"Base score from severity {alert.severity} is {base}.")

        asset_weight = {
            "low": 0.9,
            "medium": 1.0,
            "high": 1.2,
            "critical": 1.4,
        }[alert.asset_criticality]

        reasons.append(f"Asset criticality {alert.asset_criticality} scales score by {asset_weight}.")

        score = base * asset_weight

        # Boosts from certain categories
        if alert.category.lower() in ("ransomware", "lateral_movement", "privilege_escalation"):
            score += 15.0
            reasons.append(f"Category {alert.category} adds extra priority.")

        # Keywords
        text = alert.description.lower()
        if "failed login" in text or "bruteforce" in text:
            score += 8.0
            reasons.append("Sign of brute force or credential attacks.")
        if "public facing" in text or "internet exposed" in text:
            score += 12.0
            reasons.append("Issue on an internet exposed asset.")
        if "domain controller" in text:
            score += 20.0
            reasons.append("Domain controller involvement is very sensitive.")

        score = min(100.0, score)

        if score < 20.0:
            action: Action = "ignore"
        elif score < 40.0:
            action = "monitor"
        elif score < 70.0:
            action = "investigate"
        else:
            action = "escalate"

        steps: List[str] = []

        if action == "ignore":
            steps.append("No immediate action needed. Keep alert for historical context.")
        elif action == "monitor":
            steps.append("Add this asset to a short term watchlist for increased logging.")
            steps.append("Check for recurring alerts of the same pattern in the last twenty four hours.")
        elif action == "investigate":
            steps.append("Collect logs around the time of the alert from host network and identity systems.")
            steps.append("Check whether the same user or host has triggered other alerts recently.")
            steps.append("Validate if there is any sign of successful compromise or lateral movement.")
        else:
            steps.append("Notify on call incident responder or security lead immediately.")
            steps.append("Isolate the affected host or account if feasible.")
            steps.append("Preserve forensic data snapshots of logs and system state.")
            steps.append("Open an incident record and track response actions.")

        return TriageResult(
            alert_id=alert.id,
            priority_score=float(round(score, 1)),
            action=action,
            reasons=reasons,
            suggested_steps=steps,
        )
