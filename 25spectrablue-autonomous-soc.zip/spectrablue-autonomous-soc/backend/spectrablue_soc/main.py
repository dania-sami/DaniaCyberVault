
from fastapi import FastAPI
from pydantic import BaseModel, Field
from typing import List, Literal
from datetime import datetime

from .store import add_alert, list_triaged


Severity = Literal["low", "medium", "high", "critical"]
Action = Literal["ignore", "monitor", "investigate", "escalate"]


class AlertIn(BaseModel):
    source: str = Field(..., example="firewall")
    category: str = Field(..., example="lateral_movement")
    severity: Severity
    asset_criticality: Severity
    description: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class TriageOut(BaseModel):
    alert_id: int
    priority_score: float
    action: Action
    reasons: List[str]
    suggested_steps: List[str]


app = FastAPI(
    title="SpectraBlue Autonomous SOC",
    version="0.1.0",
    description="Autonomous tier one SOC assistant that triages alerts and suggests next steps.",
)


@app.post("/alerts", response_model=List[TriageOut])
def ingest_alerts(alerts: List[AlertIn]) -> List[TriageOut]:
    results: List[TriageOut] = []
    for a in alerts:
        triaged = add_alert(
            source=a.source,
            category=a.category,
            severity=a.severity,
            asset_criticality=a.asset_criticality,
            description=a.description,
            timestamp=a.timestamp,
        )
        results.append(
            TriageOut(
                alert_id=triaged.alert_id,
                priority_score=triaged.priority_score,
                action=triaged.action,
                reasons=triaged.reasons,
                suggested_steps=triaged.suggested_steps,
            )
        )
    return results


@app.get("/alerts", response_model=List[TriageOut])
def list_alerts() -> List[TriageOut]:
    triaged = list_triaged()
    return [
        TriageOut(
            alert_id=t.alert_id,
            priority_score=t.priority_score,
            action=t.action,
            reasons=t.reasons,
            suggested_steps=t.suggested_steps,
        )
        for t in triaged
    ]
