"""SpectraBlue Autonomous SOC backend package."""
