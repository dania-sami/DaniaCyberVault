from __future__ import annotations

import argparse
from pathlib import Path

import joblib
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent.parent
MODELS_DIR = BASE_DIR / "models"


def main() -> None:
    parser = argparse.ArgumentParser(description="AI-assisted vulnerability prioritiser")
    parser.add_argument("--path", type=str, required=True, help="Path to vulns CSV")
    args = parser.parse_args()

    model = joblib.load(MODELS_DIR / "vuln_prioritiser.joblib")

    df = pd.read_csv(args.path)
    X = df[["title", "description", "cvss", "asset_criticality"]]
    preds = model.predict(X)

    df["ai_priority"] = preds

    for _, row in df.iterrows():
        print(f"{row['id']}: {row['title']}")
        print(f"  CVSS={row['cvss']} asset_criticality={row['asset_criticality']} -> AI priority={row['ai_priority']}")
        print()


if __name__ == "__main__":
    main()
