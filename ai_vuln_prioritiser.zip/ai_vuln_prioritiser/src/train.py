from __future__ import annotations

from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
MODELS_DIR = BASE_DIR / "models"

for d in (DATA_DIR, MODELS_DIR):
    d.mkdir(parents=True, exist_ok=True)


def generate_synthetic_vulns() -> pd.DataFrame:
    rows = [
        ("V-1", "Open SSH port on internet", "SSH service exposed to the internet without restriction", 8.2, 3, "high"),
        ("V-2", "Outdated library in internal app", "Internal web app using outdated JS library", 5.4, 2, "medium"),
        ("V-3", "XSS on marketing site", "Reflected XSS on low-sensitivity marketing page", 6.1, 1, "medium"),
        ("V-4", "Default credentials on admin panel", "Admin console accessible with vendor default password", 9.0, 3, "high"),
        ("V-5", "TLS weak ciphers", "Supports some older ciphers but also modern ones", 4.3, 2, "low"),
        ("V-6", "Missing HTTP security headers", "Lack of CSP and HSTS on public site", 5.9, 2, "medium"),
        ("V-7", "Unpatched critical RCE on core DB server", "Remote code execution on database host with customer data", 9.8, 3, "high"),
        ("V-8", "Verbose error messages", "Stack traces exposed on dev-only endpoint", 3.7, 1, "low"),
        ("V-9", "Open S3 bucket for logs", "Logs bucket accessible to authenticated users in account", 4.9, 2, "low"),
        ("V-10", "Weak password policy", "Password length 6, no MFA on external portal", 7.0, 3, "high"),
    ]
    return pd.DataFrame(rows, columns=["id", "title", "description", "cvss", "asset_criticality", "priority"])


def main() -> None:
    data_path = DATA_DIR / "vulns.csv"
    if data_path.exists():
        df = pd.read_csv(data_path)
    else:
        df = generate_synthetic_vulns()
        df.to_csv(data_path, index=False)

    X = df[["title", "description", "cvss", "asset_criticality"]]
    y = df["priority"]

    text_features = TfidfVectorizer(ngram_range=(1, 2), min_df=1)
    numeric_features = ["cvss", "asset_criticality"]

    pre = ColumnTransformer(
        transformers=[
            ("text", text_features, ["title", "description"]),
            ("num", StandardScaler(), numeric_features),
        ],
        remainder="drop",
    )

    clf = LogisticRegression(max_iter=1000, multi_class="auto")

    pipe = Pipeline(
        steps=[
            ("pre", pre),
            ("clf", clf),
        ]
    )

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, random_state=42, stratify=y
    )

    pipe.fit(X_train, y_train)
    y_pred = pipe.predict(X_test)
    print("Validation report:")
    print(classification_report(y_test, y_pred))

    joblib.dump(pipe, MODELS_DIR / "vuln_prioritiser.joblib")
    print(f"Saved model to {MODELS_DIR/'vuln_prioritiser.joblib'}")


if __name__ == "__main__":
    main()
