# AI-Assisted Vulnerability Report Prioritiser

Hi, I am Dania 👋

This project is my **AI-style vulnerability prioritiser**:

- I take a CSV of vulnerability findings (title, description, CVSS, asset criticality).
- I build features from text + numeric scores.
- I train a model that outputs **priority levels (low/medium/high)**.

It is a clean demo of how I think about **risk-based vulnerability management**.

## How to run

```bash
cd ai_vuln_prioritiser

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt

# Train prioritisation model
python -m src.train

# Prioritise the sample file
python -m src.prioritise --path data/vulns.csv
```

The script will print each vulnerability with its predicted priority.
