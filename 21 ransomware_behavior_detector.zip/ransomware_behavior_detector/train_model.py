
from pathlib import Path

import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report

DATA_DIR = Path("data")
MODELS_DIR = Path("models")

FEATURE_COLS = [
    "files_touched",
    "fraction_renamed",
    "fraction_deleted",
    "fraction_new_ext",
    "avg_entropy",
    "avg_write_kb_per_s",
    "burstiness",
]


def main():
    MODELS_DIR.mkdir(exist_ok=True)
    path = DATA_DIR / "activity_samples.csv"
    if not path.is_file():
        raise SystemExit(f"Data file not found. Run generate_data.py first ({path}).")

    df = pd.read_csv(path)
    X = df[FEATURE_COLS]
    y = df["label"].astype(str)

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y, test_size=0.2, random_state=42, stratify=y
    )

    clf = RandomForestClassifier(
        n_estimators=200,
        random_state=42,
        n_jobs=-1,
    )
    clf.fit(X_train, y_train)

    y_pred = clf.predict(X_test)
    print("Classification report on validation set:")
    print(classification_report(y_test, y_pred, digits=4))

    joblib.dump(scaler, MODELS_DIR / "scaler.joblib")
    joblib.dump(clf, MODELS_DIR / "model.joblib")

    print(f"[info] Saved scaler to {MODELS_DIR / 'scaler.joblib'}")
    print(f"[info] Saved model to {MODELS_DIR / 'model.joblib'}")


if __name__ == "__main__":
    main()
