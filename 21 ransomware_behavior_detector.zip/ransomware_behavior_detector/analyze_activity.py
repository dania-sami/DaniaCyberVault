
import argparse
from pathlib import Path

import joblib
import pandas as pd
import numpy as np

DATA_DIR = Path("data")
MODELS_DIR = Path("models")

FEATURE_COLS = [
    "files_touched",
    "fraction_renamed",
    "fraction_deleted",
    "fraction_new_ext",
    "avg_entropy",
    "avg_write_kb_per_s",
    "burstiness",
]


def verdict_from_prob(prob_ransom: float) -> str:
    if prob_ransom < 0.2:
        return "Likely normal"
    if prob_ransom < 0.6:
        return "Suspicious"
    return "Highly suspicious"


def main():
    parser = argparse.ArgumentParser(description="Analyse activity sessions for ransomware-like behaviour")
    parser.add_argument(
        "--input",
        type=str,
        default=str(DATA_DIR / "activity_samples.csv"),
        help="CSV file with activity sessions",
    )
    parser.add_argument(
        "--output",
        type=str,
        default=str(DATA_DIR / "activity_scored.csv"),
        help="Where to write the scored sessions",
    )
    args = parser.parse_args()

    scaler_path = MODELS_DIR / "scaler.joblib"
    model_path = MODELS_DIR / "model.joblib"
    if not scaler_path.is_file() or not model_path.is_file():
        raise SystemExit("Model or scaler not found. Run train_model.py first.")

    df = pd.read_csv(args.input)
    missing = [col for col in FEATURE_COLS if col not in df.columns]
    if missing:
        raise SystemExit(f"Input file missing required columns: {missing}")

    scaler = joblib.load(scaler_path)
    model = joblib.load(model_path)

    X = df[FEATURE_COLS]
    X_scaled = scaler.transform(X)

    if hasattr(model, "predict_proba"):
        proba = model.predict_proba(X_scaled)
        # assume label order ['normal', 'ransomware_like'] or similar
        classes = list(model.classes_)
        if "ransomware_like" in classes:
            idx_r = classes.index("ransomware_like")
        else:
            # fallback if labels encoded differently
            idx_r = int(np.argmax(classes))
        prob_ransom = proba[:, idx_r]
    else:
        preds = model.predict(X_scaled)
        prob_ransom = np.where(preds == "ransomware_like", 0.8, 0.2)

    df["prob_ransomware"] = prob_ransom
    df["verdict"] = df["prob_ransomware"].apply(verdict_from_prob)

    out_path = Path(args.output)
    out_path.parent.mkdir(exist_ok=True)
    df.to_csv(out_path, index=False)

    print(f"[info] Loaded {len(df)} sessions from {args.input}")
    print(f"[info] Using trained model from {model_path}")
    print()
    print("Session  label              prob_ransomware  verdict")
    print("-------  -----------------  ---------------  ----------------------")

    for i in range(min(10, len(df))):
        row = df.iloc[i]
        label = row.get("label", "")
        print(
            f"{i:<7}  {str(label):<17}  {row['prob_ransomware']:<15.2f}  {row['verdict']}"
        )

    print()
    print(f"Results written to {out_path}")


if __name__ == "__main__":
    main()
