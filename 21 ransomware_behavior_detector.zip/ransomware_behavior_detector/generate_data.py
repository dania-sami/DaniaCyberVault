
from pathlib import Path
import random
import csv
import math

DATA_DIR = Path("data")


def entropy(bits: float) -> float:
    # here we just keep entropy as a number we control in the simulation
    return bits


def simulate_session(kind: str) -> dict:
    # kind: "normal" or "ransomware_like"
    if kind == "normal":
        files_touched = random.randint(10, 80)
        fraction_renamed = random.uniform(0.0, 0.1)
        fraction_deleted = random.uniform(0.0, 0.05)
        fraction_new_ext = random.uniform(0.0, 0.1)
        avg_entropy = entropy(random.uniform(4.5, 6.5))
        avg_write_kb_per_s = random.uniform(50, 500)
        burstiness = random.uniform(0.1, 0.4)
    else:
        # ransomware-like
        files_touched = random.randint(200, 1000)
        fraction_renamed = random.uniform(0.6, 1.0)
        fraction_deleted = random.uniform(0.2, 0.8)
        fraction_new_ext = random.uniform(0.7, 1.0)
        avg_entropy = entropy(random.uniform(7.0, 8.0))
        avg_write_kb_per_s = random.uniform(500, 5000)
        burstiness = random.uniform(0.6, 1.0)

    return {
        "files_touched": files_touched,
        "fraction_renamed": round(fraction_renamed, 3),
        "fraction_deleted": round(fraction_deleted, 3),
        "fraction_new_ext": round(fraction_new_ext, 3),
        "avg_entropy": round(avg_entropy, 3),
        "avg_write_kb_per_s": round(avg_write_kb_per_s, 3),
        "burstiness": round(burstiness, 3),
        "label": kind,
    }


def main():
    random.seed(42)
    DATA_DIR.mkdir(exist_ok=True)
    samples = []

    for _ in range(700):
        samples.append(simulate_session("normal"))
    for _ in range(300):
        samples.append(simulate_session("ransomware_like"))

    out_path = DATA_DIR / "activity_samples.csv"
    fieldnames = [
        "files_touched",
        "fraction_renamed",
        "fraction_deleted",
        "fraction_new_ext",
        "avg_entropy",
        "avg_write_kb_per_s",
        "burstiness",
        "label",
    ]
    with out_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in samples:
            writer.writerow(row)

    print(f"[info] Wrote {len(samples)} synthetic activity sessions to {out_path}")


if __name__ == "__main__":
    main()
