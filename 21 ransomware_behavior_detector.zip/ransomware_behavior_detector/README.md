
# Machine Learning Ransomware Behaviour Detector (Simulation Lab)

Hi, I am Dania and I built this project to understand how endpoint security tools look for **ransomware behaviour** instead of just signatures.

I did not want to do anything dangerous on a real system, so I created a **safe simulation lab**:

- I simulate normal user and backup activity
- I simulate ransomware style activity (fast writes, high entropy, lots of extensions changing)
- I train a small machine learning model on those patterns
- I use the model to score new activity as “more like normal” or “more like ransomware”

This way I can practise the thinking behind behaviour based detection in a controlled environment.

---

## What this project does

The project has three parts.

1. **Synthetic activity generator**  
   I generate activity sessions and write them to `data/activity_samples.csv`.  
   Each row is a “session” with features like:
   - number of files touched
   - fraction of files renamed
   - fraction of files deleted
   - average entropy of content
   - average write speed
   - label (normal or ransomware_like)

2. **Model training**  
   I train a `RandomForestClassifier` to distinguish between normal and ransomware-like sessions.  
   The model and scaler are saved with `joblib`.

3. **Activity analyser**  
   A CLI script loads the model and takes either:
   - the whole `data/activity_samples.csv`, or
   - a separate CSV with the same feature columns

   It then scores each session and prints:
   - probability that the session is ransomware-like
   - a simple verdict (Likely normal / Suspicious / Highly suspicious)

This is not a production detector, but it shows clearly how behaviour-based detection pipelines can be prototyped with data and models.

---

## Project structure

```text
ransomware_behavior_detector/
  README.md
  requirements.txt
  generate_data.py       # create synthetic activity sessions
  train_model.py         # train ML model
  analyze_activity.py    # score sessions using the trained model
  data/
  models/
```

---

## Installation

```bash
python3 -m venv venv
source venv/bin/activate           # Windows  venv\Scripts\activate
pip install -r requirements.txt
```

---

## Step 1  Generate synthetic data

```bash
python generate_data.py
```

This creates:

- `data/activity_samples.csv` with labelled sessions (normal vs ransomware_like)

You can open the CSV to see what the features look like.

---

## Step 2  Train the model

```bash
python train_model.py
```

This will:

- train a RandomForest model on the synthetic data
- print a classification report
- save the scaler and model to:
  - `models/scaler.joblib`
  - `models/model.joblib`

---

## Step 3  Analyse activity sessions

To score the generated sample sessions:

```bash
python analyze_activity.py --input data/activity_samples.csv
```

Example output:

```text
[info] Loaded 1000 sessions from data/activity_samples.csv
[info] Using trained model from models/model.joblib

Session  label              prob_ransomware  verdict
-------  -----------------  ---------------  ----------------------
0        normal             0.03             Likely normal
1        ransomware_like    0.97             Highly suspicious
2        normal             0.08             Likely normal
...

Results written to data/activity_scored.csv
```

If you create your own CSV with the same feature columns (without the label), you can point the analyser to that file instead.

---

## Features used in the model

Each activity session is described by simple but meaningful features:

- `files_touched`           — how many files were touched in the session
- `fraction_renamed`        — fraction of files that were renamed
- `fraction_deleted`        — fraction of files that were deleted
- `fraction_new_ext`        — fraction of files that ended with a different extension
- `avg_entropy`             — average entropy of file content (randomness)
- `avg_write_kb_per_s`      — approximate write throughput
- `burstiness`              — how spiky the activity was over time (0 to 1)

Normal behaviour tends to be slower, with fewer renames and moderate entropy.  
Ransomware-like behaviour in the simulation is very fast, touches many files, and changes extensions with high entropy content.

---

## How I see this project

Ransomware is one of the biggest real-world threats, and many modern products use exactly this kind of behavioural approach.

By building this simulation lab I can show that I:

- understand the idea of **behaviour-based detection**
- can design **features** that separate normal and malicious patterns
- know how to train and evaluate a small model for security use cases

The project is intentionally easy to read so it can be a good conversation piece in future interviews or studies.
