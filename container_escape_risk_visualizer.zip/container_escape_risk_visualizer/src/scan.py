from __future__ import annotations

from pathlib import Path
from typing import List

import yaml

BASE_DIR = Path(__file__).resolve().parent.parent
DOCKERFILE = BASE_DIR / "Dockerfile"
COMPOSE = BASE_DIR / "docker-compose.yml"


def scan_dockerfile(path: Path) -> List[str]:
    findings: List[str] = []
    if not path.exists():
        return ["Dockerfile not found."]
    text = path.read_text(encoding="utf-8").splitlines()
    for line in text:
        stripped = line.strip()
        if stripped.upper().startswith("USER ") and "root" in stripped:
            findings.append("Dockerfile: runs as root user (escape impact is higher).")
        if "CAP_ADD" in stripped.upper():
            findings.append("Dockerfile: CAP_ADD detected (check added capabilities).")
    if not any(l.strip().upper().startswith("USER ") for l in text):
        findings.append("Dockerfile: no USER instruction (defaults to root).")
    return findings


def scan_compose(path: Path) -> List[str]:
    findings: List[str] = []
    if not path.exists():
        return ["docker-compose.yml not found."]
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        return ["Compose file has unexpected structure."]

    services = data.get("services", {})
    if not isinstance(services, dict):
        return ["No services section found in compose file."]

    for name, svc in services.items():
        if not isinstance(svc, dict):
            continue
        if svc.get("privileged") is True:
            findings.append(f"Service {name}: runs privileged=True.")
        vols = svc.get("volumes", []) or []
        for v in vols:
            if isinstance(v, str) and "docker.sock" in v:
                findings.append(
                    f"Service {name}: mounts Docker socket ({v}), potential full host control."
                )
        security_opt = svc.get("security_opt", []) or []
        if any("unconfined" in str(opt) for opt in security_opt):
            findings.append(f"Service {name}: security_opt contains 'unconfined' profile.")
    return findings


def main() -> None:
    print("Container Escape Risk Visualizer")
    print("================================\n")

    df_findings = scan_dockerfile(DOCKERFILE)
    print("Dockerfile findings:")
    for f in df_findings:
        print(f"- {f}")
    print()

    compose_findings = scan_compose(COMPOSE)
    print("docker-compose.yml findings:")
    for f in compose_findings:
        print(f"- {f}")


if __name__ == "__main__":
    main()
