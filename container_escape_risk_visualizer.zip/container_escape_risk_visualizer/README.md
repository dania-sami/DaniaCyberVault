# Container Escape Risk Visualizer

Hi, I am Dania 👋

This project is my **container escape risk visualizer**:

- I scan a Dockerfile and a `docker-compose.yml`.
- I highlight risky patterns like:
  - privileged containers,
  - Docker socket mounts,
  - root user,
  - dangerous capabilities.

It is a focused demo of **runtime escape risks** in container setups.

## How to run

```bash
cd container_escape_risk_visualizer

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt

python -m src.scan
```

The tool prints a readable list of findings with severity hints.
