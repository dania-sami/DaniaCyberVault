# Cloud Security Group Diff Analyzer

This project is a small script I use to compare two snapshots of a cloud security group style rule set.

Each JSON file contains a list of rules with:

- `id`
- `action`
- `src`
- `dst`
- `protocol`
- `port`

The script shows which rules were added and which were removed between the two snapshots. It is a simple way to talk about change tracking in cloud security.

## Files

- `sg_diff.py` – main script
- `sg_before.json` – first snapshot
- `sg_after.json` – second snapshot

## Usage

```bash
python sg_diff.py --before sg_before.json --after sg_after.json
```
