import argparse
import json
from typing import List, Dict, Any

def load_rules(path: str) -> List[Dict[str, Any]]:
    with open(path) as f:
        return json.load(f)

def rule_key(r: Dict[str, Any]):
    return (
        r.get("action", ""),
        r.get("src", ""),
        r.get("dst", ""),
        r.get("protocol", ""),
        str(r.get("port", "")),
    )

def diff(before_path: str, after_path: str):
    before = load_rules(before_path)
    after = load_rules(after_path)

    before_set = {rule_key(r): r for r in before}
    after_set = {rule_key(r): r for r in after}

    added_keys = set(after_set.keys()) - set(before_set.keys())
    removed_keys = set(before_set.keys()) - set(after_set.keys())

    print(f"[+] Comparing {before_path} -> {after_path}\n")

    if added_keys:
        print("[+] Added rules:")
        for k in added_keys:
            r = after_set[k]
            print(f"    {r}")
        print()
    else:
        print("[+] No added rules.\n")

    if removed_keys:
        print("[+] Removed rules:")
        for k in removed_keys:
            r = before_set[k]
            print(f"    {r}")
    else:
        print("[+] No removed rules.")

def main():
    parser = argparse.ArgumentParser(description="Cloud Security Group Diff Analyzer by Dania")
    parser.add_argument("--before", required=True, help="JSON file with original rules")
    parser.add_argument("--after", required=True, help="JSON file with new rules")
    args = parser.parse_args()
    diff(args.before, args.after)

if __name__ == "__main__":
    main()
