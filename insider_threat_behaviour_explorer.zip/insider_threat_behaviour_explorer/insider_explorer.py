
import argparse, json, random, datetime

def generate_scenario(name, out_events):
    events=[]
    now=datetime.datetime(2025,1,1,9,0)

    def add(ev):
        ev["timestamp"]=now.isoformat()
        events.append(ev)

    if name=="slow_exfil":
        for i in range(20):
            add({"type":"login","user":"dania","success":True,"hour":now.hour})
            now+=datetime.timedelta(minutes=10)
        for i in range(15):
            add({"type":"file_access","file":f"confidential_{i}.pdf","sensitivity":9})
            now+=datetime.timedelta(minutes=7)
        for i in range(5):
            add({"type":"email_send","size_kb":random.randint(500,2000),"attachment":True})
            now+=datetime.timedelta(minutes=30)

    elif name=="privilege_abuse":
        add({"type":"login","user":"admin","success":True,"hour":now.hour})
        now+=datetime.timedelta(minutes=15)
        for i in range(10):
            add({"type":"role_change","new_role":"superadmin"})
            now+=datetime.timedelta(minutes=5)
        for i in range(8):
            add({"type":"file_access","file":f"salary_{i}.csv","sensitivity":7})
            now+=datetime.timedelta(minutes=12)

    else:
        for i in range(30):
            add({"type":"login","user":"normal","success":True,"hour":now.hour})
            now+=datetime.timedelta(minutes=10)

    with open(out_events,"w") as f:
        for e in events: f.write(json.dumps(e)+"\n")

def score_event(ev):
    score=0
    reasons=[]
    if ev["type"]=="file_access" and ev.get("sensitivity",0)>=8:
        score+=3; reasons.append("high sensitivity file")
    if ev["type"]=="email_send" and ev.get("size_kb",0)>1000:
        score+=2; reasons.append("large attachment")
    if ev["type"]=="role_change":
        score+=4; reasons.append("privilege escalation")
    return score,reasons

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--scenario",required=True)
    ap.add_argument("--out-prefix",required=True)
    a=ap.parse_args()

    events_file=f"{a.out_prefix}_events.jsonl"
    scored_file=f"{a.out_prefix}_scored.jsonl"
    report_file=f"{a.out_prefix}_report.md"

    generate_scenario(a.scenario,events_file)

    detections=[]
    with open(events_file) as f, open(scored_file,"w") as out:
        for line in f:
            ev=json.loads(line)
            s,r=score_event(ev)
            ev["score"]=s; ev["reasons"]=r
            if s>0: detections.append(ev)
            out.write(json.dumps(ev)+"\n")

    with open(report_file,"w") as r:
        r.write("# Insider threat scenario report\n\n")
        r.write(f"Scenario: {a.scenario}\n\n")
        if detections:
            first=detections[0]
            r.write(f"First suspicious event at {first['timestamp']} score={first['score']}\n\n")
        else:
            r.write("No suspicious events detected\n")
        r.write("## All detection events\n\n")
        for d in detections:
            r.write(f"* {d['timestamp']} – {d['type']} reasons={d['reasons']}\n")

if __name__=="__main__":
    main()
