# Insider Threat Behaviour Explorer – Dania’s behaviour simulation lab

Hi

I am Dania and this project is my small exploration lab for understanding insider threat patterns.

I always felt that insider threat detection becomes much clearer when you can *simulate* the behaviour yourself instead of only reading theoretical models. So I built a small tool that lets me generate synthetic scenarios of:

* unusual logins  
* suspicious file access  
* email metadata anomalies  
* privilege escalation steps  
* slow data exfiltration trails  

The whole goal here is not to produce enterprise grade detection but to understand which signals tend to appear together and how early simple scoring models can detect them.

## What this tool does

It has three main parts:

### 1. Synthetic scenario generator

You can create realistic event streams such as:

* a normal employee working 9–5 with predictable access  
* an insider slowly collecting sensitive files  
* privilege abuse followed by high-volume email attachments  
* abnormal login hours combined with lateral directory browsing  

The generator writes these into a JSONL timeline.

### 2. Signal extraction

The tool extracts features like:

* time-of-day deviation  
* file sensitivity score  
* email attachment size spikes  
* failed vs successful auth patterns  
* access frequency anomalies  

### 3. Simple anomaly scoring

It applies a tiny, transparent scoring system so I can see:

* which events look suspicious  
* which signals fire first  
* how long the delay is between behaviour and detection  

It outputs:

* a JSON list of scored events  
* a Markdown report summarising the signals and the earliest detection point  

## How I run it

```
python insider_explorer.py     --scenario slow_exfil     --out-prefix runs_demo
```

This generates:

* `runs_demo_events.jsonl`  
* `runs_demo_scored.jsonl`  
* `runs_demo_report.md`

The README gives more detail on how the scoring works and why each scenario behaves differently.

## Why I built this

I wanted a demo I could use in interviews to show:

* that I understand insider threat signals  
* that I can model behaviour in a small but realistic way  
* that “detection delay” depends heavily on which signals you track  
* that I know how to express detection logic clearly instead of treating it like magic  

It fits perfectly in my security portfolio because it shows the thinking process behind detection logic, not just the output.
