# Browser Cookie Security Audit (CSV)

This script is for when I export cookies to CSV from a browser or a small test app.

The CSV is expected to have columns:

- `name`
- `domain`
- `secure`
- `http_only`

The script prints cookies that are missing the `secure` or `http_only` flags so I can quickly see weak spots.

## Files

- `cookie_audit_csv.py` – main script
- `demo_cookies.csv` – example data

## Usage

```bash
python cookie_audit_csv.py --csv demo_cookies.csv
```
