import argparse
import csv

def audit(path: str):
    print(f"[+] Cookie security audit for {path}\n")
    with open(path, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row.get("name", "")
            domain = row.get("domain", "")
            secure = (row.get("secure", "false").lower() == "true")
            http_only = (row.get("http_only", "false").lower() == "true")

            issues = []
            if not secure:
                issues.append("no Secure flag")
            if not http_only:
                issues.append("no HttpOnly flag")

            if issues:
                print(f"{name} ({domain}): {', '.join(issues)}")

def main():
    parser = argparse.ArgumentParser(description="Browser Cookie Security Audit (CSV) by Dania")
    parser.add_argument("--csv", required=True, help="Path to CSV export")
    args = parser.parse_args()
    audit(args.csv)

if __name__ == "__main__":
    main()
