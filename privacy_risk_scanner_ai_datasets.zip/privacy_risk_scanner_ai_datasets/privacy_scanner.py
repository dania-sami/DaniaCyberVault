"""
Privacy Risk Scanner for AI Training Datasets – Dania's anonymisation helper

Reads a CSV dataset
looks for direct identifiers
quasi identifiers
and sensitive strings
then produces a simple privacy risk grade
"""

import argparse
import csv
import json
import re
from collections import Counter, defaultdict
from dataclasses import dataclass, asdict
from typing import List, Dict, Tuple


EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
PHONE_RE = re.compile(r"\+?\d[\d\s\-]{7,}\d")

HEALTH_KEYWORDS = [
    "cancer",
    "diabetes",
    "asthma",
    "surgery",
    "hiv",
    "depression",
    "therapy",
    "medicine",
    "diagnosis",
]

FINANCE_KEYWORDS = [
    "salary",
    "wage",
    "bank",
    "credit card",
    "debit card",
    "loan",
    "mortgage",
    "tax",
    "iban",
    "account number",
]


DIRECT_HEADER_HINTS = {
    "email": ["email", "e-mail", "mail"],
    "name": ["name", "full_name", "fullname"],
    "phone": ["phone", "mobile", "tel", "telephone"],
    "address": ["address", "street", "postcode", "zip"],
    "id": ["ssn", "social_security", "national_id", "personnummer"],
}


@dataclass
class ScanResult:
    direct_counts: Dict[str, int]
    quasi_high_risk_count: int
    quasi_examples: List[Dict[str, str]]
    sensitive_row_count: int
    risk_grade: str


def load_rows(path: str) -> Tuple[List[str], List[Dict[str, str]]]:
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        reader = csv.DictReader(f)
        headers = reader.fieldnames or []
        rows = [row for row in reader]
    return headers, rows


def detect_direct_identifiers(headers: List[str], rows: List[Dict[str, str]]) -> Dict[str, int]:
    counts = Counter()

    header_roles: Dict[str, str] = {}
    for h in headers:
        hl = (h or "").lower()
        for role, hints in DIRECT_HEADER_HINTS.items():
            if any(hint in hl for hint in hints):
                header_roles[h] = role

    for row in rows:
        for h, val in row.items():
            if not val:
                continue
            text = str(val)
            role = header_roles.get(h, "")
            if role == "email" or EMAIL_RE.search(text):
                counts["email"] += 1
            if role == "phone" or PHONE_RE.search(text):
                counts["phone"] += 1
            if role == "name":
                counts["name"] += 1
            if role == "address":
                counts["address"] += 1
            if role == "id":
                counts["id"] += 1

    return dict(counts)


def choose_quasi_columns(headers: List[str]) -> List[str]:
    # pick columns that look like categories, skip obvious identifiers
    chosen: List[str] = []
    for h in headers:
        hl = h.lower()
        if any(hint in hl for hints in DIRECT_HEADER_HINTS.values() for hint in hints):
            continue
        if hl in {"notes", "comments", "text"}:
            continue
        chosen.append(h)
    return chosen


def detect_quasi_identifiers(headers: List[str], rows: List[Dict[str, str]]) -> Tuple[int, List[Dict[str, str]]]:
    quasi_cols = choose_quasi_columns(headers)
    if not quasi_cols:
        return 0, []

    combo_counts = Counter()
    combo_examples: Dict[Tuple[str, ...], Dict[str, str]] = {}

    for row in rows:
        combo = tuple((row.get(c) or "").strip() for c in quasi_cols)
        if all(v == "" for v in combo):
            continue
        combo_counts[combo] += 1
        if combo not in combo_examples:
            combo_examples[combo] = {c: row.get(c, "") for c in quasi_cols}

    high_risk = [combo for combo, cnt in combo_counts.items() if cnt <= 2]
    examples = [combo_examples[c] for c in high_risk[:5]]
    return len(high_risk), examples


def detect_sensitive_strings(headers: List[str], rows: List[Dict[str, str]]) -> int:
    sensitive_rows = 0
    for row in rows:
        text_blob = " ".join((row.get(h) or "") for h in headers).lower()
        if any(k in text_blob for k in HEALTH_KEYWORDS) or any(
            k in text_blob for k in FINANCE_KEYWORDS
        ):
            sensitive_rows += 1
    return sensitive_rows


def grade_risk(direct_counts: Dict[str, int], quasi_count: int, sensitive_rows: int, total_rows: int) -> str:
    score = 0
    score += min(3, direct_counts.get("email", 0) // 10)
    score += min(3, direct_counts.get("phone", 0) // 10)
    score += 2 if direct_counts.get("id", 0) > 0 else 0
    score += 1 if direct_counts.get("address", 0) > 0 else 0
    score += 2 if quasi_count > (0.2 * total_rows) else (1 if quasi_count > 0 else 0)
    score += 2 if sensitive_rows > 0 else 0

    if score <= 2:
        return "Low"
    if score <= 5:
        return "Medium"
    return "High"


def write_report(result: ScanResult, path: str, total_rows: int) -> None:
    with open(path, "w", encoding="utf-8") as f:
        f.write("# Privacy risk report for dataset\n\n")
        f.write(f"* Total rows: {total_rows}\n")
        f.write(f"* Overall privacy risk grade: **{result.risk_grade}**\n\n")

        f.write("## Direct identifiers\n\n")
        if not result.direct_counts:
            f.write("No strong direct identifiers were detected with the current heuristics.\n\n")
        else:
            for k, v in result.direct_counts.items():
                f.write(f"* {k}: {v} rows with this identifier type\n")
            f.write("\n")

        f.write("## Quasi identifiers\n\n")
        f.write(f"* High risk quasi identifier combinations: {result.quasi_high_risk_count}\n\n")
        if result.quasi_examples:
            f.write("Example combinations that appear only once or twice:\n\n")
            for ex in result.quasi_examples:
                pretty = ", ".join(f"{k}={v}" for k, v in ex.items())
                f.write(f"* {pretty}\n")
            f.write("\n")

        f.write("## Sensitive strings\n\n")
        f.write(f"* Rows containing health or finance related keywords: {result.sensitive_row_count}\n\n")

        f.write("## Suggestions\n\n")
        if result.risk_grade == "High":
            f.write("* Strongly consider removing or pseudonymising direct identifiers before training.\n")
            f.write("* Reduce or generalise quasi identifiers (for example group small cities or job titles).\n")
            f.write("* Remove or redact free text fields that mention health or financial details.\n")
        elif result.risk_grade == "Medium":
            f.write("* Review which identifiers are truly needed for the model and drop the rest.\n")
            f.write("* Consider bucketising quasi identifiers (for example age ranges instead of exact ages).\n")
        else:
            f.write("* Risk looks relatively low with the current heuristics, but a human review is still recommended.\n")


def write_json_summary(result: ScanResult, path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(asdict(result), f, indent=2)


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's privacy risk scanner for AI datasets")
    parser.add_argument("--data", required=True, help="Path to CSV dataset")
    parser.add_argument("--out", default="privacy_report.md", help="Markdown report path")
    parser.add_argument("--json-out", help="Optional JSON summary path")
    args = parser.parse_args()

    headers, rows = load_rows(args.data)
    total_rows = len(rows)

    direct_counts = detect_direct_identifiers(headers, rows)
    quasi_count, quasi_examples = detect_quasi_identifiers(headers, rows)
    sensitive_rows = detect_sensitive_strings(headers, rows)

    grade = grade_risk(direct_counts, quasi_count, sensitive_rows, total_rows)

    result = ScanResult(
        direct_counts=direct_counts,
        quasi_high_risk_count=quasi_count,
        quasi_examples=quasi_examples,
        sensitive_row_count=sensitive_rows,
        risk_grade=grade,
    )

    write_report(result, args.out, total_rows)
    print(f"Wrote privacy report to {args.out}")
    if args.json_out:
        write_json_summary(result, args.json_out)
        print(f"Wrote JSON summary to {args.json_out}")


if __name__ == "__main__":
    main()
