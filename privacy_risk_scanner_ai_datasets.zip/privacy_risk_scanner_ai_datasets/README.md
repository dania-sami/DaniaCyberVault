# Privacy Risk Scanner for AI Training Datasets – Dania’s anonymisation helper

Hi

I am Dania and this project is my small toolkit for looking at AI training datasets with a privacy lens

Before we feed anything into a model
I want to know

* does this dataset contain direct identifiers like emails and phone numbers
* are there rare combinations of attributes that make people easy to re identify
* are there sensitive strings related to health or finances mixed into free text

This scanner does not try to replace serious legal review
but it gives me a fast first pass and a simple **privacy risk grade** plus concrete suggestions

## Input format

For the demo I use CSV files with headers

Each row is one record
for example

email,name,city,job_title,notes
dania@example.com,"Dania Sami",Stockholm,"Security engineer","working on incident response"
anon123@example.com,"","SmallTown","Nurse","recovered from cancer last year"

The scanner treats:

* header names as hints (email name phone address etc)
* cell contents as text to inspect for patterns

It can also work on other CSVs with different columns
it just becomes a bit more generic

## What the scanner looks for

### 1 Direct identifiers

* emails by regex
* phone like patterns
* obvious id style column names such as
  * email e_mail mail
  * name full_name
  * phone mobile
  * ssn social_security

It counts how many rows contain each type.

### 2 Quasi identifiers

Quasi identifiers are combinations of fields that by themselves are not unique identifiers
but together they make a person stand out

The scanner

* looks at non empty columns that look categorical (for example city role department)
* counts how often each combination appears
* flags those that appear only once or twice as **high re identification risk**

For the demo I keep the logic simple and interpretable.

### 3 Sensitive strings

It scans text columns for small keyword lists related to

* health (cancer diabetes surgery medicine etc)
* finance (salary bank credit card loan tax etc)

Any match is flagged as a sensitive field.

## Output

For every run the scanner writes

* `privacy_report.md`
  * summary of:
    * direct identifier counts
    * how many high risk quasi id combos exist
    * how many rows contain sensitive terms
  * an overall risk grade  Low  Medium  High
  * concrete suggestions in normal language
* `privacy_scores.json`
  * structured counts and risk grade for scripting or dashboards

## How I run it

1 optional create a virtual environment

    python -m venv venv
    source venv_bin_activate

2 install requirements (standard library only)

    pip install -r requirements.txt

3 inspect the example dataset

    examples_training_sample.csv

4 run the scanner

    python privacy_scanner.py \
        --data examples_training_sample.csv \
        --out privacy_report.md \
        --json-out privacy_scores.json

## How I think about this

For me this project is a bridge between

* privacy ideas I read in books and regulations
* and the very concrete reality of CSVs full of people data

With it I can show that I

* understand the difference between direct identifiers and quasi identifiers
* know some typical sensitive categories for AI training data
* can turn a dataset into a simple privacy risk narrative with clear actions
* think about anonymisation and minimisation before model training

It is not a legal tool but it is a very practical starting point for safer AI data pipelines
