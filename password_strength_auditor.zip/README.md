# Password Strength Auditor (Local Checklist)

This is a simple password strength auditor I wrote to explain what makes a password weak or strong.

It does not connect to any external service and does not try to crack anything. It just takes passwords from a file and scores them using a few basic rules like length, variety of character types and presence of very common patterns.

## Features

- Local only, no network calls
- Scores each password from 0 to 100
- Flags obviously weak passwords
- Includes a small demo list of passwords

## Usage

```bash
python password_auditor.py --wordlist demo_passwords.txt
```

Example output:

```text
[+] Password audit for demo_passwords.txt

password        score= 10  verdict=very weak
Sunshine123!    score= 78  verdict=ok
D4nia!Security  score= 92  verdict=strong
```

This is a simple learning and awareness tool. It is not meant to replace professional password auditing or breach checking.
