import argparse
import re

LOWER_RE = re.compile(r"[a-z]")
UPPER_RE = re.compile(r"[A-Z]")
DIGIT_RE = re.compile(r"[0-9]")
SPECIAL_RE = re.compile(r"[^a-zA-Z0-9]")

COMMON = {
    "password",
    "123456",
    "qwerty",
    "letmein",
    "welcome",
    "iloveyou",
}

def score_password(pw: str) -> int:
    score = 0
    length = len(pw)

    if length >= 8:
        score += 20
    if length >= 12:
        score += 20
    if LOWER_RE.search(pw):
        score += 15
    if UPPER_RE.search(pw):
        score += 15
    if DIGIT_RE.search(pw):
        score += 15
    if SPECIAL_RE.search(pw):
        score += 15
    if pw.lower() not in COMMON:
        score += 10

    return min(score, 100)

def verdict(score: int) -> str:
    if score < 30:
        return "very weak"
    if score < 60:
        return "weak"
    if score < 80:
        return "ok"
    return "strong"

def audit(wordlist_path: str):
    print(f"[+] Password audit for {wordlist_path}\n")
    with open(wordlist_path) as f:
        for line in f:
            pw = line.strip()
            if not pw:
                continue
            s = score_password(pw)
            v = verdict(s)
            print(f"{pw:15s} score={s:3d}  verdict={v}")

def main():
    parser = argparse.ArgumentParser(description="Password Strength Auditor by Dania")
    parser.add_argument("--wordlist", required=True, help="Path to file with one password per line")
    args = parser.parse_args()
    audit(args.wordlist)

if __name__ == "__main__":
    main()
