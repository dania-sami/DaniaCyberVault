
from dataclasses import dataclass
from typing import Dict, List


@dataclass
class GuardrailProfile:
    id: int
    name: str
    meta: Dict[str, str]
    metrics: Dict[str, float]


@dataclass
class InjectionAssessment:
    profile_id: int
    name: str
    survivability_score: float
    band: str
    weaknesses: List[str]
    strengths: List[str]


class LlmImposterBrain:
    """
    Reasoning engine for prompt injection "survivability".

    It does not run real LLMs. Instead it takes abstract scores that represent
    how well a system handles things like tool restrictions, system prompt
    isolation and output filtering.
    """

    def __init__(self) -> None:
        self._next_id = 1
        self.profiles: Dict[int, GuardrailProfile] = {}

    def register_profile(self, name: str, meta: Dict[str, str], metrics: Dict[str, float]) -> GuardrailProfile:
        pid = self._next_id
        self._next_id += 1
        prof = GuardrailProfile(
            id=pid,
            name=name,
            meta=meta,
            metrics=metrics,
        )
        self.profiles[pid] = prof
        return prof

    def assess(self, profile_id: int) -> InjectionAssessment:
        prof = self.profiles[profile_id]
        m = prof.metrics
        weaknesses: List[str] = []
        strengths: List[str] = []

        system_isolation = float(m.get("system_prompt_isolation", 0.0))
        tool_sandboxing = float(m.get("tool_sandboxing_strength", 0.0))
        output_filtering = float(m.get("output_filtering_quality", 0.0))
        instruction_prioritisation = float(m.get("instruction_priority_rigidity", 0.0))
        logging_maturity = float(m.get("attack_logging_maturity", 0.0))

        base = (
            system_isolation * 0.3
            + tool_sandboxing * 0.25
            + output_filtering * 0.2
            + instruction_prioritisation * 0.15
            + logging_maturity * 0.1
        )
        survivability = max(0.0, min(100.0, base * 100.0))

        if system_isolation < 0.4:
            weaknesses.append("System prompt isolation is weak; injections can compete with core rules.")
        else:
            strengths.append("System prompt is relatively well isolated from user content.")
        if tool_sandboxing < 0.4:
            weaknesses.append("Tool sandboxing is limited; injected tools could have wide impact.")
        else:
            strengths.append("Tool calls appear reasonably constrained.")
        if output_filtering < 0.4:
            weaknesses.append("Output filtering may not reliably catch injected content effects.")
        else:
            strengths.append("Output filtering gives an extra layer against injections.")
        if instruction_prioritisation < 0.4:
            weaknesses.append("Model may treat user instructions too close to system instructions.")
        else:
            strengths.append("Model is encouraged to obey system rules over user attempts.")
        if logging_maturity < 0.4:
            weaknesses.append("Attack logging is basic; learning from attacks will be slow.")
        else:
            strengths.append("Attack attempts are logged well for later tuning.")

        if survivability >= 80.0:
            band = "high_prompt_injection_immunity"
        elif survivability >= 60.0:
            band = "good_prompt_injection_immunity"
        elif survivability >= 40.0:
            band = "moderate_prompt_injection_immunity"
        elif survivability >= 20.0:
            band = "low_prompt_injection_immunity"
        else:
            band = "very_low_prompt_injection_immunity"

        return InjectionAssessment(
            profile_id=prof.id,
            name=prof.name,
            survivability_score=round(survivability, 2),
            band=band,
            weaknesses=weaknesses,
            strengths=strengths,
        )
