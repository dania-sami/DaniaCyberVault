
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Dict, List

from .engine import LlmImposterBrain, GuardrailProfile, InjectionAssessment


brain = LlmImposterBrain()


class GuardrailIn(BaseModel):
    name: str = Field(..., example="prod-llm-guardrails-v1")
    meta: Dict[str, str] = Field(default_factory=dict)
    metrics: Dict[str, float] = Field(
        default_factory=dict,
        description=(
            "Metrics: system_prompt_isolation, tool_sandboxing_strength, "
            "output_filtering_quality, instruction_priority_rigidity, attack_logging_maturity"
        ),
    )


class GuardrailOut(BaseModel):
    id: int
    name: str
    meta: Dict[str, str]
    metrics: Dict[str, float]


class AssessmentOut(BaseModel):
    profile_id: int
    name: str
    survivability_score: float
    band: str
    weaknesses: List[str]
    strengths: List[str]


app = FastAPI(
    title="LLM-Imposter Prompt Injection Immunity Lab",
    version="0.1.0",
    description="Reasoning engine for prompt injection survivability, using abstract guardrail scores.",
)


@app.post("/profiles", response_model=GuardrailOut)
def register_profile(payload: GuardrailIn) -> GuardrailOut:
    prof: GuardrailProfile = brain.register_profile(
        name=payload.name,
        meta=payload.meta,
        metrics=payload.metrics,
    )
    return GuardrailOut(
        id=prof.id,
        name=prof.name,
        meta=prof.meta,
        metrics=prof.metrics,
    )


@app.post("/assess", response_model=AssessmentOut)
def assess(profile_id: int) -> AssessmentOut:
    if profile_id not in brain.profiles:
        raise HTTPException(status_code=404, detail="Profile not found")
    res: InjectionAssessment = brain.assess(profile_id)
    return AssessmentOut(
        profile_id=res.profile_id,
        name=res.name,
        survivability_score=res.survivability_score,
        band=res.band,
        weaknesses=res.weaknesses,
        strengths=res.strengths,
    )
