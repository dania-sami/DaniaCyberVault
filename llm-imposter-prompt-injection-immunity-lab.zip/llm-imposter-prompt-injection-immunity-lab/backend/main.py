
from fastapi import FastAPI
app = FastAPI(title="LLM-Imposter Prompt Injection Immunity Lab")

@app.get("/status")
def status():
    return {
        "project": "LLM-Imposter Prompt Injection Immunity Lab",
        "status": "working",
        "message": "All systems operational"
    }
