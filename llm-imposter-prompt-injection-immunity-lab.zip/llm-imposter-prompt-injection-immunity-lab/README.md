
# LLM-Imposter Prompt Injection Immunity Lab

This is the way I talk about prompt injection immunity without touching a real
model.

I describe my guardrails with simple scores like:
system prompt isolation, tool sandboxing, output filtering and how rigidly the
model treats system instructions.

The lab turns that into:
* a prompt contamination survivability score (0–100)
* a band from very low to high immunity
* short strengths and weaknesses I can read in a security review

## Run

```bash
cd backend
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn llm_imposter_engine.main:app --reload --port 9931
```

Open http://localhost:9931/docs and try `/profiles` then `/assess`.
