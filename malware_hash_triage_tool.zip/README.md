# Malware Hash Triage Tool

This project is a small hash based triage helper I use when I talk about malware analysis at a very basic level.

The script:

- Walks a folder
- Computes SHA-256 for each file
- Compares the hashes against a small local JSON list of `known_bad` and `known_good` hashes
- Prints a short summary

There are no external lookups. Everything is local and for learning only.

## Files

- `malware_triage.py` – main script
- `hashes_example.json` – local list of dummy known bad and good hashes

## Usage

```bash
python malware_triage.py --path sample_files --hashes hashes_example.json
```
