from __future__ import annotations

from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
MODELS_DIR = BASE_DIR / "models"

for d in (DATA_DIR, MODELS_DIR):
    d.mkdir(parents=True, exist_ok=True)


def generate_synthetic_orgs(n: int = 120) -> pd.DataFrame:
    rng = np.random.RandomState(21)
    rows = []
    industries = ["retail", "healthcare", "saas", "manufacturing", "finance"]
    for i in range(n):
        employees = rng.randint(10, 500)
        cloud_score = rng.randint(0, 4)  # 0 low, 3 heavy cloud reliance
        mfa_coverage = rng.uniform(0.0, 1.0)
        patch_delay = rng.randint(0, 90)  # days
        external_exposure = rng.randint(1, 10)
        has_sec_team = rng.binomial(1, 0.4)
        industry = rng.choice(industries)

        # Heuristic label
        risk = "low"
        if patch_delay > 45 or mfa_coverage < 0.3 or external_exposure >= 8:
            risk = "medium"
        if (patch_delay > 60 and mfa_coverage < 0.4) or (
            external_exposure >= 8 and has_sec_team == 0
        ):
            risk = "high"

        rows.append(
            {
                "org_id": f"ORG-{i+1:03d}",
                "employees": employees,
                "cloud_score": cloud_score,
                "mfa_coverage": mfa_coverage,
                "patch_delay_days": patch_delay,
                "external_exposure": external_exposure,
                "has_security_team": has_sec_team,
                "industry": industry,
                "risk_level": risk,
            }
        )
    return pd.DataFrame(rows)


def main() -> None:
    data_path = DATA_DIR / "org_profiles.csv"
    if data_path.exists():
        df = pd.read_csv(data_path)
    else:
        df = generate_synthetic_orgs()
        df.to_csv(data_path, index=False)

    features = [
        "employees",
        "cloud_score",
        "mfa_coverage",
        "patch_delay_days",
        "external_exposure",
        "has_security_team",
    ]

    # One-hot encode industry manually for simplicity
    df_encoded = pd.get_dummies(df, columns=["industry"])
    feature_cols = [c for c in df_encoded.columns if c not in ("org_id", "risk_level")]

    X = df_encoded[feature_cols]
    y = df_encoded["risk_level"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, random_state=42, stratify=y
    )

    clf = RandomForestClassifier(
        n_estimators=150, max_depth=6, random_state=42
    )
    clf.fit(X_train, y_train)

    y_pred = clf.predict(X_test)
    print("Validation report:")
    print(classification_report(y_test, y_pred))

    joblib.dump(
        {"model": clf, "feature_cols": feature_cols},
        MODELS_DIR / "breach_risk_model.joblib",
    )
    print(f"Saved model bundle to {MODELS_DIR/'breach_risk_model.joblib'}")


if __name__ == "__main__":
    main()
