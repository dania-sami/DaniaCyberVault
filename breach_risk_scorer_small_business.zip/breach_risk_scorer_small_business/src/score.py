from __future__ import annotations

import argparse
from pathlib import Path
from typing import Dict, Any, List

import joblib
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
MODELS_DIR = BASE_DIR / "models"


def load_bundle() -> Dict[str, Any]:
    return joblib.load(MODELS_DIR / "breach_risk_model.joblib")


def compute_drivers(row: pd.Series) -> List[str]:
    drivers: List[str] = []
    if row.get("patch_delay_days", 0) > 45:
        drivers.append("long patch delay")
    if row.get("mfa_coverage", 1.0) < 0.5:
        drivers.append("low MFA coverage")
    if row.get("external_exposure", 0) >= 7:
        drivers.append("high external exposure")
    if row.get("has_security_team", 1) == 0:
        drivers.append("no dedicated security team")
    if row.get("employees", 0) > 300:
        drivers.append("larger attack surface (many employees)")
    if not drivers:
        drivers.append("baseline risk only")
    return drivers


def main() -> None:
    parser = argparse.ArgumentParser(description="Breach risk scoring for small businesses")
    parser.add_argument("--path", type=str, required=True, help="Path to org_profiles CSV")
    args = parser.parse_args()

    bundle = load_bundle()
    model = bundle["model"]
    feature_cols = bundle["feature_cols"]

    df = pd.read_csv(args.path)
    df_encoded = pd.get_dummies(df, columns=["industry"])
    # Ensure all expected feature columns exist
    for col in feature_cols:
        if col not in df_encoded.columns:
            df_encoded[col] = 0
    X = df_encoded[feature_cols]

    preds = model.predict(X)
    proba = model.predict_proba(X)
    classes = list(model.classes_)

    for i, row in df.iterrows():
        org_id = row.get("org_id", f"row_{i}")
        probs = proba[i]
        label = preds[i]
        drivers = compute_drivers(row)
        print(f"{org_id}: predicted risk = {label}")
        print("  probabilities:")
        for c, p in zip(classes, probs):
            print(f"    {c}: {p:.2f}")
        print("  key drivers: " + ", ".join(drivers))
        print()


if __name__ == "__main__":
    main()
