# Predictive Breach Risk Scoring for Small Businesses

Hi, I am Dania 👋

This project is my **breach risk scoring lab** for small organisations:

- I simulate small-business profiles with realistic security attributes.
- I train a model that predicts **breach risk levels (low/medium/high)**.
- I also print the top human-readable factors driving each score.

It is a compact example of **risk-based security analytics**.

## How to run

```bash
cd breach_risk_scorer_small_business

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt

# Train the risk scoring model
python -m src.train

# Score the sample organisations
python -m src.score --path data/org_profiles.csv
```

The scorer prints each organisation, its risk level and the key drivers behind it.
