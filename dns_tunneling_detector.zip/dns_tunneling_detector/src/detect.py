from __future__ import annotations

import argparse

import joblib
import pandas as pd

from .config import MODEL_PATH
from .features import extract_features


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="DNS tunneling detector")
    parser.add_argument("--path", type=str, required=True, help="Path to DNS CSV file.")
    parser.add_argument("--top", type=int, default=10, help="Top N suspicious queries to show.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    df = pd.read_csv(args.path)
    X = extract_features(df)

    clf = joblib.load(MODEL_PATH)
    proba = clf.predict_proba(X)
    classes = clf.classes_
    # find index for "tunnel" class
    try:
        tunnel_idx = list(classes).index("tunnel")
    except ValueError:
        tunnel_idx = 1  # fallback

    tunnel_score = proba[:, tunnel_idx]
    df_scores = df.copy()
    df_scores["tunnel_score"] = tunnel_score
    df_scores = df_scores.sort_values("tunnel_score", ascending=False).head(args.top)

    print("Top suspicious DNS queries:")
    for _, row in df_scores.iterrows():
        print(
            f"{row['timestamp']} | {row['src_ip']} | {row['qname']} "
            f"| score={row['tunnel_score']:.3f}"
        )


if __name__ == "__main__":
    main()
