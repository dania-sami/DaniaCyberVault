from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
MODELS_DIR = BASE_DIR / "models"

DATA_DIR.mkdir(parents=True, exist_ok=True)
MODELS_DIR.mkdir(parents=True, exist_ok=True)

DNS_CSV = DATA_DIR / "dns_logs.csv"
MODEL_PATH = MODELS_DIR / "dns_tunnel_model.joblib"
