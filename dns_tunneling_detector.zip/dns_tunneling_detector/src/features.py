from __future__ import annotations

from typing import Iterable

import numpy as np
import pandas as pd


def extract_features(df: pd.DataFrame) -> pd.DataFrame:
    qname = df["qname"].fillna("")

    lengths = qname.str.len()
    labels = qname.str.split(".")
    num_labels = labels.apply(len).astype("float64")

    def avg_label_len(parts: Iterable[str]) -> float:
        parts = [p for p in parts if p]
        if not parts:
            return 0.0
        return float(sum(len(p) for p in parts) / len(parts))

    avg_label = labels.apply(avg_label_len)

    max_label_len = labels.apply(lambda parts: max((len(p) for p in parts if p), default=0))
    rand_like = (max_label_len > 20).astype("int64")

    size = df.get("size", 0).astype("float64")

    out = pd.DataFrame(
        {
            "len_qname": lengths.astype("float64"),
            "num_labels": num_labels,
            "avg_label_len": avg_label.astype("float64"),
            "max_label_len": max_label_len.astype("float64"),
            "rand_like_label": rand_like,
            "size": size,
        }
    )
    return out
