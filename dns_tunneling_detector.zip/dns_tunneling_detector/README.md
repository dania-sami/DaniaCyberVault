# DNS Tunneling Detector

Hi, I am Dania Sami 👋

DNS tunneling is a classic way to smuggle data out of a network using
DNS queries as a covert channel.

For this project I wanted something practical that:

- works on **DNS log CSVs**
- extracts simple **statistical features**
- trains a small ML model to distinguish **normal vs tunneling-like queries**
- highlights the top suspicious queries from a log file

This is not a full enterprise product, but it is a clean demonstration of how
to do **behavioural detection on DNS queries**.

---

## What this project does

1. **Takes DNS logs as CSV**

   The format is:

   - `timestamp`
   - `src_ip`
   - `qname`
   - `qtype`
   - `size`
   - `label` (only needed for training: `normal` or `tunnel`)

   I ship a small synthetic dataset in `data/dns_logs.csv` so the project works
   out of the box.

2. **Extracts features**

   In `src/features.py` I compute:

   - domain length
   - number of labels (subdomains)
   - average label length
   - presence of long random-looking labels
   - query size

3. **Trains a classifier**

   In `src/train.py` I train a `RandomForestClassifier` to classify queries as
   `normal` or `tunnel`. The model is saved to `models/dns_tunnel_model.joblib`.

4. **Runs detection on a log file**

   `src/detect.py` loads a CSV, applies the same feature extraction and prints
   the **top N most suspicious queries** with their probability of being
   tunneling.

---

## How to run

You need Python 3.10+.

```bash
python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt
```

### Train the model

```bash
python -m src.train
```

### Run detection on a (synthetic) log file

```bash
python -m src.detect --path data/dns_logs.csv --top 10
```

You will see a table of the most suspicious DNS queries according to the model.

---

## Project structure

```text
dns_tunneling_detector/
  ├─ README.md
  ├─ requirements.txt
  ├─ data/
  │    └─ dns_logs.csv
  ├─ models/
  │    └─ dns_tunnel_model.joblib
  └─ src/
       ├─ __init__.py
       ├─ config.py
       ├─ features.py
       ├─ train.py
       └─ detect.py
```

---

## Why I built this

DNS is everywhere in real environments, and tunneling is a real technique that
blue teams care about. This project shows that I understand:

- what makes DNS tunneling different from normal queries
- how to turn that intuition into features
- how to use ML to help analysts rank suspicious activity
