
# ethertrace-smart-contract-fraud-lab

I built this project as Dania.  
It is a compact security reasoning engine with FastAPI.

## How I run it

```
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn ethertrace_lab.main:app --reload --port 9900
```

## Usage

POST /analyse

```
{
  "metrics": {"signal": 0.9, "entropy": 0.8}
}
```

## What it does

* Computes a score based on anomalies
* Labels risk level
* Returns reasons in plain language
