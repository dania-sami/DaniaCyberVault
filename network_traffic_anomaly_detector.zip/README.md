# Network Traffic Anomaly Detector

This is a small script I wrote to play with very simple anomaly detection on network traffic data.

The idea is basic on purpose: I feed it a CSV file with timestamps and bytes per second, and it tells me when the traffic suddenly spikes compared to normal behaviour.

It is not meant to replace any serious SIEM or ML model, but it is a nice way for me to show that I understand the idea behind baselining and spotting outliers.

## What it does

- Reads a CSV file with two columns: `timestamp`, `bytes`
- Calculates the average and standard deviation
- Flags samples that are above **mean + 3×std** as anomalies
- Prints a short, clean summary

There is also a small script to generate dummy data so the project runs out of the box.

## Files

- `anomaly_detector.py`  – main script
- `generate_dummy_traffic.py` – creates a demo CSV

## Usage

Create demo data:

```bash
python generate_dummy_traffic.py
```

Run the detector:

```bash
python anomaly_detector.py --csv traffic_demo.csv
```

Example output:

```text
[+] Loaded 300 samples
[+] Mean bytes: 10234.12
[+] Std  bytes: 2033.55
[+] Threshold: 16334.77

[+] Anomalies:
    2025-01-01 12:05:00  bytes=45000
    2025-01-01 12:15:00  bytes=38000
```

## Why I built it

I wanted something very small but still useful to talk about:
- Baselines
- Spikes and outliers
- Simple detection logic without heavy libraries
