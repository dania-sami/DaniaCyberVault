import argparse
import csv
import statistics

def load_csv(path: str):
    timestamps = []
    values = []
    with open(path, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            try:
                ts = row["timestamp"]
                val = float(row["bytes"])
            except (KeyError, ValueError):
                continue
            timestamps.append(ts)
            values.append(val)
    return timestamps, values

def main():
    parser = argparse.ArgumentParser(description="Network Traffic Anomaly Detector by Dania")
    parser.add_argument("--csv", required=True, help="Path to CSV file with timestamp,bytes")
    args = parser.parse_args()

    ts, vals = load_csv(args.csv)
    if not vals:
        print("[-] No valid data in CSV")
        return

    mean = statistics.mean(vals)
    stdev = statistics.pstdev(vals)
    threshold = mean + 3 * stdev

    print(f"[+] Loaded {len(vals)} samples")
    print(f"[+] Mean bytes: {mean:.2f}")
    print(f"[+] Std  bytes: {stdev:.2f}")
    print(f"[+] Threshold: {threshold:.2f}\n")

    print("[+] Anomalies:")
    any_anomaly = False
    for t, v in zip(ts, vals):
        if v > threshold:
            any_anomaly = True
            print(f"    {t}  bytes={v:.0f}")
    if not any_anomaly:
        print("    (none, traffic looks normal by this simple rule)")

if __name__ == "__main__":
    main()
