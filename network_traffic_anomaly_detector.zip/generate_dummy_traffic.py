import csv
import random
from datetime import datetime, timedelta

def generate_demo_csv(path: str, minutes: int = 300):
    start = datetime(2025, 1, 1, 12, 0, 0)
    rows = []

    base = 10000
    for i in range(minutes):
        ts = start + timedelta(minutes=i)
        # Normal traffic with some noise
        val = base + random.randint(-2000, 2000)
        # Occasionally simulate a big spike
        if random.random() < 0.03:
            val = base * 3 + random.randint(0, 10000)
        rows.append({"timestamp": ts.strftime("%Y-%m-%d %H:%M:%S"), "bytes": val})

    with open(path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["timestamp", "bytes"])
        writer.writeheader()
        writer.writerows(rows)

if __name__ == "__main__":
    generate_demo_csv("traffic_demo.csv")
    print("[+] Demo traffic written to traffic_demo.csv")
