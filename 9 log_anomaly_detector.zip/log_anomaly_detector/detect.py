
import argparse
import joblib
import numpy as np
from pathlib import Path


def extract_features(lines):
    feats = []
    for line in lines:
        length = len(line)
        digits = sum(c.isdigit() for c in line)
        uppercase = sum(c.isupper() for c in line)
        symbols = sum(not c.isalnum() and not c.isspace() for c in line)
        feats.append([length, digits, uppercase, symbols])
    return np.array(feats, dtype=float)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("logfile", type=str)
    parser.add_argument("--model", default="model.joblib")
    parser.add_argument("--scaler", default="scaler.joblib")
    args = parser.parse_args()

    logfile = Path(args.logfile)
    if not logfile.is_file():
        raise SystemExit(f"Log file not found: {logfile}")

    lines = logfile.read_text(errors="ignore").splitlines()

    model = joblib.load(args.model)
    scaler = joblib.load(args.scaler)

    X = extract_features(lines)
    X_scaled = scaler.transform(X)

    preds = model.predict(X_scaled)  # -1 = anomaly

    print(f"[info] Total lines: {len(lines)}")
    anomalies = np.where(preds == -1)[0]
    print(f"[info] Anomalies: {len(anomalies)}")

    for idx in anomalies:
        print(f"[warn] Suspicious line {idx}: {lines[idx]}")


if __name__ == "__main__":
    main()
