
# Log Anomaly Detection Tool

I built this project to learn how security teams detect unusual or suspicious patterns inside log files.  
It reads a log, learns what “normal” looks like, and then highlights lines that look strange or out of pattern.

---

## What this project does

- Reads any plain text log file  
- Extracts simple numeric features from each line  
- Trains an Isolation Forest anomaly detection model  
- Flags log lines that look unusual  
- Prints a clean summary of suspicious entries  

It’s a simple and effective way to practise log analysis in cyber security.

---

## Installation

```bash
python3 -m venv venv
source venv/bin/activate           # Windows  venv\Scripts\activate
pip install -r requirements.txt
```

---

## Step 1: Train the model

Use any log file you have:

```bash
python train_model.py path/to/logfile.log
```

This creates:
- model.joblib  
- scaler.joblib  

---

## Step 2: Detect anomalies

```bash
python detect.py path/to/logfile.log
```

Example output:

```
[info] Total lines  524
[info] Anomalies    7
[warn] Suspicious line 104: Failed password for invalid user admin
```

---

## Why this matters for cyber security

Log analysis is one of the most important skills in defensive security.  
By making this tool, I practised:

- spotting unusual behaviour  
- using ML to detect suspicious log entries  
- understanding patterns in system activity  

It’s simple, clean, and shows real interest in security work.
