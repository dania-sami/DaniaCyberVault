
import argparse
import joblib
import numpy as np
from pathlib import Path
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler


def extract_features(lines):
    feats = []
    for line in lines:
        length = len(line)
        digits = sum(c.isdigit() for c in line)
        uppercase = sum(c.isupper() for c in line)
        symbols = sum(not c.isalnum() and not c.isspace() for c in line)
        feats.append([length, digits, uppercase, symbols])
    return np.array(feats, dtype=float)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("logfile", type=str)
    args = parser.parse_args()

    path = Path(args.logfile)
    if not path.is_file():
        raise SystemExit(f"Log file not found: {path}")

    lines = path.read_text(errors="ignore").splitlines()
    X = extract_features(lines)

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    model = IsolationForest(random_state=42, contamination=0.05)
    model.fit(X_scaled)

    joblib.dump(model, "model.joblib")
    joblib.dump(scaler, "scaler.joblib")

    print("[info] Model trained")
    print(f"[info] Total lines used: {len(lines)}")


if __name__ == "__main__":
    main()
