// LLM Misuse Monitor content script
// Wraps fetch and XHR to observe AI related network calls and store local timeline entries

(function() {
  const AI_HINTS = ["openai", "anthropic", "v1/chat/completions", "v1/completions", "claude", "gpt"];

  function looksLikeAIUrl(url) {
    const lower = url.toLowerCase();
    return AI_HINTS.some(h => lower.includes(h));
  }

  function analyseBody(bodyText) {
    const reasons = [];
    const lower = bodyText.toLowerCase();

    // simple code-like heuristic
    if (lower.includes("function(") || lower.includes("=>") || lower.includes("var ") || lower.includes("const ")) {
      if (lower.includes("eval(") || lower.includes("new function(")) {
        reasons.push("code_like_with_eval");
      } else {
        reasons.push("code_like");
      }
    }

    // obfuscation like
    if (lower.includes("atob(") && bodyText.length > 500) {
      reasons.push("obfuscation_like");
    }

    // external url heuristic
    const urlMatch = bodyText.match(/https?:\/\/[^\s"'`]+/g);
    if (urlMatch && urlMatch.length > 0) {
      reasons.push("external_url");
    }

    return reasons;
  }

  function storeTimelineEntry(entry) {
    try {
      chrome.storage.local.get({ timeline: [] }, function(data) {
        const timeline = data.timeline || [];
        timeline.unshift(entry);
        // keep only the latest 50
        const trimmed = timeline.slice(0, 50);
        chrome.storage.local.set({ timeline: trimmed });
      });
    } catch (e) {
      // not fatal
      console.warn("LLM Misuse Monitor storage error", e);
    }
  }

  // Wrap fetch
  const origFetch = window.fetch;
  window.fetch = function(input, init) {
    const url = typeof input === "string" ? input : (input && input.url) || "";
    const isAI = looksLikeAIUrl(url);

    if (!isAI) {
      return origFetch.apply(this, arguments);
    }

    return origFetch.apply(this, arguments).then(async (response) => {
      try {
        const clone = response.clone();
        const text = await clone.text();
        const reasons = analyseBody(text);
        if (reasons.length > 0) {
          const entry = {
            ts: new Date().toISOString(),
            source: "fetch",
            url: url,
            host: (new URL(url)).host,
            reasons: reasons
          };
          console.log("[LLM Misuse Monitor] suspicious AI response", entry);
          storeTimelineEntry(entry);
        }
      } catch (e) {
        console.warn("[LLM Misuse Monitor] failed to analyse response", e);
      }
      return response;
    });
  };

  // Wrap XHR
  const OrigXHR = window.XMLHttpRequest;
  function WrappedXHR() {
    const xhr = new OrigXHR();
    let url = "";
    let isAI = false;

    const origOpen = xhr.open;
    xhr.open = function(method, requestUrl) {
      url = requestUrl || "";
      isAI = looksLikeAIUrl(url);
      return origOpen.apply(xhr, arguments);
    };

    xhr.addEventListener("load", function() {
      if (!isAI) return;
      try {
        const text = xhr.responseText || "";
        const reasons = analyseBody(text);
        if (reasons.length > 0) {
          const entry = {
            ts: new Date().toISOString(),
            source: "xhr",
            url: url,
            host: (new URL(url, window.location.href)).host,
            reasons: reasons
          };
          console.log("[LLM Misuse Monitor] suspicious AI XHR response", entry);
          storeTimelineEntry(entry);
        }
      } catch (e) {
        console.warn("[LLM Misuse Monitor] error in XHR analysis", e);
      }
    });

    return xhr;
  }
  window.XMLHttpRequest = WrappedXHR;
})();
