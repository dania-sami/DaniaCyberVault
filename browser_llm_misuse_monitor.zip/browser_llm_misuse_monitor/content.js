// monitors suspicious patterns
chrome.storage.local.get({logs:[]}, x=>{});
function log(x){chrome.storage.local.get({logs:[]}, d=>{
 d.logs.push({...x,ts:Date.now()}); chrome.storage.local.set({logs:d.logs});
});}
new MutationObserver(m=>{
 m.forEach(rec=>{
   rec.addedNodes.forEach(n=>{
     if(n.innerText && n.innerText.match(/eval|atob|new Function/)){
        log({type:"sus_output", snippet:n.innerText.slice(0,200)});
     }
   })
 })
}).observe(document.body,{childList:true,subtree:true});
