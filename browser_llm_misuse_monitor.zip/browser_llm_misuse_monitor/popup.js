// Popup script: render last suspicious responses from storage

document.addEventListener("DOMContentLoaded", function() {
  const container = document.getElementById("entries");
  chrome.storage.local.get({ timeline: [] }, function(data) {
    const timeline = data.timeline || [];
    if (timeline.length === 0) {
      container.textContent = "No suspicious AI responses observed yet with current simple rules.";
      return;
    }
    container.innerHTML = "";
    timeline.forEach(entry => {
      const div = document.createElement("div");
      div.className = "entry";
      const host = document.createElement("div");
      host.className = "host";
      host.textContent = entry.host || "(unknown host)";
      const reasons = document.createElement("div");
      reasons.className = "reasons";
      reasons.textContent = "Reasons: " + (entry.reasons || []).join(", ");
      const ts = document.createElement("div");
      ts.className = "ts";
      ts.textContent = entry.ts;
      div.appendChild(host);
      div.appendChild(reasons);
      div.appendChild(ts);
      container.appendChild(div);
    });
  });
});
