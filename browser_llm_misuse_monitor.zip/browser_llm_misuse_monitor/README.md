# Browser side LLM Misuse Monitor – Dania’s local AI traffic notebook

Hi

I am Dania and this project is a small browser extension style skeleton that watches AI related network calls in the browser and keeps a **local** timeline of potentially risky outputs

It is designed for researchers and blue teamers who want to better understand how browser based tools use AI APIs
not for blocking users or phoning data home

Everything stays local in `chrome.storage` and the console
There is no backend and nothing leaves the browser

## What the extension does

At a high level

* a content script wraps `window.fetch` and `XMLHttpRequest`
* if a request URL looks like an AI model endpoint (for example it mentions `openai` or `v1/chat/completions`)
  * it clones the response text
  * runs a few simple checks on the output
* suspicious looking responses are stored in `chrome.storage.local` as timeline entries

Heuristics are intentionally simple and transparent for the demo

* does the output look like JavaScript code with `eval(` or `new Function(`
* does it combine code and obfuscation helpers like `atob(` plus long random looking strings
* does it contain unknown external URLs that could be used for callbacks

The popup shows a tiny view of the stored timeline

* timestamp
* URL host
* a very short reason such as
  * `code_like`
  * `obfuscation_like`
  * `external_url`

This makes it easier to review how often browser tools request things that look like runnable scripts from AI models.

## Files in this project

* `manifest.json`
* `content_script.js`
* `popup.html`
* `popup.js`
* `README.md` (this file)

I keep the scope deliberately small so it is easy to read through and extend

## How to load it (Chrome style)

1. Open `chrome://extensions` in your browser
2. Enable **Developer mode**
3. Click **Load unpacked**
4. Select the `browser_llm_misuse_monitor` directory

The extension will appear in the toolbar
Pin it if you want quick access to the popup

## How to use it in practice

1. With the extension loaded
2. Visit a page that uses AI in the browser or through JavaScript calls
3. Open **DevTools** and the **Console**
4. Trigger some AI calls  for example a chat completion in a web app

The content script will log when it sees AI related requests and will

* attempt to clone the response
* run the simple misuse heuristics
* store any hits in local storage

Then you can open the extension popup

* click the icon
* it will read from `chrome.storage.local`
* you will see a short list of recent suspicious looking responses

This is not meant to be perfect detection
It is a research notebook style tool to support manual analysis

## Why I built this

There is a lot of discussion around AI powered attack tools
but not many simple ways to look at AI usage from the **browser side**

With this project I can show that I

* understand how to intercept network calls in web context
* can design light weight and explainable heuristics for risky outputs
* think about privacy and keep data local by default
* can turn all of this into a clean browser extension structure

For a production ready version
I would add better UI, more precise detection logic, and configurable rules
but this skeleton already demonstrates the idea clearly.
