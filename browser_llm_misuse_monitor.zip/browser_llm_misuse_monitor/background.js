chrome.webRequest.onBeforeRequest.addListener(
 d=>{
   if(d.url.includes("/v1/chat")||d.url.includes("ai")){
      chrome.storage.local.get({logs:[]}, x=>{
       x.logs.push({type:"ai_call",url:d.url,ts:Date.now()});
       chrome.storage.local.set({logs:x.logs});
      });
   }
 },
 {urls:["<all_urls>"]},
 ["blocking"]
);
