# DNS Spoofing Integrity Checker

This is a safe simulation tool I made. It checks mismatches in expected vs observed DNS results.
