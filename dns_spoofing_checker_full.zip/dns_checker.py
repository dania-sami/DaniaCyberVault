import argparse, csv

def check(path):
    with open(path) as f:
        r = csv.DictReader(f)
        for row in r:
            if row["expected_ip"] != row["observed_ip"]:
                print(f"[!] {row['domain']} mismatch: {row['expected_ip']} != {row['observed_ip']}")
    print("[+] Done")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", required=True)
    args = ap.parse_args()
    check(args.csv)

if __name__ == "__main__":
    main()
