
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Dict, List

from .engine import ZeroTraceBrain, ImplProfile, HardeningAdvice


brain = ZeroTraceBrain()


class ImplIn(BaseModel):
    name: str = Field(..., example="aes_table_based_impl")
    meta: Dict[str, str] = Field(default_factory=dict)
    metrics: Dict[str, float] = Field(
        default_factory=dict,
        description="Metrics: timing_leakage_score, cache_leakage_score, power_leakage_score, em_leakage_score, masking_maturity",
    )


class ImplOut(BaseModel):
    id: int
    name: str
    meta: Dict[str, str]
    metrics: Dict[str, float]


class AdviceOut(BaseModel):
    impl_id: int
    name: str
    leakage_pressure: float
    band: str
    primary_focus: str
    recommendations: List[str]


app = FastAPI(
    title="ZeroTrace Side-Channel Hardening Advisor",
    version="0.1.0",
    description="My advisor for side-channel hardening priorities based on abstract leakage metrics.",
)


@app.post("/impls", response_model=ImplOut)
def register_impl(payload: ImplIn) -> ImplOut:
    prof: ImplProfile = brain.register_impl(
        name=payload.name,
        meta=payload.meta,
        metrics=payload.metrics,
    )
    return ImplOut(
        id=prof.id,
        name=prof.name,
        meta=prof.meta,
        metrics=prof.metrics,
    )


@app.post("/advise", response_model=AdviceOut)
def advise(impl_id: int) -> AdviceOut:
    if impl_id not in brain.impls:
        raise HTTPException(status_code=404, detail="Implementation not found")
    advice: HardeningAdvice = brain.advise(impl_id)
    return AdviceOut(
        impl_id=advice.impl_id,
        name=advice.name,
        leakage_pressure=advice.leakage_pressure,
        band=advice.band,
        primary_focus=advice.primary_focus,
        recommendations=advice.recommendations,
    )
