"""ZeroTrace Side-Channel Hardening Advisor backend package."""
