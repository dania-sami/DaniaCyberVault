
from dataclasses import dataclass
from typing import Dict, List


@dataclass
class ImplProfile:
    id: int
    name: str
    meta: Dict[str, str]
    metrics: Dict[str, float]


@dataclass
class HardeningAdvice:
    impl_id: int
    name: str
    leakage_pressure: float
    band: str
    primary_focus: str
    recommendations: List[str]


class ZeroTraceBrain:
    """
    ZeroTrace is my side-channel hardening advisor.

    The goal is simple: look at abstract leakage metrics and tell me where to
    focus first: timing, cache, power or EM, and what basic hardening moves
    make the most sense.
    """

    def __init__(self) -> None:
        self._next_id = 1
        self.impls: Dict[int, ImplProfile] = {}

    def register_impl(self, name: str, meta: Dict[str, str], metrics: Dict[str, float]) -> ImplProfile:
        iid = self._next_id
        self._next_id += 1
        prof = ImplProfile(
            id=iid,
            name=name,
            meta=meta,
            metrics=metrics,
        )
        self.impls[iid] = prof
        return prof

    def advise(self, impl_id: int) -> HardeningAdvice:
        prof = self.impls[impl_id]
        m = prof.metrics
        recs: List[str] = []

        timing = float(m.get("timing_leakage_score", 0.0))
        cache = float(m.get("cache_leakage_score", 0.0))
        power = float(m.get("power_leakage_score", 0.0))
        em = float(m.get("em_leakage_score", 0.0))
        masking = float(m.get("masking_maturity", 0.0))

        leakage_pressure = (timing + cache + power + em) / 4.0 * 100.0

        channel_scores = {
            "timing": timing,
            "cache": cache,
            "power": power,
            "em": em,
        }
        primary_focus = max(channel_scores, key=channel_scores.get)

        if timing > 0.4:
            recs.append("Move critical code paths to constant-time patterns.")
        if cache > 0.4:
            recs.append("Use cache-neutral access patterns or prefetch strategies.")
        if power > 0.4 or em > 0.4:
            recs.append("Consider masking and shuffling for sensitive operations.")
        if masking < 0.3:
            recs.append("Increase masking maturity through targeted code segments.")
        if not recs:
            recs.append("Leakage scores look low; monitor but focus on other risks first.")

        if leakage_pressure >= 80.0:
            band = "urgent_hardening_needed"
        elif leakage_pressure >= 60.0:
            band = "hardening_should_be_prio"
        elif leakage_pressure >= 40.0:
            band = "medium_concern"
        elif leakage_pressure >= 20.0:
            band = "low_concern"
        else:
            band = "very_low_concern"

        return HardeningAdvice(
            impl_id=prof.id,
            name=prof.name,
            leakage_pressure=round(leakage_pressure, 2),
            band=band,
            primary_focus=primary_focus,
            recommendations=recs,
        )
