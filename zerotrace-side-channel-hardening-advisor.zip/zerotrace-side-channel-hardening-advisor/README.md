
# ZeroTrace Side-Channel Hardening Advisor

ZeroTrace is my quick advisor for side-channel hardening.

I give it rough leakage scores for timing, cache, power and EM plus a sense of
masking maturity. It tells me:
* how much overall leakage pressure I am under
* which channel deserves focus first
* a short set of hardening recommendations

## Run

```bash
cd backend
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn zerotrace_engine.main:app --reload --port 9922
```

Then open http://localhost:9922/docs and use `/impls` then `/advise`.
