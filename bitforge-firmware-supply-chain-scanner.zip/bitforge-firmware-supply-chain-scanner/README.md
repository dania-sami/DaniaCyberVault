
# BitForge Firmware Supply Chain Scanner

BitForge is my firmware supply chain reasoning engine.

In real environments firmware is one of the hardest things to reason about.
Images come from different build systems, third party vendors, and update
servers that may or may not be well protected. Instead of pretending to
reverse engineer binaries inside a portfolio project, I focus on the signals
that usually drive risk conversations.

BitForge takes a firmware profile with boolean signals about security posture
and produces a clear supply chain risk score plus narrative reasons.

## What this project does

* lets me register firmware profiles with
  * device model
  * vendor
  * version
  * free form metadata
  * a dictionary of boolean security signals
* calculates a risk score between zero and one hundred based on those signals
* assigns a band such as
  * `low_supply_chain_risk`
  * `moderate_supply_chain_risk`
  * `elevated_supply_chain_risk`
  * `high_supply_chain_risk`
  * `critical_supply_chain_risk`
* returns human readable reasons that show exactly which conditions increased
  or reduced the risk

All of the scoring logic is in one file `engine.py` so anyone can review or
tune it.

## Project layout

```text
bitforge-firmware-supply-chain-scanner
└── backend
    ├── bitforge_scanner
    │   ├── __init__.py
    │   ├── engine.py  Firmware profile model and risk scoring
    │   └── main.py    FastAPI HTTP API
    ├── requirements.txt
    └── example_requests.http
```

## How I run it locally

From the backend folder

```bash
python -m venv .venv
source .venv/bin/activate        # On Windows I use .venv\Scripts\activate
pip install -r requirements.txt
uvicorn bitforge_scanner.main:app --reload --port 9901
```

Then I open

* http://localhost:9901/docs to call the endpoints interactively

## Example I like to show

First I register a firmware profile that looks a bit messy from a supply chain
perspective.

```bash
curl -X POST http://localhost:9901/profiles   -H "Content-Type: application/json"   -d '{
    "device_model": "router-x1000",
    "vendor": "trusted-networks-inc",
    "version": "1.2.3",
    "meta": {
      "environment": "branch-office"
    },
    "signals": {
      "unsigned_updates": false,
      "rollback_allowed": true,
      "debug_interface_open": true,
      "no_secure_boot": false,
      "unvetted_third_party_blob": true,
      "build_pipeline_unverified": true,
      "keys_on_device": false,
      "insecure_update_channel": false,
      "measured_boot": true,
      "hardware_root_of_trust": false,
      "independent_security_audit": false
    }
  }'
```

Then I ask BitForge to assess it.

```bash
curl -X POST "http://localhost:9901/assess?profile_id=1"
```

The response gives me

* a numeric score
* a band such as `high_supply_chain_risk`
* a list of reasons that map directly to the signals

This is exactly the kind of material I like to use when leading a discussion
about firmware hardening and supply chain improvements.

## Future directions

If I want to extend BitForge later I can

* pull real metadata from inventory systems
* connect it with SBOM information
* tune scores based on threat intelligence

Even in this focused version it already shows how I reason about firmware
supply chain risk in a structured and explainable way.
