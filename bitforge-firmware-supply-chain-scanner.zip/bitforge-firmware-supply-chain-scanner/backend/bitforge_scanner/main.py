
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Dict, List

from .engine import BitForgeBrain, FirmwareProfile, FirmwareAssessment


brain = BitForgeBrain()


class ProfileIn(BaseModel):
    device_model: str = Field(..., example="router-x1000")
    vendor: str = Field(..., example="trusted-networks-inc")
    version: str = Field(..., example="1.2.3")
    meta: Dict[str, str] = Field(
        default_factory=dict,
        description="Free form metadata such as product line or environment.",
    )
    signals: Dict[str, bool] = Field(
        default_factory=dict,
        description=(
            "Signals like unsigned_updates, rollback_allowed, debug_interface_open, "
            "no_secure_boot, unvetted_third_party_blob, build_pipeline_unverified, "
            "keys_on_device, insecure_update_channel, measured_boot, "
            "hardware_root_of_trust, independent_security_audit"
        ),
    )


class ProfileOut(BaseModel):
    id: int
    device_model: str
    vendor: str
    version: str
    meta: Dict[str, str]
    signals: Dict[str, bool]


class AssessmentOut(BaseModel):
    profile_id: int
    device_model: str
    vendor: str
    version: str
    score: float
    band: str
    reasons: List[str]


app = FastAPI(
    title="BitForge Firmware Supply Chain Scanner",
    version="0.1.0",
    description="My reasoning engine for firmware and supply chain risk based on high level signals.",
)


@app.post("/profiles", response_model=ProfileOut)
def register_profile(payload: ProfileIn) -> ProfileOut:
    prof: FirmwareProfile = brain.register_profile(
        device_model=payload.device_model,
        vendor=payload.vendor,
        version=payload.version,
        meta=payload.meta,
        signals=payload.signals,
    )
    return ProfileOut(
        id=prof.id,
        device_model=prof.device_model,
        vendor=prof.vendor,
        version=prof.version,
        meta=prof.meta,
        signals=prof.signals,
    )


@app.post("/assess", response_model=AssessmentOut)
def assess(profile_id: int) -> AssessmentOut:
    if profile_id not in brain.profiles:
        raise HTTPException(status_code=404, detail="Firmware profile not found")
    res: FirmwareAssessment = brain.assess(profile_id)
    return AssessmentOut(
        profile_id=res.profile_id,
        device_model=res.device_model,
        vendor=res.vendor,
        version=res.version,
        score=res.score,
        band=res.band,
        reasons=res.reasons,
    )
