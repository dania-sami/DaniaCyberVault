
from dataclasses import dataclass
from typing import Dict, List


@dataclass
class FirmwareProfile:
    id: int
    device_model: str
    vendor: str
    version: str
    meta: Dict[str, str]
    signals: Dict[str, bool]


@dataclass
class FirmwareAssessment:
    profile_id: int
    device_model: str
    vendor: str
    version: str
    score: float
    band: str
    reasons: List[str]


class BitForgeBrain:
    """
    BitForge is my firmware supply chain reasoning engine.

    I use it to talk about firmware risk without ever touching real binary
    images. Instead I work with high level signals such as

    * is secure boot enforced
    * are updates signed and validated
    * is rollback protection enabled
    * are debug interfaces locked down
    * do we trust the build pipeline
    * are there unexpected third party components

    From these signals BitForge produces a risk score and narrative reasons.
    """

    def __init__(self) -> None:
        self._next_id = 1
        self.profiles: Dict[int, FirmwareProfile] = {}

    def register_profile(
        self,
        device_model: str,
        vendor: str,
        version: str,
        meta: Dict[str, str],
        signals: Dict[str, bool],
    ) -> FirmwareProfile:
        pid = self._next_id
        self._next_id += 1
        profile = FirmwareProfile(
            id=pid,
            device_model=device_model,
            vendor=vendor,
            version=version,
            meta=meta,
            signals=signals,
        )
        self.profiles[pid] = profile
        return profile

    def assess(self, profile_id: int) -> FirmwareAssessment:
        profile = self.profiles[profile_id]
        s = profile.signals
        reasons: List[str] = []
        score = 0.0

        # Negative signals add risk
        if s.get("unsigned_updates"):
            score += 25.0
            reasons.append("Firmware updates are not strictly signed and verified.")
        if s.get("rollback_allowed"):
            score += 20.0
            reasons.append("Rollback to older firmware is allowed, enabling downgrade attacks.")
        if s.get("debug_interface_open"):
            score += 15.0
            reasons.append("Hardware debug interface (JTAG, UART, etc.) is exposed or not locked down.")
        if s.get("no_secure_boot"):
            score += 25.0
            reasons.append("Secure boot is not enforced for this device.")
        if s.get("unvetted_third_party_blob"):
            score += 20.0
            reasons.append("Unvetted third party firmware components are present.")
        if s.get("build_pipeline_unverified"):
            score += 20.0
            reasons.append("Build pipeline provenance is uncertain or not attested.")
        if s.get("keys_on_device"):
            score += 15.0
            reasons.append("Signing or encryption keys are stored directly on the device.")
        if s.get("insecure_update_channel"):
            score += 25.0
            reasons.append("Update channel is not strongly protected against tampering.")

        # Positive signals reduce risk slightly
        if s.get("measured_boot"):
            score -= 10.0
            reasons.append("Measured boot support reduces the impact of some firmware tampering.")
        if s.get("hardware_root_of_trust"):
            score -= 15.0
            reasons.append("Hardware root of trust present, improving supply chain resilience.")
        if s.get("independent_security_audit"):
            score -= 10.0
            reasons.append("Recent independent security audit reported for the firmware line.")

        score = max(0.0, min(100.0, score))

        if score >= 80.0:
            band = "critical_supply_chain_risk"
        elif score >= 60.0:
            band = "high_supply_chain_risk"
        elif score >= 40.0:
            band = "elevated_supply_chain_risk"
        elif score >= 20.0:
            band = "moderate_supply_chain_risk"
        else:
            band = "low_supply_chain_risk"

        if not reasons:
            reasons.append("No strong negative or positive signals were provided; defaulting to neutral assessment.")

        return FirmwareAssessment(
            profile_id=profile.id,
            device_model=profile.device_model,
            vendor=profile.vendor,
            version=profile.version,
            score=round(score, 2),
            band=band,
            reasons=reasons,
        )
