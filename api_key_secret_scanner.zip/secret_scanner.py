import argparse
import os
import re

# Very simple example patterns, not perfect on purpose
PATERNS = [
    (re.compile(r"AKIA[0-9A-Z]{16}"), "possible AWS access key"),
    (re.compile(r"(?i)secret[_-]?key\s*[:=]\s*['\"]?[A-Za-z0-9+/]{20,}"), "generic secret key assignment"),
    (re.compile(r"(?i)api[_-]?key\s*[:=]\s*['\"]?[A-Za-z0-9]{16,}"), "API key assignment"),
    (re.compile(r"[A-Fa-f0-9]{32,}"), "long hex string"),
]

TEXT_EXT = {".py", ".js", ".ts", ".txt", ".env", ".json", ".yml", ".yaml", ".cfg", ".ini", ".md"}

def should_scan_file(path: str) -> bool:
    _, ext = os.path.splitext(path)
    return ext.lower() in TEXT_EXT

def scan_file(path: str):
    results = []
    try:
        with open(path, "r", errors="ignore") as f:
            for lineno, line in enumerate(f, start=1):
                for regex, desc in PATERNS:
                    if regex.search(line):
                        results.append((lineno, line.rstrip("\n"), desc))
    except (OSError, UnicodeDecodeError):
        return []
    return results

def scan_folder(root: str):
    for dirpath, _, files in os.walk(root):
        for name in files:
            full = os.path.join(dirpath, name)
            if not should_scan_file(full):
                continue
            findings = scan_file(full)
            if findings:
                rel = os.path.relpath(full, root)
                print(f"[+] Possible secrets in {rel}:")
                for lineno, line, desc in findings:
                    print(f"    line {lineno}: {line}")
                    print(f"        -> {desc}")
                print()

def main():
    parser = argparse.ArgumentParser(description="Local API Key and Secret Scanner by Dania")
    parser.add_argument("--path", required=True, help="Root folder to scan")
    args = parser.parse_args()
    scan_folder(args.path)

if __name__ == "__main__":
    main()
