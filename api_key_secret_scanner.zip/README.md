# Local API Key and Secret Scanner

This project is a local file scanner I use to check small projects for accidentally committed API keys and secrets.

It does not upload anything anywhere. It simply walks a folder, looks at text files and applies a few simple regular expressions to highlight lines that look like they might contain keys or tokens.

## Features

- Recursively walks a directory
- Skips obvious binary files by extension
- Highlights lines that match simple patterns (like `AWS` style keys or long hex strings)
- Includes a small demo file to show how it works

## Usage

```bash
python secret_scanner.py --path demo_project
```

The idea is not to perfectly detect every secret, but to show that I know how to reason about accidental leaks in code.
