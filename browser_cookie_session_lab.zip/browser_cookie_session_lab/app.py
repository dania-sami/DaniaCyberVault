from flask import Flask, make_response, redirect, url_for, request, render_template_string
import secrets

app = Flask(__name__)

TEMPLATE_LOGIN = '''
<!doctype html>
<title>Login Simulator</title>
<h1>Login Simulator</h1>
<p>This is a safe local demo of a session cookie.</p>
<form method="post">
  <button type="submit">Log in</button>
</form>
'''

TEMPLATE_DASH = '''
<!doctype html>
<title>Dashboard</title>
<h1>Dashboard</h1>
<p>You are "logged in" with session id: {{ sid }}</p>
<p>Try opening <a href="{{ leak_url }}">/leak</a> to see a simulated leak.</p>
'''

TEMPLATE_LEAK = '''
<!doctype html>
<title>Leak Simulation</title>
<h1>Leak Simulation</h1>
<p>This page shows a <b>fake captured HTTP request</b> that contains your cookie.</p>
<pre>{{ request_text }}</pre>
<p>This is why we never want session IDs to be visible or sent over insecure channels.</p>
'''

SESSION_COOKIE_NAME = "demo_session_id"


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        sid = secrets.token_hex(16)
        resp = make_response(redirect(url_for("dashboard")))
        resp.set_cookie(SESSION_COOKIE_NAME, sid, httponly=True)
        return resp
    return render_template_string(TEMPLATE_LOGIN)


@app.route("/dashboard")
def dashboard():
    sid = request.cookies.get(SESSION_COOKIE_NAME)
    if not sid:
        return redirect(url_for("login"))
    return render_template_string(
        TEMPLATE_DASH,
        sid=sid,
        leak_url=url_for("leak"),
    )


@app.route("/leak")
def leak():
    sid = request.cookies.get(SESSION_COOKIE_NAME, "UNKNOWN")
    fake_request = f"""GET /dashboard HTTP/1.1
Host: localhost:5000
User-Agent: DemoBrowser/1.0
Cookie: {SESSION_COOKIE_NAME}={sid}
"""
    return render_template_string(
        TEMPLATE_LEAK,
        request_text=fake_request,
    )


if __name__ == "__main__":
    app.run(debug=True)
