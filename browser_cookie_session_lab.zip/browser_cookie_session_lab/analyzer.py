fake_http = """GET /dashboard HTTP/1.1
Host: localhost:5000
User-Agent: DemoBrowser/1.0
Cookie: demo_session_id=abc123fakevalue
"""


def extract_cookie(request_text: str) -> str | None:
    for line in request_text.splitlines():
        if line.lower().startswith("cookie:"):
            return line.split(":", 1)[1].strip()
    return None


if __name__ == "__main__":
    cookie_header = extract_cookie(fake_http)
    print("Simulated captured request:")
    print(fake_http)
    print()
    print(f"Extracted Cookie header: {cookie_header}")
