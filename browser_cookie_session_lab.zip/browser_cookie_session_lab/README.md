# Browser Cookie and Session Hijack Simulator (Safe Lab)

Hi, I am Dania Sami 👋

I built this small lab to **understand how cookies and sessions work in the browser**
and what happens if a session token is leaked.

This is a completely **local and safe simulation**. It does not attack any real
site and is only meant to teach:

- how a login session is created
- where cookies are used
- why leaking a session ID is dangerous
- how secure flags (HttpOnly, Secure) protect us

---

## What this lab contains

1. **A tiny Flask web app**

   In `app.py` I run a local server with three pages:

   - `/login` – simulates a login and sets a session cookie
   - `/dashboard` – only accessible if the cookie is present
   - `/leak` – shows what would happen if the session ID leaked (simulated)

2. **A simple "analyzer"**

   In `analyzer.py` I parse a fake HTTP request and extract its `Cookie` header
   just to demonstrate how easily a leaked request could expose a session ID.

No real exploitation is happening. Everything is about seeing the flow and
understanding why **protecting cookies and HTTPS** matters.

---

## How to run

You need Python 3.10+.

```bash
python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt

export FLASK_APP=app.py
flask run
```

Open `http://127.0.0.1:5000/login` in your browser.

Flow:

1. Go to `/login` → click the button to "log in"
2. You will be redirected to `/dashboard`, which reads the session cookie
3. Visit `/leak` to see a simulated "leaked request" and how the cookie looks

You can then run the analyzer:

```bash
python analyzer.py
```

to see how easy it is to programmatically read that cookie value once leaked.

---

## Project structure

```text
browser_cookie_session_lab/
  ├─ README.md
  ├─ requirements.txt
  ├─ app.py
  └─ analyzer.py
```

---

## Why I built this

I wanted a concrete way to talk about:

- why session cookies must be protected
- why HttpOnly and Secure flags matter
- why we should avoid putting secrets in URLs

This little lab lets me demo the typical flow in interviews or workshops, and
I can connect it to browser security headers and my other web security projects.
