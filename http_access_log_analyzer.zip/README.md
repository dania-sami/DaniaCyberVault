# HTTP Access Log Analyzer (Security Focus)

This is a small HTTP access log analyzer I use to practise seeing patterns in web traffic.

It is not a full SIEM, but it can:
- Count requests per status code
- Highlight IPs with many requests
- Show requests to suspicious paths (like `/admin`, `/phpmyadmin`, `/wp-login.php`)

## Files

- `http_log_analyzer.py` – main script
- `demo_access_log.txt` – small demo log

## Usage

```bash
python http_log_analyzer.py --log demo_access_log.txt
```

The log format used in the demo is a simplified Nginx style combined log.
