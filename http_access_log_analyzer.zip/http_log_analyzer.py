import argparse
import re
from collections import Counter, defaultdict

LOG_RE = re.compile(
    r'(?P<ip>\S+) - - \[(?P<time>[^\]]+)\] "(?P<method>\S+) (?P<path>\S+) [^"]*" (?P<status>\d{3})'
)

SUSPICIOUS_PATHS = [
    "/admin",
    "/phpmyadmin",
    "/wp-login.php",
    "/.git/",
    "/server-status",
]

def analyse_log(path: str):
    status_counter = Counter()
    ip_counter = Counter()
    suspicious_hits = []

    with open(path) as f:
        for line in f:
            m = LOG_RE.search(line)
            if not m:
                continue
            ip = m.group("ip")
            status = m.group("status")
            req_path = m.group("path")
            status_counter[status] += 1
            ip_counter[ip] += 1
            for s in SUSPICIOUS_PATHS:
                if req_path.startswith(s):
                    suspicious_hits.append((ip, req_path, status))
                    break

    print(f"[+] Analysing {path}\n")
    print("[+] Status code counts:")
    for code, count in sorted(status_counter.items()):
        print(f"    {code}: {count}")
    print()

    print("[+] Top talkers (by request count):")
    for ip, count in ip_counter.most_common(5):
        print(f"    {ip}: {count}")
    print()

    if suspicious_hits:
        print("[+] Suspicious path requests:")
        for ip, req_path, status in suspicious_hits:
            print(f"    {ip} -> {req_path} (status {status})")
    else:
        print("[+] No suspicious paths seen (from the simple list we use).")

def main():
    parser = argparse.ArgumentParser(description="HTTP Access Log Analyzer by Dania")
    parser.add_argument("--log", required=True, help="Path to HTTP access log")
    args = parser.parse_args()
    analyse_log(args.log)

if __name__ == "__main__":
    main()
