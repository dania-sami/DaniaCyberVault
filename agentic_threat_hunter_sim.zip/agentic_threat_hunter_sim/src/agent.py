from __future__ import annotations

from dataclasses import dataclass
from typing import List

from .env import LogEnvironment


@dataclass
class Step:
    action: str
    description: str
    rows_preview: str


class ThreatHunterAgent:
    def __init__(self, env: LogEnvironment) -> None:
        self.env = env
        self.steps: List[Step] = []

    def hunt_suspicious_logins(self) -> None:
        q1 = self.env.run_query_failed_logins()
        self.steps.append(
            Step(
                action="filter_failed_logins",
                description=q1.description,
                rows_preview=q1.rows.head(5).to_string(index=False),
            )
        )

        q2 = self.env.run_query_bruteforce_candidates()
        self.steps.append(
            Step(
                action="aggregate_failed_per_user_ip",
                description=q2.description,
                rows_preview=q2.rows.head(5).to_string(index=False),
            )
        )

        q3 = self.env.run_query_success_after_many_failures()
        self.steps.append(
            Step(
                action="success_after_multiple_failures",
                description=q3.description,
                rows_preview=q3.rows.to_string(index=False) if not q3.rows.empty else "(none)",
            )
        )

    def print_report(self) -> None:
        print("Agentic Threat Hunting Session")
        print("Goal: find suspicious login behaviour (possible bruteforce).")
        print()
        for i, step in enumerate(self.steps, start=1):
            print(f"Step {i}: {step.action}")
            print(f"  {step.description}")
            print(step.rows_preview)
            print()
