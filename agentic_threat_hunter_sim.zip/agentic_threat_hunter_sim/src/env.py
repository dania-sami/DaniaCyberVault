from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import List

import pandas as pd

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)


def generate_logs(path: Path) -> pd.DataFrame:
    data = [
        ("2026-02-01T10:00:00", "alice", "10.0.0.5", "login_success", 1),
        ("2026-02-01T10:02:00", "alice", "10.0.0.5", "login_success", 1),
        ("2026-02-01T10:05:00", "bob", "203.0.113.10", "login_failure", 0),
        ("2026-02-01T10:06:00", "bob", "203.0.113.10", "login_failure", 0),
        ("2026-02-01T10:07:00", "bob", "203.0.113.10", "login_failure", 0),
        ("2026-02-01T10:08:00", "bob", "203.0.113.10", "login_success", 1),
        ("2026-02-01T10:10:00", "carol", "198.51.100.7", "login_success", 1),
        ("2026-02-01T10:12:00", "carol", "198.51.100.7", "login_failure", 0),
        ("2026-02-01T10:15:00", "dave", "192.0.2.44", "login_failure", 0),
        ("2026-02-01T10:16:00", "dave", "192.0.2.44", "login_failure", 0),
        ("2026-02-01T10:17:00", "dave", "192.0.2.44", "login_failure", 0),
        ("2026-02-01T10:18:00", "dave", "192.0.2.44", "login_failure", 0),
    ]
    df = pd.DataFrame(
        data,
        columns=["timestamp", "user", "ip", "event", "success"],
    )
    df.to_csv(path, index=False)
    return df


class LogEnvironment:
    def __init__(self) -> None:
        self.log_path = DATA_DIR / "auth_logs.csv"
        if self.log_path.exists():
            self.df = pd.read_csv(self.log_path)
        else:
            self.df = generate_logs(self.log_path)
        self.actions_taken: List[str] = []

    def run_query_failed_logins(self):
        from collections import namedtuple
        QueryResult = namedtuple("QueryResult", ["description", "rows"])
        self.actions_taken.append("filter_failed_logins")
        rows = self.df[self.df["success"] == 0]
        return QueryResult("All failed logins", rows)

    def run_query_bruteforce_candidates(self):
        from collections import namedtuple
        QueryResult = namedtuple("QueryResult", ["description", "rows"])
        self.actions_taken.append("aggregate_failed_per_user_ip")
        failed = self.df[self.df["success"] == 0]
        agg = (
            failed.groupby(["user", "ip"])
            .size()
            .reset_index(name="fail_count")
            .sort_values("fail_count", ascending=False)
        )
        return QueryResult("Failed login counts per user+ip", agg)

    def run_query_success_after_many_failures(self):
        from collections import namedtuple
        QueryResult = namedtuple("QueryResult", ["description", "rows"])
        self.actions_taken.append("success_after_multiple_failures")
        failed = self.df[self.df["success"] == 0]
        success = self.df[self.df["success"] == 1]

        fail_counts = failed.groupby(["user", "ip"]).size().reset_index(name="fail_count")
        candidates = fail_counts[fail_counts["fail_count"] >= 3]

        rows_list = []
        for _, row in candidates.iterrows():
            u, ip = row["user"], row["ip"]
            succ = success[(success["user"] == u) & (success["ip"] == ip)]
            if not succ.empty:
                rows_list.append(
                    {
                        "user": u,
                        "ip": ip,
                        "fail_count": int(row["fail_count"]),
                        "successes": len(succ),
                    }
                )
        result_df = pd.DataFrame(rows_list)
        return QueryResult("Users with many failures then success", result_df)
