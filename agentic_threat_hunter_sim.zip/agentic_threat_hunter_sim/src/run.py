from __future__ import annotations

import argparse

from .env import LogEnvironment
from .agent import ThreatHunterAgent


def main() -> None:
    parser = argparse.ArgumentParser(description="Agentic AI Threat Hunter Simulator")
    parser.add_argument(
        "--goal",
        type=str,
        default="suspicious_logins",
        help="Currently only 'suspicious_logins' is supported.",
    )
    args = parser.parse_args()

    env = LogEnvironment()
    agent = ThreatHunterAgent(env)

    if args.goal == "suspicious_logins":
        agent.hunt_suspicious_logins()
    else:
        print(f"Unknown goal: {args.goal}")
        return

    agent.print_report()


if __name__ == "__main__":
    main()
