# Agentic AI Threat Hunter Simulator

Hi, I am Dania 👋

This is my **mini threat-hunting agent**:

- I simulate authentication logs.
- I define an environment with simple query actions.
- An "agent" chooses a sequence of queries to find suspicious logins.

Everything runs locally and prints a clear trace of the agent’s reasoning.

## How to run

```bash
cd agentic_threat_hunter_sim

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt

python -m src.run --goal suspicious_logins
```

You will see each action, the query it runs, and the final suspects it finds.
