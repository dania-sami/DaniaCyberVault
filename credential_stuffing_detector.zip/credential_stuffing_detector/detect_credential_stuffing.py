
import argparse
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

DATA_DIR = Path("data")
MODELS_DIR = Path("models")

FEATURE_COLS = [
    "total_attempts",
    "failed_attempts",
    "success_attempts",
    "distinct_ips",
    "distinct_countries",
    "max_attempts_per_minute",
    "has_success_after_many_failures",
]


def verdict_from_prob(p: float) -> str:
    if p < 0.2:
        return "Likely normal"
    if p < 0.6:
        return "Suspicious"
    return "Highly suspicious"


def main():
    parser = argparse.ArgumentParser(description="Credential stuffing detector")
    parser.add_argument(
        "--input",
        type=str,
        default=str(DATA_DIR / "account_sessions.csv"),
        help="CSV file with account feature rows",
    )
    parser.add_argument(
        "--output",
        type=str,
        default=str(DATA_DIR / "account_scored.csv"),
        help="Where to write the scored accounts",
    )
    args = parser.parse_args()

    scaler_path = MODELS_DIR / "scaler.joblib"
    model_path = MODELS_DIR / "model.joblib"
    if not scaler_path.is_file() or not model_path.is_file():
        raise SystemExit("Model or scaler not found. Run train_model.py first.")

    df = pd.read_csv(args.input)
    missing = [c for c in FEATURE_COLS if c not in df.columns]
    if missing:
        raise SystemExit(f"Input is missing required feature columns: {missing}")

    scaler = joblib.load(scaler_path)
    model = joblib.load(model_path)

    X = df[FEATURE_COLS].astype(float).values
    X_scaled = scaler.transform(X)

    if hasattr(model, "predict_proba"):
        proba = model.predict_proba(X_scaled)
        classes = list(model.classes_)
        if "stuffing_like" in classes:
            idx = classes.index("stuffing_like")
        else:
            idx = int(np.argmax(classes))
        prob_stuffing = proba[:, idx]
    else:
        preds = model.predict(X_scaled)
        prob_stuffing = np.where(preds == "stuffing_like", 0.8, 0.2)

    df["prob_stuffing"] = prob_stuffing
    df["verdict"] = df["prob_stuffing"].apply(verdict_from_prob)

    out_path = Path(args.output)
    df.to_csv(out_path, index=False)

    print(f"[info] Loaded {len(df)} accounts from {args.input}")
    print(f"[info] Using trained model from {model_path}")
    print()
    print("username    label             prob_stuffing  verdict")
    print("----------  ----------------  -------------  ----------------------")
    label_col = "label" if "label" in df.columns else None
    for i in range(min(10, len(df))):
        row = df.iloc[i]
        label = row[label_col] if label_col else ""
        print(
            f"{str(row['username']):<10}  {str(label):<16}  {row['prob_stuffing']:<13.2f}  {row['verdict']}"
        )
    print()
    print(f"Results written to {out_path}")


if __name__ == "__main__":
    main()
