
import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest
from collections import defaultdict
import os

os.makedirs("data", exist_ok=True)

df = pd.read_csv("data/logins.csv", parse_dates=["timestamp"])

# feature extraction
features=[]
for user, group in df.groupby("user"):
    total=len(group)
    failures = len(group[group["success"]==0])
    ip_count = group["ip"].nunique()
    time_range = (group["timestamp"].max()-group["timestamp"].min()).total_seconds()+1
    rate = total/time_range
    features.append([user, total, failures, ip_count, rate])

fdf = pd.DataFrame(features, columns=["user","total","failures","ip_count","rate"])
X=fdf[["total","failures","ip_count","rate"]]

model = IsolationForest(contamination=0.25, random_state=42)
scores = model.fit_predict(X)
anomaly = model.decision_function(X)

fdf["score"]=anomaly
fdf["flag"]=np.where(anomaly<np.percentile(anomaly,25),"suspicious","normal")

fdf.to_csv("data/user_risk.csv", index=False)
print("[info] results saved to data/user_risk.csv")
