
# Machine Learning Credential Stuffing Detector

Hi, I am Dania and I built this project to understand how identity security teams detect **credential stuffing** in real login logs.

I did not want to only count failed logins.  
I wanted a small pipeline that can:

- simulate realistic login events (normal vs credential-stuffing behaviour)
- aggregate them into per-account features
- train a machine learning model
- score accounts by risk and give a clear verdict

This is my credential stuffing detection lab, focused on behaviour instead of just thresholds.

---

## What this project does

The workflow has three parts.

1. **Synthetic login generator**  
   I generate login events in `data/login_events.csv` with fields like:

   - timestamp
   - username
   - ip
   - country
   - success (0/1)

   Some users behave normally, others are attacked by a simulated credential stuffing campaign
   (many rapid failures from multiple IPs, maybe one success).

2. **Feature aggregation**  
   From the raw events I build per-account features such as:

   - `total_attempts`
   - `failed_attempts`
   - `success_attempts`
   - `distinct_ips`
   - `distinct_countries`
   - `max_attempts_per_minute`
   - `has_success_after_many_failures`

   The aggregated table is stored in `data/account_sessions.csv` with a label (`normal` or `stuffing_like`).

3. **Model training and detection**  

   - `train_model.py` trains a `RandomForestClassifier` on the account sessions.
   - `detect_credential_stuffing.py` loads the model and scores accounts from any compatible CSV.
   - Each account gets:

     - `prob_stuffing` (0..1)
     - `verdict` (Likely normal / Suspicious / Highly suspicious)

This is exactly the kind of logic that could sit behind a sign in risk engine or identity protection feature.

---

## Project structure

```text
credential_stuffing_detector/
  README.md
  requirements.txt
  generate_logins.py          # create synthetic login events + account features
  train_model.py              # train ML model on account features
  detect_credential_stuffing.py  # score accounts and flag likely stuffing
  data/
  models/
```

---

## Installation

```bash
python3 -m venv venv
source venv/bin/activate           # Windows  venv\Scripts\activate
pip install -r requirements.txt
```

---

## Step 1  Generate synthetic login data

```bash
python generate_logins.py
```

This creates:

- `data/login_events.csv` — raw login logs
- `data/account_sessions.csv` — per-account features with labels

---

## Step 2  Train the model

```bash
python train_model.py
```

This will:

- train a RandomForest on the account sessions
- print a classification report
- save:

  - `models/scaler.joblib`
  - `models/model.joblib`

---

## Step 3  Detect credential stuffing

By default, the script uses the generated `account_sessions.csv`:

```bash
python detect_credential_stuffing.py --input data/account_sessions.csv
```

Example style of output:

```text
[info] Loaded 200 accounts from data/account_sessions.csv
[info] Using trained model from models/model.joblib

username    label             prob_stuffing  verdict
----------  ----------------  -------------  ----------------------
user_001    normal            0.04           Likely normal
user_057    stuffing_like     0.93           Highly suspicious
user_121    stuffing_like     0.87           Highly suspicious
...
Results written to data/account_scored.csv
```

You can also plug in your own CSV with the same feature columns (without the label).

---

## Features I use

Each account has:

- `total_attempts`
- `failed_attempts`
- `success_attempts`
- `distinct_ips`
- `distinct_countries`
- `max_attempts_per_minute`
- `has_success_after_many_failures` (0/1)

In real life you would add even more context (device, ASN, IP reputation), but this lab already shows how to think like a detection engineer.

---

## Why I like this project

Credential stuffing attacks are very common in the real world.

With this small lab I show that I can:

- simulate realistic login behaviour
- engineer features for identity security
- train and use a model for **account-level risk scoring**

It is a compact but strong way to talk about detection engineering during a security conversation.
