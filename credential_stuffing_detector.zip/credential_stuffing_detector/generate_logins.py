
from pathlib import Path
import random
import csv
from datetime import datetime, timedelta
from collections import defaultdict

DATA_DIR = Path("data")


def generate_events(n_users=200, base_time=None):
    if base_time is None:
        base_time = datetime(2025, 1, 10, 8, 0, 0)
    random.seed(42)

    countries_normal = ["SE", "DE", "FR", "NL", "US"]
    countries_attack = ["CN", "RU", "BR"]
    ip_ranges_normal = ["10.0.0.", "192.168.1.", "172.16.0."]
    ip_ranges_attack = ["203.0.113.", "198.51.100.", "192.0.2."]

    def random_ip(prefixes):
        prefix = random.choice(prefixes)
        return prefix + str(random.randint(1, 254))

    events = []
    users = [f"user_{i:03d}" for i in range(1, n_users + 1)]

    # choose some accounts to be attacked
    attacked_users = set(random.sample(users, k=int(0.2 * n_users)))

    current = base_time
    for user in users:
        # normal baseline behaviour
        normal_days = random.randint(3, 10)
        for d in range(normal_days):
            # each day, 0–3 logins
            attempts = random.randint(0, 3)
            for _ in range(attempts):
                ts = current + timedelta(days=d, minutes=random.randint(0, 600))
                success = 1
                ip = random_ip(ip_ranges_normal)
                country = random.choice(countries_normal)
                events.append(
                    {
                        "timestamp": ts.strftime("%Y-%m-%d %H:%M:%S"),
                        "username": user,
                        "ip": ip,
                        "country": country,
                        "success": success,
                    }
                )

        # if user is attacked, add credential stuffing pattern
        if user in attacked_users:
            # pick an hour window
            attack_start = base_time + timedelta(days=random.randint(0, 5), hours=random.randint(0, 23))
            ip_pool = [random_ip(ip_ranges_attack) for _ in range(5)]
            for i in range(random.randint(20, 60)):
                ts = attack_start + timedelta(seconds=i * random.randint(5, 20))
                success = 0
                ip = random.choice(ip_pool)
                country = random.choice(countries_attack)
                events.append(
                    {
                        "timestamp": ts.strftime("%Y-%m-%d %H:%M:%S"),
                        "username": user,
                        "ip": ip,
                        "country": country,
                        "success": success,
                    }
                )
            # maybe 1 success at the end
            if random.random() < 0.5:
                ts = attack_start + timedelta(minutes=30)
                events.append(
                    {
                        "timestamp": ts.strftime("%Y-%m-%d %H:%M:%S"),
                        "username": user,
                        "ip": random.choice(ip_pool),
                        "country": random.choice(countries_attack),
                        "success": 1,
                    }
                )

    return events, attacked_users


def write_events(events, path):
    fieldnames = ["timestamp", "username", "ip", "country", "success"]
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for e in events:
            w.writerow(e)


def aggregate_accounts(events, attacked_users, path):
    # sort by time
    events_sorted = sorted(events, key=lambda e: e["timestamp"])
    per_user = defaultdict(list)
    for e in events_sorted:
        per_user[e["username"]].append(e)

    rows = []
    for user, evs in per_user.items():
        total_attempts = len(evs)
        failed_attempts = sum(1 for e in evs if int(e["success"]) == 0)
        success_attempts = sum(1 for e in evs if int(e["success"]) == 1)
        ips = {e["ip"] for e in evs}
        countries = {e["country"] for e in evs}

        # compute max attempts per minute
        times = [datetime.strptime(e["timestamp"], "%Y-%m-%d %H:%M:%S") for e in evs]
        times.sort()
        max_per_minute = 0
        if times:
            window_start = times[0]
            count = 0
            j = 0
            for i, t in enumerate(times):
                while times[j] < t - timedelta(minutes=1):
                    j += 1
                count = i - j + 1
                if count > max_per_minute:
                    max_per_minute = count

        # success after many failures
        has_success_after_many_failures = 0
        failures_before_success = 0
        for e in evs:
            if int(e["success"]) == 0:
                failures_before_success += 1
            else:
                if failures_before_success >= 10:
                    has_success_after_many_failures = 1
                    break

        label = "stuffing_like" if user in attacked_users else "normal"

        rows.append(
            {
                "username": user,
                "total_attempts": total_attempts,
                "failed_attempts": failed_attempts,
                "success_attempts": success_attempts,
                "distinct_ips": len(ips),
                "distinct_countries": len(countries),
                "max_attempts_per_minute": max_per_minute,
                "has_success_after_many_failures": has_success_after_many_failures,
                "label": label,
            }
        )

    fieldnames = [
        "username",
        "total_attempts",
        "failed_attempts",
        "success_attempts",
        "distinct_ips",
        "distinct_countries",
        "max_attempts_per_minute",
        "has_success_after_many_failures",
        "label",
    ]
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in rows:
            w.writerow(r)


def main():
    DATA_DIR.mkdir(exist_ok=True)
    events, attacked_users = generate_events()
    events_path = DATA_DIR / "login_events.csv"
    write_events(events, events_path)
    print(f"[info] Wrote {len(events)} login events to {events_path}")

    accounts_path = DATA_DIR / "account_sessions.csv"
    aggregate_accounts(events, attacked_users, accounts_path)
    print(f"[info] Wrote account feature table to {accounts_path} (users={len(set(e['username'] for e in events))})")


if __name__ == "__main__":
    from datetime import datetime, timedelta  # local import for aggregation

    main()
