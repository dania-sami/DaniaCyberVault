
from pathlib import Path

import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
from sklearn.preprocessing import StandardScaler

DATA_DIR = Path("data")
MODELS_DIR = Path("models")

FEATURE_COLS = [
    "total_attempts",
    "failed_attempts",
    "success_attempts",
    "distinct_ips",
    "distinct_countries",
    "max_attempts_per_minute",
    "has_success_after_many_failures",
]


def main():
    MODELS_DIR.mkdir(exist_ok=True)
    path = DATA_DIR / "account_sessions.csv"
    if not path.is_file():
        raise SystemExit(f"Account sessions file not found. Run generate_logins.py first ({path}).")

    df = pd.read_csv(path)
    X = df[FEATURE_COLS].astype(float).values
    y = df["label"].astype(str).values

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y, test_size=0.2, random_state=42, stratify=y
    )

    clf = RandomForestClassifier(
        n_estimators=200,
        random_state=42,
        n_jobs=-1,
    )
    clf.fit(X_train, y_train)

    y_pred = clf.predict(X_test)
    print("Classification report on validation set:")
    print(classification_report(y_test, y_pred, digits=4))

    joblib.dump(scaler, MODELS_DIR / "scaler.joblib")
    joblib.dump(clf, MODELS_DIR / "model.joblib")
    print(f"[info] Saved scaler to {MODELS_DIR / 'scaler.joblib'}")
    print(f"[info] Saved model to {MODELS_DIR / 'model.joblib'}")


if __name__ == "__main__":
    main()
