
import random, csv, os
from datetime import datetime, timedelta

os.makedirs("data", exist_ok=True)

def main():
    users = ["alice","bob","charlie","dania","root","service1","qauser"]
    rows=[]
    now=datetime.now()

    for u in users:
        # normal activity
        for _ in range(random.randint(20,40)):
            ts = now - timedelta(minutes=random.randint(0,2000))
            ip = f"10.0.{random.randint(0,3)}.{random.randint(1,254)}"
            success = random.random() < 0.8
            rows.append([ts,u,ip, int(success)])

        # attack simulation
        if random.random()<0.5:
            for _ in range(random.randint(50,200)):
                ts = now - timedelta(minutes=random.randint(0,500))
                ip = f"203.0.113.{random.randint(1,254)}"
                rows.append([ts,u,ip,0])

    with open("data/logins.csv","w",newline="") as f:
        w=csv.writer(f)
        w.writerow(["timestamp","user","ip","success"])
        for r in rows: w.writerow(r)

    print("[info] generated data/logins.csv")

if __name__=="__main__":
    main()
