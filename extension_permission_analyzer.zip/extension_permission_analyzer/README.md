# Browser Extension Permission Analyzer

Hi, I am Dania 👋

This project is my **browser extension permission analyzer**:

- I parse `manifest.json` for a browser extension.
- I score risk based on:
  - powerful permissions (tabs, scripting, clipboard, webRequest),
  - host matches like `<all_urls>`.
- I produce a small risk report with a final score.

It is a practical way to talk about **extension attack surface**.

## How to run

```bash
cd extension_permission_analyzer

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt   # stdlib only

python -m src.analyse --manifest data/manifest.json
```

The report lists permissions, host patterns, and a HIGH/MEDIUM/LOW risk level.
