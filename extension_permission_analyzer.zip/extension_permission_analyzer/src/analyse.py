from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, Any, List

POWER_PERMS = {
    "tabs": 3,
    "scripting": 4,
    "webRequest": 4,
    "webRequestBlocking": 4,
    "clipboardWrite": 2,
    "clipboardRead": 2,
    "history": 3,
    "cookies": 3,
    "downloads": 2,
    "management": 4,
}


def load_manifest(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def score_permissions(perms: List[str]) -> int:
    score = 0
    for p in perms:
        score += POWER_PERMS.get(p, 1)
    return score


def score_hosts(hosts: List[str]) -> int:
    score = 0
    for h in hosts:
        if h == "<all_urls>":
            score += 5
        elif h.startswith("http://"):
            score += 2
        else:
            score += 1
    return score


def risk_label(total: int) -> str:
    if total >= 15:
        return "HIGH"
    if total >= 8:
        return "MEDIUM"
    return "LOW"


def main() -> None:
    parser = argparse.ArgumentParser(description="Browser Extension Permission Analyzer")
    parser.add_argument("--manifest", type=str, required=True, help="Path to manifest.json")
    args = parser.parse_args()

    path = Path(args.manifest)
    if not path.exists():
        print(f"manifest.json not found at {path}")
        return

    manifest = load_manifest(path)
    perms = manifest.get("permissions", []) or []
    host_perms = manifest.get("host_permissions", []) or manifest.get("permissions", [])
    perms = [str(p) for p in perms]
    host_perms = [str(h) for h in host_perms]

    perm_score = score_permissions(perms)
    host_score = score_hosts(host_perms)
    total = perm_score + host_score
    label = risk_label(total)

    print("Browser Extension Permission Report")
    print("===================================")
    print(f"Name: {manifest.get('name', 'unknown')}")
    print(f"Version: {manifest.get('version', 'unknown')}")
    print()
    print("Requested permissions:")
    for p in perms:
        print(f"  - {p}")
    print(f"Permission score: {perm_score}")
    print()
    print("Host permissions:")
    for h in host_perms:
        print(f"  - {h}")
    print(f"Host score: {host_score}")
    print()
    print(f"Total risk score: {total} -> {label}")


if __name__ == "__main__":
    main()
