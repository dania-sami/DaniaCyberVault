import json, argparse, pathlib
p=argparse.ArgumentParser(); p.add_argument('--file');a=p.parse_args()
m=json.loads(pathlib.Path(a.file).read_text())
perms=m.get('permissions',[]); print('Permissions:',perms)