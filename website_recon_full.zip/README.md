# Website Recon Toolkit

A simple recon tool that resolves IP, fetches title, headers, and robots.txt.
