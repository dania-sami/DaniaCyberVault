import argparse, socket, requests, re
from urllib.parse import urlparse, urljoin

HEADERS = ["Server", "Content-Type", "X-Powered-By"]

def title(html):
    m = re.search(r"<title>(.*?)</title>", html, re.I)
    return m.group(1).strip() if m else ""

def recon(url):
    print("[+] Target:", url)
    host = urlparse(url).hostname
    print("[+] IP:", socket.gethostbyname(host))
    r = requests.get(url)
    print("[+] Status:", r.status_code)
    print("[+] Title:", title(r.text))
    for h in HEADERS:
        print(h, ":", r.headers.get(h, "-"))
    rob = requests.get(urljoin(url, "/robots.txt"))
    print("[+] robots.txt:", rob.status_code)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", required=True)
    a = ap.parse_args()
    recon(a.url)

if __name__ == "__main__":
    main()
