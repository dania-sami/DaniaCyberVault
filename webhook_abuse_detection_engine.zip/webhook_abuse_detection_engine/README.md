# Webhook Abuse Detection Engine

Hi, I am Dania Sami 👋

Webhooks are everywhere now: payment processors, SaaS tools, Git events.
If they are not monitored properly, they can become a new attack surface.

I built this **Webhook Abuse Detection Engine** as a small, safe lab:

- a minimal Flask-based webhook receiver
- a local log of all incoming payloads
- an offline analyser that looks for suspicious patterns

No external services are required. You can use `curl` or any local tool to
send JSON payloads to it and see how the analyser reacts.

---

## Components

1. **Collector (`src/app.py`)**

   A small Flask app exposing:

   - `POST /webhook`

   It:

   - accepts JSON payloads
   - stores them line-by-line into `data/received.jsonl`
   - returns a simple OK response

2. **Abuse analyser (`src/analyze.py`)**

   This script loads `data/received.jsonl` and flags payloads that have:

   - very large body size
   - unknown or strange `event_type`
   - suspicious keys like `eval`, `os.system`, etc.

   It prints a small per-payload report with a score.

---

## How to run

### 1. Start the webhook collector

```bash
cd webhook_abuse_detection_engine

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt

python -m src.app
```

This will start Flask on `http://127.0.0.1:5000`.

### 2. Send a test payload

In another terminal (with or without the venv):

```bash
curl -X POST http://127.0.0.1:5000/webhook \
  -H "Content-Type: application/json" \
  -d '{"event_type": "order.created", "amount": 100}'
```

### 3. Run the analyser

```bash
python -m src.analyze
```

You will see each stored payload with a simple risk score and reasons.

---

## Project structure

```text
webhook_abuse_detection_engine/
  ├─ README.md
  ├─ requirements.txt
  ├─ data/
  │    └─ received.jsonl        # appended at runtime
  └─ src/
       ├─ __init__.py
       ├─ app.py
       └─ analyze.py
```

---

## Why I built this

This project lets me show that I understand:

- how webhook endpoints are implemented
- what malicious payloads might look like in practice
- how to combine logging and simple heuristics for abuse detection

It is intentionally compact but very easy to demo and extend.
