from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List, Tuple


BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
STORE_PATH = DATA_DIR / "received.jsonl"


SUSPICIOUS_KEYS = {"eval", "os.system", "exec", "drop_table", "delete_all"}


def score_payload(payload: Dict) -> Tuple[int, List[str]]:
    reasons: List[str] = []
    score = 0

    raw = json.dumps(payload)
    if len(raw) > 2000:
        score += 2
        reasons.append("payload is very large")

    event_type = str(payload.get("event_type", "")).lower()
    if not event_type:
        score += 1
        reasons.append("missing event_type")
    elif any(word in event_type for word in ["debug", "test", "probe"]):
        score += 1
        reasons.append(f"suspicious event_type={event_type!r}")

    flat_keys = set(payload.keys())
    if flat_keys & SUSPICIOUS_KEYS:
        score += 3
        reasons.append("payload contains suspicious keys")

    return score, reasons


def main() -> None:
    if not STORE_PATH.exists():
        print(f"No payload log found at {STORE_PATH}")
        return

    with STORE_PATH.open("r", encoding="utf-8") as f:
        lines = [line.strip() for line in f if line.strip()]

    if not lines:
        print("No payloads stored yet.")
        return

    print(f"Analysing {len(lines)} payload(s) from {STORE_PATH}")
    for idx, line in enumerate(lines, start=1):
        try:
            payload = json.loads(line)
        except json.JSONDecodeError:
            print(f"#{idx}: invalid json line")
            continue

        score, reasons = score_payload(payload)
        level = "OK"
        if score >= 4:
            level = "HIGH"
        elif score >= 2:
            level = "MEDIUM"

        print(f"Payload #{idx}: level={level}, score={score}")
        print(f"  payload={payload}")
        for r in reasons:
            print(f"   - {r}")
        print()


if __name__ == "__main__":
    main()
