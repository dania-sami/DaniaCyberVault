from __future__ import annotations

import json
from pathlib import Path

from flask import Flask, request, jsonify

app = Flask(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)
STORE_PATH = DATA_DIR / "received.jsonl"


@app.route("/webhook", methods=["POST"])
def webhook():
    try:
        payload = request.get_json(force=True, silent=False)
    except Exception:
        return jsonify({"status": "error", "reason": "invalid json"}), 400

    with STORE_PATH.open("a", encoding="utf-8") as f:
        f.write(json.dumps(payload) + "\n")

    return jsonify({"status": "ok"}), 200


def main() -> None:
    app.run(debug=True)


if __name__ == "__main__":
    main()
