"""
IoT Fleet Intrusion Radar – Dania's tiny SOC for devices

Reads baseline and live JSONL metrics
builds per type baselines
scores live records for anomalies
and writes JSON and Markdown summaries
"""

import argparse
import json
import math
import os
from collections import defaultdict
from dataclasses import dataclass, asdict
from typing import Dict, List, Tuple


@dataclass
class Metrics:
    cpu: float
    mem: float
    net_kbps: float
    error_count: float


@dataclass
class BaselineStats:
    mean: Metrics
    std: Metrics
    firmware_versions: List[str]


@dataclass
class ScoredRecord:
    device_id: str
    device_type: str
    ts: str
    score: float
    cpu_z: float
    mem_z: float
    net_z: float
    error_z: float
    firmware: str
    firmware_new: bool
    reasons: List[str]
    raw: dict


def parse_metrics(obj: dict) -> Metrics:
    return Metrics(
        cpu=float(obj.get("cpu", 0.0)),
        mem=float(obj.get("mem", 0.0)),
        net_kbps=float(obj.get("net_kbps", 0.0)),
        error_count=float(obj.get("error_count", 0.0)),
    )


def compute_baseline(baseline_path: str) -> Dict[str, BaselineStats]:
    by_type: Dict[str, List[Metrics]] = defaultdict(list)
    firmwares: Dict[str, set] = defaultdict(set)

    with open(baseline_path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue
            device_type = str(obj.get("device_type", "unknown"))
            m = parse_metrics(obj)
            by_type[device_type].append(m)
            fw = str(obj.get("firmware", ""))
            if fw:
                firmwares[device_type].add(fw)

    baselines: Dict[str, BaselineStats] = {}
    for d_type, lst in by_type.items():
        if not lst:
            continue

        def mean_attr(attr: str) -> float:
            vals = [getattr(m, attr) for m in lst]
            return sum(vals) / len(vals)

        def std_attr(attr: str, mean_val: float) -> float:
            vals = [getattr(m, attr) for m in lst]
            var = sum((v - mean_val) ** 2 for v in vals) / max(len(vals), 1)
            std = math.sqrt(var)
            # floor to avoid zero which would explode z scores
            return max(std, 0.1)

        cpu_mean = mean_attr("cpu")
        mem_mean = mean_attr("mem")
        net_mean = mean_attr("net_kbps")
        err_mean = mean_attr("error_count")

        cpu_std = std_attr("cpu", cpu_mean)
        mem_std = std_attr("mem", mem_mean)
        net_std = std_attr("net_kbps", net_mean)
        err_std = std_attr("error_count", err_mean)

        baselines[d_type] = BaselineStats(
            mean=Metrics(cpu_mean, mem_mean, net_mean, err_mean),
            std=Metrics(cpu_std, mem_std, net_std, err_std),
            firmware_versions=sorted(firmwares[d_type]),
        )

    return baselines


def z_score(value: float, mean_val: float, std_val: float) -> float:
    if std_val <= 0:
        return 0.0
    return (value - mean_val) / std_val


def score_live(
    live_path: str, baselines: Dict[str, BaselineStats]
) -> List[ScoredRecord]:
    scored: List[ScoredRecord] = []

    with open(live_path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue
            d_type = str(obj.get("device_type", "unknown"))
            base = baselines.get(d_type)
            if not base:
                # no baseline for this type
                continue

            m = parse_metrics(obj)
            cpu_z = z_score(m.cpu, base.mean.cpu, base.std.cpu)
            mem_z = z_score(m.mem, base.mean.mem, base.std.mem)
            net_z = z_score(m.net_kbps, base.mean.net_kbps, base.std.net_kbps)
            err_z = z_score(m.error_count, base.mean.error_count, base.std.error_count)

            firmware = str(obj.get("firmware", ""))
            firmware_new = firmware and firmware not in base.firmware_versions

            # simple combined score
            score_val = sum(abs(z) for z in [cpu_z, mem_z, net_z, err_z]) / 4.0

            reasons: List[str] = []
            if abs(cpu_z) > 2:
                reasons.append("cpu_deviation")
            if abs(mem_z) > 2:
                reasons.append("mem_deviation")
            if abs(net_z) > 2:
                reasons.append("net_deviation")
            if abs(err_z) > 2:
                reasons.append("error_count_deviation")
            if firmware_new:
                reasons.append("new_firmware_version")

            if score_val < 1.0 and not firmware_new:
                # treat as normal and skip if totally boring
                continue

            scored.append(
                ScoredRecord(
                    device_id=str(obj.get("device_id", "")),
                    device_type=d_type,
                    ts=str(obj.get("ts", "")),
                    score=round(score_val, 3),
                    cpu_z=round(cpu_z, 3),
                    mem_z=round(mem_z, 3),
                    net_z=round(net_z, 3),
                    error_z=round(err_z, 3),
                    firmware=firmware,
                    firmware_new=firmware_new,
                    reasons=reasons,
                    raw=obj,
                )
            )
    scored.sort(key=lambda r: -r.score)
    return scored


def write_json(scored: List[ScoredRecord], path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump([asdict(r) for r in scored], f, indent=2)


def write_report(scored: List[ScoredRecord], path: str) -> None:
    # group by device_id
    from collections import defaultdict

    by_device: Dict[str, List[ScoredRecord]] = defaultdict(list)
    for r in scored:
        by_device[r.device_id].append(r)

    with open(path, "w", encoding="utf-8") as f:
        f.write("# IoT fleet intrusion radar report\n\n")
        if not scored:
            f.write("No strong anomalies found with the current baseline and thresholds.\n")
            return
        f.write(f"Total suspicious measurements: {len(scored)}\n\n")

        for dev, lst in by_device.items():
            dev_type = lst[0].device_type if lst else "unknown"
            f.write(f"## Device {dev} type {dev_type}\n\n")
            for r in lst[:5]:
                f.write(f"* {r.ts} score {r.score} reasons {', '.join(r.reasons) or 'none'}\n")
                f.write(f"  cpu_z {r.cpu_z} mem_z {r.mem_z} net_z {r.net_z} error_z {r.error_z}\n")
                if r.firmware:
                    extra = " new" if r.firmware_new else ""
                    f.write(f"  firmware {r.firmware}{extra}\n")
            f.write("\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's IoT fleet intrusion radar")
    parser.add_argument("--baseline", required=True, help="Baseline JSONL file path")
    parser.add_argument("--live", required=True, help="Live JSONL file path")
    parser.add_argument(
        "--out-prefix",
        default="iot_radar",
        help="Prefix for output files (default iot_radar)",
    )
    args = parser.parse_args()

    baselines = compute_baseline(args.baseline)
    scored = score_live(args.live, baselines)

    json_path = f"{args.out_prefix}_iot_radar_results.json"
    md_path = f"{args.out_prefix}_iot_radar_report.md"

    write_json(scored, json_path)
    write_report(scored, md_path)

    print(f"Wrote {len(scored)} scored measurements to {json_path}")
    print(f"Wrote human summary to {md_path}")


if __name__ == "__main__":
    main()
