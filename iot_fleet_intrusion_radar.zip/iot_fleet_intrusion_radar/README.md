# IoT Fleet Intrusion Radar – Dania’s tiny SOC for devices

Hi

I am Dania and this project is my small lab for thinking about security on fleets of IoT devices

Most IoT monitoring ideas stay very abstract
I wanted something that actually ingests metrics from devices
learns what normal looks like per device type
and then points out devices that start behaving in a strange way

So IoT Fleet Intrusion Radar is a simple Python tool that

* reads JSON lines with periodic metrics from simulated devices
* builds a baseline of normal behaviour per device type
* scores new metrics as normal or suspicious
* writes both a machine readable JSON report and a human summary in Markdown

It is not a full blown production system
It is a portfolio project that I can walk through line by line in an interview

## Data model

The tool expects JSON lines in two files

* a baseline file with normal behaviour
* a live file with current measurements you want to score

Each line is one measurement for one device
For example

{"ts": "2025-10-01T10:00:00", "device_id": "cam_01", "device_type": "camera", "cpu": 18.2, "mem": 32.1, "net_kbps": 120.5, "error_count": 0, "firmware": "1.0.0"}

Fields

* ts  timestamp as an ISO like string
* device_id  unique id for the device
* device_type  for example camera sensor or gateway
* cpu  cpu usage percentage
* mem  memory usage percentage
* net_kbps  network throughput in kilobits per second
* error_count  count of errors during this period
* firmware  firmware version string

If some numeric fields are missing the script will treat them as zero

## How the radar works

1 It reads the baseline file
   * groups records by device_type
   * for each numeric metric computes
     * mean
     * standard deviation with a minimum floor so it never becomes zero
2 It reads the live file
   * for each record it finds the baseline for that device_type
   * computes how many standard deviations away each metric is
   * combines this into a simple anomaly score
   * also flags
     * sudden jumps in error_count
     * devices running a firmware version that never appeared in baseline
3 It writes
   * iot_radar_results.json with a list of scored measurements
   * iot_radar_report.md with a human friendly summary and top suspicious devices

The scoring is intentionally simple and fully transparent so I can adjust it easily

## How I run it

First I try the sample data

1 Create and optionally activate a virtual environment

   python3 -m venv venv
   source venv_bin_activate

2 Install the requirements

   pip install -r requirements.txt

   The project uses only the Python standard library
   The requirements file just keeps the layout familiar

3 Look at the example data in the examples folder

   * baseline_sample.jsonl
   * live_sample.jsonl

4 Run the radar

   python iot_radar.py \
       --baseline examples_baseline_sample.jsonl \
       --live examples_live_sample.jsonl \
       --out-prefix runs_demo

This will produce

* runs_demo_iot_radar_results.json
* runs_demo_iot_radar_report.md

In the report I can see

* how many device types and devices were analysed
* which devices stood out as most suspicious
* for each suspicious measurement which metrics were far from normal

## Why I built this

IoT security is usually described with buzzwords
I wanted to show that I can take a concrete dataset
define a simple model of normal behaviour
and then turn deviations into something that looks like an intrusion radar

With this project I can talk about

* per type baselines instead of one global threshold
* using simple statistics instead of heavy frameworks
* thinking about metrics like firmware drift and error spikes
* keeping the results analyst friendly and explainable

In a real setting this could be extended with streaming ingestion
better visualisation and more metrics
but as a compact project it already shows my way of reasoning about IoT fleets

