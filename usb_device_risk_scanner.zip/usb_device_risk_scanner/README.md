# USB Device Risk Scanner – Dania

Hi

I am Dania and this scanner looks at USB plug and play style events and maps risky usage

It flags unknown devices  devices shared across many hosts and use outside normal working hours

This is a simple way to tell a story about removable media risk using only local JSONL logs
