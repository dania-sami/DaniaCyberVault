"""
USB Device Risk Scanner – Dania

Reads JSONL usb events:

{"ts": "...", "host": "host1", "user": "alice", "device_id": "usb123", "vendor": "Generic", "action": "insert"}

and flags:

* devices seen on many hosts
* use outside working hours
* devices on a blocklist (if provided)
"""

import argparse
import json
from dataclasses import dataclass, asdict
from datetime import datetime
from typing import List, Dict, Set

TS_FORMAT = "%Y-%m-%dT%H:%M:%S"


@dataclass
class UsbEvent:
    ts: str
    host: str
    user: str
    device_id: str
    vendor: str
    action: str


@dataclass
class UsbFinding:
    device_id: str
    hosts: List[str]
    total_events: int
    out_of_hours_events: int
    users: List[str]
    reasons: List[str]


def parse_ts(ts: str) -> datetime:
    return datetime.strptime(ts, TS_FORMAT)


def load_events(path: str) -> List[UsbEvent]:
    events: List[UsbEvent] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            events.append(
                UsbEvent(
                    ts=obj["ts"],
                    host=obj.get("host", "unknown"),
                    user=obj.get("user", "unknown"),
                    device_id=obj.get("device_id", "unknown"),
                    vendor=obj.get("vendor", ""),
                    action=obj.get("action", ""),
                )
            )
    return events


def analyse(events: List[UsbEvent], blocklist: Set[str] = None) -> List[UsbFinding]:
    if blocklist is None:
        blocklist = set()

    by_device: Dict[str, List[UsbEvent]] = {}
    for e in events:
        by_device.setdefault(e.device_id, []).append(e)

    findings: List[UsbFinding] = []

    for dev_id, dev_events in by_device.items():
        hosts = sorted({e.host for e in dev_events})
        users = sorted({e.user for e in dev_events})
        total = len(dev_events)
        out_of_hours = 0
        reasons: List[str] = []

        for e in dev_events:
            hour = parse_ts(e.ts).hour
            # simple work window 7 to 19
            if hour < 7 or hour > 19:
                out_of_hours += 1

        if len(hosts) > 1:
            reasons.append("device_seen_on_multiple_hosts")
        if out_of_hours > 0:
            reasons.append("device_used_outside_working_hours")
        if dev_id in blocklist:
            reasons.append("device_in_blocklist")

        if reasons:
            findings.append(
                UsbFinding(
                    device_id=dev_id,
                    hosts=hosts,
                    total_events=total,
                    out_of_hours_events=out_of_hours,
                    users=users,
                    reasons=reasons,
                )
            )

    findings.sort(key=lambda f: len(f.reasons), reverse=True)
    return findings


def write_outputs(findings: List[UsbFinding], md_path: str, json_path: str) -> None:
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump([asdict(fd) for fd in findings], f, indent=2)

    with open(md_path, "w", encoding="utf-8") as f:
        f.write("# USB device risk report\n\n")
        f.write(f"* Devices with findings: {len(findings)}\n\n")
        for fd in findings:
            f.write(f"## Device {fd.device_id}\n\n")
            f.write(f"* Hosts: {', '.join(fd.hosts)}\n")
            f.write(f"* Users: {', '.join(fd.users)}\n")
            f.write(f"* Events: {fd.total_events} (out of hours: {fd.out_of_hours_events})\n")
            f.write(f"* Reasons: {', '.join(fd.reasons)}\n\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's USB device risk scanner")
    parser.add_argument("--events", default="example_usb_events.jsonl", help="USB events JSONL")
    parser.add_argument("--out-prefix", default="usb_risk", help="Output prefix")
    args = parser.parse_args()

    events = load_events(args.events)
    findings = analyse(events)
    md_path = f"{args.out_prefix}_report.md"
    json_path = f"{args.out_prefix}_findings.json"
    write_outputs(findings, md_path, json_path)
    print(f"Analysed {len(events)} events  devices_with_findings={len(findings)}")
    print(f"Wrote report to {md_path}")


if __name__ == "__main__":
    main()
