from __future__ import annotations

import argparse
import os
import re
from pathlib import Path
from typing import List


def scan_file(path: Path) -> List[str]:
    findings: List[str] = []
    text = path.read_text(encoding="utf-8", errors="ignore")

    if "resource "aws_security_group"" in text:
        if re.search(r"0\.0\.0\.0/0", text):
            findings.append("aws_security_group allows 0.0.0.0/0")

    if "resource "aws_s3_bucket"" in text:
        if re.search(r'acl\s*=\s*"public-read"', text) or re.search(
            r'acl\s*=\s*"public-read-write"', text
        ):
            findings.append("S3 bucket ACL is public")

    if "resource "aws_db_instance"" in text:
        if re.search(r"publicly_accessible\s*=\s*true", text):
            findings.append("RDS instance is publicly accessible")

    return findings


def main() -> None:
    parser = argparse.ArgumentParser(description="Terraform misconfiguration checker")
    parser.add_argument("--path", type=str, required=True, help="Path to Terraform code")
    args = parser.parse_args()

    base = Path(args.path)
    if not base.exists():
        print(f"Path {base} does not exist.")
        return

    any_findings = False
    for root, _, files in os.walk(base):
        for fname in files:
            if not fname.endswith(".tf"):
                continue
            full = Path(root) / fname
            findings = scan_file(full)
            if not findings:
                continue
            any_findings = True
            print(f"File: {full}")
            for f in findings:
                print(f"  - {f}")
            print()

    if not any_findings:
        print("No obvious misconfigurations found with current rules.")


if __name__ == "__main__":
    main()
