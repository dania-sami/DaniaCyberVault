# Security Misconfiguration-as-Code Checker (Terraform)

Hi, I am Dania Sami 👋

IaC is powerful, but it can also encode very dangerous defaults like:

- `0.0.0.0/0` in security groups
- public S3 buckets
- open databases

I built this **Terraform Misconfiguration-as-Code Checker** to statically scan
Terraform `.tf` files for some classic mistakes and print a clear report.

---

## What this tool checks

It scans `.tf` files under a directory and flags:

- `aws_security_group` rules that allow `0.0.0.0/0`
- S3 buckets with `acl = "public-read"` or `acl = "public-read-write"`
- RDS instances with `publicly_accessible = true`

The checks are intentionally simple and readable, implemented with Python
string/regex parsing only, so the tool has **no heavy dependencies**.

---

## How to run

```bash
cd terraform_misconfig_checker

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt   # empty, stdlib only
```

Run the checker on the built-in examples:

```bash
python -m src.check --path iac
```

You will see findings for:

- `insecure_sg.tf`
- `insecure_s3.tf`
- `insecure_rds.tf`

You can then point it to your own Terraform modules:

```bash
python -m src.check --path /path/to/your/tf/code
```

---

## Project structure

```text
terraform_misconfig_checker/
  ├─ README.md
  ├─ requirements.txt
  ├─ iac/
  │    ├─ insecure_sg.tf
  │    ├─ insecure_s3.tf
  │    └─ insecure_rds.tf
  └─ src/
       ├─ __init__.py
       └─ check.py
```

---

## Why I built this

This project shows that I can:

- think like a **cloud security reviewer**
- encode simple policies as code
- build tools that developers can run locally or in CI
