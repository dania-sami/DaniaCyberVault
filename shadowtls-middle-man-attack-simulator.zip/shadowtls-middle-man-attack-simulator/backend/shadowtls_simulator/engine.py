
from dataclasses import dataclass
from typing import Dict, List


@dataclass
class TlsProfile:
    id: int
    service_name: str
    hostname: str
    meta: Dict[str, str]
    flags: Dict[str, bool]


@dataclass
class TlsAssessment:
    profile_id: int
    service_name: str
    hostname: str
    mitm_feasibility: float
    band: str
    reasons: List[str]


class ShadowTLSBrain:
    """
    ShadowTLS is my MITM reasoning engine for TLS configurations.

    It does not perform real interception. Instead it models how feasible
    a man in the middle attack might be based on configuration flags.
    """

    def __init__(self) -> None:
        self._next_id = 1
        self.profiles: Dict[int, TlsProfile] = {}

    def register_profile(self, service_name: str, hostname: str, meta: Dict[str, str], flags: Dict[str, bool]) -> TlsProfile:
        pid = self._next_id
        self._next_id += 1
        prof = TlsProfile(
            id=pid,
            service_name=service_name,
            hostname=hostname,
            meta=meta,
            flags=flags,
        )
        self.profiles[pid] = prof
        return prof

    def assess(self, profile_id: int) -> TlsAssessment:
        prof = self.profiles[profile_id]
        f = prof.flags
        reasons: List[str] = []
        score = 0.0

        if f.get("tls13_disabled"):
            score += 15.0
            reasons.append("TLS 1.3 is disabled, increasing reliance on older protocol versions.")
        if f.get("weak_cipher_suites_enabled"):
            score += 20.0
            reasons.append("Weak cipher suites are still enabled on the service.")
        if f.get("legacy_renegotiation_allowed"):
            score += 15.0
            reasons.append("Legacy renegotiation is allowed, which has a history of issues.")
        if f.get("no_hsts"):
            score += 15.0
            reasons.append("HSTS is not enforced, making browser downgrade easier.")
        if f.get("public_ca_with_weak_controls"):
            score += 15.0
            reasons.append("Service depends on a public CA that is known for weaker issuance controls.")
        if f.get("client_cert_not_required"):
            score += 10.0
            reasons.append("No mutual TLS, making user to service impersonation easier.")
        if f.get("mixed_content_risks"):
            score += 10.0
            reasons.append("The application mixes secure and insecure content.")
        if f.get("insecure_tls_versions_enabled"):
            score += 25.0
            reasons.append("Old TLS versions such as TLS 1.0 or 1.1 are still enabled.")

        if f.get("certificate_pinning"):
            score -= 15.0
            reasons.append("Client side certificate pinning reduces MITM options.")
        if f.get("strict_hpkp_like_controls"):
            score -= 10.0
            reasons.append("Strict key pinning or similar measures reduce attacker flexibility.")
        if f.get("short_lived_certificates"):
            score -= 5.0
            reasons.append("Short lived certificates reduce the window for abuse of mis-issued certs.")

        score = max(0.0, min(100.0, score))

        if score >= 80.0:
            band = "mitm_feasible_in_many_ways"
        elif score >= 60.0:
            band = "mitm_feasible_with_effort"
        elif score >= 40.0:
            band = "mitm_some_paths_exist"
        elif score >= 20.0:
            band = "mitm_unlikely_but_possible"
        else:
            band = "mitm_hard_under_normal_conditions"

        if not reasons:
            reasons.append("No significant positive or negative factors were flagged for this profile.")

        return TlsAssessment(
            profile_id=prof.id,
            service_name=prof.service_name,
            hostname=prof.hostname,
            mitm_feasibility=round(score, 2),
            band=band,
            reasons=reasons,
        )
