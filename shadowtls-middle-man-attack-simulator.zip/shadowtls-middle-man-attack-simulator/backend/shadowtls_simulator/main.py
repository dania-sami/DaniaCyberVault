
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Dict, List

from .engine import ShadowTLSBrain, TlsProfile, TlsAssessment


brain = ShadowTLSBrain()


class TlsProfileIn(BaseModel):
    service_name: str = Field(..., example="payments-api")
    hostname: str = Field(..., example="payments.example.test")
    meta: Dict[str, str] = Field(default_factory=dict)
    flags: Dict[str, bool] = Field(
        default_factory=dict,
        description=(
            "Flags such as tls13_disabled, weak_cipher_suites_enabled, legacy_renegotiation_allowed, "
            "no_hsts, public_ca_with_weak_controls, client_cert_not_required, mixed_content_risks, "
            "insecure_tls_versions_enabled, certificate_pinning, strict_hpkp_like_controls, short_lived_certificates"
        ),
    )


class TlsProfileOut(BaseModel):
    id: int
    service_name: str
    hostname: str
    meta: Dict[str, str]
    flags: Dict[str, bool]


class TlsAssessmentOut(BaseModel):
    profile_id: int
    service_name: str
    hostname: str
    mitm_feasibility: float
    band: str
    reasons: List[str]


app = FastAPI(
    title="ShadowTLS Middle-Man Attack Simulator",
    version="0.1.0",
    description="My TLS configuration reasoning engine for middle man attack feasibility.",
)


@app.post("/profiles", response_model=TlsProfileOut)
def register_profile(payload: TlsProfileIn) -> TlsProfileOut:
    prof: TlsProfile = brain.register_profile(
        service_name=payload.service_name,
        hostname=payload.hostname,
        meta=payload.meta,
        flags=payload.flags,
    )
    return TlsProfileOut(
        id=prof.id,
        service_name=prof.service_name,
        hostname=prof.hostname,
        meta=prof.meta,
        flags=prof.flags,
    )


@app.post("/assess", response_model=TlsAssessmentOut)
def assess(profile_id: int) -> TlsAssessmentOut:
    if profile_id not in brain.profiles:
        raise HTTPException(status_code=404, detail="TLS profile not found")
    res: TlsAssessment = brain.assess(profile_id)
    return TlsAssessmentOut(
        profile_id=res.profile_id,
        service_name=res.service_name,
        hostname=res.hostname,
        mitm_feasibility=res.mitm_feasibility,
        band=res.band,
        reasons=res.reasons,
    )
