
# ShadowTLS Middle-Man Attack Simulator

ShadowTLS is my thought experiment engine for man in the middle risk on TLS
secured services.

Instead of sniffing real traffic or doing anything intrusive, I focus on the
configuration side. Given a set of flags that describe how a service uses TLS,
ShadowTLS estimates how feasible a MITM attack would be and explains why.

## What this project does

* registers TLS profiles for services with
  * service name
  * hostname
  * free form metadata
  * boolean flags about TLS posture
* scores how feasible a MITM style attack is, between zero and one hundred
* assigns a band, for example
  * `mitm_hard_under_normal_conditions`
  * `mitm_unlikely_but_possible`
  * `mitm_some_paths_exist`
  * `mitm_feasible_with_effort`
  * `mitm_feasible_in_many_ways`
* returns narrative reasons that show which flags drove the decision

The scoring rules live in `engine.py` and can be read or adjusted in minutes.

## Project layout

```text
shadowtls-middle-man-attack-simulator
└── backend
    ├── shadowtls_simulator
    │   ├── __init__.py
    │   ├── engine.py  TLS profile and MITM feasibility scoring
    │   └── main.py    FastAPI HTTP API
    ├── requirements.txt
    └── example_requests.http
```

## How I run it locally

From the backend folder

```bash
python -m venv .venv
source .venv/bin/activate        # On Windows I use .venv\Scripts\activate
pip install -r requirements.txt
uvicorn shadowtls_simulator.main:app --reload --port 9903
```

Then I open

* http://localhost:9903/docs to register profiles and run assessments

## A scenario I often demo

I define a TLS profile for a payment API that still has some historical
issues.

```bash
curl -X POST http://localhost:9903/profiles   -H "Content-Type: application/json"   -d '{
    "service_name": "payments-api",
    "hostname": "payments.example.test",
    "meta": {
      "environment": "production"
    },
    "flags": {
      "tls13_disabled": true,
      "weak_cipher_suites_enabled": true,
      "legacy_renegotiation_allowed": false,
      "no_hsts": true,
      "public_ca_with_weak_controls": true,
      "client_cert_not_required": true,
      "mixed_content_risks": false,
      "insecure_tls_versions_enabled": true,
      "certificate_pinning": false,
      "strict_hpkp_like_controls": false,
      "short_lived_certificates": false
    }
  }'
```

Then I ask ShadowTLS to assess it.

```bash
curl -X POST "http://localhost:9903/assess?profile_id=1"
```

The answer gives me

* a high feasibility score
* a band like `mitm_feasible_in_many_ways`
* reasons that mention protocol downgrades, weak ciphers and CA trust issues

This is the kind of explanation I like when I sit with teams to plan TLS
hardening work.

## Where I can take this next

In the future I could

* feed real scan results into these flags
* add more points for certificate details
* build a small dashboard that ranks services by MITM risk

For now ShadowTLS is already a strong and honest way to show how I think
through TLS configuration and attack feasibility.
