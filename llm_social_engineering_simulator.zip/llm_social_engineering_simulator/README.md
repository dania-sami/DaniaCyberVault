# LLM Fueled Social Engineering Simulator – Dania

Hi

I am Dania and this project is an ethical training simulator for social engineering awareness

It turns role and job descriptions into clearly marked simulation emails that trainers can use to teach people how to spot suspicious messages

The output is always labelled as an internal exercise and is meant only for awareness campaigns
