"""
LLM Fueled Social Engineering Simulator – Dania

Takes a small JSON plan with roles and scenarios
and generates clearly marked simulation messages for awareness training

This is for ethical internal training  not real attacks
"""

import argparse
import json
import csv
from typing import List, Dict


def load_plan(path: str) -> Dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def build_messages(plan: Dict) -> List[Dict[str, str]]:
    roles = plan.get("roles", [])
    themes = plan.get("themes", ["login_security"])
    out: List[Dict[str, str]] = []

    for role in roles:
        name = role.get("name", "Colleague")
        job = role.get("job_title", "Team member")
        dept = role.get("department", "General")

        for theme in themes:
            subject = f"[Training Simulation] Security awareness exercise for {dept}"
            body_lines = [
                f"Hi {name},",
                "",
                "This message is part of an internal security awareness simulation.",
                "There is no real risk here  the goal is to practice how to think when something looks unusual.",
                "",
            ]
            if theme == "invoice":
                body_lines.append(
                    "Imagine this was an invoice request that did not match any work you recently did. "
                    "A safe reaction would be to verify the request through a trusted channel before approving anything."
                )
            elif theme == "login_security":
                body_lines.append(
                    "Imagine this was a message claiming your password will expire in 24 hours and urging you to click a link. "
                    "Instead of clicking  you would go directly to the official login page you already know."
                )
            elif theme == "file_share":
                body_lines.append(
                    "Imagine this looked like a file sharing invitation from someone you do not recognise. "
                    "You would pause and confirm the context before opening any attachments."
                )
            else:
                body_lines.append(
                    "The scenario here is generic  pause for a second when something feels off and verify before you act."
                )
            body_lines.append("")
            body_lines.append(
                "Your security team can use this simulation to discuss what helped you feel suspicious or confident."
            )
            body = "\n".join(body_lines)

            out.append(
                {
                    "name": name,
                    "job_title": job,
                    "department": dept,
                    "theme": theme,
                    "subject": subject,
                    "body": body,
                }
            )
    return out


def write_csv(messages: List[Dict[str, str]], path: str) -> None:
    if not messages:
        return
    fieldnames = list(messages[0].keys())
    with open(path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(messages)


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's LLM fueled social engineering simulator")
    parser.add_argument("--plan", required=True, help="Plan JSON with roles and themes")
    parser.add_argument("--out-prefix", default="sim", help="Prefix for output files")
    args = parser.parse_args()

    plan = load_plan(args.plan)
    messages = build_messages(plan)
    csv_path = f"{args.out_prefix}_messages.csv"
    write_csv(messages, csv_path)
    print(f"Wrote {len(messages)} simulation messages to {csv_path}")


if __name__ == "__main__":
    main()
