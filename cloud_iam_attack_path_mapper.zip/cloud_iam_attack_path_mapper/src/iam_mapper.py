from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import json

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
DATA_PATH = DATA_DIR / "iam_graph.json"


@dataclass
class Node:
    id: str
    type: str  # user, role, resource


@dataclass
class Edge:
    source: str
    target: str
    relation: str  # assume-role, access


def load_graph() -> Tuple[Dict[str, Node], List[Edge]]:
    with DATA_PATH.open("r", encoding="utf-8") as f:
        raw = json.load(f)

    nodes: Dict[str, Node] = {}
    for n in raw.get("nodes", []):
        node = Node(id=n["id"], type=n["type"])
        nodes[node.id] = node

    edges: List[Edge] = []
    for e in raw.get("edges", []):
        edges.append(
            Edge(
                source=e["from"],
                target=e["to"],
                relation=e["type"],
            )
        )
    return nodes, edges


def build_adjacency(edges: List[Edge]) -> Dict[str, List[Edge]]:
    adj: Dict[str, List[Edge]] = {}
    for e in edges:
        adj.setdefault(e.source, []).append(e)
    return adj


def dfs_paths(
    start: str,
    targets: List[str],
    adj: Dict[str, List[Edge]],
    max_depth: int = 6,
) -> List[List[Edge]]:
    paths: List[List[Edge]] = []

    def _dfs(current: str, path: List[Edge], depth: int) -> None:
        if depth > max_depth:
            return
        if current in targets and path:
            paths.append(list(path))
        for e in adj.get(current, []):
            # Avoid simple cycles by not revisiting nodes already in path
            if any(prev.source == e.target or prev.target == e.target for prev in path):
                continue
            path.append(e)
            _dfs(e.target, path, depth + 1)
            path.pop()

    _dfs(start, [], 0)
    return paths


def list_nodes(nodes: Dict[str, Node]) -> None:
    print("Nodes in graph:")
    for n in nodes.values():
        print(f"  {n.id} ({n.type})")


def main() -> None:
    parser = argparse.ArgumentParser(description="Cloud IAM Attack Path Mapper (lab)")
    parser.add_argument("--start", type=str, help="Starting identity id")
    parser.add_argument("--list", action="store_true", help="List all nodes")
    args = parser.parse_args()

    nodes, edges = load_graph()
    if args.list:
        list_nodes(nodes)
        return

    if not args.start:
        parser.error("You must either use --list or provide --start <id>")

    if args.start not in nodes:
        print(f"Unknown start id: {args.start}")
        return

    start_node = nodes[args.start]
    if start_node.type not in ("user", "role"):
        print(f"Start id {args.start} is not an identity/role.")
        return

    adj = build_adjacency(edges)
    resource_ids = [n.id for n in nodes.values() if n.type == "resource"]

    paths = dfs_paths(args.start, resource_ids, adj)
    if not paths:
        print(f"No attack paths found from {args.start}.")
        return

    print(f"Attack paths starting from {args.start}:")
    for i, path in enumerate(paths, start=1):
        print(f"Path {i}:")
        for e in path:
            print(f"  {e.source} --({e.relation})--> {e.target}")
        print()


if __name__ == "__main__":
    main()
