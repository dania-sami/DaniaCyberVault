# Cloud IAM Attack Path Mapper

Hi, I am Dania 👋

This project is my **cloud IAM attack path lab**:

- I model a small cloud environment as identities, roles and resources.
- I build a directed graph of "can assume" / "can access" edges.
- Given a starting identity, I show all **reachable sensitive resources**
  and the exact paths to get there.

It is a compact way to talk about **identity-centric attack paths in the cloud**.

## How to run

```bash
cd cloud_iam_attack_path_mapper

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt   # stdlib only

# List nodes
python -m src.iam_mapper --list

# Show attack paths starting from a specific identity
python -m src.iam_mapper --start UserAlice
```

The script prints all paths from the starting identity to resources.
