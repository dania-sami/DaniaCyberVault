
from fastapi import FastAPI
app = FastAPI(title="DeepFakePulse Biometrics Spoofing Resistance Modeler")

@app.get("/status")
def status():
    return {
        "project": "DeepFakePulse Biometrics Spoofing Resistance Modeler",
        "status": "working",
        "message": "All systems operational"
    }
