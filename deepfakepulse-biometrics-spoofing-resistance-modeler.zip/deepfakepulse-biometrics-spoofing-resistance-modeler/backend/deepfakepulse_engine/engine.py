
from dataclasses import dataclass
from typing import Dict, List


@dataclass
class BiometricSystemProfile:
    id: int
    name: str
    modality: str
    meta: Dict[str, str]
    metrics: Dict[str, float]


@dataclass
class SpoofingAssessment:
    profile_id: int
    name: str
    modality: str
    spoofing_risk: float
    band: str
    weak_vectors: List[str]
    strong_controls: List[str]


class DeepFakePulseBrain:
    """
    High level reasoning engine for biometric spoofing and deepfake resistance.

    It uses abstract metrics about liveness checks, anti-deepfake models,
    template protection and audit strength.
    """

    def __init__(self) -> None:
        self._next_id = 1
        self.systems: Dict[int, BiometricSystemProfile] = {}

    def register_system(self, name: str, modality: str, meta: Dict[str, str], metrics: Dict[str, float]) -> BiometricSystemProfile:
        sid = self._next_id
        self._next_id += 1
        prof = BiometricSystemProfile(
            id=sid,
            name=name,
            modality=modality,
            meta=meta,
            metrics=metrics,
        )
        self.systems[sid] = prof
        return prof

    def assess(self, profile_id: int) -> SpoofingAssessment:
        prof = self.systems[profile_id]
        m = prof.metrics
        weak_vectors: List[str] = []
        strong_controls: List[str] = []

        liveness_strength = float(m.get("liveness_check_strength", 0.0))
        deepfake_detector_quality = float(m.get("deepfake_detector_quality", 0.0))
        template_protection_maturity = float(m.get("template_protection_maturity", 0.0))
        fallback_channel_risk = float(m.get("fallback_channel_risk", 0.0))
        audit_trail_strength = float(m.get("audit_trail_strength", 0.0))

        risk = 0.0
        risk += max(0.0, 0.6 - liveness_strength) * 40.0
        risk += max(0.0, 0.6 - deepfake_detector_quality) * 35.0
        risk += max(0.0, 0.6 - template_protection_maturity) * 25.0
        risk += fallback_channel_risk * 30.0
        risk -= audit_trail_strength * 10.0

        risk = max(0.0, min(100.0, risk))

        if liveness_strength < 0.4:
            weak_vectors.append("basic-liveness-checks")
        else:
            strong_controls.append("strong-liveness-signals")
        if deepfake_detector_quality < 0.4:
            weak_vectors.append("weak-deepfake-detection")
        else:
            strong_controls.append("dedicated-deepfake-detector")
        if template_protection_maturity < 0.4:
            weak_vectors.append("template-protection-gaps")
        else:
            strong_controls.append("hardened-template-protection")
        if fallback_channel_risk > 0.4:
            weak_vectors.append("fallback-channel-abuse")
        else:
            strong_controls.append("controlled-fallback-procedures")
        if audit_trail_strength > 0.5:
            strong_controls.append("strong-audit-trails")
        else:
            weak_vectors.append("limited-auditability")

        if risk >= 80.0:
            band = "high_spoofing_risk"
        elif risk >= 60.0:
            band = "elevated_spoofing_risk"
        elif risk >= 40.0:
            band = "moderate_spoofing_risk"
        elif risk >= 20.0:
            band = "low_spoofing_risk"
        else:
            band = "very_low_spoofing_risk_under_model"

        return SpoofingAssessment(
            profile_id=prof.id,
            name=prof.name,
            modality=prof.modality,
            spoofing_risk=round(risk, 2),
            band=band,
            weak_vectors=weak_vectors,
            strong_controls=strong_controls,
        )
