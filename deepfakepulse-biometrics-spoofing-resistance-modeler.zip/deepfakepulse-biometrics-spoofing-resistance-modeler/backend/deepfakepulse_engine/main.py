
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Dict, List

from .engine import DeepFakePulseBrain, BiometricSystemProfile, SpoofingAssessment


brain = DeepFakePulseBrain()


class SystemIn(BaseModel):
    name: str = Field(..., example="face-id-gate")
    modality: str = Field(..., example="face")
    meta: Dict[str, str] = Field(default_factory=dict)
    metrics: Dict[str, float] = Field(
        default_factory=dict,
        description=(
            "Metrics: liveness_check_strength, deepfake_detector_quality, template_protection_maturity, "
            "fallback_channel_risk, audit_trail_strength"
        ),
    )


class SystemOut(BaseModel):
    id: int
    name: str
    modality: str
    meta: Dict[str, str]
    metrics: Dict[str, float]


class SpoofOut(BaseModel):
    profile_id: int
    name: str
    modality: str
    spoofing_risk: float
    band: str
    weak_vectors: List[str]
    strong_controls: List[str]


app = FastAPI(
    title="DeepFakePulse Biometrics Spoofing Resistance Modeler",
    version="0.1.0",
    description="Reasoning engine for biometric spoofing and deepfake resistance based on abstract metrics.",
)


@app.post("/systems", response_model=SystemOut)
def register_system(payload: SystemIn) -> SystemOut:
    prof: BiometricSystemProfile = brain.register_system(
        name=payload.name,
        modality=payload.modality,
        meta=payload.meta,
        metrics=payload.metrics,
    )
    return SystemOut(
        id=prof.id,
        name=prof.name,
        modality=prof.modality,
        meta=prof.meta,
        metrics=prof.metrics,
    )


@app.post("/assess", response_model=SpoofOut)
def assess(profile_id: int) -> SpoofOut:
    if profile_id not in brain.systems:
        raise HTTPException(status_code=404, detail="Biometric system not found")
    res: SpoofingAssessment = brain.assess(profile_id)
    return SpoofOut(
        profile_id=res.profile_id,
        name=res.name,
        modality=res.modality,
        spoofing_risk=res.spoofing_risk,
        band=res.band,
        weak_vectors=res.weak_vectors,
        strong_controls=res.strong_controls,
    )
