
# DeepFakePulse Biometrics Spoofing Resistance Modeler

DeepFakePulse is my biometrics and deepfake conversation tool.

I describe a biometric system using scores for liveness checks, deepfake
detection quality, template protection, fallback channel risk and audit
strength.

The modeler returns:
* a spoofing risk score (0–100)
* a band from very low to high spoofing risk
* weak vectors and strong controls in one view

## Run

```bash
cd backend
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn deepfakepulse_engine.main:app --reload --port 9935
```

Open http://localhost:9935/docs and try `/systems` then `/assess`.
