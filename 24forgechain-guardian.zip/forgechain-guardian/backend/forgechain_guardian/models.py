
from dataclasses import dataclass
from typing import List, Dict
from datetime import datetime


@dataclass
class Component:
    name: str
    version: str
    kind: str            # code, dependency, model, dataset, container
    origin: str          # internal, pypi, npm, dockerhub, huggingface, other
    integrity: str       # verified, unsigned, missing
    critical: bool
    hash: str


@dataclass
class Snapshot:
    id: int
    project_id: str
    created_at: datetime
    components: List[Component]
    score: float
    issues: List[str]


@dataclass
class Project:
    id: str
    name: str
    owner: str
    repo_url: str | None = None
    notes: str | None = None


class RiskEngine:
    """
    Tiny rule based risk scorer for supply chain snapshots.

    This is not a full security scanner. It gives a simple but clear score
    so that you can demonstrate the full flow project to snapshot to risk.
    """

    def score_components(self, components: List[Component]) -> tuple[float, List[str]]:
        score = 0.0
        issues: List[str] = []

        for c in components:
            # Integrity
            if c.integrity == "missing":
                delta = 15.0 if c.critical else 8.0
                score += delta
                issues.append(
                    f"{c.name} has no integrity information recorded which is risky for {c.kind} assets"
                )
            elif c.integrity == "unsigned":
                delta = 10.0 if c.critical else 4.0
                score += delta
                issues.append(
                    f"{c.name} is unsigned which is weaker than verified integrity"
                )

            # Origin
            if c.origin == "other":
                score += 5.0
                issues.append(
                    f"{c.name} comes from an unclassified origin"
                )

            # Critical
            if c.critical and c.kind in ("model", "container", "code"):
                score += 5.0
                issues.append(
                    f"{c.name} is marked as critical and should be watched closely"
                )

        # Normalize into zero to one hundred capped
        score = min(100.0, score)
        return score, issues
