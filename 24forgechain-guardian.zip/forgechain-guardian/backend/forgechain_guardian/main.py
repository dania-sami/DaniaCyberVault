
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field, HttpUrl
from typing import List, Optional

from .store import store


app = FastAPI(
    title="ForgeChain Guardian",
    version="0.1.0",
    description="Supply chain integrity radar for code models dependencies and artifacts.",
)


class ProjectIn(BaseModel):
    name: str = Field(..., example="payments service")
    owner: str = Field(..., example="platform team")
    repo_url: Optional[HttpUrl] = Field(None, example="https://github.com/example/payments")
    notes: Optional[str] = None


class ProjectOut(BaseModel):
    id: str
    name: str
    owner: str
    repo_url: Optional[HttpUrl]
    notes: Optional[str]


class ComponentIn(BaseModel):
    name: str
    version: str
    kind: str = Field(..., example="dependency")
    origin: str = Field(..., example="pypi")
    integrity: str = Field(..., example="verified")
    critical: bool = False
    hash: str = ""


class SnapshotOut(BaseModel):
    id: int
    project_id: str
    created_at: str
    score: float
    issues: List[str]
    components: List[ComponentIn]


class SnapshotSummaryOut(BaseModel):
    id: int
    created_at: str
    score: float
    issues: List[str]


@app.post("/projects", response_model=ProjectOut)
def create_project(payload: ProjectIn) -> ProjectOut:
    project = store.create_project(
        name=payload.name,
        owner=payload.owner,
        repo_url=str(payload.repo_url) if payload.repo_url else None,
        notes=payload.notes,
    )
    return ProjectOut(
        id=project.id,
        name=project.name,
        owner=project.owner,
        repo_url=project.repo_url,
        notes=project.notes,
    )


@app.get("/projects", response_model=List[ProjectOut])
def list_projects() -> List[ProjectOut]:
    items = []
    for p in store.list_projects():
        items.append(
            ProjectOut(
                id=p.id,
                name=p.name,
                owner=p.owner,
                repo_url=p.repo_url,
                notes=p.notes,
            )
        )
    return items


@app.get("/projects/{project_id}", response_model=ProjectOut)
def get_project(project_id: str) -> ProjectOut:
    project = store.get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    return ProjectOut(
        id=project.id,
        name=project.name,
        owner=project.owner,
        repo_url=project.repo_url,
        notes=project.notes,
    )


@app.post("/projects/{project_id}/snapshots", response_model=SnapshotOut)
def create_snapshot(project_id: str, components: List[ComponentIn]) -> SnapshotOut:
    project = store.get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    snap = store.create_snapshot(project_id, [c.dict() for c in components])
    return SnapshotOut(
        id=snap.id,
        project_id=snap.project_id,
        created_at=snap.created_at.isoformat() + "Z",
        score=snap.score,
        issues=snap.issues,
        components=[ComponentIn(**c.__dict__) for c in snap.components],
    )


@app.get("/projects/{project_id}/snapshots", response_model=List[SnapshotSummaryOut])
def list_snapshots(project_id: str) -> List[SnapshotSummaryOut]:
    project = store.get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    snaps = store.list_snapshots_for_project(project_id)
    return [
        SnapshotSummaryOut(
            id=s.id,
            created_at=s.created_at.isoformat() + "Z",
            score=s.score,
            issues=s.issues,
        )
        for s in snaps
    ]


@app.get("/snapshots/{snapshot_id}", response_model=SnapshotOut)
def get_snapshot(snapshot_id: int) -> SnapshotOut:
    snap = store.get_snapshot(snapshot_id)
    if not snap:
        raise HTTPException(status_code=404, detail="Snapshot not found")
    return SnapshotOut(
        id=snap.id,
        project_id=snap.project_id,
        created_at=snap.created_at.isoformat() + "Z",
        score=snap.score,
        issues=snap.issues,
        components=[ComponentIn(**c.__dict__) for c in snap.components],
    )
