
from typing import Dict, List
from datetime import datetime
import uuid

from .models import Project, Component, Snapshot, RiskEngine


class GuardianStore:
    """
    Very small in memory store for a prototype.

    For a real implementation you would plug this into a database.
    """

    def __init__(self) -> None:
        self.projects: Dict[str, Project] = {}
        self.snapshots: Dict[int, Snapshot] = {}
        self._next_snapshot_id: int = 1
        self.engine = RiskEngine()

    def create_project(self, name: str, owner: str, repo_url: str | None, notes: str | None) -> Project:
        proj_id = str(uuid.uuid4())
        project = Project(
            id=proj_id,
            name=name,
            owner=owner,
            repo_url=repo_url,
            notes=notes,
        )
        self.projects[proj_id] = project
        return project

    def list_projects(self) -> List[Project]:
        return list(self.projects.values())

    def get_project(self, project_id: str) -> Project | None:
        return self.projects.get(project_id)

    def create_snapshot(self, project_id: str, components_data: List[dict]) -> Snapshot:
        comp_objs: List[Component] = []
        for item in components_data:
            comp_objs.append(
                Component(
                    name=item["name"],
                    version=item["version"],
                    kind=item["kind"],
                    origin=item.get("origin", "other"),
                    integrity=item.get("integrity", "missing"),
                    critical=bool(item.get("critical", False)),
                    hash=item.get("hash", ""),
                )
            )
        score, issues = self.engine.score_components(comp_objs)
        snap = Snapshot(
            id=self._next_snapshot_id,
            project_id=project_id,
            created_at=datetime.utcnow(),
            components=comp_objs,
            score=score,
            issues=issues,
        )
        self.snapshots[snap.id] = snap
        self._next_snapshot_id += 1
        return snap

    def list_snapshots_for_project(self, project_id: str) -> List[Snapshot]:
        return sorted(
            [s for s in self.snapshots.values() if s.project_id == project_id],
            key=lambda s: s.created_at,
            reverse=True,
        )

    def get_snapshot(self, snapshot_id: int) -> Snapshot | None:
        return self.snapshots.get(snapshot_id)


store = GuardianStore()
