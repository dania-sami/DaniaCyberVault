
# ForgeChain Guardian

ForgeChain Guardian is a supply chain integrity radar for modern software projects.

You can register projects describe the components that make them up and receive a simple clear risk score plus explanations. Components can be code modules libraries containers models or data sets.

This prototype will not scan your code by itself. Instead it acts like a central nervous system that other scanners and build pipelines can talk to. You send snapshots of what is currently in your project and ForgeChain Guardian records them evaluates the risk and lets you query the history.

## What the prototype includes

* FastAPI backend for projects and snapshots
* In memory store so you do not need a database for local tests
* Rule based risk engine that scores each snapshot and lists issues
* Example HTTP requests you can run directly

The design leaves plenty of room to plug in real scanners later such as software bill of materials generators container scanners and dependency checkers.

## Folder layout

```text
forgechain-guardian
└── backend
    ├── forgechain_guardian
    │   ├── __init__.py
    │   ├── main.py        HTTP API
    │   ├── models.py      Core data models and risk engine
    │   └── store.py       Simple store for projects and snapshots
    ├── requirements.txt
    └── example_requests.http
```

## Running the backend

From the backend folder

```bash
python -m venv .venv
source .venv/bin/activate        # On Windows use .venv\Scripts\activate
pip install -r requirements.txt
uvicorn forgechain_guardian.main:app --reload --port 9300
```

The API will be reachable at

* http://localhost:9300
* interactive documentation at http://localhost:9300/docs

## Typical flow

You can follow this sequence either with curl or by using the example_requests.http file.

### Step one register a project

```bash
curl -X POST http://localhost:9300/projects   -H "Content-Type: application/json"   -d '{
    "name": "fraud detection service",
    "owner": "ml platform",
    "repo_url": "https://github.com/example/fraud-service",
    "notes": "Service that uses an internal model and several third party packages"
  }'
```

The response will contain an id for the project. Use that id in later calls.

### Step two describe a snapshot of the supply chain

A snapshot is a picture of the components that currently make up the project.  
For each component you send

* name and version
* kind for example code dependency model container dataset
* origin for example internal pypi dockerhub huggingface
* integrity information such as verified unsigned or missing
* whether it is critical to the project
* a hash if you have one

Example

```bash
curl -X POST http://localhost:9300/projects/{project_id}/snapshots   -H "Content-Type: application/json"   -d '[
    {
      "name": "app",
      "version": "1.4.2",
      "kind": "code",
      "origin": "internal",
      "integrity": "verified",
      "critical": true,
      "hash": "sha256:example_app_hash"
    },
    {
      "name": "customers-finetune-v1",
      "version": "1.0.0",
      "kind": "model",
      "origin": "huggingface",
      "integrity": "missing",
      "critical": true,
      "hash": "sha256:example_model"
    }
  ]'
```

ForgeChain Guardian calculates a risk score and stores the snapshot.

### Step three read back the risk and issues

You can list all snapshots for a project

```bash
curl http://localhost:9300/projects/{project_id}/snapshots
```

Each entry shows

* snapshot id
* time when it was created
* risk score between zero and one hundred
* short issue descriptions

You can also fetch full details for a specific snapshot

```bash
curl http://localhost:9300/snapshots/{snapshot_id}
```

This includes the components that were sent plus the calculated issues.

## How the risk engine works

The current logic is simple and totally transparent so that you can easily extend it.

* Missing integrity information for a component increases the score more strongly especially when the component is marked as critical
* Unsigned components also increase the score
* Components from an unclassified origin add some risk
* Critical components of kind code model or container add a small constant amount

The combined score is capped at one hundred. In a real deployment you might

* add severity levels such as green yellow red
* store thresholds that are specific to each project
* fail a build when the score goes above an accepted limit

## Ideas for extending ForgeChain Guardian

You can use this prototype as the central part of a larger supply chain story. For example

* Connect it to a continuous integration pipeline so that every build produces a snapshot
* Call external tools that generate software bill of materials and send the result here
* Show trends of risk over time for each project
* Integrate with a notification channel so that risky snapshots create tickets or alerts
* Attach provenance information for models and data sets such as who trained them and where the data came from

By iterating on this base you can turn ForgeChain Guardian into a strong portfolio or research project that shows you understand real world supply chain security challenges.
