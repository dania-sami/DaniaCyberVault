# AI-Driven Phishing Kit Fingerprinter

Hi, I am Dania 👋

This project is my **phishing kit fingerprinting lab**:

- I work on synthetic phishing landing page HTML.
- I extract text/structure features with TF–IDF.
- I cluster pages into **families** to approximate different kits.

It gives a small but clear view of how I would group phishing campaigns.

## How to run

```bash
cd phishing_kit_fingerprinter

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt

python -m src.cluster
```

The script prints each sample with its assigned cluster and shows a
representative example for each family.
