from __future__ import annotations

from pathlib import Path

import pandas as pd
from sklearn.cluster import KMeans
from sklearn.feature_extraction.text import TfidfVectorizer

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"

for d in (DATA_DIR, OUTPUT_DIR):
    d.mkdir(parents=True, exist_ok=True)


def synthetic_phishing_samples() -> pd.DataFrame:
    rows = [
        (
            "sample_1",
            "<html><body><h1>Sign in to your Bank</h1><p>Your session expired, please login again.</p><form>Username: <input> Password: <input></form></body></html>",
        ),
        (
            "sample_2",
            "<html><body><h2>Account Verification</h2><p>We detected unusual activity. Confirm your credentials now.</p></body></html>",
        ),
        (
            "sample_3",
            "<html><body><h1>Office365 Login</h1><p>To continue reading your mail, please sign in.</p></body></html>",
        ),
        (
            "sample_4",
            "<html><body><h1>Outlook Web Access</h1><p>Your mailbox is almost full. Re-login to increase quota.</p></body></html>",
        ),
        (
            "sample_5",
            "<html><body><h1>PayPal Security Check</h1><p>Your account has been limited. Confirm your card details.</p></body></html>",
        ),
        (
            "sample_6",
            "<html><body><h1>Payment Provider Notice</h1><p>We could not process your recent transaction. Re-enter billing info.</p></body></html>",
        ),
    ]
    return pd.DataFrame(rows, columns=["id", "html_text"])


def main() -> None:
    data_path = DATA_DIR / "phishing_samples.csv"
    if data_path.exists():
        df = pd.read_csv(data_path)
    else:
        df = synthetic_phishing_samples()
        df.to_csv(data_path, index=False)

    # Use textual content as a proxy for kit fingerprinting.
    texts = df["html_text"].astype(str).tolist()
    vectorizer = TfidfVectorizer(ngram_range=(1, 2), min_df=1)
    X = vectorizer.fit_transform(texts)

    n_clusters = 3
    km = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    labels = km.fit_predict(X)
    df["cluster"] = labels

    out_path = OUTPUT_DIR / "clustered_samples.csv"
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    df.to_csv(out_path, index=False)
    print(f"Cluster assignments written to {out_path}")

    print("\n=== Samples by cluster ===")
    for cid in sorted(df["cluster"].unique()):
        group = df[df["cluster"] == cid]
        print(f"Cluster {cid}:")
        for _, row in group.iterrows():
            snippet = row["html_text"][:90].replace("\n", " ")
            print(f"  {row['id']}: {snippet}...")
        print()

    print("Representative sample per cluster:")
    for cid in sorted(df["cluster"].unique()):
        group = df[df["cluster"] == cid]
        rep = group.iloc[0]
        print(f"Cluster {cid} representative: {rep['id']}")
        print(rep["html_text"])
        print()


if __name__ == "__main__":
    main()
