import argparse
import socket
import ssl
from datetime import datetime

def check_host(host: str, port: int):
    ctx = ssl.create_default_context()
    with socket.create_connection((host, port), timeout=5) as sock:
        with ctx.wrap_socket(sock, server_hostname=host) as ssock:
            cert = ssock.getpeercert()
    not_after = cert.get("notAfter")
    if not_after is None:
        return None, None
    exp = datetime.strptime(not_after, "%b %d %H:%M:%S %Y %Z")
    now = datetime.utcnow()
    remaining = exp - now
    return exp, remaining.days

def main():
    parser = argparse.ArgumentParser(description="Certificate Expiry Checker by Dania")
    parser.add_argument("--file", required=True, help="Path to file with host:port per line")
    args = parser.parse_args()

    with open(args.file) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if ":" not in line:
                print(f"{line} -> invalid format, expected host:port")
                continue
            host, port_str = line.split(":", 1)
            try:
                port = int(port_str)
            except ValueError:
                print(f"{line} -> invalid port")
                continue
            try:
                exp, days = check_host(host, port)
            except Exception as e:
                print(f"{host}:{port} -> error: {e}")
                continue
            if exp is None:
                print(f"{host}:{port} -> could not read expiry")
            else:
                print(f"{host}:{port} -> expires {exp.isoformat()} (in {days} day(s))")

if __name__ == "__main__":
    main()
