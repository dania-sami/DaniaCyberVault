# Certificate Expiry Checker

This is a small CLI tool I wrote to check how many days are left before TLS certificates expire for a list of hosts.

It reads a text file where each line is `host:port`, for example:

- `example.com:443`
- `mail.example.com:993`

For each entry it opens an SSL connection, reads the certificate and prints the expiry date and remaining days. This is handy when talking about basic PKI hygiene.

## Files

- `cert_expiry_checker.py` – main script
- `hosts_example.txt` – example targets

## Usage

```bash
python cert_expiry_checker.py --file hosts_example.txt
```

I only point this at hosts I am allowed to connect to, and it only does a basic TLS handshake.
