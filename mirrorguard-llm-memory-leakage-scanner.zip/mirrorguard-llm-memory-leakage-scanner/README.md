
# MirrorGuard LLM Memory Leakage Scanner

MirrorGuard is how I talk about "memory" leakage risks in LLM deployments.

I feed it simple metrics like how much sensitive data reaches the model,
how mature my prompt redaction is, how exposed logs are and how strong my
retention and training contamination controls look.

It gives me:
* a leakage risk score (0–100)
* a band from low to critical
* a short list of risks and mitigations I can bring to a review

## Run

```bash
cd backend
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn mirrorguard_engine.main:app --reload --port 9933
```

Open http://localhost:9933/docs and try `/deployments` then `/assess`.
