
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Dict, List

from .engine import MirrorGuardBrain, DeploymentProfile, LeakageReport


brain = MirrorGuardBrain()


class DeploymentIn(BaseModel):
    name: str = Field(..., example="customer-support-llm")
    meta: Dict[str, str] = Field(default_factory=dict)
    metrics: Dict[str, float] = Field(
        default_factory=dict,
        description=(
            "Metrics: sensitive_data_fraction, prompt_redaction_maturity, logging_exposure_score, "
            "retention_policy_strength, training_contamination_risk"
        ),
    )


class DeploymentOut(BaseModel):
    id: int
    name: str
    meta: Dict[str, str]
    metrics: Dict[str, float]


class LeakageOut(BaseModel):
    profile_id: int
    name: str
    leakage_risk: float
    band: str
    risks: List[str]
    mitigations: List[str]


app = FastAPI(
    title="MirrorGuard LLM Memory Leakage Scanner",
    version="0.1.0",
    description="Reasoning engine for leakage-style risk in LLM deployments based on abstract metrics.",
)


@app.post("/deployments", response_model=DeploymentOut)
def register_deployment(payload: DeploymentIn) -> DeploymentOut:
    prof: DeploymentProfile = brain.register_deployment(
        name=payload.name,
        meta=payload.meta,
        metrics=payload.metrics,
    )
    return DeploymentOut(
        id=prof.id,
        name=prof.name,
        meta=prof.meta,
        metrics=prof.metrics,
    )


@app.post("/assess", response_model=LeakageOut)
def assess(profile_id: int) -> LeakageOut:
    if profile_id not in brain.deployments:
        raise HTTPException(status_code=404, detail="Deployment profile not found")
    res: LeakageReport = brain.assess(profile_id)
    return LeakageOut(
        profile_id=res.profile_id,
        name=res.name,
        leakage_risk=res.leakage_risk,
        band=res.band,
        risks=res.risks,
        mitigations=res.mitigations,
    )
