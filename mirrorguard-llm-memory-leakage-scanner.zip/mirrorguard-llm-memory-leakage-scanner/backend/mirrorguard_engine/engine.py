
from dataclasses import dataclass
from typing import Dict, List


@dataclass
class DeploymentProfile:
    id: int
    name: str
    meta: Dict[str, str]
    metrics: Dict[str, float]


@dataclass
class LeakageReport:
    profile_id: int
    name: str
    leakage_risk: float
    band: str
    risks: List[str]
    mitigations: List[str]


class MirrorGuardBrain:
    """
    High level reasoning engine for memory-style leakage risks in LLM deployments.

    It works with abstract metrics: how much sensitive data the model sees,
    how retention is handled and how strong the redaction discipline is.
    """

    def __init__(self) -> None:
        self._next_id = 1
        self.deployments: Dict[int, DeploymentProfile] = {}

    def register_deployment(self, name: str, meta: Dict[str, str], metrics: Dict[str, float]) -> DeploymentProfile:
        did = self._next_id
        self._next_id += 1
        prof = DeploymentProfile(
            id=did,
            name=name,
            meta=meta,
            metrics=metrics,
        )
        self.deployments[did] = prof
        return prof

    def assess(self, profile_id: int) -> LeakageReport:
        prof = self.deployments[profile_id]
        m = prof.metrics
        risks: List[str] = []
        mitigations: List[str] = []

        sensitive_fraction = float(m.get("sensitive_data_fraction", 0.0))
        prompt_redaction = float(m.get("prompt_redaction_maturity", 0.0))
        logging_exposure = float(m.get("logging_exposure_score", 0.0))
        retention_policy = float(m.get("retention_policy_strength", 0.0))
        training_contamination = float(m.get("training_contamination_risk", 0.0))

        base = 0.0
        base += sensitive_fraction * 40.0
        base += logging_exposure * 25.0
        base += training_contamination * 25.0
        base -= prompt_redaction * 15.0
        base -= retention_policy * 15.0
        leakage_risk = max(0.0, min(100.0, base))

        if sensitive_fraction > 0.4:
            risks.append("A large fraction of prompts contain sensitive or personal data.")
        else:
            mitigations.append("Sensitive data fraction appears limited.")
        if logging_exposure > 0.4:
            risks.append("Logs could expose model inputs or outputs widely.")
        else:
            mitigations.append("Logging exposure looks contained under this model.")
        if training_contamination > 0.4:
            risks.append("There is notable risk that sensitive content enters training or fine tuning.")
        else:
            mitigations.append("Training contamination controls look reasonable.")
        if prompt_redaction < 0.4:
            risks.append("Prompt redaction flows are immature.")
        else:
            mitigations.append("Prompt redaction systems are in place.")
        if retention_policy < 0.4:
            risks.append("Retention policies might allow data to live longer than necessary.")
        else:
            mitigations.append("Retention policies contribute to lowering leakage risk.")

        if leakage_risk >= 80.0:
            band = "critical_leakage_risk"
        elif leakage_risk >= 60.0:
            band = "high_leakage_risk"
        elif leakage_risk >= 40.0:
            band = "elevated_leakage_risk"
        elif leakage_risk >= 20.0:
            band = "moderate_leakage_risk"
        else:
            band = "low_leakage_risk_under_model"

        return LeakageReport(
            profile_id=prof.id,
            name=prof.name,
            leakage_risk=round(leakage_risk, 2),
            band=band,
            risks=risks,
            mitigations=mitigations,
        )
