
from fastapi import FastAPI
app = FastAPI(title="MirrorGuard LLM Memory Leakage Scanner")

@app.get("/status")
def status():
    return {
        "project": "MirrorGuard LLM Memory Leakage Scanner",
        "status": "working",
        "message": "All systems operational"
    }
