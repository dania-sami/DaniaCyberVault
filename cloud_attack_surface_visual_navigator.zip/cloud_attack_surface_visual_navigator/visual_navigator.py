"""
Cloud Attack Surface Visual Navigator – Dania

Offline tool that turns a JSON asset graph into:

* Graphviz DOT graph
* Markdown summary of exposed to data paths
"""

import argparse
import json
from dataclasses import dataclass
from typing import List, Dict, Set


@dataclass
class Asset:
    id: str
    kind: str
    internet_exposed: bool
    holds_sensitive_data: bool


@dataclass
class Edge:
    src: str
    dst: str
    protocol: str
    port: int


def load_graph(path: str):
    with open(path, "r", encoding="utf-8") as f:
        raw = json.load(f)
    assets: Dict[str, Asset] = {}
    for a in raw.get("assets", []):
        assets[a["id"]] = Asset(
            id=a["id"],
            kind=a.get("kind", "unknown"),
            internet_exposed=bool(a.get("internet_exposed", False)),
            holds_sensitive_data=bool(a.get("holds_sensitive_data", False)),
        )
    edges: List[Edge] = []
    for e in raw.get("edges", []):
        edges.append(
            Edge(
                src=e["src"],
                dst=e["dst"],
                protocol=e.get("protocol", "tcp"),
                port=int(e.get("port", 0)),
            )
        )
    return assets, edges


def build_adjacency(edges: List[Edge]) -> Dict[str, List[Edge]]:
    adj: Dict[str, List[Edge]] = {}
    for e in edges:
        adj.setdefault(e.src, []).append(e)
    return adj


def dfs_paths(start: str, is_target, adj: Dict[str, List[Edge]], max_depth: int = 5) -> List[List[str]]:
    paths: List[List[str]] = []

    def dfs(node: str, visited: Set[str], path: List[str], depth: int):
        if depth > max_depth:
            return
        if is_target(node):
            paths.append(list(path))
        for e in adj.get(node, []):
            if e.dst in visited:
                continue
            visited.add(e.dst)
            path.append(e.dst)
            dfs(e.dst, visited, path, depth + 1)
            path.pop()
            visited.remove(e.dst)

    dfs(start, {start}, [start], 0)
    return paths


def write_dot(assets: Dict[str, Asset], edges: List[Edge], path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        f.write("digraph cloud {\n")
        f.write("  rankdir=LR;\n")
        for a in assets.values():
            color = "#e8f0fe"
            if a.internet_exposed and a.holds_sensitive_data:
                color = "#ffcdd2"
            elif a.internet_exposed:
                color = "#bbdefb"
            elif a.holds_sensitive_data:
                color = "#c8e6c9"
            label = f"{a.id}\\n{a.kind}"
            f.write(f'  "{a.id}" [label="{label}", style="filled,rounded", fillcolor="{color}"];\n')
        for e in edges:
            f.write(f'  "{e.src}" -> "{e.dst}" [label="{e.protocol}/{e.port}"];\n')
        f.write("}\n")


def write_summary(assets: Dict[str, Asset], edges: List[Edge], path: str) -> None:
    adj = build_adjacency(edges)
    internet_nodes = [a.id for a in assets.values() if a.internet_exposed]
    sensitive_nodes = set(a.id for a in assets.values() if a.holds_sensitive_data)

    def is_target(node_id: str) -> bool:
        return node_id in sensitive_nodes

    with open(path, "w", encoding="utf-8") as f:
        f.write("# Cloud attack surface summary\n\n")
        f.write(f"* Internet exposed assets: {len(internet_nodes)}\n")
        f.write(f"* Sensitive data assets: {len(sensitive_nodes)}\n\n")

        for src in internet_nodes:
            paths = dfs_paths(src, is_target, adj)
            if not paths:
                continue
            f.write(f"## Paths from {src} to sensitive assets\n\n")
            for p in paths:
                f.write("* " + " → ".join(p) + "\n")
            f.write("\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's cloud attack surface visual navigator")
    parser.add_argument("--graph", default="example_graph.json", help="Asset graph JSON")
    parser.add_argument("--out-prefix", default="attack_surface", help="Output prefix")
    args = parser.parse_args()

    assets, edges = load_graph(args.graph)
    dot_path = f"{args.out_prefix}_graph.dot"
    md_path = f"{args.out_prefix}_summary.md"
    write_dot(assets, edges, dot_path)
    write_summary(assets, edges, md_path)

    print(f"Wrote DOT graph to {dot_path}")
    print(f"Wrote Markdown summary to {md_path}")


if __name__ == "__main__":
    main()
