# Cloud Attack Surface Visual Navigator – Dania

Hi

I am Dania and this project is my visual map for a cloud attack surface

It reads a small JSON file with assets and connections and then produces

* a Graphviz DOT file so I can draw the graph
* a Markdown summary of which internet exposed nodes can reach sensitive data

It is offline and file based so I can experiment with designs without touching any real cloud
