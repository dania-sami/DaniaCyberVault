from __future__ import annotations

from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
MODELS_DIR = BASE_DIR / "models"

for d in (DATA_DIR, MODELS_DIR):
    d.mkdir(parents=True, exist_ok=True)


def generate_synthetic_multi_tenant(n_per_tenant: int = 200, tenants: int = 3) -> pd.DataFrame:
    rng = np.random.RandomState(123)
    rows = []
    for tenant_id in range(1, tenants + 1):
        base = rng.normal(loc=tenant_id * 0.5, scale=1.0, size=(n_per_tenant, 4))
        noise = rng.normal(scale=0.5, size=(n_per_tenant, 4))
        X = base + noise
        weights = np.array([1.0, 0.8, -0.6, 0.9]) + (tenant_id - 2) * 0.2
        logits = X @ weights
        probs = 1 / (1 + np.exp(-logits))
        y = (probs > 0.6).astype(int)
        for i in range(n_per_tenant):
            rows.append(
                {
                    "tenant": f"tenant_{tenant_id}",
                    "f1": X[i, 0],
                    "f2": X[i, 1],
                    "f3": X[i, 2],
                    "f4": X[i, 3],
                    "label": int(y[i]),
                }
            )
    return pd.DataFrame(rows)


def train_central(df: pd.DataFrame) -> None:
    X = df[["f1", "f2", "f3", "f4"]]
    y = df["label"]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, random_state=42, stratify=y
    )
    model = LogisticRegression(max_iter=500)
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    print("Central model report:")
    print(classification_report(y_test, y_pred))
    joblib.dump({"model": model, "X_test": X_test, "y_test": y_test}, MODELS_DIR / "central_model.joblib")


def train_federated(df: pd.DataFrame) -> None:
    tenants = df["tenant"].unique()
    local_models = []
    for t in tenants:
        sub = df[df["tenant"] == t]
        X = sub[["f1", "f2", "f3", "f4"]]
        y = sub["label"]
        model = LogisticRegression(max_iter=500)
        model.fit(X, y)
        local_models.append(model)
        print(f"Trained local model for {t} with {len(sub)} samples.")

    coef_avg = sum(m.coef_ for m in local_models) / len(local_models)
    intercept_avg = sum(m.intercept_ for m in local_models) / len(local_models)

    global_model = LogisticRegression(max_iter=1)
    X_dummy = df[["f1", "f2", "f3", "f4"]].iloc[:5]
    y_dummy = df["label"].iloc[:5]
    global_model.fit(X_dummy, y_dummy)
    global_model.coef_ = coef_avg
    global_model.intercept_ = intercept_avg

    X = df[["f1", "f2", "f3", "f4"]]
    y = df["label"]
    _, X_test, _, y_test = train_test_split(
        X, y, test_size=0.3, random_state=42, stratify=y
    )
    y_pred = global_model.predict(X_test)
    print("Federated (averaged) model report:")
    print(classification_report(y_test, y_pred))

    joblib.dump({"model": global_model, "X_test": X_test, "y_test": y_test}, MODELS_DIR / "federated_model.joblib")


def main() -> None:
    data_path = DATA_DIR / "network_multi_tenant.csv"
    if data_path.exists():
        df = pd.read_csv(data_path)
    else:
        df = generate_synthetic_multi_tenant()
        df.to_csv(data_path, index=False)

    print(f"Dataset with {len(df)} rows across tenants: {df['tenant'].unique().tolist()}")

    print("\n=== Training central model ===")
    train_central(df)

    print("\n=== Training federated-style model ===")
    train_federated(df)


if __name__ == "__main__":
    main()
