# Federated Learning IDS Lab (Multi-Tenant Simulation)

Hi, I am Dania 👋

This project is a **federated-style IDS experiment**:

- I simulate multiple tenants, each with their own network data.
- Each tenant trains a local Logistic Regression model.
- I then average the model weights (FedAvg style) into a global model.
- Finally I compare global vs centralised training.

It is a small but concrete way to talk about **federated intrusion detection**.

## How to run

```bash
cd federated_ids_lab

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt

python -m src.train_federated
```

The script prints metrics for:

- a central model trained on all data
- a federated model built by averaging tenant models
