
# TitanGuard Cloud Shield

I built TitanGuard Cloud Shield to show how I think about cloud security posture in a way that is simple honest and easy to demo.

In real life a cloud scanner talks to provider APIs collects massive configuration data and then runs many rules. For this project I wanted the core idea without the heavy integration so I designed TitanGuard to accept structured descriptions of resources and return

* a risk score for the account
* a list of findings with clear explanations
* simple remediation suggestions I would actually give to a team

This makes it ideal as a portfolio project a teaching tool or a starting point for a real scanner.

## What TitanGuard does

* accepts a list of resources such as storage buckets security groups databases and identity users
* applies a set of opinionated rules that mirror common misconfigurations
* calculates a score between zero and one hundred based on severity
* returns findings that include
  * severity
  * a short title
  * an explanation in natural language
  * a concrete remediation step

The rules are easy to read in the engine file so anyone can see exactly how I approach misconfiguration analysis.

## Project layout

```text
titanguard-cloud-shield
└── backend
    ├── titanguard_shield
    │   ├── __init__.py
    │   ├── main.py    FastAPI HTTP API
    │   └── engine.py  Rule engine and scoring
    ├── requirements.txt
    └── example_requests.http
```

## How I run it locally

From the backend folder

```bash
python -m venv .venv
source .venv/bin/activate        # On Windows I use .venv\Scripts\activate
pip install -r requirements.txt
uvicorn titanguard_shield.main:app --reload --port 9900
```

Then I open

* http://localhost:9900/docs to try the scan endpoint

## Example scan I like to show

I send a small fake account that has a few classic mistakes

* a public storage bucket
* an administrative port open to the whole internet
* a database without encryption at rest
* a user without multi factor authentication

```bash
curl -X POST http://localhost:9900/scan   -H "Content-Type: application/json"   -d '{
    "account_id": "aws-prod-123456789",
    "resources": [
      {
        "id": "bucket-logs",
        "type": "storage_bucket",
        "cloud": "aws",
        "tags": {"env": "prod"},
        "properties": {"public": "true"}
      },
      {
        "id": "sg-admin",
        "type": "security_group",
        "cloud": "aws",
        "tags": {"env": "prod"},
        "properties": {"cidr": "0.0.0.0/0", "port": "22"}
      },
      {
        "id": "db-orders",
        "type": "database_instance",
        "cloud": "aws",
        "tags": {"env": "prod"},
        "properties": {"encrypted": "false"}
      },
      {
        "id": "user-ops-1",
        "type": "iam_user",
        "cloud": "aws",
        "tags": {"team": "operations"},
        "properties": {"has_mfa": "false"}
      }
    ]
  }'
```

The response gives me

* overall score
* one finding for each problem
* remediation text for every item

I can open engine.py and show exactly where each rule lives which makes this project very transparent and easy to extend.

## Ideas I would like to explore next

* add more resource types for different cloud providers while keeping the same schema
* tag findings with categories such as data protection network exposure or identity hygiene
* add thresholds so that a score above a limit fails a continuous integration pipeline
* build a small visual report that groups findings by severity and by service

For now this version already shows how I think about multi cloud configuration hygiene and how I communicate risk and remediation to teams.
