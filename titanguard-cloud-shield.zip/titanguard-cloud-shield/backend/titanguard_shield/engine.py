
from dataclasses import dataclass
from typing import Dict, List


@dataclass
class ResourceConfig:
    id: str
    type: str
    cloud: str
    tags: Dict[str, str]
    properties: Dict[str, str]


@dataclass
class Finding:
    id: int
    resource_id: str
    severity: str
    title: str
    explanation: str
    remediation: str


@dataclass
class ScanResult:
    account_id: str
    findings: List[Finding]
    score: float


class CloudShieldBrain:
    """
    TitanGuard Cloud Shield is my lab friendly misconfiguration scanner.

    It does not call real cloud APIs. Instead it accepts structured descriptions
    of resources and applies clear rules so I can show how I think about cloud
    security posture and remediation.
    """

    def __init__(self) -> None:
        self._next_id = 1

    def _new_find(self, resource_id: str, severity: str, title: str, explanation: str, remediation: str) -> Finding:
        fid = self._next_id
        self._next_id += 1
        return Finding(
            id=fid,
            resource_id=resource_id,
            severity=severity,
            title=title,
            explanation=explanation,
            remediation=remediation,
        )

    def scan(self, account_id: str, resources: List[ResourceConfig]) -> ScanResult:
        findings: List[Finding] = []

        for r in resources:
            # Public storage
            if r.type == "storage_bucket":
                if r.properties.get("public", "false").lower() == "true":
                    findings.append(
                        self._new_find(
                            resource_id=r.id,
                            severity="high",
                            title="Public storage bucket",
                            explanation="This bucket is marked as public which can expose data to everyone.",
                            remediation="Restrict bucket access to specific principals and remove public read access.",
                        )
                    )
            # Security group like
            if r.type == "security_group":
                cidr = r.properties.get("cidr", "")
                port = r.properties.get("port", "")
                if cidr == "0.0.0.0/0" and port in ("22", "3389"):
                    findings.append(
                        self._new_find(
                            resource_id=r.id,
                            severity="critical",
                            title="Administrative port open to the internet",
                            explanation=f"Port {port} is open to the world which invites brute force attacks.",
                            remediation="Limit access to this port to a small set of trusted networks or through VPN.",
                        )
                    )
            # Database
            if r.type == "database_instance":
                if r.properties.get("encrypted", "false").lower() != "true":
                    findings.append(
                        self._new_find(
                            resource_id=r.id,
                            severity="high",
                            title="Database not encrypted at rest",
                            explanation="The database instance is not configured for encryption at rest.",
                            remediation="Enable encryption at rest with a managed key or customer managed key.",
                        )
                    )
            # Identity
            if r.type == "iam_user":
                if r.properties.get("has_mfa", "false").lower() != "true":
                    findings.append(
                        self._new_find(
                            resource_id=r.id,
                            severity="medium",
                            title="User without multi factor authentication",
                            explanation="This identity can sign in without multi factor authentication.",
                            remediation="Require and enforce multi factor authentication for human identities.",
                        )
                    )

        # Simple score based on counts and severity
        score = 0.0
        for f in findings:
            if f.severity == "critical":
                score += 25.0
            elif f.severity == "high":
                score += 15.0
            elif f.severity == "medium":
                score += 7.0
            else:
                score += 3.0

        score = min(100.0, score)
        return ScanResult(account_id=account_id, findings=findings, score=score)
