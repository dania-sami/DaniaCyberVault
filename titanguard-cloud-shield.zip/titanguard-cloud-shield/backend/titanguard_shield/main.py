
from fastapi import FastAPI
from pydantic import BaseModel, Field
from typing import Dict, List

from .engine import CloudShieldBrain, ResourceConfig, ScanResult, Finding


brain = CloudShieldBrain()


class ResourceIn(BaseModel):
    id: str = Field(..., example="sg-frontend-01")
    type: str = Field(..., example="security_group")
    cloud: str = Field(..., example="aws")
    tags: Dict[str, str] = Field(default_factory=dict)
    properties: Dict[str, str] = Field(default_factory=dict)


class FindingOut(BaseModel):
    id: int
    resource_id: str
    severity: str
    title: str
    explanation: str
    remediation: str


class ScanIn(BaseModel):
    account_id: str = Field(..., example="aws-prod-123456789")
    resources: List[ResourceIn]


class ScanOut(BaseModel):
    account_id: str
    score: float
    findings: List[FindingOut]


app = FastAPI(
    title="TitanGuard Cloud Shield",
    version="0.1.0",
    description="My multi cloud misconfiguration scanner for lab style configurations.",
)


@app.post("/scan", response_model=ScanOut)
def scan(payload: ScanIn) -> ScanOut:
    resources = [
        ResourceConfig(
            id=r.id,
            type=r.type,
            cloud=r.cloud,
            tags=r.tags,
            properties=r.properties,
        )
        for r in payload.resources
    ]
    result: ScanResult = brain.scan(payload.account_id, resources)
    return ScanOut(
        account_id=result.account_id,
        score=result.score,
        findings=[
            FindingOut(
                id=f.id,
                resource_id=f.resource_id,
                severity=f.severity,
                title=f.title,
                explanation=f.explanation,
                remediation=f.remediation,
            )
            for f in result.findings
        ],
    )
