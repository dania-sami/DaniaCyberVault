# Security Posture Coach – Dania’s IDE helper engine

Hi

I am Dania and this project is the core analysis engine behind a small “security coach” I imagine living inside an IDE

Instead of only running big external scanners
I wanted a lightweight helper that can look at code as I write it and say:

* “this SQL query looks like it might be vulnerable”
* “this crypto call is probably not what you want”
* “this input is being used without any validation”

In this repository I focus on the **engine**
that reads source files
spots some common insecure patterns
and suggests safer snippets plus short explanations in plain language

An actual IDE plugin would call this engine on the fly
but even as a CLI tool it is already useful for practice and demos

## What the coach looks for

Right now I handle two main language families for the demo:

* Python
* JavaScript (Node / Express style)

The checks are intentionally small and explainable:

### 1. String based SQL queries

Patterns like:

* direct string concatenation into `cursor.execute(...)`
* `f"SELECT ... {user_input}"` style SQL
* JavaScript `db.query("SELECT ... " + userInput)`

The coach flags these lines
and suggests moving to parameterised queries instead.

### 2. Unvalidated input

For Python it looks for use of `input(` or web style variables like `request.args[...]` or `request.GET[...]`
directly inside SQL or command strings.

For JavaScript it looks for `req.query`, `req.body` or `req.params`
being concatenated into queries or shell commands without any intermediate validation call.

### 3. Weak or outdated cryptography

It flags things like:

* `hashlib.md5`, `hashlib.sha1`
* use of `random.random()` in a context that looks like token or password generation
* Node `crypto.createHash('md5')` etc

For each match it attaches a short explanation and a suggestion.

## How I run it

1. Optional: create and activate a virtual environment

       python -m venv venv
       source venv_bin_activate

2. Install requirements (standard library only):

       pip install -r requirements.txt

3. Look at the example files:

   * `examples/app_insecure.py`
   * `examples/app_insecure.js`

4. Run the coach on the examples:

       python coach_engine.py \
           --files examples/app_insecure.py examples/app_insecure.js \
           --out coach_report.md

This will create:

* `coach_report.md` with:
  * one section per file
  * each finding with:
    * line number
    * short message
    * explanation
    * a tiny “better snippet” you could paste in

In a real IDE extension this engine would be called automatically on file save
and the findings would be shown as hints or quick‑fix actions.

## Why I built this

I like the idea of having a “security buddy” next to me while I code

With this project I can show that I:

* understand common secure coding pitfalls around SQL, input validation and crypto
* can turn simple pattern detection into human friendly advice
* think about integrations with IDEs not just offline scans
* keep the design small and transparent so other developers actually trust it

This engine could be extended with more languages and checks
but even this first version is enough to demonstrate how I think about secure defaults while coding.
