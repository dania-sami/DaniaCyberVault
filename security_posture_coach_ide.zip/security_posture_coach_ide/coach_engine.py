"""
Security Posture Coach – core engine

Scans Python and JavaScript files for a few common insecure patterns:
- string based SQL queries
- unvalidated input used in queries or commands
- weak cryptography choices

Outputs a Markdown report with explanations and safer snippets.
"""

import argparse
import os
from dataclasses import dataclass
from typing import List


@dataclass
class Finding:
    file_path: str
    line_no: int
    category: str
    message: str
    explanation: str
    suggestion: str


def is_python(path: str) -> bool:
    return path.endswith(".py")


def is_js(path: str) -> bool:
    return path.endswith(".js") or path.endswith(".ts")


def analyse_python(path: str) -> List[Finding]:
    findings: List[Finding] = []
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        lines = f.readlines()

    for idx, line in enumerate(lines, start=1):
        lower = line.strip().lower()

        # String based SQL concatenation
        if "execute(" in lower and "select " in lower and "+" in lower:
            findings.append(
                Finding(
                    file_path=path,
                    line_no=idx,
                    category="sql_string_concatenation",
                    message="Possible SQL query built with string concatenation.",
                    explanation=(
                        "This execute call seems to build the SQL query with string concatenation. "
                        "If any part of it comes from user input it can be vulnerable to SQL injection."
                    ),
                    suggestion=(
                        "Use parameterised queries instead, for example:\n\n"
                        "cursor.execute(\"SELECT * FROM users WHERE id = %s\", (user_id,))"
                    ),
                )
            )

        # f-string style SQL
        if "execute(" in lower and "select " in lower and "f\"" in line:
            findings.append(
                Finding(
                    file_path=path,
                    line_no=idx,
                    category="sql_f_string",
                    message="Possible SQL query built using f-string.",
                    explanation=(
                        "This execute call uses an f-string to interpolate values into the SQL directly. "
                        "This is convenient but unsafe for untrusted input."
                    ),
                    suggestion=(
                        "Build the query with placeholders and pass parameters separately to execute()."
                    ),
                )
            )

        # weak crypto
        if "hashlib.md5" in lower or "hashlib.sha1" in lower:
            algo = "MD5/SHA1"
            findings.append(
                Finding(
                    file_path=path,
                    line_no=idx,
                    category="weak_crypto",
                    message=f"Weak hash algorithm {algo} used.",
                    explanation=(
                        "MD5 and SHA1 are considered broken for many security purposes and "
                        "should not be used for password hashing or security tokens."
                    ),
                    suggestion=(
                        "Consider using hashlib.sha256 or a dedicated password hashing function "
                        "such as bcrypt, scrypt or Argon2."
                    ),
                )
            )

        if "random.random" in lower and ("token" in lower or "password" in lower or "secret" in lower):
            findings.append(
                Finding(
                    file_path=path,
                    line_no=idx,
                    category="weak_random",
                    message="random.random() used for something that looks security sensitive.",
                    explanation=(
                        "random.random() is not cryptographically secure and should not be used "
                        "for secrets, tokens or passwords."
                    ),
                    suggestion=(
                        "Use secrets.token_hex(), secrets.token_urlsafe() or os.urandom() for "
                        "security sensitive randomness."
                    ),
                )
            )

        # unvalidated input (very heuristic)
        if "input(" in lower and ("os.system" in lower or "subprocess" in lower):
            findings.append(
                Finding(
                    file_path=path,
                    line_no=idx,
                    category="unvalidated_input_command",
                    message="Raw input appears to be used in a system command.",
                    explanation=(
                        "Using raw input directly in system commands can lead to command injection "
                        "if the input is not validated or escaped."
                    ),
                    suggestion=(
                        "Validate and sanitise the input or use safer APIs (for example subprocess "
                        "with argument lists instead of shell=True)."
                    ),
                )
            )

    return findings


def analyse_js(path: str) -> List[Finding]:
    findings: List[Finding] = []
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        lines = f.readlines()

    for idx, line in enumerate(lines, start=1):
        lower = line.strip().lower()

        # SQL concatenation in JS
        if "select " in lower and "db.query" in lower and "+" in lower:
            findings.append(
                Finding(
                    file_path=path,
                    line_no=idx,
                    category="sql_string_concatenation",
                    message="Possible SQL query built with string concatenation in JavaScript.",
                    explanation=(
                        "This db.query call appears to build the SQL string by concatenating values. "
                        "If those values come from req.query or req.body this can be a SQL injection risk."
                    ),
                    suggestion=(
                        "Use parameterised queries or query builders that pass values separately "
                        "from the SQL template."
                    ),
                )
            )

        # unvalidated request parameters
        if ("req.query" in lower or "req.body" in lower or "req.params" in lower) and "+" in lower and (
            "select " in lower or "update " in lower or "insert " in lower
        ):
            findings.append(
                Finding(
                    file_path=path,
                    line_no=idx,
                    category="unvalidated_input_query",
                    message="HTTP request data concatenated into a query string.",
                    explanation=(
                        "This line concatenates HTTP request parameters into a query string. "
                        "Without validation or parameterisation this is a common injection pattern."
                    ),
                    suggestion=(
                        "Validate and normalise req.* values first, then use parameterised queries."
                    ),
                )
            )

        # weak crypto in Node
        if "crypto.createhash('md5')" in lower or "crypto.createhash(\"md5\")" in lower:
            findings.append(
                Finding(
                    file_path=path,
                    line_no=idx,
                    category="weak_crypto",
                    message="MD5 hash used in Node crypto.",
                    explanation=(
                        "MD5 is not suitable for security sensitive hashing, especially passwords or tokens."
                    ),
                    suggestion=(
                        "Prefer a modern algorithm such as SHA-256, and for passwords use dedicated hashing libraries."
                    ),
                )
            )

    return findings


def analyse_file(path: str) -> List[Finding]:
    if is_python(path):
        return analyse_python(path)
    if is_js(path):
        return analyse_js(path)
    return []


def write_report(findings: List[Finding], out_path: str) -> None:
    by_file = {}
    for f in findings:
        by_file.setdefault(f.file_path, []).append(f)

    with open(out_path, "w", encoding="utf-8") as out:
        out.write("# Security posture coach report\n\n")
        if not findings:
            out.write("No patterns were flagged with the current simple rules.\n")
            return

        for file_path, items in sorted(by_file.items()):
            out.write(f"## {file_path}\n\n")
            for fnd in items:
                out.write(f"### Line {fnd.line_no} – {fnd.category}\n\n")
                out.write(f"* Message: {fnd.message}\n")
                out.write(f"* Explanation: {fnd.explanation}\n\n")
                if fnd.suggestion:
                    out.write("Suggested safer pattern:\n\n")
                    out.write("```text\n")
                    out.write(fnd.suggestion.strip() + "\n")
                    out.write("```\n\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's security posture coach engine")
    parser.add_argument("--files", nargs="+", required=True, help="Source files to analyse")
    parser.add_argument("--out", default="coach_report.md", help="Output Markdown report path")
    args = parser.parse_args()

    all_findings: List[Finding] = []
    for path in args.files:
        if not os.path.isfile(path):
            continue
        all_findings.extend(analyse_file(path))

    write_report(all_findings, args.out)
    print(f"Analysed {len(args.files)} file(s); wrote report to {args.out}")


if __name__ == "__main__":
    main()
