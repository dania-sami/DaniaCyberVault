import hashlib
import sqlite3
import random

def get_user(db, user_id):
    cursor = db.cursor()
    # insecure: string concatenation
    query = "SELECT * FROM users WHERE id = " + user_id
    cursor.execute(query)
    return cursor.fetchall()

def make_reset_token(username):
    # insecure: md5 and random.random used for token
    raw = username + str(random.random())
    return hashlib.md5(raw.encode()).hexdigest()
