const crypto = require('crypto');

function getUser(db, req) {
  // insecure: concatenating request data into SQL
  const q = "SELECT * FROM users WHERE name = '" + req.query.name + "'";
  return db.query(q);
}

function hashThing(value) {
  // insecure: MD5
  return crypto.createHash('md5').update(value).digest('hex');
}
