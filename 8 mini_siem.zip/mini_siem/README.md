# Mini SIEM – Security Log Aggregator

This is a small but powerful **Mini SIEM (Security Information and Event Management)** project.

It shows how to:
- Ingest security logs from different tools (IDS, web scanner, malware detector)
- Normalise them into a common format
- Correlate events by host and time
- Compute a simple risk score for each host
- Generate a clear text report of the most suspicious hosts and events

The goal:
- Easy to understand and extend
- No external infrastructure required
- Great as a portfolio project that connects your other security tools

The dataset in `data/` is synthetic and safe. You can later replace it with real logs
from your own projects or lab environment.

> ⚠️ This project is for learning and demonstration, not a full production SIEM.

## Quick start

```bash
# 1. Create and activate a virtual environment (recommended)
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Run the SIEM analysis on the sample logs
python -m src.main
```

A summary will be printed in the terminal and a full report will be written to the
`reports/` folder with a timestamped filename.

## Project structure

- `src/`
  - `config.py`    paths and constants
  - `loaders.py`   functions for loading and normalising different log files
  - `correlate.py` simple correlation and risk scoring engine
  - `report.py`    pretty text report writer
  - `main.py`      CLI entry point
- `data/`
  - `ids_logs.csv`       synthetic intrusion detection alerts
  - `webscan_logs.csv`   synthetic web vulnerability scan results
  - `malware_logs.csv`   synthetic malware detection events
- `reports/`      generated SIEM reports

## Ideas to extend

You can make this Mini SIEM more advanced by:

- Adding support for JSON log formats
- Adding more event sources (firewall, auth logs, cloud logs)
- Exporting the report as HTML and visualising with charts
- Exposing a small API or dashboard (e.g. with Flask or Streamlit)

This repo is intentionally minimal but realistic so reviewers can see your thinking
about **log analysis**, **incident correlation** and **risk-based security**.
