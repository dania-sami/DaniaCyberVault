from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Dict

import pandas as pd

from .config import REPORT_DIR
from .correlate import HostSummary, top_hosts_by_risk


def generate_report(events: pd.DataFrame, summaries: Dict[str, HostSummary]) -> Path:
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    filename = f"siem_report_{ts}.txt"
    path = REPORT_DIR / filename

    lines = []
    lines.append("Mini SIEM Report")
    lines.append(f"Generated: {datetime.now().isoformat()}")
    lines.append(f"Total events: {len(events)}")
    lines.append(f"Distinct hosts: {events['host'].nunique()}")
    lines.append("")

    lines.append("Top hosts by risk score:")
    for idx, host_summary in enumerate(top_hosts_by_risk(summaries), start=1):
        lines.append(
            f"[{idx}] {host_summary.host} | risk={host_summary.risk_score:.2f} | "
            f"events={host_summary.total_events} | max_sev={host_summary.max_severity:.1f} | "
            f"sources={','.join(host_summary.sources)}"
        )

    lines.append("")
    lines.append("All events (chronological):")
    for _, row in events.sort_values("timestamp").iterrows():
        lines.append(
            f"{row['timestamp']} | host={row['host']} | src={row['source']} | "
            f"sev={row['severity']} | {row['event_type']} | {row['description']}"
        )

    path.write_text("\n".join(lines), encoding="utf-8")
    return path
