from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List

import numpy as np
import pandas as pd


@dataclass
class HostSummary:
    host: str
    total_events: int
    max_severity: float
    avg_severity: float
    sources: List[str]
    risk_score: float


def compute_host_summaries(events: pd.DataFrame) -> Dict[str, HostSummary]:
    summaries: Dict[str, HostSummary] = {}
    grouped = events.groupby("host")

    for host, group in grouped:
        total_events = len(group)
        max_severity = float(group["severity"].max())
        avg_severity = float(group["severity"].mean())
        sources = sorted(group["source"].unique().tolist())

        # Simple risk formula:
        # risk = max_severity * log(1 + total_events) * (1 + 0.2 * (num_sources - 1))
        num_sources = len(sources)
        risk_score = max_severity * float(np.log1p(total_events)) * (1 + 0.2 * (num_sources - 1))

        summaries[host] = HostSummary(
            host=host,
            total_events=total_events,
            max_severity=max_severity,
            avg_severity=avg_severity,
            sources=sources,
            risk_score=risk_score,
        )

    return summaries


def top_hosts_by_risk(summaries: Dict[str, HostSummary], n: int = 5) -> List[HostSummary]:
    return sorted(summaries.values(), key=lambda s: s.risk_score, reverse=True)[:n]
