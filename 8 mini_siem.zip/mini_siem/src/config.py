from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
REPORT_DIR = BASE_DIR / "reports"

IDS_LOG = DATA_DIR / "ids_logs.csv"
WEBSCAN_LOG = DATA_DIR / "webscan_logs.csv"
MALWARE_LOG = DATA_DIR / "malware_logs.csv"

REPORT_DIR.mkdir(exist_ok=True)
