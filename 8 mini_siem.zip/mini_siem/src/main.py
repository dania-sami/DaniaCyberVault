from __future__ import annotations

from .loaders import load_all_events
from .correlate import compute_host_summaries
from .report import generate_report


def main() -> None:
    print("[*] Loading events from IDS, web scanner and malware detector...")
    events = load_all_events()
    print(f"[+] Loaded {len(events)} events from {events['source'].nunique()} sources")
    print(f"[+] Hosts involved: {events['host'].nunique()}\n")

    summaries = compute_host_summaries(events)
    report_path = generate_report(events, summaries)

    print("[+] Analysis complete.")
    print(f"[+] Report written to: {report_path}")
    print("\nOpen the report file to see:")
    print("  - Top risky hosts")
    print("  - Severity levels per host")
    print("  - All correlated events in time order")


if __name__ == "__main__":
    main()
