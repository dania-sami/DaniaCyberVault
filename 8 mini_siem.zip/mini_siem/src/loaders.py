from __future__ import annotations

from typing import List

import pandas as pd

from .config import IDS_LOG, WEBSCAN_LOG, MALWARE_LOG


COMMON_COLUMNS = [
    "timestamp",  # ISO8601 string
    "host",       # hostname or IP
    "event_type",
    "severity",   # 1-10
    "description",
    "source",     # ids / webscan / malware (filled below)
]


def _parse_datetime(df: pd.DataFrame) -> pd.DataFrame:
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    return df


def load_ids_logs() -> pd.DataFrame:
    df = pd.read_csv(IDS_LOG)
    df["source"] = "ids"
    return _parse_datetime(df[COMMON_COLUMNS])


def load_webscan_logs() -> pd.DataFrame:
    df = pd.read_csv(WEBSCAN_LOG)
    df["source"] = "webscan"
    return _parse_datetime(df[COMMON_COLUMNS])


def load_malware_logs() -> pd.DataFrame:
    df = pd.read_csv(MALWARE_LOG)
    df["source"] = "malware"
    return _parse_datetime(df[COMMON_COLUMNS])


def load_all_events() -> pd.DataFrame:
    frames: List[pd.DataFrame] = [
        load_ids_logs(),
        load_webscan_logs(),
        load_malware_logs(),
    ]
    df = pd.concat(frames, ignore_index=True)
    df = df.sort_values("timestamp").reset_index(drop=True)
    return df
