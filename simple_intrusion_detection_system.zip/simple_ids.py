import argparse
import json
from typing import List, Dict, Any

def load_rules(path: str) -> List[Dict[str, Any]]:
    with open(path) as f:
        data = json.load(f)
    rules = []
    for r in data:
        if "name" in r and "pattern" in r:
            rules.append(r)
    return rules

def scan_log(log_path: str, rules_path: str):
    rules = load_rules(rules_path)
    print(f"[+] Loaded {len(rules)} rules")
    print(f"[+] Scanning {log_path}\n")

    with open(log_path) as f:
        for line in f:
            line = line.rstrip("\n")
            for r in rules:
                pat = r.get("pattern", "")
                if pat and pat in line:
                    level = r.get("level", "info")
                    name = r.get("name", "rule")
                    print(f"[ALERT] Rule={name} level={level}")
                    print(f"        {line}\n")
                    break

def main():
    parser = argparse.ArgumentParser(description="Simple Log based IDS by Dania")
    parser.add_argument("--log", required=True, help="Path to log file")
    parser.add_argument("--rules", required=True, help="Path to rules.json file")
    args = parser.parse_args()
    scan_log(args.log, args.rules)

if __name__ == "__main__":
    main()
