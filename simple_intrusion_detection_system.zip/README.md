# Simple Intrusion Detection System (Log based)

This is a very small log based IDS that I wrote to practice the idea of rule based detection.

The script reads a log file line by line and checks for simple patterns that I care about, like failed logins, access to sensitive paths, or SQL error messages. When it sees something that matches a rule, it prints a clear alert.

## What it can do

- Load a `rules.json` file with simple detection rules
- Scan any text log file
- Print alerts with rule name and the matching log line
- Keep things small and easy to understand so it is good for learning and interviews

## Files

- `simple_ids.py` – main script
- `rules.json` – example rules
- `demo_log.txt` – small demo log so the project runs directly

## Usage

Run it like this:

```bash
python simple_ids.py --log demo_log.txt --rules rules.json
```

Example output:

```text
[+] Loaded 4 rules
[+] Scanning demo_log.txt

[ALERT] Rule=failed_login level=high
        2025-01-01 12:00:01 sshd: Failed password for dania from 10.0.0.5 port 54321

[ALERT] Rule=suspicious_path level=medium
        2025-01-01 12:03:10 nginx: GET /admin/phpmyadmin/index.php HTTP/1.1
```

## Why this is useful for me

- It shows that I understand the idea of signatures and rules
- It gives me a small code base I can extend with more advanced logic later
- It is easy to walk through in an interview and explain line by line
