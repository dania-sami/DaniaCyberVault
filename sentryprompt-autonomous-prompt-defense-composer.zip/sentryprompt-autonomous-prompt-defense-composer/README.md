
# SentryPrompt Autonomous Prompt Defense Composer

SentryPrompt is my way to turn messy prompt misuse signals into a clean,
explainable defense playbook.

I describe a scenario with a few signal scores: jailbreak pressure, data
exfil pressure, policy evasion attempts, tool misuse and spam pressure.

It gives me:
* a severity band for this scenario
* a short list of rules I can actually implement
* a few notes I can read to the team

## Run

```bash
cd backend
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn sentryprompt_engine.main:app --reload --port 9934
```

Open http://localhost:9934/docs and try `/scenarios` then `/compose`.
