
from fastapi import FastAPI
app = FastAPI(title="SentryPrompt Autonomous Prompt Defense Composer")

@app.get("/status")
def status():
    return {
        "project": "SentryPrompt Autonomous Prompt Defense Composer",
        "status": "working",
        "message": "All systems operational"
    }
