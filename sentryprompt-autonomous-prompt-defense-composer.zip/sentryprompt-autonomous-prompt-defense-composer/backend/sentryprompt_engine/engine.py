
from dataclasses import dataclass
from typing import Dict, List


@dataclass
class ScenarioProfile:
    id: int
    name: str
    meta: Dict[str, str]
    signals: Dict[str, float]


@dataclass
class DefensePlaybook:
    scenario_id: int
    name: str
    severity_band: str
    rules: List[str]
    notes: List[str]


class SentryPromptBrain:
    """
    Reasoning engine that turns prompt misuse signals into a small defense
    playbook: a handful of concrete rules with rationale.
    """

    def __init__(self) -> None:
        self._next_id = 1
        self.scenarios: Dict[int, ScenarioProfile] = {}

    def register_scenario(self, name: str, meta: Dict[str, str], signals: Dict[str, float]) -> ScenarioProfile:
        sid = self._next_id
        self._next_id += 1
        prof = ScenarioProfile(
            id=sid,
            name=name,
            meta=meta,
            signals=signals,
        )
        self.scenarios[sid] = prof
        return prof

    def compose(self, scenario_id: int) -> DefensePlaybook:
        prof = self.scenarios[scenario_id]
        s = prof.signals
        rules: List[str] = []
        notes: List[str] = []

        jailbreak_pressure = float(s.get("jailbreak_signal_strength", 0.0))
        data_exfil_pressure = float(s.get("data_exfil_signal_strength", 0.0))
        policy_evasion_pressure = float(s.get("policy_evasion_signal_strength", 0.0))
        tool_misuse_pressure = float(s.get("tool_misuse_signal_strength", 0.0))
        spam_abuse_pressure = float(s.get("spam_abuse_signal_strength", 0.0))

        overall = (
            jailbreak_pressure
            + data_exfil_pressure
            + policy_evasion_pressure
            + tool_misuse_pressure
            + spam_abuse_pressure
        ) / 5.0

        if jailbreak_pressure > 0.4:
            rules.append("Force safety classifier on all responses in this scenario.")
            notes.append("Jailbreak attempts show up often in this traffic.")
        if data_exfil_pressure > 0.4:
            rules.append("Block sensitive data patterns and redact identifiers in outputs.")
            notes.append("There is pressure to extract internal or private data.")
        if policy_evasion_pressure > 0.4:
            rules.append("Add a stricter policy reminder inside the system prompt.")
            notes.append("Users try to sidestep policies with meta prompts.")
        if tool_misuse_pressure > 0.4:
            rules.append("Require explicit allow-list for tool arguments in this use case.")
            notes.append("Tools are being steered into unusual or risky calls.")
        if spam_abuse_pressure > 0.4:
            rules.append("Throttle repeated similar prompts and add captcha outside the LLM.")
            notes.append("Traffic has spam or automated abuse characteristics.")

        if not rules:
            rules.append("Maintain current policy and logging; no strong misuse signals in this scenario.")
            notes.append("Signals remain low; focus on monitoring and gradual tuning.")

        if overall >= 0.8:
            severity_band = "critical_defense_needed"
        elif overall >= 0.6:
            severity_band = "high_defense_needed"
        elif overall >= 0.4:
            severity_band = "moderate_defense_needed"
        elif overall >= 0.2:
            severity_band = "light_defense_needed"
        else:
            severity_band = "monitor_only"

        return DefensePlaybook(
            scenario_id=prof.id,
            name=prof.name,
            severity_band=severity_band,
            rules=rules,
            notes=notes,
        )
