
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Dict, List

from .engine import SentryPromptBrain, ScenarioProfile, DefensePlaybook


brain = SentryPromptBrain()


class ScenarioIn(BaseModel):
    name: str = Field(..., example="public-chat-interface")
    meta: Dict[str, str] = Field(default_factory=dict)
    signals: Dict[str, float] = Field(
        default_factory=dict,
        description=(
            "Signals: jailbreak_signal_strength, data_exfil_signal_strength, "
            "policy_evasion_signal_strength, tool_misuse_signal_strength, spam_abuse_signal_strength"
        ),
    )


class ScenarioOut(BaseModel):
    id: int
    name: str
    meta: Dict[str, str]
    signals: Dict[str, float]


class PlaybookOut(BaseModel):
    scenario_id: int
    name: str
    severity_band: str
    rules: List[str]
    notes: List[str]


app = FastAPI(
    title="SentryPrompt Autonomous Prompt Defense Composer",
    version="0.1.0",
    description="Turns prompt misuse signals into a compact defense playbook.",
)


@app.post("/scenarios", response_model=ScenarioOut)
def register_scenario(payload: ScenarioIn) -> ScenarioOut:
    prof: ScenarioProfile = brain.register_scenario(
        name=payload.name,
        meta=payload.meta,
        signals=payload.signals,
    )
    return ScenarioOut(
        id=prof.id,
        name=prof.name,
        meta=prof.meta,
        signals=prof.signals,
    )


@app.post("/compose", response_model=PlaybookOut)
def compose(scenario_id: int) -> PlaybookOut:
    if scenario_id not in brain.scenarios:
        raise HTTPException(status_code=404, detail="Scenario not found")
    res: DefensePlaybook = brain.compose(scenario_id)
    return PlaybookOut(
        scenario_id=res.scenario_id,
        name=res.name,
        severity_band=res.severity_band,
        rules=res.rules,
        notes=res.notes,
    )
