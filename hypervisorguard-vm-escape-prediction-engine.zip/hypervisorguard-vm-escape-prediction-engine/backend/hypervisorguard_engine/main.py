
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Dict, List

from .engine import HyperVisorBrain, VMProfile, EscapeAssessment


brain = HyperVisorBrain()


class VMIn(BaseModel):
    host_name: str = Field(..., example="esxi-prod-01")
    hypervisor: str = Field(..., example="esxi")
    version: str = Field(..., example="7.0")
    metadata: Dict[str, str] = Field(default_factory=dict)
    risk_flags: Dict[str, bool] = Field(
        default_factory=dict,
        description="Flags such as outdated_hypervisor, nested_virtualisation_enabled, speculative_execution_mitigations_disabled, shared_gpu_pass_through, untrusted_multi_tenant, weak_isolation_config, debug_interfaces_exposed",
    )


class VMOut(BaseModel):
    id: int
    host_name: str
    hypervisor: str
    version: str
    metadata: Dict[str, str]
    risk_flags: Dict[str, bool]


class AssessmentOut(BaseModel):
    vm_id: int
    host_name: str
    hypervisor: str
    score: float
    band: str
    reasons: List[str]


app = FastAPI(
    title="HyperVisorGuard VM Escape Prediction Engine",
    version="0.1.0",
    description="My reasoning engine for VM escape risk based on hypervisor configuration signals.",
)


@app.post("/vms", response_model=VMOut)
def register_vm(payload: VMIn) -> VMOut:
    vm: VMProfile = brain.register_vm(
        host_name=payload.host_name,
        hypervisor=payload.hypervisor,
        version=payload.version,
        metadata=payload.metadata,
        flags=payload.risk_flags,
    )
    return VMOut(
        id=vm.id,
        host_name=vm.host_name,
        hypervisor=vm.hypervisor,
        version=vm.version,
        metadata=vm.metadata,
        risk_flags=vm.risk_flags,
    )


@app.post("/assess", response_model=AssessmentOut)
def assess(vm_id: int) -> AssessmentOut:
    if vm_id not in brain.vms:
        raise HTTPException(status_code=404, detail="VM not found")
    res: EscapeAssessment = brain.assess(vm_id)
    return AssessmentOut(
        vm_id=res.vm_id,
        host_name=res.host_name,
        hypervisor=res.hypervisor,
        score=res.score,
        band=res.band,
        reasons=res.reasons,
    )
