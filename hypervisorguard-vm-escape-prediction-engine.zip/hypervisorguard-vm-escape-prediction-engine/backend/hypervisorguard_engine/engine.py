
from dataclasses import dataclass
from typing import Dict, List


@dataclass
class VMProfile:
    id: int
    host_name: str
    hypervisor: str
    version: str
    metadata: Dict[str, str]
    risk_flags: Dict[str, bool]


@dataclass
class EscapeAssessment:
    vm_id: int
    host_name: str
    hypervisor: str
    score: float
    band: str
    reasons: List[str]


class HyperVisorBrain:
    """
    HyperVisorGuard is my lab project for thinking about VM escape risk.

    It does not exploit anything. Instead it takes high level signals about the
    virtualisation stack and host hygiene and turns them into a risk style
    assessment for potential escape paths.
    """

    def __init__(self) -> None:
        self.vms: Dict[int, VMProfile] = {}
        self._next_id = 1

    def register_vm(self, host_name: str, hypervisor: str, version: str, metadata: Dict[str, str], flags: Dict[str, bool]) -> VMProfile:
        vid = self._next_id
        self._next_id += 1
        prof = VMProfile(
            id=vid,
            host_name=host_name,
            hypervisor=hypervisor.lower(),
            version=version,
            metadata=metadata,
            risk_flags=flags,
        )
        self.vms[vid] = prof
        return prof

    def assess(self, vm_id: int) -> EscapeAssessment:
        vm = self.vms[vm_id]
        f = vm.risk_flags
        reasons: List[str] = []
        score = 0.0

        if f.get("outdated_hypervisor"):
            score += 25.0
            reasons.append("Hypervisor version is flagged as outdated or near end of support.")
        if f.get("nested_virtualisation_enabled"):
            score += 15.0
            reasons.append("Nested virtualisation is enabled which increases complexity and attack surface.")
        if f.get("speculative_execution_mitigations_disabled"):
            score += 20.0
            reasons.append("Speculative execution mitigations are disabled or incomplete.")
        if f.get("shared_gpu_pass_through"):
            score += 15.0
            reasons.append("GPU passthrough or sharing is used which can create additional cross VM channels.")
        if f.get("untrusted_multi_tenant"):
            score += 25.0
            reasons.append("Host runs untrusted workloads from multiple tenants.")
        if f.get("weak_isolation_config"):
            score += 20.0
            reasons.append("Isolation settings for memory or devices are weaker than recommended defaults.")
        if f.get("debug_interfaces_exposed"):
            score += 20.0
            reasons.append("Debug or management interfaces are reachable from less trusted networks.")

        if not reasons:
            reasons.append("No explicit high risk factors were flagged for this VM host profile.")

        score = min(100.0, score)

        if score >= 80.0:
            band = "critical_escape_risk"
        elif score >= 60.0:
            band = "high_escape_risk"
        elif score >= 40.0:
            band = "medium_escape_risk"
        else:
            band = "low_escape_risk"

        return EscapeAssessment(
            vm_id=vm.id,
            host_name=vm.host_name,
            hypervisor=vm.hypervisor,
            score=round(score, 2),
            band=band,
            reasons=reasons,
        )
