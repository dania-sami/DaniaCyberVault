
# HyperVisorGuard VM Escape Prediction Engine

HyperVisorGuard is my reasoning engine for VM escape risk.

Modern virtualised environments are complicated. Between hypervisor versions,
nested virtualisation, speculative execution issues and GPU passthrough it is
easy to lose track of how exposed a host might be to an escape class attack.

This project does not exploit anything. Instead it gives me a clear structure
to talk about configuration risk and attack surface.

## What HyperVisorGuard does

* records VM host profiles with
  * hypervisor type and version
  * free form metadata
  * boolean risk flags for critical conditions
* calculates a score between zero and one hundred based on which flags are set
* assigns a band for example
  * `low_escape_risk`
  * `medium_escape_risk`
  * `high_escape_risk`
  * `critical_escape_risk`
* returns a list of reasons that explain the score

All scoring logic lives in `engine.py` so I can tweak weights or add new risk
factors easily.

## Project layout

```text
hypervisorguard-vm-escape-prediction-engine
└── backend
    ├── hypervisorguard_engine
    │   ├── __init__.py
    │   ├── engine.py  VM profile model and risk scoring
    │   └── main.py    FastAPI HTTP API
    ├── requirements.txt
    └── example_requests.http
```

## How I run it locally

From the backend folder

```bash
python -m venv .venv
source .venv/bin/activate        # On Windows I use .venv\Scripts\activate
pip install -r requirements.txt
uvicorn hypervisorguard_engine.main:app --reload --port 9829
```

Then I open

* http://localhost:9829/docs to register profiles and run assessments

## Example profile I like to experiment with

I register a host profile that has several red flags

```bash
curl -X POST http://localhost:9829/vms   -H "Content-Type: application/json"   -d '{
    "host_name": "esxi-prod-01",
    "hypervisor": "esxi",
    "version": "7.0",
    "metadata": {
      "cluster": "prod-core"
    },
    "risk_flags": {
      "outdated_hypervisor": true,
      "nested_virtualisation_enabled": true,
      "speculative_execution_mitigations_disabled": true,
      "shared_gpu_pass_through": false,
      "untrusted_multi_tenant": true,
      "weak_isolation_config": true,
      "debug_interfaces_exposed": false
    }
  }'
```

Then I ask HyperVisorGuard to assess it

```bash
curl -X POST "http://localhost:9829/assess?vm_id=1"
```

The response gives me

* a score that is likely in the high or critical band
* clear reasons, each mapping to a risk flag

With this I can have a real conversation about which settings to fix first and
how different configurations compare.

## Why I like this project

HyperVisorGuard captures how I think about complex infrastructure risk

* break it into explicit factors
* assign weights
* keep everything explainable

It is a good starting point for a richer risk model that could be fed from
real hypervisor inventory and vulnerability data in the future.
