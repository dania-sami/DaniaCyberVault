
from dataclasses import dataclass
from datetime import datetime
from typing import Dict, List, Literal


EventType = Literal[
    "login_success",
    "login_failure",
    "role_change",
    "privilege_grant",
    "mfa_bypass",
    "suspicious_location",
]


@dataclass
class Identity:
    id: str
    display_name: str
    department: str
    criticality: Literal["low", "medium", "high"]
    last_seen: datetime | None = None


@dataclass
class IdentityEvent:
    identity_id: str
    type: EventType
    timestamp: datetime
    details: Dict[str, str]


@dataclass
class IdentityPosture:
    identity_id: str
    risk_score: float
    level: Literal["low", "medium", "high", "critical"]
    reasons: List[str]
    last_updated: datetime


class IdentityBrain:
    """
    Small identity posture engine.

    It does not try to be a full UEBA system. Instead it shows clearly
    how identity events are converted into a drift and risk score.
    """

    def __init__(self) -> None:
        self.events: Dict[str, List[IdentityEvent]] = {}

    def add_event(self, event: IdentityEvent) -> None:
        self.events.setdefault(event.identity_id, []).append(event)

    def compute_posture(self, identity: Identity) -> IdentityPosture:
        history = self.events.get(identity.id, [])
        reasons: List[str] = []

        base = {
            "low": 10.0,
            "medium": 25.0,
            "high": 40.0,
        }[identity.criticality]

        reasons.append(f"Base score from identity criticality {identity.criticality} is {base}.")

        score = base

        # Simple counters
        failed_logins = sum(1 for e in history if e.type == "login_failure")
        mfa_bypass = any(e.type == "mfa_bypass" for e in history)
        priv_grants = [e for e in history if e.type == "privilege_grant"]
        suspicious_locations = [e for e in history if e.type == "suspicious_location"]

        if failed_logins:
            bump = min(15.0, failed_logins * 3.0)
            score += bump
            reasons.append(f"{failed_logins} failed login events add {bump} to the score.")

        if mfa_bypass:
            score += 25.0
            reasons.append("At least one MFA bypass was recorded. This is very sensitive.")

        if priv_grants:
            bump = 10.0
            score += bump
            reasons.append(f"{len(priv_grants)} privilege grants add {bump} risk.")

        if suspicious_locations:
            bump = 20.0
            score += bump
            reasons.append("Login or access from suspicious or new locations detected.")

        # Recency
        if history:
            latest = max(e.timestamp for e in history)
        else:
            latest = datetime.utcnow()

        # Cap and classify
        score = min(100.0, score)

        if score < 25.0:
            level: Literal["low", "medium", "high", "critical"] = "low"
        elif score < 50.0:
            level = "medium"
        elif score < 75.0:
            level = "high"
        else:
            level = "critical"

        return IdentityPosture(
            identity_id=identity.id,
            risk_score=float(round(score, 1)),
            level=level,
            reasons=reasons or ["No notable risk signals in recent history."],
            last_updated=latest,
        )
