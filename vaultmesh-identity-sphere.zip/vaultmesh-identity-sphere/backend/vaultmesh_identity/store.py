
from dataclasses import dataclass
from datetime import datetime
from typing import Dict, List

from .engine import Identity, IdentityEvent, IdentityBrain, IdentityPosture, EventType


@dataclass
class VaultMeshStore:
    identities: Dict[str, Identity]
    brain: IdentityBrain


store = VaultMeshStore(
    identities={},
    brain=IdentityBrain(),
)


def upsert_identity(
    identity_id: str,
    display_name: str,
    department: str,
    criticality: str,
) -> Identity:
    existing = store.identities.get(identity_id)
    if existing:
        existing.display_name = display_name
        existing.department = department
        existing.criticality = criticality  # type: ignore[assignment]
        return existing
    ident = Identity(
        id=identity_id,
        display_name=display_name,
        department=department,
        criticality=criticality,  # type: ignore[arg-type]
    )
    store.identities[identity_id] = ident
    return ident


def add_event(
    identity_id: str,
    type_: EventType,
    timestamp: datetime,
    details: Dict[str, str],
) -> None:
    event = IdentityEvent(
        identity_id=identity_id,
        type=type_,
        timestamp=timestamp,
        details=details,
    )
    store.brain.add_event(event)
    ident = store.identities.get(identity_id)
    if ident:
        ident.last_seen = timestamp


def posture_for(identity_id: str) -> IdentityPosture | None:
    ident = store.identities.get(identity_id)
    if not ident:
        return None
    return store.brain.compute_posture(ident)


def all_postures() -> List[IdentityPosture]:
    return [store.brain.compute_posture(i) for i in store.identities.values()]
