
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Dict, List, Literal
from datetime import datetime

from .store import upsert_identity, add_event, posture_for, all_postures


Criticality = Literal["low", "medium", "high"]
EventType = Literal[
    "login_success",
    "login_failure",
    "role_change",
    "privilege_grant",
    "mfa_bypass",
    "suspicious_location",
]


class IdentityIn(BaseModel):
    id: str = Field(..., example="dania.sami")
    display_name: str = Field(..., example="Dania Sami")
    department: str = Field(..., example="Engineering")
    criticality: Criticality = "medium"


class IdentityOut(IdentityIn):
    last_seen: datetime | None = None


class EventIn(BaseModel):
    identity_id: str
    type: EventType
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    details: Dict[str, str] = Field(default_factory=dict)


class PostureOut(BaseModel):
    identity_id: str
    risk_score: float
    level: Literal["low", "medium", "high", "critical"]
    reasons: List[str]
    last_updated: datetime


app = FastAPI(
    title="VaultMesh Identity Sphere",
    version="0.1.0",
    description="Continuous identity posture engine for your lab environment.",
)


@app.post("/identities", response_model=IdentityOut)
def register_identity(payload: IdentityIn) -> IdentityOut:
    ident = upsert_identity(
        identity_id=payload.id,
        display_name=payload.display_name,
        department=payload.department,
        criticality=payload.criticality,
    )
    return IdentityOut(
        id=ident.id,
        display_name=ident.display_name,
        department=ident.department,
        criticality=ident.criticality,  # type: ignore[arg-type]
        last_seen=ident.last_seen,
    )


@app.get("/identities", response_model=List[IdentityOut])
def list_identities() -> List[IdentityOut]:
    from .store import store  # local import to avoid circular reference

    out: List[IdentityOut] = []
    for ident in store.identities.values():
        out.append(
            IdentityOut(
                id=ident.id,
                display_name=ident.display_name,
                department=ident.department,
                criticality=ident.criticality,  # type: ignore[arg-type]
                last_seen=ident.last_seen,
            )
        )
    return out


@app.post("/events")
def ingest_events(events: List[EventIn]) -> Dict[str, int]:
    for e in events:
        add_event(
            identity_id=e.identity_id,
            type_=e.type,
            timestamp=e.timestamp,
            details=e.details,
        )
    return {"ingested": len(events)}


@app.get("/posture/{identity_id}", response_model=PostureOut)
def get_posture(identity_id: str) -> PostureOut:
    p = posture_for(identity_id)
    if not p:
        raise HTTPException(status_code=404, detail="Identity not found")
    return PostureOut(
        identity_id=p.identity_id,
        risk_score=p.risk_score,
        level=p.level,
        reasons=p.reasons,
        last_updated=p.last_updated,
    )


@app.get("/posture", response_model=List[PostureOut])
def list_postures() -> List[PostureOut]:
    items = []
    for p in all_postures():
        items.append(
            PostureOut(
                identity_id=p.identity_id,
                risk_score=p.risk_score,
                level=p.level,
                reasons=p.reasons,
                last_updated=p.last_updated,
            )
        )
    return items
