
# VaultMesh Identity Sphere

VaultMesh Identity Sphere is a small identity posture engine for lab use.

Instead of looking only at machines and networks this project focuses on people and accounts. It lets you register identities send key events such as failed logins or privilege grants and see a clear risk score and reasons for each identity.

This is not meant to be a full blown enterprise product. It is a clear working prototype that you can show in a portfolio or extend into a richer identity security story.

## Project layout

```text
vaultmesh-identity-sphere
└── backend
    ├── vaultmesh_identity
    │   ├── __init__.py
    │   ├── main.py     FastAPI HTTP API
    │   ├── engine.py   Identity posture logic
    │   └── store.py    In memory state
    ├── requirements.txt
    └── example_requests.http
```

## Running the backend

From the backend folder

```bash
python -m venv .venv
source .venv/bin/activate        # On Windows use .venv\Scripts\activate
pip install -r requirements.txt
uvicorn vaultmesh_identity.main:app --reload --port 9600
```

The API will be reachable at

* http://localhost:9600
* interactive docs at http://localhost:9600/docs

## Basic workflow

### Step one register identities

```bash
curl -X POST http://localhost:9600/identities   -H "Content-Type: application/json"   -d '{
    "id": "alice",
    "display_name": "Alice Smith",
    "department": "Finance",
    "criticality": "high"
  }'
```

You can repeat this call for several people or service accounts.

### Step two send events

Events describe security relevant activity for an identity. For example failed logins privilege grants or MFA bypasses.

```bash
curl -X POST http://localhost:9600/events   -H "Content-Type: application/json"   -d '[
    {
      "identity_id": "alice",
      "type": "login_failure",
      "details": {"source": "vpn", "reason": "wrong password"}
    },
    {
      "identity_id": "alice",
      "type": "login_failure",
      "details": {"source": "vpn", "reason": "wrong password"}
    },
    {
      "identity_id": "alice",
      "type": "mfa_bypass",
      "details": {"source": "idp", "method": "temporary bypass by helpdesk"}
    }
  ]'
```

### Step three read posture

```bash
curl http://localhost:9600/posture/alice
```

The response describes

* risk score between zero and one hundred
* level low medium high or critical
* reasons that explain how the score was built
* last updated time

You can also list postures for all identities

```bash
curl http://localhost:9600/posture
```

## How the scoring works

The identity brain in engine.py uses

* identity criticality as a base score
* number of failed logins
* whether any MFA bypass has happened
* how many privilege grants occurred
* whether suspicious location events have appeared

From these signals it computes a capped score and maps it to a simple level. This logic is intentionally transparent so that you can open the file and explain it line by line during an interview or presentation.

## Ideas for extending VaultMesh Identity Sphere

You can build many features on top of this core

* add time windows so that recent events count more than old ones
* connect to real sources such as identity providers VPN logs or ticketing systems
* keep a full audit log of identity risk changes
* build a small dashboard that shows which identities are the riskiest today
* integrate with access review workflows so that very risky identities trigger manual review

As it stands this project already shows clear thinking about identity centric security and risk based access.
