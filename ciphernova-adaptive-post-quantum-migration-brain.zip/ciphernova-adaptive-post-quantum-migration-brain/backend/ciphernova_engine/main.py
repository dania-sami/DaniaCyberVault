
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Dict, List

from .engine import CipherNovaBrain, OrgProfile, MigrationPlan


brain = CipherNovaBrain()


class OrgIn(BaseModel):
    name: str = Field(..., example="Critical Payments Platform")
    meta: Dict[str, str] = Field(default_factory=dict)
    metrics: Dict[str, float] = Field(
        default_factory=dict,
        description=(
            "Metrics: architecture_criticality, legacy_crypto_fraction, "
            "migration_budget_score, compliance_pressure, risk_tolerance"
        ),
    )


class OrgOut(BaseModel):
    id: int
    name: str
    meta: Dict[str, str]
    metrics: Dict[str, float]


class PlanOut(BaseModel):
    profile_id: int
    name: str
    urgency_score: float
    track: str
    phases: List[str]
    reasons: List[str]


app = FastAPI(
    title="CipherNova Adaptive Post-Quantum Migration Brain",
    version="0.1.0",
    description="My engine for reasoning about when and how aggressively to migrate to post-quantum crypto.",
)


@app.post("/orgs", response_model=OrgOut)
def register_org(payload: OrgIn) -> OrgOut:
    prof: OrgProfile = brain.register_profile(
        name=payload.name,
        meta=payload.meta,
        metrics=payload.metrics,
    )
    return OrgOut(
        id=prof.id,
        name=prof.name,
        meta=prof.meta,
        metrics=prof.metrics,
    )


@app.post("/assess", response_model=PlanOut)
def assess(profile_id: int) -> PlanOut:
    if profile_id not in brain.profiles:
        raise HTTPException(status_code=404, detail="Organisation profile not found")
    plan: MigrationPlan = brain.assess(profile_id)
    return PlanOut(
        profile_id=plan.profile_id,
        name=plan.name,
        urgency_score=plan.urgency_score,
        track=plan.track,
        phases=plan.phases,
        reasons=plan.reasons,
    )
