
from dataclasses import dataclass
from typing import Dict, List


@dataclass
class OrgProfile:
    id: int
    name: str
    meta: Dict[str, str]
    metrics: Dict[str, float]


@dataclass
class MigrationPlan:
    profile_id: int
    name: str
    urgency_score: float
    track: str
    phases: List[str]
    reasons: List[str]


class CipherNovaBrain:
    """
    CipherNova is my reasoning engine for post-quantum migration.

    It does not choose specific algorithms for you. Instead it takes high level
    organisation metrics and turns them into a clear migration urgency score and
    a simple track: aggressive, balanced or conservative.
    """

    def __init__(self) -> None:
        self._next_id = 1
        self.profiles: Dict[int, OrgProfile] = {}

    def register_profile(self, name: str, meta: Dict[str, str], metrics: Dict[str, float]) -> OrgProfile:
        pid = self._next_id
        self._next_id += 1
        prof = OrgProfile(
            id=pid,
            name=name,
            meta=meta,
            metrics=metrics,
        )
        self.profiles[pid] = prof
        return prof

    def assess(self, profile_id: int) -> MigrationPlan:
        prof = self.profiles[profile_id]
        m = prof.metrics
        reasons: List[str] = []
        urgency = 0.0

        criticality = float(m.get("architecture_criticality", 0.0))
        legacy_fraction = float(m.get("legacy_crypto_fraction", 0.0))
        budget = float(m.get("migration_budget_score", 0.5))
        compliance = float(m.get("compliance_pressure", 0.0))
        risk_tol = float(m.get("risk_tolerance", 0.5))

        if criticality > 0.5:
            delta = (criticality - 0.5) * 30.0
            urgency += delta
            reasons.append("High criticality systems depend on current cryptography.")
        if legacy_fraction > 0.3:
            delta = (legacy_fraction - 0.3) * 40.0
            urgency += delta
            reasons.append("Large fraction of estate still on legacy crypto.")
        if compliance > 0.4:
            delta = (compliance - 0.4) * 35.0
            urgency += delta
            reasons.append("Incoming regulation or compliance pressure.")
        if risk_tol < 0.5:
            delta = (0.5 - risk_tol) * 25.0
            urgency += delta
            reasons.append("Low risk tolerance suggests earlier migration.")

        # Budget can slow things down a bit
        if budget < 0.4:
            urgency -= (0.4 - budget) * 20.0
            reasons.append("Limited budget will slow migration pace.")
        elif budget > 0.7:
            urgency += (budget - 0.7) * 10.0
            reasons.append("Healthy budget can support more aggressive migration.")

        urgency = max(0.0, min(100.0, urgency))

        if urgency >= 75.0:
            track = "aggressive"
            phases = [
                "Immediate crypto inventory and classification",
                "Dual stack classical + PQ in critical paths",
                "Retire legacy primitives on new deployments",
            ]
        elif urgency >= 45.0:
            track = "balanced"
            phases = [
                "Crypto inventory and risk mapping",
                "Pilot PQ in a subset of systems",
                "Rollout to high impact services first",
            ]
        else:
            track = "conservative"
            phases = [
                "Monitor standards and vendor roadmaps",
                "Add PQ readiness requirements to new projects",
                "Plan gradual migration windows",
            ]

        if not reasons:
            reasons.append("Metrics do not show strong immediate pressure for migration.")

        return MigrationPlan(
            profile_id=prof.id,
            name=prof.name,
            urgency_score=round(urgency, 2),
            track=track,
            phases=phases,
            reasons=reasons,
        )
