
# CipherNova Adaptive Post-Quantum Migration Brain

I built CipherNova as my brain for post-quantum migration decisions.

Instead of arguing in the air, I feed it simple metrics about an organisation:
how critical systems are, how much legacy crypto they use, how strong the
compliance pressure is, how much budget they have and how much risk they are
willing to accept.

CipherNova turns that into:
* a migration urgency score (0–100)
* a track: aggressive, balanced or conservative
* a short list of phases I can explain to anyone

## Run

```bash
cd backend
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn ciphernova_engine.main:app --reload --port 9921
```

Then open http://localhost:9921/docs and try registering an organisation and
calling `/assess`.
