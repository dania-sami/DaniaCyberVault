import argparse
import csv

def check(path: str):
    print(f"[+] Checking classifications in {path}\n")
    with open(path, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            res = row.get("resource", "")
            cls = (row.get("classification", "") or "").lower()
            grp = (row.get("access_group", "") or "").lower()

            issue = None
            if cls == "confidential" and "public" in grp:
                issue = "confidential data with public access group"
            elif cls == "internal" and "external" in grp:
                issue = "internal data with external group"
            if issue:
                print(f"    {res}: {issue} (classification={cls}, group={grp})")

def main():
    parser = argparse.ArgumentParser(description="Data Classification Tag Checker by Dania")
    parser.add_argument("--csv", required=True, help="CSV file with resource,classification,access_group")
    args = parser.parse_args()
    check(args.csv)

if __name__ == "__main__":
    main()
