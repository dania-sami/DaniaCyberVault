# Data Classification Tag Checker

This project is a small script I use to connect information security policy with something concrete.

It reads a CSV file with:

- `resource`
- `classification` (for example: public, internal, confidential)
- `access_group`

and flags simple mismatches, like:

- `confidential` data accessed by a `public` group
- `internal` data with an obviously external group

The rules in the script are intentionally small but they are enough to start a discussion about data classification and access control.

## Files

- `classification_checker.py` – main script
- `demo_classification.csv` – example data

## Usage

```bash
python classification_checker.py --csv demo_classification.csv
```
