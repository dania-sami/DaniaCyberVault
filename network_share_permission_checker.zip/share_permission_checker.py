import argparse
import csv

def check_shares(path: str):
    print(f"[+] Checking shares in {path}\n")
    with open(path, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            share = row.get("share", "")
            group = (row.get("group", "") or "").lower()
            perm = (row.get("permission", "") or "").lower()
            if "everyone" in group and ("write" in perm or "full" in perm):
                print(f"    {share}: group='{group}' has '{perm}' access (too broad)")

def main():
    parser = argparse.ArgumentParser(description="Network Share Permission Checker by Dania")
    parser.add_argument("--csv", required=True, help="CSV with share,group,permission")
    args = parser.parse_args()
    check_shares(args.csv)

if __name__ == "__main__":
    main()
