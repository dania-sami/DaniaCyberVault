# Network Share Permission Checker

This project is a small script I use to talk about basic file share hygiene.

It reads a CSV file with:

- `share`
- `group`
- `permission` (for example: read, write, full)

The script prints any shares where a very broad group like `Everyone` has write or full access.

## Files

- `share_permission_checker.py` – main script
- `demo_shares.csv` – example data

## Usage

```bash
python share_permission_checker.py --csv demo_shares.csv
```
