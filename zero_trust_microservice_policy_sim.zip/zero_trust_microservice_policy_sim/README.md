# Zero Trust Policy Simulator for Microservices

Hi, I am Dania 👋

This project is my **zero trust policy lab** for microservices:

- I define a tiny mesh of services and identities.
- Policies are written in a simple YAML format.
- I simulate service-to-service calls and show which are **allowed or blocked**.

It is a compact way to discuss **zero trust thinking** with something that actually runs.

## How to run

```bash
cd zero_trust_microservice_policy_sim

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt

# Use the sample policy and traffic
python -m src.simulate --policy data/policies.yaml
```

The simulator prints a table of requests with ALLOW / DENY decisions and reasons.
