from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path
from typing import List, Dict, Any

import yaml

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"


@dataclass
class Policy:
    subject: str
    action: str
    resource: str
    effect: str  # ALLOW / DENY


@dataclass
class Request:
    source: str
    target: str
    action: str
    context: Dict[str, Any]


def load_config(path: Path) -> Dict[str, Any]:
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def parse_policies(raw: List[Dict[str, Any]]) -> List[Policy]:
    policies: List[Policy] = []
    for p in raw:
        policies.append(
            Policy(
                subject=p["subject"],
                action=p.get("action", "call"),
                resource=p["resource"],
                effect=p.get("effect", "DENY").upper(),
            )
        )
    return policies


def parse_requests(raw: List[Dict[str, Any]]) -> List[Request]:
    reqs: List[Request] = []
    for r in raw:
        reqs.append(
            Request(
                source=r["source"],
                target=r["target"],
                action=r.get("action", "call"),
                context=r.get("context", {}),
            )
        )
    return reqs


def evaluate_request(req: Request, policies: List[Policy]) -> (str, str):
    # Very simple: first matching policy wins, default DENY
    for p in policies:
        if p.subject == req.source and p.resource == req.target and p.action == req.action:
            return p.effect, f"Matched policy: {p.subject} {p.action} {p.resource} -> {p.effect}"
    return "DENY", "No matching policy (default deny)"


def main() -> None:
    parser = argparse.ArgumentParser(description="Zero Trust microservice policy simulator")
    parser.add_argument("--policy", type=str, default=str(DATA_DIR / "policies.yaml"))
    args = parser.parse_args()

    cfg = load_config(Path(args.policy))
    policies = parse_policies(cfg.get("policies", []))
    requests = parse_requests(cfg.get("requests", []))

    print("Zero Trust Policy Simulator")
    print("===========================")
    print(f"Loaded {len(policies)} policies and {len(requests)} requests.\n")

    header = f"{'SOURCE':15} {'TARGET':15} {'ACTION':8} {'DECISION':8} REASON"
    print(header)
    print("-" * len(header))
    for req in requests:
        decision, reason = evaluate_request(req, policies)
        print(f"{req.source:15} {req.target:15} {req.action:8} {decision:8} {reason}")


if __name__ == "__main__":
    main()
