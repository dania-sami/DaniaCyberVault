import argparse, requests
from urllib.parse import urljoin

SEC = [
    "Content-Security-Policy", "X-Frame-Options",
    "X-Content-Type-Options", "Strict-Transport-Security"
]

PATHS = ["/admin", "/phpinfo.php", "/.git/"]

def scan(url):
    print("[+] Scanning", url)
    r = requests.get(url)
    print("\n[+] Security headers:")
    for h in SEC:
        print(h, ":", r.headers.get(h, "missing"))
    print("\n[+] Interesting paths:")
    for p in PATHS:
        try:
            x = requests.get(urljoin(url, p))
            print(p, "->", x.status_code)
        except:
            print(p, "-> error")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", required=True)
    a = ap.parse_args()
    scan(a.url)

if __name__ == "__main__":
    main()
