# Mini Vulnerability Scanner

A safe lightweight vulnerability scanner I made to check security headers and a few sensitive paths.
