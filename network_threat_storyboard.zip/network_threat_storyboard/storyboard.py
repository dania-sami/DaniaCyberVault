"""
Smart Network Threat Storyboard – Dania's attack narrative builder

Reads JSONL network flows
classifies them into simple threat steps
and builds a Markdown storyboard
"""

import argparse
import ipaddress
import json
from dataclasses import dataclass
from datetime import datetime
from typing import List, Dict, Tuple


@dataclass
class Flow:
    start: datetime
    end: datetime
    src_ip: str
    dst_ip: str
    src_port: int
    dst_port: int
    protocol: str
    bytes: int
    packets: int


@dataclass
class Step:
    actor: str
    kind: str
    start: datetime
    end: datetime
    description: str
    details: Dict[str, str]
    tactic: str


def parse_time(s: str) -> datetime:
    try:
        return datetime.fromisoformat(s)
    except Exception:
        # best effort
        return datetime.strptime(s, "%Y-%m-%dT%H:%M:%S")


def load_flows(path: str) -> List[Flow]:
    flows: List[Flow] = []
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue
            try:
                flow = Flow(
                    start=parse_time(obj["start"]),
                    end=parse_time(obj["end"]),
                    src_ip=str(obj["src_ip"]),
                    dst_ip=str(obj["dst_ip"]),
                    src_port=int(obj.get("src_port", 0)),
                    dst_port=int(obj.get("dst_port", 0)),
                    protocol=str(obj.get("protocol", "tcp")).lower(),
                    bytes=int(obj.get("bytes", 0)),
                    packets=int(obj.get("packets", 0)),
                )
                flows.append(flow)
            except Exception:
                continue
    flows.sort(key=lambda f: f.start)
    return flows


def is_internal(ip: str) -> bool:
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return False
    return addr.is_private


def detect_scan(flows: List[Flow]) -> List[Step]:
    steps: List[Step] = []
    from collections import defaultdict

    by_src_dst: Dict[Tuple[str, str], List[Flow]] = defaultdict(list)
    for f in flows:
        by_src_dst[(f.src_ip, f.dst_ip)].append(f)

    for (src, dst), fs in by_src_dst.items():
        if not is_internal(src):
            continue
        if not is_internal(dst):
            continue
        ports = {f.dst_port for f in fs}
        # simple heuristic number of ports and small bytes
        if len(ports) >= 5 and all(f.bytes < 5000 for f in fs):
            start = min(f.start for f in fs)
            end = max(f.end for f in fs)
            desc = f"{src} appears to be scanning {dst} on {len(ports)} different ports."
            steps.append(
                Step(
                    actor=src,
                    kind="SCAN",
                    start=start,
                    end=end,
                    description=desc,
                    details={"target": dst, "port_count": str(len(ports))},
                    tactic="Discovery: Network Service Scanning",
                )
            )
    return steps


def detect_lateral(flows: List[Flow]) -> List[Step]:
    steps: List[Step] = []
    lateral_ports = {22, 3389, 445}
    for f in flows:
        if not (is_internal(f.src_ip) and is_internal(f.dst_ip)):
            continue
        if f.dst_port not in lateral_ports:
            continue
        desc = f"Possible lateral movement from {f.src_ip} to {f.dst_ip} on port {f.dst_port}."
        steps.append(
            Step(
                actor=f.src_ip,
                kind="LATERAL_MOVEMENT",
                start=f.start,
                end=f.end,
                description=desc,
                details={"dst": f.dst_ip, "port": str(f.dst_port)},
                tactic="Lateral Movement: Remote Services",
            )
        )
    return steps


def detect_exfil(flows: List[Flow], bytes_threshold: int = 1000000) -> List[Step]:
    steps: List[Step] = []
    from collections import defaultdict

    by_src_dst: Dict[Tuple[str, str], List[Flow]] = defaultdict(list)
    for f in flows:
        by_src_dst[(f.src_ip, f.dst_ip)].append(f)

    for (src, dst), fs in by_src_dst.items():
        if not is_internal(src):
            continue
        if is_internal(dst):
            continue
        total_bytes = sum(f.bytes for f in fs)
        if total_bytes < bytes_threshold:
            continue
        start = min(f.start for f in fs)
        end = max(f.end for f in fs)
        desc = f"Large data transfer from {src} to external host {dst} (~{total_bytes} bytes)."
        steps.append(
            Step(
                actor=src,
                kind="EXFILTRATION",
                start=start,
                end=end,
                description=desc,
                details={"dst": dst, "bytes": str(total_bytes)},
                tactic="Exfiltration: Exfiltration Over Web Services",
            )
        )
    return steps


def build_storyboard(flows: List[Flow]) -> List[Step]:
    steps: List[Step] = []
    steps.extend(detect_scan(flows))
    steps.extend(detect_lateral(flows))
    steps.extend(detect_exfil(flows))
    steps.sort(key=lambda s: (s.actor, s.start))
    return steps


def write_markdown(steps: List[Step], flows: List[Flow], out_path: str) -> None:
    actors = sorted({s.actor for s in steps})
    with open(out_path, "w", encoding="utf-8") as f:
        f.write("# Network threat storyboard\n\n")
        f.write(f"Total flows: {len(flows)}\n\n")
        if not steps:
            f.write("No suspicious patterns detected with the current heuristics.\n")
            return

        f.write(f"Detected {len(steps)} potential threat steps across {len(actors)} actor(s).\n\n")
        for actor in actors:
            f.write(f"## Actor {actor}\n\n")
            actor_steps = [s for s in steps if s.actor == actor]
            for s in actor_steps:
                f.write(f"### {s.kind}  ({s.start.isoformat()} – {s.end.isoformat()})\n\n")
                f.write(f"* Tactic: {s.tactic}\n")
                for k, v in s.details.items():
                    f.write(f"* {k}: `{v}`\n")
                f.write("\n")
                f.write(s.description + "\n\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's smart network threat storyboard builder")
    parser.add_argument(
        "--flows",
        required=True,
        help="Path to a JSONL file with flow records.",
    )
    parser.add_argument(
        "--out",
        default="storyboard.md",
        help="Output Markdown file path (default: storyboard.md).",
    )
    args = parser.parse_args()

    flows = load_flows(args.flows)
    steps = build_storyboard(flows)
    write_markdown(steps, flows, args.out)
    print(f"Wrote storyboard with {len(steps)} steps to {args.out}")


if __name__ == "__main__":
    main()
