# Smart Network Threat Storyboard – Dania’s Attack Narrative Builder

Hi

I am Dania and this project is my way of turning raw network data into stories

Most packet captures and flow logs are very low level
You get endless lines of src_ip dst_ip ports and bytes
but what you really want is a short narrative like

An attacker scanned the web server
then moved laterally to the database
then exfiltrated data out to the internet

So this tool reads simple flow records
classifies activity into a few categories
and writes a Markdown storyboard that I can read like a mini incident report

## Data format

To keep things lightweight I use a JSON lines format for flows

Each line is one flow with fields like

{
  "start": "2025-10-01T10:00:01",
  "end": "2025-10-01T10:00:06",
  "src_ip": "10.0.0.5",
  "dst_ip": "10.0.0.10",
  "src_port": 51500,
  "dst_port": 22,
  "protocol": "tcp",
  "bytes": 2048,
  "packets": 10
}

You can export something similar from tools like Zeek
NetFlow exporters or custom scripts

For the demo I included

examples_flows_sample.jsonl

with a tiny scenario containing

* a scan phase
* a lateral movement step
* an exfiltration flow

## How the classification works (simple on purpose)

I keep it small and interpretable

* I treat RFC1918 addresses as internal
* I treat everything else as external

Then I build some simple detectors

* Scan
  * one internal host hits many dst_ports on the same target
  * each flow is small in bytes and packets
* Lateral movement
  * flows between internal hosts on typical admin ports
    such as 22, 3389, 445
* Data exfiltration
  * an internal host sends a large amount of data to an external host
  * especially on ports like 443 or 80

From these detectors I build a set of steps
and then group them into a storyboard per suspected attacker

The output is not perfect truth
It is a human friendly hypothesis that an analyst can start from

## How I run it

1 Optional create and activate a virtual environment

   python3 -m venv venv
   source venv_bin_activate

2 Install requirements

   pip install -r requirements.txt

   This just confirms that only the standard library is used

3 Run the storyboard builder on the sample flows

   python storyboard.py \
       --flows examples_flows_sample.jsonl \
       --out storyboard.md

4 Open storyboard.md

You will see something like

* Overview with how many flows and how many actors
* One section per suspected actor IP
* Within each section a sequence of steps
  * SCAN / LATERAL_MOVEMENT / EXFILTRATION
  * time windows
  * short descriptions
  * rough ATTandCK style labels

## Why I built this

I love the idea of taking very technical low level data
and turning it into something a non specialist can understand

With this project I can show that I

* understand basic network flow concepts
* can build simple classification logic for scan lateral movement and exfiltration
* know how to map technical events to rough ATTandCK style tactics
* can present results in a narrative format instead of just a table

It is not a replacement for a full NDR solution
but it is a nice little project to discuss during security interviews

