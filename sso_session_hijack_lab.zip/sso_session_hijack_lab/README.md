# Single Sign-On Session Hijack Lab (Safe)

Hi, I am Dania 👋

This project is my **SSO session hijack lab** in a safe, simulated form:

- I model an IdP and two relying-party apps behind SSO.
- Each app has cookie settings (Secure, HttpOnly, SameSite, domain).
- I run simple scenarios like mixed-content and shared-cookie domains
  to see if an attacker could reuse or fixate a session id.

It is a clean way to talk about **SSO session risks** without any real traffic.

## How to run

```bash
cd sso_session_hijack_lab

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt   # stdlib only

python -m src.simulate --config data/sso_config.json
```

The simulator prints each scenario and whether a hijack looks possible.
