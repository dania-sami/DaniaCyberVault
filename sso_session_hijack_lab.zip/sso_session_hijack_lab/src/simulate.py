from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import List, Dict, Any


@dataclass
class CookieConfig:
    name: str
    domain: str
    secure: bool
    http_only: bool
    same_site: str  # None, Lax, Strict


@dataclass
class AppConfig:
    name: str
    cookie: CookieConfig


@dataclass
class Scenario:
    id: str
    description: str
    victim_app: str
    attacker_origin: str
    mixed_content: bool
    network_sniffing: bool


def load_config(path: Path):
    raw = json.loads(path.read_text(encoding="utf-8"))
    apps: Dict[str, AppConfig] = {}
    for a in raw.get("apps", []):
        c = a["cookie"]
        cookie = CookieConfig(
            name=c["name"],
            domain=c["domain"],
            secure=bool(c["secure"]),
            http_only=bool(c["http_only"]),
            same_site=str(c.get("same_site", "Lax")),
        )
        apps[a["name"]] = AppConfig(name=a["name"], cookie=cookie)

    scenarios: List[Scenario] = []
    for s in raw.get("scenarios", []):
        scenarios.append(
            Scenario(
                id=s["id"],
                description=s["description"],
                victim_app=s["victim_app"],
                attacker_origin=s["attacker_origin"],
                mixed_content=bool(s.get("mixed_content", False)),
                network_sniffing=bool(s.get("network_sniffing", False)),
            )
        )
    return apps, scenarios


def evaluate_scenario(app: AppConfig, sc: Scenario) -> str:
    c = app.cookie
    reasons = []

    if not c.secure and sc.network_sniffing:
        reasons.append("cookie is not Secure and traffic is sniffable (session id could be stolen).")

    if c.domain.startswith(".") and sc.attacker_origin.endswith(c.domain.lstrip(".")):
        reasons.append("cookie domain covers attacker origin (shared cookies across apps).")

    if c.same_site.lower() == "none":
        reasons.append("SameSite=None allows full cross-site cookie sending.")
    elif c.same_site.lower() == "lax" and sc.mixed_content:
        reasons.append("SameSite=Lax plus mixed-content may allow more cross-site exposure.")

    if not reasons:
        return "LOW – hijack unlikely in this simplified model."

    if any("not Secure" in r for r in reasons) and any("covers attacker origin" in r for r in reasons):
        return "HIGH – attacker on sibling domain can reuse sniffed session cookie."
    if any("not Secure" in r for r in reasons) or any("SameSite=None" in r for r in reasons):
        return "MEDIUM – session cookie is easier to abuse."
    return "LOW – minor issues only."


def main() -> None:
    parser = argparse.ArgumentParser(description="SSO Session Hijack Lab (safe simulator)")
    parser.add_argument("--config", type=str, required=True, help="Path to sso_config.json")
    args = parser.parse_args()

    apps, scenarios = load_config(Path(args.config))

    print("SSO Session Hijack Lab")
    print("======================\n")
    for sc in scenarios:
        app = apps[sc.victim_app]
        verdict = evaluate_scenario(app, sc)
        print(f"Scenario {sc.id}: {sc.description}")
        print(f"  victim_app={sc.victim_app}, attacker_origin={sc.attacker_origin}")
        print(f"  cookie: domain={app.cookie.domain}, Secure={app.cookie.secure}, "
              f"HttpOnly={app.cookie.http_only}, SameSite={app.cookie.same_site}")
        print(f"  mixed_content={sc.mixed_content}, network_sniffing={sc.network_sniffing}")
        print(f"  verdict={verdict}")
        print()


if __name__ == "__main__":
    main()
