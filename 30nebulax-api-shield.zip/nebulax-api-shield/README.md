
# NebulaX API Shield

NebulaX API Shield is my light weight experiment in behavioural protection for APIs.

Instead of building a full blown WAFF style product I focus on one clear idea
learn what looks normal for each client and endpoint and then score requests
that deviate strongly from that pattern.

In this prototype I focus on request body size as the main signal. It is simple
but still very useful when thinking about things like data exfiltration or
unexpected payloads.

## What NebulaX does

* tracks average request size per client id plus HTTP method plus path
* learns from the first requests and builds a profile
* when enough history exists it calculates how far a new request is from typical size
* returns a score and a decision whether the request would be allowed or flagged

The logic is intentionally easy to read so that I can discuss it in detail and
extend it with more features such as rate or header patterns later.

## Project layout

```text
nebulax-api-shield
└── backend
    ├── nebulax_shield
    │   ├── __init__.py
    │   ├── engine.py  Behaviour profiling and anomaly scoring
    │   └── main.py    FastAPI endpoints
    ├── requirements.txt
    └── example_requests.http
```

## How I run it locally

From the backend folder

```bash
python -m venv .venv
source .venv/bin/activate        # On Windows I use .venv\Scripts\activate
pip install -r requirements.txt
uvicorn nebulax_shield.main:app --reload --port 9302
```

Then I open

* http://localhost:9302/docs to play with the inspect endpoint

## Typical flow I use

First I send a series of normal looking requests from a client to an endpoint.
This teaches the shield what typical size looks like.

```bash
curl -X POST http://localhost:9302/inspect   -H "Content-Type: application/json"   -d '{
    "client_id": "frontend-service",
    "path": "/api/orders",
    "method": "POST",
    "size": 1100
  }'
```

After I have sent similar requests around ten times the profile stabilises.
Then I send a huge request to simulate a data dump or unexpected payload.

```bash
curl -X POST http://localhost:9302/inspect   -H "Content-Type: application/json"   -d '{
    "client_id": "frontend-service",
    "path": "/api/orders",
    "method": "POST",
    "size": 500000
  }'
```

The service responds with a high anomaly score and marks the request as not
allowed. I can still choose how to act on this decision but the model has done
its part.

I can also inspect all learned profiles.

```bash
curl http://localhost:9302/profiles
```

This gives me a compact view of which client endpoint pairs are most active
and what their typical sizes are.

## Why I like this project

NebulaX gives me a concrete way to talk about statistical learning for APIs
without going into heavy machine learning frameworks. The core concept fits in
one file, and I can extend it gradually with new features like

* tracking request rates
* learning header or method distributions
* introducing thresholds per endpoint

It is a nice bridge between security engineering and data driven thinking.
