
from dataclasses import dataclass
from typing import Dict, List
from datetime import datetime


@dataclass
class RequestProfile:
    count: int = 0
    total_size: int = 0
    last_seen: datetime | None = None

    @property
    def avg_size(self) -> float:
        if self.count == 0:
            return 0.0
        return self.total_size / self.count


@dataclass
class RequestEvent:
    timestamp: datetime
    client_id: str
    path: str
    method: str
    size: int


@dataclass
class AnomalyDecision:
    allowed: bool
    score: float
    reasons: List[str]


class ApiShieldBrain:
    """
    This is my small API behaviour profiler.

    It learns normal body sizes per client and endpoint and then scores
    new requests based on how far they are from the usual pattern.
    """

    def __init__(self) -> None:
        self.profiles: Dict[str, RequestProfile] = {}
        self.history: List[RequestEvent] = []

    def _key(self, client_id: str, path: str, method: str) -> str:
        return f"{client_id}|{method.upper()}|{path}"

    def observe(self, client_id: str, path: str, method: str, size: int) -> AnomalyDecision:
        now = datetime.utcnow()
        key = self._key(client_id, path, method)
        prof = self.profiles.get(key)
        if not prof:
            prof = RequestProfile()
            self.profiles[key] = prof

        # Before updating we calculate how unusual this looks based on the previous profile
        reasons: List[str] = []
        score = 0.0

        if prof.count >= 10:
            avg = prof.avg_size
            diff = abs(size - avg)
            relative = diff / (avg + 1.0)
            if relative > 2.0:
                score = min(100.0, relative * 40.0)
                reasons.append(f"Request size {size} is far from typical size {int(avg)} for this client endpoint pair.")
        else:
            reasons.append("Not enough history yet, treating request as learning data.")

        allowed = score < 70.0

        prof.count += 1
        prof.total_size += size
        prof.last_seen = now

        self.history.append(
            RequestEvent(
                timestamp=now,
                client_id=client_id,
                path=path,
                method=method,
                size=size,
            )
        )

        return AnomalyDecision(
            allowed=allowed,
            score=float(round(score, 2)),
            reasons=reasons or ["No anomaly indicators were triggered."],
        )

    def stats(self) -> Dict[str, RequestProfile]:
        return self.profiles
