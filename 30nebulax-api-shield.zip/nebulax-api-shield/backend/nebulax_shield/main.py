
from fastapi import FastAPI
from pydantic import BaseModel, Field
from typing import Dict, List

from .engine import ApiShieldBrain, RequestProfile, AnomalyDecision


brain = ApiShieldBrain()


class RequestIn(BaseModel):
    client_id: str = Field(..., example="frontend-service")
    path: str = Field(..., example="/api/orders")
    method: str = Field(..., example="POST")
    size: int = Field(..., example=1024, ge=0)


class DecisionOut(BaseModel):
    allowed: bool
    score: float
    reasons: List[str]


class ProfileOut(BaseModel):
    key: str
    count: int
    avg_size: float
    last_seen: str | None


app = FastAPI(
    title="NebulaX API Shield",
    version="0.1.0",
    description="My API behaviour profiler that scores unusual requests.",
)


@app.post("/inspect", response_model=DecisionOut)
def inspect(payload: RequestIn) -> DecisionOut:
    decision: AnomalyDecision = brain.observe(
        client_id=payload.client_id,
        path=payload.path,
        method=payload.method,
        size=payload.size,
    )
    return DecisionOut(
        allowed=decision.allowed,
        score=decision.score,
        reasons=decision.reasons,
    )


@app.get("/profiles", response_model=List[ProfileOut])
def profiles() -> List[ProfileOut]:
    out: List[ProfileOut] = []
    for key, prof in brain.stats().items():
        out.append(
            ProfileOut(
                key=key,
                count=prof.count,
                avg_size=prof.avg_size,
                last_seen=prof.last_seen.isoformat() + "Z" if prof.last_seen else None,
            )
        )
    return out
