import argparse
import csv

def prioritise(path: str):
    risks = []
    with open(path, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            try:
                likelihood = int(row.get("likelihood", "0"))
                impact = int(row.get("impact", "0"))
            except ValueError:
                continue
            score = likelihood * impact
            risks.append((score, row))

    risks.sort(key=lambda x: x[0], reverse=True)
    print(f"[+] Risks in {path} by priority:\n")
    for score, row in risks:
        rid = row.get("id", "")
        desc = row.get("description", "")
        print(f"    {rid:5s} score={score:2d}  {desc}")

def main():
    parser = argparse.ArgumentParser(description="Risk Register Prioritizer by Dania")
    parser.add_argument("--csv", required=True, help="Path to CSV risk register")
    args = parser.parse_args()
    prioritise(args.csv)

if __name__ == "__main__":
    main()
