# Risk Register Prioritizer

This project is my simple way of working with a risk register from the command line.

It reads a CSV file with:

- `id`
- `description`
- `likelihood` (1–5)
- `impact` (1–5)

The script computes a simple risk score (`likelihood * impact`) and prints the risks sorted from highest to lowest.

## Files

- `risk_prioritizer.py` – main script
- `demo_risks.csv` – example risks

## Usage

```bash
python risk_prioritizer.py --csv demo_risks.csv
```
