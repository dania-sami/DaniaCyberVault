from __future__ import annotations

from dataclasses import dataclass
from typing import List


@dataclass
class Device:
    name: str
    supports_encryption: bool
    legacy_pairing: bool
    uses_static_pin: bool
    allows_just_works: bool


def get_simulated_devices() -> List[Device]:
    return [
        Device(
            name="Smart Lock v1",
            supports_encryption=True,
            legacy_pairing=True,
            uses_static_pin=True,
            allows_just_works=False,
        ),
        Device(
            name="Fitness Band Lite",
            supports_encryption=False,
            legacy_pairing=True,
            uses_static_pin=False,
            allows_just_works=True,
        ),
        Device(
            name="Industrial Sensor Pro",
            supports_encryption=True,
            legacy_pairing=False,
            uses_static_pin=False,
            allows_just_works=False,
        ),
        Device(
            name="Smart Speaker Mini",
            supports_encryption=True,
            legacy_pairing=True,
            uses_static_pin=False,
            allows_just_works=True,
        ),
    ]
