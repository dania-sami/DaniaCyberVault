from __future__ import annotations

from typing import List, Tuple

from .devices import get_simulated_devices, Device


def assess_device(dev: Device) -> Tuple[str, List[str]]:
    reasons: List[str] = []
    risk = "LOW"

    if not dev.supports_encryption:
        risk = "HIGH"
        reasons.append("Does not support encryption.")
    if dev.legacy_pairing and dev.uses_static_pin:
        if risk != "HIGH":
            risk = "MEDIUM"
        reasons.append("Uses legacy pairing with static PIN.")
    if dev.allows_just_works:
        if risk == "LOW":
            risk = "WARN"
        reasons.append("Allows 'just works' pairing without authentication.")

    if not reasons:
        reasons.append("No obvious issues in this simple model.")
    return risk, reasons


def main() -> None:
    devices = get_simulated_devices()
    print("Simulated Bluetooth Security Scan")
    print("=" * 40)
    for dev in devices:
        risk, reasons = assess_device(dev)
        print(f"Device: {dev.name}")
        print(f"  Risk: {risk}")
        for r in reasons:
            print(f"   - {r}")
        print()


if __name__ == "__main__":
    main()
