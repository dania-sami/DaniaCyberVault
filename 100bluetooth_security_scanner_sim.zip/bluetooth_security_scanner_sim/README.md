# Bluetooth Security Scanner (Simulation)

Hi, I am Dania Sami 👋

Real Bluetooth security testing often requires specialised hardware and
careful handling. For my portfolio I wanted something that is **safe,
local and still educational**.

This project is a **simulated Bluetooth Low Energy (BLE) security scanner**:

- it uses an in-memory list of "devices" with properties
- applies simple rules to flag insecure configurations
- prints a small report per device

The goal is to show how I think about **BLE security properties**, not
to interact with real hardware.

---

## What this project does

1. **Defines simulated devices**

   In `src/devices.py` I define a few fake BLE devices with fields like:

   - `name`
   - `supports_encryption`
   - `legacy_pairing`
   - `uses_static_pin`
   - `allows_just_works`

2. **Runs security checks**

   `src/scan.py` applies simple rules, for example:

   - devices that do not support encryption are `HIGH` risk
   - devices that use legacy pairing with a static PIN are `MEDIUM` risk
   - devices that allow "just works" pairing are `WARN` level

3. **Prints a table-like report**

   It prints each device with its risk level and the reasons.

---

## How to run

```bash
cd bluetooth_security_scanner_sim

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt   # stdlib only, this is instant

python -m src.scan
```

---

## Project structure

```text
bluetooth_security_scanner_sim/
  ├─ README.md
  ├─ requirements.txt
  └─ src/
       ├─ __init__.py
       ├─ devices.py
       └─ scan.py
```

---

## Why I built this

Even simple simulations can show a lot about how a person thinks.
Here I demonstrate:

- knowledge of BLE security concepts
- ability to encode them into rules
- clean, explainable output that would make sense to engineers and auditors
