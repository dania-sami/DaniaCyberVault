# Log Retention Policy Checker

This project is a small helper script for talking about log retention from a governance and security perspective.

It reads a JSON file with systems and their configured log retention, for example:

```json
{
  "web": 30,
  "db": 90,
  "vpn": 7
}
```

Given a minimum required retention in days, the script prints which systems meet the threshold and which do not.

## Files

- `log_retention_checker.py` – main script
- `log_retention_example.json` – example configuration

## Usage

```bash
python log_retention_checker.py --config log_retention_example.json --min-days 30
```
