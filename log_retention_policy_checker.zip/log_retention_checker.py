import argparse
import json

def check(cfg_path: str, min_days: int):
    with open(cfg_path) as f:
        data = json.load(f)

    print(f"[+] Log retention check (min {min_days} days):\n")
    for system, days in data.items():
        status = "ok" if days >= min_days else "too low"
        print(f"    {system:10s} -> {days:3d} days ({status})")

def main():
    parser = argparse.ArgumentParser(description="Log Retention Policy Checker by Dania")
    parser.add_argument("--config", required=True, help="JSON file with system: days mapping")
    parser.add_argument("--min-days", type=int, required=True, help="Minimum required retention in days")
    args = parser.parse_args()
    check(args.config, args.min_days)

if __name__ == "__main__":
    main()
