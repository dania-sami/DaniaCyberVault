
from dataclasses import dataclass
from typing import Dict, List, Literal, Tuple

Channel = Literal["browser", "email", "desktop"]


@dataclass
class CoachingResult:
    risk_score: float              # 0.0 to 1.0
    label: str                     # "low", "medium", "high"
    should_block: bool
    nudges: List[str]              # Short coaching messages
    hints: List[str]               # Extra context / learning


SUSPICIOUS_KEYWORDS = [
    "urgent",
    "immediately",
    "password",
    "verify your account",
    "click this link",
    "unusual activity",
    "update your details",
]

HIGH_RISK_DOMAINS = [
    "http://",
    "https://short.ly",
    "bit.ly",
    "tinyurl.com",
]

TRUSTED_DOMAINS = [
    "kth.se",
    "github.com",
    "microsoft.com",
    "google.com",
]


def _base_risk_from_channel(channel: Channel) -> float:
    if channel == "email":
        return 0.25
    if channel == "browser":
        return 0.2
    if channel == "desktop":
        return 0.15
    return 0.2


def _text_features(text: str) -> Tuple[float, List[str]]:
    """Very simple keyword based scoring for the prototype."""
    text_lower = text.lower()
    score = 0.0
    hits: List[str] = []

    for kw in SUSPICIOUS_KEYWORDS:
        if kw in text_lower:
            score += 0.12
            hits.append(f'Keyword "{kw}" detected')

    # Password or MFA mention gets extra attention
    if "password" in text_lower or "one-time code" in text_lower or "otp" in text_lower:
        score += 0.15

    return min(score, 0.8), hits


def _url_features(url: str) -> Tuple[float, List[str]]:
    score = 0.0
    hits: List[str] = []
    url_lower = url.lower()

    for dom in HIGH_RISK_DOMAINS:
        if dom in url_lower:
            score += 0.2
            hits.append(f"Suspicious domain pattern: {dom}")

    # Brand impersonation: login page with brand name but wrong domain
    brand_words = ["microsoft", "google", "apple", "kth"]
    if any(word in url_lower for word in brand_words) and not any(
        trusted in url_lower for trusted in TRUSTED_DOMAINS
    ):
        score += 0.25
        hits.append("Brand mention on non trusted domain")

    if url_lower.startswith("http://"):
        score += 0.15
        hits.append("Connection is not using HTTPS")

    return min(score, 0.9), hits


def assess_and_coach(event: Dict) -> CoachingResult:
    """Main entry point: take an event dict and produce coaching."""
    channel: Channel = event.get("channel", "browser")  # type: ignore
    url = event.get("url", "") or ""
    text = event.get("text", "") or ""
    claimed_risk = event.get("claimed_risk", "medium")

    base = _base_risk_from_channel(channel)
    text_score, text_hits = _text_features(text)
    url_score, url_hits = _url_features(url)

    risk_score = min(1.0, base + text_score + url_score)

    # If caller claims high risk, lean a bit higher
    if claimed_risk == "high":
        risk_score = min(1.0, risk_score + 0.1)

    if risk_score < 0.3:
        label = "low"
    elif risk_score < 0.6:
        label = "medium"
    else:
        label = "high"

    should_block = risk_score >= 0.8

    nudges: List[str] = []
    hints: List[str] = []

    if label == "low":
        nudges.append("Looks safe, but keep your usual awareness.")
    elif label == "medium":
        nudges.append("Take a breath and double check before you click anything here.")
        hints.append("Ask yourself: was I expecting this message or link from this sender now?")
    else:
        nudges.append("This looks risky. Do not enter passwords until you are absolutely sure.")
        hints.append("Verify the sender through a separate known channel before acting.")
        if "password" in text.lower():
            hints.append("Legitimate services almost never ask for your password via email.")

    # Add feature specific hints
    for hit in text_hits + url_hits:
        hints.append(hit)

    return CoachingResult(
        risk_score=float(round(risk_score, 3)),
        label=label,
        should_block=should_block,
        nudges=nudges,
        hints=hints,
    )
