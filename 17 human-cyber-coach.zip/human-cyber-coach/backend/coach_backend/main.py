
from fastapi import FastAPI
from pydantic import BaseModel, HttpUrl
from typing import Optional, List, Literal

from .engine import assess_and_coach, CoachingResult


Channel = Literal["browser", "email", "desktop"]


class Event(BaseModel):
    user_id: str
    channel: Channel
    url: Optional[HttpUrl] = None
    text: Optional[str] = None
    claimed_risk: Literal["low", "medium", "high"] = "medium"


class CoachingResponse(BaseModel):
    risk_score: float
    label: Literal["low", "medium", "high"]
    should_block: bool
    nudges: List[str]
    hints: List[str]


app = FastAPI(
    title="Human Cyber Coach",
    version="0.1.0",
    description="Real-time micro-coaching API for human cyber security decisions.",
)


@app.post("/event", response_model=CoachingResponse)
def handle_event(event: Event) -> CoachingResponse:
    """Receive a user interaction event and return micro-coaching."""
    result: CoachingResult = assess_and_coach(event.dict())

    return CoachingResponse(
        risk_score=result.risk_score,
        label=result.label,
        should_block=result.should_block,
        nudges=result.nudges,
        hints=result.hints,
    )
