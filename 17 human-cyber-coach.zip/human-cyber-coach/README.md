
# Human Cyber Coach

Real time **micro coaching for cyber security**, designed to sit quietly beside a human
and whisper the right thing just before they click on something risky.

This project has two pieces:

1. **Backend coach API** (FastAPI on port 9000)  
   Takes a description of what the user is doing (URL + text) and returns:
   - a risk score
   - a friendly coaching nudge
   - a few short hints to build long term intuition

2. **Browser extension (Chrome Manifest v3)**  
   Observes pages the user visits, sends lightweight events to the backend and shows a small
   floating “coach bubble” when something looks risky.

It is intentionally small but opinionated, so you can extend it into a serious human centric
cyber defence project or a portfolio piece.

---

## 1. Backend coach API

### Setup

```bash
cd backend
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### Run

```bash
uvicorn coach_backend.main:app --reload --port 9000
```

The API will be live at `http://localhost:9000`.

- Swagger UI: `http://localhost:9000/docs`
- ReDoc: `http://localhost:9000/redoc`

### Example request

You can use `example_events.http` or plain curl:

```bash
curl -X POST http://localhost:9000/event       -H "Content-Type: application/json"       -d '{
    "user_id": "user-123",
    "channel": "email",
    "url": "https://accounts-secure-update.com/login",
    "text": "We detected unusual activity, please verify your account immediately by entering your password.",
    "claimed_risk": "medium"
  }'
```

Example response:

```json
{
  "risk_score": 0.84,
  "label": "high",
  "should_block": true,
  "nudges": [
    "This looks risky. Do not enter passwords until you are absolutely sure."
  ],
  "hints": [
    "Verify the sender through a separate known channel before acting.",
    "Legitimate services almost never ask for your password via email.",
    "Keyword \"urgent\" detected",
    "Keyword \"password\" detected",
    "Brand mention on non trusted domain"
  ]
}
```

---

## 2. Browser extension (Chrome)

This is a minimal Manifest v3 extension that:

- Watches the current page
- Extracts a short text snippet
- Guesses a rough risk level
- Sends an event to `http://localhost:9000/event`
- Shows a soft **coach bubble** in the corner with nudges and hints

### Loading the extension

1. Open Chrome and go to `chrome://extensions/`  
2. Turn on **Developer mode** (top right)  
3. Click **“Load unpacked”**  
4. Select the `extension` folder from this project  

Make sure your backend is running on `http://localhost:9000` before testing.

### How it behaves

- On every page load (and URL change), the content script:
  - Collects the first 500 characters of body text
  - Computes a quick guess of the risk (e.g. if it sees the word “password” it treats it as high)
  - Sends that to the background service worker
- The background script POSTs the event to the backend API
- When the response arrives, the content script renders a **floating coaching bubble** like:

  > Cyber coach: HIGH RISK (84%)  
  > This looks risky. Do not enter passwords until you are absolutely sure.  
  > • Keyword "urgent" detected  
  > • Brand mention on non trusted domain

The bubble is intentionally small, dismissible, and uses soft language so it feels like a coach
instead of a nagging popup.

---

## 3. Project layout

```text
human-cyber-coach/
├── backend/
│   ├── coach_backend/
│   │   ├── __init__.py
│   │   ├── engine.py          # Risk scoring + coaching logic
│   │   └── main.py            # FastAPI app with /event endpoint
│   ├── example_events.http    # Ready-to-use HTTP examples
│   └── requirements.txt
└── extension/
    ├── manifest.json          # Chrome Manifest v3
    ├── background.js          # Talks to backend API
    ├── contentScript.js       # Injected into pages, shows bubble
    ├── icon16.png             # Placeholder icons (replace for production)
    ├── icon48.png
    └── icon128.png
```

---

## 4. How to extend this into something insane

This repository is deliberately simple, but the concept scales very far:

1. **Personalised coaching profiles**
   - Track which nudges work for a given user (for example, which ones reduce risky clicks)
   - Adapt tone and length automatically per user
   - Store this in a privacy respecting way (e.g. hashed user IDs, local first analytics)

2. **Integration with email and desktop apps**
   - Add a small email add in or hook into a mail gateway
   - Add a lightweight desktop agent to watch for risky file opens, USB usage, etc.

3. **Behaviour analytics backend**
   - Time series of risk scores and user decisions
   - Measure “time since last risky click” as a health metric
   - Use this as a human centric security KPI instead of only technical ones

4. **Policy aware coaching**
   - Read the organisation’s security policy and incorporate it into the hints
   - Example: “Your organisation’s policy says you should never approve payments via email alone.”

5. **A B testing of coaching styles**
   - Randomly try different micro messages (short vs explanatory vs visual)
   - Learn which style actually reduces incidents per user group

---

## 5. Why this is a strong cyber security project

Most security tooling focuses on infrastructure, logs and malware.

This project is about the **person** at the keyboard:

- Real time feedback **before** damage happens
- Short, psychologically aware coaching instead of boring training modules
- Clear architecture that can be extended with real ML models, analytics and org policies

Use this as your starting point and show that you are not just thinking about firewalls and logs,
but about the last line of defence: the human.
