
// contentScript.js
// Watches for navigation to potential login / important pages
// and asks the backend coach for micro feedback.

function extractSnippet() {
  const bodyText = document.body.innerText || "";
  return bodyText.slice(0, 500);
}

function guessRiskLevel() {
  const text = extractSnippet().toLowerCase();
  if (text.includes("password") || text.includes("verify your account")) {
    return "high";
  }
  return "medium";
}

function sendEventToCoach() {
  chrome.runtime.sendMessage(
    {
      type: "HUMAN_CYBER_EVENT",
      url: window.location.href,
      textSnippet: extractSnippet(),
      claimedRisk: guessRiskLevel()
    },
    (response) => {
      if (!response || !response.ok) {
        return;
      }
      const coach = response.coach;
      if (!coach) return;

      // Minimal UI: small floating bubble in the corner.
      showCoachBubble(coach);
    }
  );
}

function showCoachBubble(coach) {
  const existing = document.getElementById("human-cyber-coach-bubble");
  if (existing) {
    existing.remove();
  }

  const bubble = document.createElement("div");
  bubble.id = "human-cyber-coach-bubble";
  bubble.style.position = "fixed";
  bubble.style.bottom = "16px";
  bubble.style.right = "16px";
  bubble.style.maxWidth = "320px";
  bubble.style.zIndex = "2147483647";
  bubble.style.fontFamily = "system-ui, -apple-system, BlinkMacSystemFont, sans-serif";
  bubble.style.fontSize = "13px";
  bubble.style.borderRadius = "10px";
  bubble.style.padding = "10px 12px";
  bubble.style.boxShadow = "0 4px 12px rgba(0,0,0,0.18)";
  bubble.style.backgroundColor = coach.label === "high" ? "#ffe5e5" : "#e6f3ff";
  bubble.style.color = "#111";

  const title = document.createElement("div");
  title.style.fontWeight = "600";
  title.style.marginBottom = "4px";
  title.textContent = `Cyber coach: ${coach.label.toUpperCase()} RISK (${Math.round(coach.risk_score * 100)}%)`;

  const nudges = document.createElement("div");
  nudges.textContent = coach.nudges.join(" ");

  const hints = document.createElement("ul");
  hints.style.margin = "6px 0 0 16px";
  hints.style.padding = "0";
  hints.style.listStyle = "disc";
  coach.hints.slice(0, 3).forEach((hintText) => {
    const li = document.createElement("li");
    li.textContent = hintText;
    hints.appendChild(li);
  });

  const close = document.createElement("button");
  close.textContent = "OK";
  close.style.marginTop = "6px";
  close.style.border = "none";
  close.style.borderRadius = "6px";
  close.style.padding = "4px 10px";
  close.style.cursor = "pointer";
  close.style.fontSize = "12px";
  close.style.backgroundColor = "#111";
  close.style.color = "#fff";
  close.addEventListener("click", () => bubble.remove());

  bubble.appendChild(title);
  bubble.appendChild(nudges);
  bubble.appendChild(hints);
  bubble.appendChild(close);

  document.body.appendChild(bubble);
}

// Trigger on first load and when the URL changes (SPA).
sendEventToCoach();

let lastHref = location.href;
const observer = new MutationObserver(() => {
  const href = location.href;
  if (href !== lastHref) {
    lastHref = href;
    sendEventToCoach();
  }
});

observer.observe(document.body, { childList: true, subtree: true });
