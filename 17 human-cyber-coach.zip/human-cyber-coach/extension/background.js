
// background.js
// Listens for messages from the content script and forwards them
// to the backend coach API.

const API_URL = "http://localhost:9000/event";

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "HUMAN_CYBER_EVENT") {
    fetch(API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        user_id: "demo-user",
        channel: "browser",
        url: message.url,
        text: message.textSnippet,
        claimed_risk: message.claimedRisk || "medium"
      })
    })
      .then(res => res.json())
      .then(data => {
        sendResponse({ ok: true, coach: data });
      })
      .catch(err => {
        console.error("Coach API error", err);
        sendResponse({ ok: false, error: String(err) });
      });

    // indicate we will respond asynchronously
    return true;
  }
});
