"""
Kubernetes Attack Replay Lab – Dania

Takes a JSON scenario and produces

* Graphviz DOT graph of nodes/pods/roles/bindings
* Markdown step-by-step attack narrative
"""

import argparse
import json
from dataclasses import dataclass
from typing import List, Dict


@dataclass
class Node:
    name: str
    role: str  # worker, control-plane


@dataclass
class Pod:
    name: str
    namespace: str
    node: str
    service_account: str


@dataclass
class Role:
    name: str
    namespace: str
    permissions: List[str]


@dataclass
class Binding:
    name: str
    namespace: str
    role: str
    subject_sa: str


@dataclass
class AttackStep:
    id: int
    title: str
    actor: str
    action: str
    impact: str
    objects: List[str]


def load_scenario(path: str):
    with open(path, "r", encoding="utf-8") as f:
        raw = json.load(f)

    nodes = [Node(**n) for n in raw.get("nodes", [])]
    pods = [Pod(**p) for p in raw.get("pods", [])]
    roles = [Role(**r) for r in raw.get("roles", [])]
    bindings = [Binding(**b) for b in raw.get("bindings", [])]
    steps = [AttackStep(**s) for s in raw.get("steps", [])]

    return nodes, pods, roles, bindings, steps


def write_dot(nodes: List[Node], pods: List[Pod], roles: List[Role], bindings: List[Binding], steps: List[AttackStep], path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        f.write("digraph k8s_attack {\n")
        f.write("  rankdir=LR;\n")

        # nodes
        for n in nodes:
            color = "#c8e6c9" if n.role == "control-plane" else "#e8f0fe"
            f.write(f'  "{n.name}" [shape=box,style="filled,rounded",fillcolor="{color}",label="{n.name}\\n{n.role}"];\n')

        # pods
        for p in pods:
            label = f"{p.name}\\nns={p.namespace}\\nsa={p.service_account}"
            f.write(f'  "{p.name}" [shape=oval,style="filled",fillcolor="#fff9c4",label="{label}"];\n')
            f.write(f'  "{p.node}" -> "{p.name}" [label="schedules"];\n')

        # roles and bindings
        for r in roles:
            label = f"{r.name}\\n{r.namespace}"
            f.write(f'  "role:{r.name}" [shape=box,style="dashed",label="{label}"];\n')
        for b in bindings:
            f.write(f'  "sa:{b.subject_sa}" [shape=oval,style="dotted",label="{b.subject_sa}"];\n')
            f.write(f'  "sa:{b.subject_sa}" -> "role:{b.role}" [label="binding"]; \n')

        # attack steps as annotations
        for s in steps:
            node_id = f"step:{s.id}"
            label = f"{s.id}. {s.title}"
            f.write(f'  "{node_id}" [shape=note,style="filled",fillcolor="#ffcdd2",label="{label}"];\n')
            for obj in s.objects:
                f.write(f'  "{node_id}" -> "{obj}" [style="dashed"];\n')

        f.write("}\n")


def write_markdown(steps: List[AttackStep], path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        f.write("# Kubernetes attack replay\n\n")
        for s in steps:
            f.write(f"## Step {s.id} – {s.title}\n\n")
            f.write(f"* Actor: {s.actor}\n")
            f.write(f"* Action: {s.action}\n")
            f.write(f"* Impact: {s.impact}\n")
            if s.objects:
                f.write(f"* Objects touched: {', '.join(s.objects)}\n")
            f.write("\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's Kubernetes attack replay lab")
    parser.add_argument("--scenario", default="example_scenario.json", help="Scenario JSON file")
    parser.add_argument("--out-prefix", default="k8s_attack", help="Output prefix")
    args = parser.parse_args()

    nodes, pods, roles, bindings, steps = load_scenario(args.scenario)
    dot_path = f"{args.out_prefix}_graph.dot"
    md_path = f"{args.out_prefix}_story.md"
    write_dot(nodes, pods, roles, bindings, steps, dot_path)
    write_markdown(steps, md_path)

    print(f"Wrote DOT graph to {dot_path}")
    print(f"Wrote Markdown story to {md_path}")


if __name__ == "__main__":
    main()
