# Kubernetes Attack Replay Lab – Dania

Hi

I am Dania and this lab turns a simple JSON description of a Kubernetes attack path into a human friendly walkthrough

It reads nodes  pods  roles and bindings plus attack steps and then writes

* a Graphviz DOT graph of the cluster pieces used in the attack
* a Markdown story that explains each step  from initial pod to escalation

It is a safe offline way to talk through common Kubernetes attack ideas without touching any real cluster
