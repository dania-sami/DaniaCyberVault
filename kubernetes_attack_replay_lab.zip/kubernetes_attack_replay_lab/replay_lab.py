
import json, argparse

def load_scenarios(path):
    with open(path,"r",encoding="utf-8") as f:
        return json.load(f)

def render(s):
    out=[]
    out.append("# "+s["title"]+"\n")
    out.append(s["summary"]+"\n")
    out.append("## Steps\n")
    for st in s["steps"]:
        out.append(f"{st['id']}. {st['actor']} – {st['action']} (goal: {st['goal']})")
    out.append("\n## Controls\n")
    for c in s["controls"]:
        out.append(f"* {c['name']} – breaks steps {','.join(str(x) for x in c['breaks'])}")
    return "\n".join(out)

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--scenarios",default="k8s_scenarios.json")
    p.add_argument("--id",required=True)
    p.add_argument("--out",default="k8s_story.md")
    a=p.parse_args()
    allsc=load_scenarios(a.scenarios)
    sc=None
    for s in allsc:
        if s["id"]==a.id: sc=s
    if not sc:
        raise SystemExit("scenario not found")
    txt=render(sc)
    with open(a.out,"w",encoding="utf-8") as f:f.write(txt)
    print("Wrote",a.out)

if __name__=="__main__":
    main()
