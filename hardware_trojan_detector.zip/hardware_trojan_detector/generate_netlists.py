
from pathlib import Path
import csv
import random

DATA_DIR = Path("data")

def main():
    random.seed(42)
    DATA_DIR.mkdir(exist_ok=True)

    rows = []
    n_total = 200
    trojan_fraction = 0.25

    for i in range(n_total):
        base_gates = random.randint(200, 800)
        is_trojan = random.random() < trojan_fraction

        num_gates = base_gates
        num_xor = int(base_gates * random.uniform(0.05, 0.15))
        num_and = int(base_gates * random.uniform(0.3, 0.5))
        num_or = int(base_gates * random.uniform(0.2, 0.4))
        rare_gate_ratio = random.uniform(0.01, 0.04)
        trigger_logic_size = 0
        payload_fanout = random.randint(1, 5)
        max_fanout = random.randint(4, 16)

        if is_trojan:
            trigger_logic_size = random.randint(10, 30)
            rare_gate_ratio = random.uniform(0.06, 0.15)
            payload_fanout = random.randint(5, 20)
            max_fanout = random.randint(10, 32)

        rows.append(
            {
                "id": i,
                "num_gates": num_gates,
                "num_xor": num_xor,
                "num_and": num_and,
                "num_or": num_or,
                "max_fanout": max_fanout,
                "rare_gate_ratio": round(rare_gate_ratio, 4),
                "trigger_logic_size": trigger_logic_size,
                "payload_fanout": payload_fanout,
                "label": "trojan_like" if is_trojan else "clean",
            }
        )

    out_path = DATA_DIR / "netlists.csv"
    fieldnames = list(rows[0].keys())
    with out_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in rows:
            w.writerow(r)

    print(f"[info] Wrote {len(rows)} synthetic netlists to {out_path}")

if __name__ == "__main__":
    main()
