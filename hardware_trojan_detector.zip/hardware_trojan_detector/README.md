
# Hardware Trojan Detection System (Netlist Feature Anomaly Lab)

Hi, I am Dania and I built this project to explore how researchers detect **hardware Trojans** in digital circuits.

Instead of working with real silicon, I simulate netlists as feature vectors and then:

- generate many “normal” circuits and a few with Trojan-like patterns
- compute simple structural features (gate mix, fanout, trigger logic)
- train an anomaly model to separate clean vs suspicious designs

This is a compact lab for thinking about hardware Trojan detection using machine learning.

---

## What this project does

There are two main scripts:

1. `generate_netlists.py`  
   - simulates many netlists as rows in `data/netlists.csv`  
   - each row has features such as:
     - `num_gates`
     - `num_xor`
     - `num_and`
     - `num_or`
     - `max_fanout`
     - `rare_gate_ratio`
     - `trigger_logic_size`
     - `payload_fanout`
   - labels each circuit as `clean` or `trojan_like` based on how it was generated

2. `detect_trojans.py`  
   Two modes in one script:
   - trains an `IsolationForest` anomaly detector on all circuits
   - computes an `anomaly_score` and `verdict` for each netlist
   - prints the most suspicious netlists and writes `data/netlists_scored.csv`

The idea is not to recreate real EDA flows but to show how structural features of a netlist can be used for Trojan detection.

---

## Project structure

```text
hardware_trojan_detector/
  README.md
  requirements.txt
  generate_netlists.py   # simulate clean and Trojan-like circuits
  detect_trojans.py      # anomaly detection on netlist features
  data/
```

---

## Installation

```bash
python3 -m venv venv
source venv/bin/activate       # Windows  venv\Scripts\activate
pip install -r requirements.txt
```

---

## Step 1  Generate synthetic netlists

```bash
python generate_netlists.py
```

This creates:

- `data/netlists.csv` where each row is one circuit with features and a `label` (`clean` or `trojan_like`).

---

## Step 2  Detect Trojan-like circuits

```bash
python detect_trojans.py
```

The script will:

- train an IsolationForest on the feature space
- compute `anomaly_score` for each netlist (0..1, higher = more suspicious)
- assign a `verdict` (Typical / Suspicious / Highly suspicious)
- write everything to `data/netlists_scored.csv`

Example style of console output:

```text
[info] Loaded 200 netlists from data/netlists.csv
[info] Scores written to data/netlists_scored.csv
[info] Top suspicious netlists:
  id=173  label=trojan_like   score=0.94  num_gates=540   trigger_logic_size=18   rare_gate_ratio=0.12
  id=188  label=trojan_like   score=0.91  num_gates=510   trigger_logic_size=20   rare_gate_ratio=0.10
  id= 37  label=clean         score=0.63  num_gates=300   trigger_logic_size= 0   rare_gate_ratio=0.03
```

---

## Feature design (simplified)

Each simulated netlist has:

- `num_gates` — rough size of the design
- `num_xor`, `num_and`, `num_or` — gate type counts
- `max_fanout` — maximum number of sinks driven by one node
- `rare_gate_ratio` — proportion of “rare” or unusual gates
- `trigger_logic_size` — size of Trojan trigger cone (non-zero for trojan_like)
- `payload_fanout` — fanout of payload node (usually small but meaningful for Trojans)

Trojan-like circuits tend to have:

- non-zero trigger logic
- slightly elevated rare gate usage
- suspicious fanout patterns

---

## Why I like this project

Hardware Trojans are a very modern concern in hardware security.

With this project I can show that I:

- understand the concept of structural features in netlists
- know how to generate synthetic “Trojan-like” designs
- can apply anomaly detection to identify suspicious circuits
- and can communicate results in a way that hardware teams could understand

It is a good foundation for more advanced work using real EDA outputs in the future.
