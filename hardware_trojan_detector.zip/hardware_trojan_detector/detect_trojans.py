
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest

DATA_DIR = Path("data")

FEATURE_COLS = [
    "num_gates",
    "num_xor",
    "num_and",
    "num_or",
    "max_fanout",
    "rare_gate_ratio",
    "trigger_logic_size",
    "payload_fanout",
]

def verdict(score: float) -> str:
    if score < 0.4:
        return "Typical"
    if score < 0.7:
        return "Suspicious"
    return "Highly suspicious"

def main():
    path = DATA_DIR / "netlists.csv"
    if not path.is_file():
        raise SystemExit(f"Netlist feature file not found: {path} (run generate_netlists.py first)")
    df = pd.read_csv(path)
    print(f"[info] Loaded {len(df)} netlists from {path}")

    X = df[FEATURE_COLS].astype(float).values

    model = IsolationForest(
        n_estimators=200,
        contamination=0.25,
        random_state=42,
    )
    model.fit(X)

    scores_raw = model.decision_function(X)
    min_s = scores_raw.min()
    max_s = scores_raw.max()
    if max_s - min_s > 1e-9:
        anomaly_scores = (min_s - scores_raw) / (min_s - max_s)
    else:
        anomaly_scores = np.zeros_like(scores_raw)

    df["anomaly_score"] = anomaly_scores
    df["verdict"] = df["anomaly_score"].apply(verdict)

    out_path = DATA_DIR / "netlists_scored.csv"
    df.to_csv(out_path, index=False)
    print(f"[info] Scores written to {out_path}")

    top = df.sort_values("anomaly_score", ascending=False).head(10)
    print("[info] Top suspicious netlists:")
    for _, row in top.iterrows():
        print(
            f"  id={int(row['id']):3d}  label={row['label']:<11}  score={row['anomaly_score']:.2f}  "
            f"num_gates={int(row['num_gates']):4d}   trigger_logic_size={int(row['trigger_logic_size']):2d}   "
            f"rare_gate_ratio={row['rare_gate_ratio']:.2f}"
        )

if __name__ == "__main__":
    main()
