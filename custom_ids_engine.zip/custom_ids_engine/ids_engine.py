
import argparse
import csv
import json
import random
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest

DATA_DIR = Path("data")
RULES_FILE = Path("rules.json")

HTTP_PATHS = [
    "/",
    "/index.php",
    "/home",
    "/login",
    "/wp-login.php",
    "/xmlrpc.php",
    "/admin",
    "/phpmyadmin",
    "/search",
    "/api/v1/data",
]

MALICIOUS_FRAGMENTS = [
    "union select",
    "or 1=1",
    "<script>",
    "../etc/passwd",
]


def gen_demo_logs(n_normal=400, n_attack=80):
    random.seed(42)
    DATA_DIR.mkdir(exist_ok=True)
    rows = []
    base_time = datetime(2025, 1, 1, 12, 0, 0)

    normal_ips = [f"192.0.2.{i}" for i in range(10, 40)]
    attacker_ips = [f"203.0.113.{i}" for i in range(1, 5)]

    # normal traffic
    for _ in range(n_normal):
        t = base_time + timedelta(seconds=random.randint(0, 3600))
        src_ip = random.choice(normal_ips)
        dst_ip = "10.0.0.10"
        path = random.choice(HTTP_PATHS[:6])
        method = random.choice(["GET", "POST"])
        status = random.choice([200, 200, 200, 302, 404])
        bytes_sent = random.randint(300, 5000)
        rows.append({
            "timestamp": t.isoformat(),
            "src_ip": src_ip,
            "dst_ip": dst_ip,
            "method": method,
            "path": path,
            "status": status,
            "bytes": bytes_sent,
        })

    # attack traffic
    for _ in range(n_attack):
        t = base_time + timedelta(seconds=random.randint(0, 3600))
        src_ip = random.choice(attacker_ips)
        dst_ip = "10.0.0.10"
        base_path = random.choice(HTTP_PATHS)
        # occasionally inject malicious fragments
        if random.random() < 0.6:
            frag = random.choice(MALICIOUS_FRAGMENTS)
            path = base_path + "?" + frag.replace(" ", "+")
        else:
            path = base_path
        method = random.choice(["GET", "POST"])
        status = random.choice([200, 403, 500])
        bytes_sent = random.randint(100, 8000)
        rows.append({
            "timestamp": t.isoformat(),
            "src_ip": src_ip,
            "dst_ip": dst_ip,
            "method": method,
            "path": path,
            "status": status,
            "bytes": bytes_sent,
        })

    out_path = DATA_DIR / "http_logs.csv"
    with out_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    print(f"[info] Demo logs written to {out_path}")


def load_rules():
    if not RULES_FILE.is_file():
        # minimal default rules
        rules = [
            {"id": "1001", "name": "SQL injection", "pattern": "union select"},
            {"id": "1002", "name": "Path traversal", "pattern": "../etc/passwd"},
            {"id": "1003", "name": "WordPress brute force", "pattern": "/wp-login.php"},
            {"id": "1004", "name": "PhpMyAdmin probe", "pattern": "/phpmyadmin"},
            {"id": "1005", "name": "XSS attempt", "pattern": "<script>"},
        ]
        with RULES_FILE.open("w", encoding="utf-8") as f:
            json.dump(rules, f, indent=2)
        return rules
    with RULES_FILE.open("r", encoding="utf-8") as f:
        return json.load(f)


def run_ids():
    log_path = DATA_DIR / "http_logs.csv"
    if not log_path.is_file():
        raise SystemExit(f"Log file not found: {log_path} (run with 'demo' to generate)")
    df = pd.read_csv(log_path)
    rules = load_rules()

    alerts = []

    # Signature based
    for _, row in df.iterrows():
        path = str(row["path"]).lower()
        for rule in rules:
            if rule["pattern"].lower() in path:
                alerts.append({
                    "timestamp": row["timestamp"],
                    "src_ip": row["src_ip"],
                    "type": "signature",
                    "rule_id": rule["id"],
                    "rule_name": rule["name"],
                    "detail": f"path matched pattern '{rule['pattern']}'",
                })

    # Aggregate per source for anomaly detection
    grouped = df.groupby("src_ip")
    feature_rows = []
    for src_ip, sub in grouped:
        total = len(sub)
        unique_paths = sub["path"].nunique()
        error_rate = (sub["status"] >= 400).mean()
        avg_bytes = sub["bytes"].mean()
        feature_rows.append({
            "src_ip": src_ip,
            "total_reqs": total,
            "unique_paths": unique_paths,
            "error_rate": error_rate,
            "avg_bytes": avg_bytes,
        })
    feat_df = pd.DataFrame(feature_rows)
    X = feat_df[["total_reqs", "unique_paths", "error_rate", "avg_bytes"]].astype(float).values

    if len(feat_df) >= 5:
        model = IsolationForest(n_estimators=200, contamination=0.2, random_state=42)
        model.fit(X)
        scores = model.decision_function(X)
        # lower score means more anomalous; convert to 0..1 anomaly score
        min_s, max_s = scores.min(), scores.max()
        if max_s - min_s > 1e-9:
            anomaly_scores = (min_s - scores) / (min_s - max_s)
        else:
            anomaly_scores = np.zeros_like(scores)
        feat_df["anomaly_score"] = anomaly_scores

        for _, row in feat_df.iterrows():
            if row["anomaly_score"] > 0.7:
                alerts.append({
                    "timestamp": "",
                    "src_ip": row["src_ip"],
                    "type": "anomaly",
                    "rule_id": "ML-1",
                    "rule_name": "High anomaly score",
                    "detail": f"anomaly_score={row['anomaly_score']:.2f}, total_reqs={row['total_reqs']}",
                })

    alerts_path = DATA_DIR / "alerts.csv"
    if alerts:
        with alerts_path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(alerts[0].keys()))
            writer.writeheader()
            writer.writerows(alerts)
        print(f"[info] Wrote {len(alerts)} alerts to {alerts_path}")
        print("[info] Sample alerts:")
        for a in alerts[:10]:
            print(f"  {a['src_ip']:15} {a['type']:9} {a['rule_name']:22} {a['detail']}")
    else:
        print("[info] No alerts generated for this dataset.")


def main():
    parser = argparse.ArgumentParser(description="Custom hybrid IDS engine")
    parser.add_argument("mode", choices=["demo"], help="Run demo (generate logs + detect)")
    args = parser.parse_args()

    DATA_DIR.mkdir(exist_ok=True)

    if args.mode == "demo":
        gen_demo_logs()
        run_ids()


if __name__ == "__main__":
    import argparse
    main()
