
# Custom Intrusion Detection Signature Engine (Hybrid IDS Lab)

Hi, I am Dania and I built this project to combine **signature based detection** with **anomaly detection** in a single mini IDS pipeline.

The idea is:

- parse simple HTTP style logs
- apply Snort like signatures using pattern rules
- compute basic statistical features per source IP
- run an `IsolationForest` model to catch outliers

This mirrors how modern IDS systems mix known bad with behaviour analytics.

---

## What this project does

The main script is `ids_engine.py`. It can:

1. Generate a demo log file `data/http_logs.csv` with fields:
   - `timestamp`
   - `src_ip`
   - `dst_ip`
   - `method`
   - `path`
   - `status`
   - `bytes`
2. Load a small rule set from `rules.json` with patterns like:
   - `/wp-login.php` brute force
   - `union select` SQL injection
   - `/phpmyadmin` probes
3. Run detection in two layers:
   - **Signature engine**: string pattern matching on `path`
   - **Anomaly engine**: aggregates per `src_ip` and uses IsolationForest over:
     - total requests
     - unique paths
     - error rate
     - average bytes
4. Write alerts to:
   - `data/alerts.csv`

and print a concise summary to the console.

---

## Project structure

```text
custom_ids_engine/
  README.md
  requirements.txt
  ids_engine.py
  rules.json
  data/
```

---

## Installation

```bash
python3 -m venv venv
source venv/bin/activate            # Windows  venv\Scripts\activate
pip install -r requirements.txt
```

---

## Usage (demo)

```bash
python ids_engine.py demo
```

This will:

- generate synthetic logs
- apply signatures and anomaly detection
- write `data/http_logs.csv` and `data/alerts.csv`
- print top alerts

---

## Why this project matters to me

IDS design is a core topic in network security.

With this project I can show that I:

- understand the strengths and limits of pattern signatures
- can aggregate flows by source and model normal vs abnormal
- can implement a hybrid approach that feels close to real systems

It’s small, readable and ready to discuss line by line.
