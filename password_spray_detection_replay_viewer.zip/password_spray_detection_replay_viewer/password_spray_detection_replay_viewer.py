"""
Password Spray Detection and Replay Viewer – Dania

Input: JSONL auth events, one per line, for example:

{"ts":"2025-01-01T10:00:00","user":"alice","ip":"203.0.113.10","result":"fail","protocol":"web"}
{"ts":"2025-01-01T10:00:05","user":"bob","ip":"203.0.113.10","result":"fail","protocol":"web"}

The detector looks for:

* many distinct users
* from the same IP
* mostly failed attempts
* within a sliding time window

and then writes:

* JSON file with detected spray clusters
* Markdown replay report per cluster
"""

import argparse
import json
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
from typing import List, Dict

TS_FORMAT = "%Y-%m-%dT%H:%M:%S"


@dataclass
class AuthEvent:
    ts: str
    user: str
    ip: str
    result: str
    protocol: str


@dataclass
class SprayCluster:
    id: int
    ip: str
    start_ts: str
    end_ts: str
    total_events: int
    distinct_users: int
    fail_count: int
    success_count: int
    sample_users: List[str]


def parse_ts(ts: str) -> datetime:
    return datetime.strptime(ts, TS_FORMAT)


def load_events(path: str) -> List[AuthEvent]:
    events: List[AuthEvent] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            events.append(
                AuthEvent(
                    ts=obj["ts"],
                    user=obj.get("user", "unknown"),
                    ip=obj.get("ip", "unknown"),
                    result=obj.get("result", ""),
                    protocol=obj.get("protocol", ""),
                )
            )
    events.sort(key=lambda e: e.ts)
    return events


def detect_spray(events: List[AuthEvent], window_minutes: int = 5, min_users: int = 5, min_events: int = 10) -> List[SprayCluster]:
    window = timedelta(minutes=window_minutes)
    clusters: List[SprayCluster] = []
    current_id = 1

    # group by IP first
    by_ip: Dict[str, List[AuthEvent]] = {}
    for e in events:
        by_ip.setdefault(e.ip, []).append(e)

    for ip, ip_events in by_ip.items():
        ip_events.sort(key=lambda e: e.ts)
        n = len(ip_events)
        start_idx = 0
        while start_idx < n:
            start_ts = parse_ts(ip_events[start_idx].ts)
            users = set()
            fail_count = 0
            success_count = 0
            end_idx = start_idx
            while end_idx < n:
                e = ip_events[end_idx]
                t = parse_ts(e.ts)
                if t - start_ts > window:
                    break
                users.add(e.user)
                if e.result.lower() == "fail":
                    fail_count += 1
                else:
                    success_count += 1
                end_idx += 1

            total = fail_count + success_count
            if total >= min_events and len(users) >= min_users and fail_count > success_count:
                cluster_events = ip_events[start_idx:end_idx]
                clusters.append(
                    SprayCluster(
                        id=current_id,
                        ip=ip,
                        start_ts=cluster_events[0].ts,
                        end_ts=cluster_events[-1].ts,
                        total_events=total,
                        distinct_users=len(users),
                        fail_count=fail_count,
                        success_count=success_count,
                        sample_users=sorted(list(users))[:10],
                    )
                )
                current_id += 1
                # move window forward to avoid huge overlap
                start_idx = end_idx
            else:
                start_idx += 1

    return clusters


def write_outputs(clusters: List[SprayCluster], events: List[AuthEvent], md_path: str, json_path: str) -> None:
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump([asdict(c) for c in clusters], f, indent=2)

    # index events by ip and time for replay section
    by_ip: Dict[str, List[AuthEvent]] = {}
    for e in events:
        by_ip.setdefault(e.ip, []).append(e)
    for ip in by_ip:
        by_ip[ip].sort(key=lambda e: e.ts)

    with open(md_path, "w", encoding="utf-8") as f:
        f.write("# Password spray detection report\n\n")
        f.write(f"* Total candidate spray clusters: {len(clusters)}\n\n")

        for c in clusters:
            f.write(f"## Cluster {c.id} – IP {c.ip}\n\n")
            f.write(f"* Time window: {c.start_ts} → {c.end_ts}\n")
            f.write(f"* Events: {c.total_events}\n")
            f.write(f"* Distinct users: {c.distinct_users}\n")
            f.write(f"* Failures: {c.fail_count}  Successes: {c.success_count}\n")
            if c.sample_users:
                f.write(f"* Sample users: {', '.join(c.sample_users)}\n")
            f.write("\n")
            f.write("Replay timeline:\n\n")
            for e in by_ip.get(c.ip, []):
                if c.start_ts <= e.ts <= c.end_ts:
                    f.write(f"- {e.ts}  user={e.user}  result={e.result}  protocol={e.protocol}\n")
            f.write("\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's password spray detection and replay viewer")
    parser.add_argument("--auth-log", default="example_auth.jsonl", help="Auth events in JSONL format")
    parser.add_argument("--window-minutes", type=int, default=5, help="Time window for grouping attempts from same IP")
    parser.add_argument("--out-prefix", default="spray", help="Output prefix")
    args = parser.parse_args()

    events = load_events(args.auth_log)
    clusters = detect_spray(events, window_minutes=args.window_minutes)
    md_path = f"{args.out_prefix}_report.md"
    json_path = f"{args.out_prefix}_clusters.json"
    write_outputs(clusters, events, md_path, json_path)
    print(f"Analysed {len(events)} auth events  clusters={len(clusters)}")
    print(f"Wrote report to {md_path}")


if __name__ == "__main__":
    main()
