# Password Spray Detection and Replay Viewer – Dania

Hi

I am Dania and this project is my helper for spotting password spray in authentication logs

It groups failed logins from the same IP against many accounts into spray events and then builds a human friendly replay timeline for each attack

I use it to practise how I would explain a spray campaign to a security team using only JSONL logs and a Markdown report
