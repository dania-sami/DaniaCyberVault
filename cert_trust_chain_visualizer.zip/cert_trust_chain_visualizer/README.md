# Digital Certificate Trust Chain Visualizer

Hi, I am Dania Sami 👋

This project is my way of showing that I understand how **TLS certificates and trust chains** actually work,
not just at the buzzword level.

I wanted a small, practical tool that can:

- connect to a remote TLS endpoint
- pull the presented certificate chain
- parse basic properties of each certificate
- show the chain in a clear, readable form
- optionally export a simple Graphviz-style `.dot` file for visualisation

It is **perfect for demos and learning**, and the code is focused and easy to extend.

---

## What this tool does

1. **Connects to a host and port**

   Using Python's `ssl` and `socket` modules, the script connects to a TLS server
   and retrieves the certificate chain in binary form.

2. **Parses certificate details**

   Using the `cryptography` library, it extracts for each certificate:

   - subject common name
   - issuer common name
   - not-before and not-after dates
   - whether it is self-signed (very rough check)

3. **Prints a human-readable chain view**

   It prints something like:

   ```text
   [0] CN=www.example.com  -->  Issuer: CN=Example Issuing CA
   [1] CN=Example Issuing CA  -->  Issuer: CN=Example Root CA
   [2] CN=Example Root CA (self-signed)
   ```

4. **Exports a `.dot` file**

   It also writes `chain.dot` which you can visualise with Graphviz
   or any dot viewer.

---

## How to run

You need Python 3.10+ and `cryptography` installed.

```bash
python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt
```

Then:

```bash
python -m src.fetch_chain --host example.com --port 443
```

This will:

- print the certificate chain to the terminal
- create `chain.dot` in the project root

You can then render the dot file with any Graphviz tool if you want
a visual graph.

---

## Project structure

```text
cert_trust_chain_visualizer/
  ├─ README.md
  ├─ requirements.txt
  └─ src/
       ├─ __init__.py
       └─ fetch_chain.py
```

---

## Why I built this

In security conversations, certificates and PKI come up all the time,
yet many people never actually parse or inspect real chains.

This small project lets me:

- talk concretely about X.509 and TLS
- show that I can combine networking code with parsing
- demonstrate a security engineering mindset focused on **visibility and clarity**
