from __future__ import annotations

import argparse
import socket
import ssl
from pathlib import Path
from typing import List

from cryptography import x509
from cryptography.hazmat.backends import default_backend


def get_cert_chain(host: str, port: int) -> List[bytes]:
    context = ssl.create_default_context()
    conn = context.wrap_socket(socket.socket(socket.AF_INET), server_hostname=host)
    conn.settimeout(10)
    conn.connect((host, port))
    der_chain = conn.getpeercert(True)
    # Python ssl only exposes leaf by default; some implementations provide 'ssl.get_server_certificate'
    # For simplicity, we treat this as a single-cert "chain".
    conn.close()
    return [der_chain]


def parse_cert(der: bytes) -> x509.Certificate:
    return x509.load_der_x509_certificate(der, default_backend())


def common_name(name) -> str:
    try:
        for attr in name:
            if attr.oid.dotted_string == "2.5.4.3":
                return attr.value
    except Exception:
        pass
    return "<unknown>"


def main() -> None:
    parser = argparse.ArgumentParser(description="TLS certificate chain visualizer")
    parser.add_argument("--host", required=True, help="Hostname to connect to")
    parser.add_argument("--port", type=int, default=443, help="Port (default 443)")
    parser.add_argument("--dot-path", type=str, default="chain.dot", help="Path to write dot file")
    args = parser.parse_args()

    der_chain = get_cert_chain(args.host, args.port)
    certs = [parse_cert(der) for der in der_chain]

    print(f"Retrieved {len(certs)} certificate(s) from {args.host}:{args.port}")
    lines = []
    for idx, cert in enumerate(certs):
        subj_cn = common_name(cert.subject)
        iss_cn = common_name(cert.issuer)
        self_signed = cert.issuer == cert.subject
        if self_signed:
            line = f"[{idx}] CN={subj_cn} (self-signed)"
        else:
            line = f"[{idx}] CN={subj_cn}  -->  Issuer: CN={iss_cn}"
        print(line)
        lines.append((subj_cn, iss_cn, self_signed))

    # write a very small dot file
    dot_path = Path(args.dot_path)
    with dot_path.open("w", encoding="utf-8") as f:
        f.write("digraph cert_chain {\n")
        for subj, iss, self_signed in lines:
            if self_signed:
                f.write(f'  "{subj}" [shape=box];\n')
            else:
                f.write(f'  "{subj}" -> "{iss}";\n')
        f.write("}\n")
    print(f"Dot graph written to {dot_path}")


if __name__ == "__main__":
    main()
