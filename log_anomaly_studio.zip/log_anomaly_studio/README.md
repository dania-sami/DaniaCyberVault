# Log Anomaly Studio – Dania’s Small SOC Lab

Hi

I am Dania and this is my upgraded version of the Sentinel Log Guardian project

I wanted something that feels a bit closer to a real SOC workflow
not just a one shot script

So Log Anomaly Studio does three things for me

1 It understands multiple log flavours (SSH auth logs web server logs and generic app logs)
2 It lets me define simple anomaly recipes in a JSON config
3 It gives me a tiny interactive CLI so I can label anomalies as benign or suspicious
  and it remembers those labels between runs

It is still intentionally small and based only on the Python standard library
The goal is to show that I can structure log analysis code in a clean and extendable way

## What it can analyse

Right now I support three simple log types

* ssh   typical auth log style lines e.g. sshd failed password etc
* web   common log format like nginx or Apache
* app   generic text logs with levels like INFO WARN ERROR

I also support a default mode that just treats every line as a generic log entry

The studio expects one or more input files
and you tell it what type you think they are

## How the anomaly engine works

1 For each log entry I extract a few normalised features
   * timestamp approximation if present
   * source IP if present
   * log level
   * template version of the line with numbers and IPs replaced by tokens
2 I build simple frequency statistics per file
3 I mark lines as anomaly candidates when
   * their template is very rare
   * the level is error or similar
   * the line matches any of my custom recipes from config_anomaly_recipes.json
4 I then show these candidates either
   * in a Markdown report, or
   * in an interactive CLI session where I can label them

When I label a line as benign for a given template
future runs will automatically suppress identical templates
so the noise goes down over time just like in real log tuning

All labels are stored in labels.json inside the project folder

## How I run it

First run on the sample data

1 Create a virtual environment if you like

   python3 -m venv venv
   source venv_bin_activate

2 Install the requirements

   pip install -r requirements.txt

3 Look at the example logs in the examples folder

   * ssh_sample.log
   * web_sample.log
   * app_sample.log

4 Run the studio in non interactive mode

   python studio.py \
       --type ssh \
       --files examples_ssh_sample.log \
       --out ssh_report.md

   python studio.py \
       --type web \
       --files examples_web_sample.log \
       --out web_report.md

5 Try the interactive lab

   python studio.py \
       --type ssh \
       --files examples_ssh_sample.log \
       --interactive

You will see each anomaly candidate one by one
and you can press

* s   mark as suspicious
* b   mark as benign
* enter   skip for now

At the end the labels.json file will contain what I decided
and the next run will be a bit smarter

## Why this project helps my learning

I built this because I wanted something between toy scripts and huge SIEM products

With Log Anomaly Studio I can show that I

* understand typical patterns in SSH web and application logs
* can build simple but useful anomaly detection on top of templates and counts
* know how to design a config driven recipe system for extra rules
* can add a tiny human in the loop labelling flow that improves the results over time

It is a small SOC lab that runs entirely on my laptop

