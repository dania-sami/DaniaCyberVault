"""
Log Anomaly Studio – Dania's upgraded log lab

Supports SSH, web and app logs
Allows simple anomaly recipes
And lets a human analyst label anomalies interactively
"""

import argparse
import json
import os
import re
from dataclasses import dataclass, asdict
from typing import List, Dict, Iterable, Tuple


TEMPLATE_IP = "<IP>"
TEMPLATE_NUMBER = "<NUM>"


ip_re = re.compile(r"(?:\d{1,3}\.){3}\d{1,3}")
number_re = re.compile(r"(?<![\w.])(\d+)(?![\w.])")


@dataclass
class LogEntry:
    file: str
    index: int
    raw: str
    template: str
    level: str
    source_ip: str
    extras: Dict[str, str]


@dataclass
class Anomaly:
    entry: LogEntry
    score: float
    reasons: List[str]


def build_template(line: str) -> str:
    def repl_ip(m: re.Match) -> str:
        return TEMPLATE_IP

    def repl_num(m: re.Match) -> str:
        return TEMPLATE_NUMBER

    line = ip_re.sub(repl_ip, line)
    line = number_re.sub(repl_num, line)
    return " ".join(line.split())


def parse_level_generic(line: str) -> str:
    lower = line.lower()
    if "error" in lower or "err " in lower:
        return "error"
    if "warn" in lower:
        return "warning"
    if "crit" in lower or "fatal" in lower:
        return "critical"
    if "info" in lower:
        return "info"
    return "unknown"


def first_ip(line: str) -> str:
    m = ip_re.search(line)
    return m.group(0) if m else ""


def parse_ssh(lines: Iterable[str], file_name: str) -> List[LogEntry]:
    entries: List[LogEntry] = []
    for idx, raw in enumerate(lines):
        stripped = raw.rstrip("\n")
        if not stripped:
            continue
        template = build_template(stripped)
        level = parse_level_generic(stripped)
        ip = first_ip(stripped)
        entries.append(
            LogEntry(
                file=file_name,
                index=idx,
                raw=stripped,
                template=template,
                level=level,
                source_ip=ip,
                extras={},
            )
        )
    return entries


def parse_web(lines: Iterable[str], file_name: str) -> List[LogEntry]:
    entries: List[LogEntry] = []
    log_re = re.compile(
        r'(\S+) (\S+) (\S+) \[(.*?)\] "([^"]*)" (\d{3}) (\S+)'
    )
    for idx, raw in enumerate(lines):
        stripped = raw.rstrip("\n")
        if not stripped:
            continue
        m = log_re.match(stripped)
        status = ""
        ip = ""
        extras: Dict[str, str] = {}
        if m:
            ip = m.group(1)
            request = m.group(5)
            status = m.group(6)
            extras = {"request": request, "status": status}
        template = build_template(stripped)
        level = "info"
        if status.startswith("5"):
            level = "error"
        elif status.startswith("4"):
            level = "warning"
        entries.append(
            LogEntry(
                file=file_name,
                index=idx,
                raw=stripped,
                template=template,
                level=level,
                source_ip=ip,
                extras=extras,
            )
        )
    return entries


def parse_app(lines: Iterable[str], file_name: str) -> List[LogEntry]:
    entries: List[LogEntry] = []
    for idx, raw in enumerate(lines):
        stripped = raw.rstrip("\n")
        if not stripped:
            continue
        template = build_template(stripped)
        level = parse_level_generic(stripped)
        ip = first_ip(stripped)
        entries.append(
            LogEntry(
                file=file_name,
                index=idx,
                raw=stripped,
                template=template,
                level=level,
                source_ip=ip,
                extras={},
            )
        )
    return entries


def parse_logs(files: List[str], log_type: str) -> List[LogEntry]:
    all_entries: List[LogEntry] = []
    parser = {
        "ssh": parse_ssh,
        "web": parse_web,
        "app": parse_app,
    }.get(log_type, parse_app)

    for path in files:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            entries = parser(f, os.path.basename(path))
            all_entries.extend(entries)
    return all_entries


def load_recipes(path: str = "config_anomaly_recipes.json") -> Dict[str, Dict]:
    if not os.path.isfile(path):
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def load_labels(path: str = "labels.json") -> Dict[str, str]:
    if not os.path.isfile(path):
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_labels(labels: Dict[str, str], path: str = "labels.json") -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(labels, f, indent=2, ensure_ascii=False)


def score_anomalies(entries: List[LogEntry], recipes: Dict[str, Dict], labels: Dict[str, str]) -> List[Anomaly]:
    from collections import Counter

    template_counts = Counter(e.template for e in entries)
    anomalies: List[Anomaly] = []

    # compile recipe regexes
    compiled_recipes: List[Tuple[re.Pattern, Dict]] = []
    for name, rule in recipes.items():
        pattern = rule.get("pattern")
        if not pattern:
            continue
        try:
            compiled_recipes.append((re.compile(pattern, re.IGNORECASE), rule))
        except re.error:
            continue

    for e in entries:
        reasons: List[str] = []
        score = 0.0

        # skip templates known as benign
        label_key = f"{e.file}|{e.template}"
        if labels.get(label_key) == "benign":
            continue

        count = template_counts[e.template]
        if count == 1:
            reasons.append("unique_template")
            score += 1.0
        elif count <= 3:
            reasons.append("rare_template")
            score += 0.7

        if e.level in {"error", "critical"}:
            reasons.append(f"level_{e.level}")
            score += 0.8
        elif e.level == "warning":
            reasons.append("level_warning")
            score += 0.4

        # recipe matches
        for cre, rule in compiled_recipes:
            if cre.search(e.raw):
                tag = rule.get("tag", "recipe_match")
                reasons.append(tag)
                score += float(rule.get("score", 1.0))

        if score >= 1.0:
            anomalies.append(Anomaly(entry=e, score=round(score, 3), reasons=reasons))

    anomalies.sort(key=lambda a: (-a.score, a.entry.file, a.entry.index))
    return anomalies


def write_report(anomalies: List[Anomaly], out_path: str) -> None:
    with open(out_path, "w", encoding="utf-8") as f:
        f.write("# Log Anomaly Studio report\n\n")
        if not anomalies:
            f.write("No strong anomalies found based on current rules and labels.\n")
            return
        f.write(f"Total anomaly candidates: {len(anomalies)}\n\n")
        for a in anomalies:
            e = a.entry
            f.write(f"## {e.file} line {e.index}\n\n")
            f.write(f"* Score: `{a.score}`\n")
            f.write(f"* Level: `{e.level}`\n")
            if e.source_ip:
                f.write(f"* Source IP: `{e.source_ip}`\n")
            if a.reasons:
                f.write(f"* Reasons: {', '.join(a.reasons)}\n")
            f.write("\n")
            f.write("```text\n")
            f.write(e.raw + "\n")
            f.write("```\n\n")


def interactive_label(anomalies: List[Anomaly], labels: Dict[str, str]) -> None:
    print("Entering interactive labelling mode.")
    print("Press 's' = suspicious, 'b' = benign, Enter = skip, 'q' = quit.\n")

    for a in anomalies:
        e = a.entry
        label_key = f"{e.file}|{e.template}"
        if label_key in labels:
            continue

        print("=" * 60)
        print(f"File: {e.file} line {e.index}")
        print(f"Score: {a.score}  Level: {e.level}  Reasons: {', '.join(a.reasons)}")
        print(e.raw)
        choice = input("[s]uspicious / [b]enign / [Enter] skip / [q]uit: ").strip().lower()
        if choice == "q":
            break
        if choice == "s":
            labels[label_key] = "suspicious"
        elif choice == "b":
            labels[label_key] = "benign"
        # skip otherwise

    save_labels(labels)
    print("Labels saved to labels.json")


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's Log Anomaly Studio")
    parser.add_argument(
        "--type",
        choices=["ssh", "web", "app", "default"],
        default="default",
        help="Log type for parsing (default: app).",
    )
    parser.add_argument(
        "--files",
        nargs="+",
        required=True,
        help="One or more log files to analyse.",
    )
    parser.add_argument(
        "--out",
        default="anomaly_report.md",
        help="Markdown report path (default: anomaly_report.md).",
    )
    parser.add_argument(
        "--interactive",
        action="store_true",
        help="If set, enter interactive labelling mode after scoring.",
    )
    args = parser.parse_args()

    log_type = args.type if args.type != "default" else "app"

    entries = parse_logs(args.files, log_type)
    recipes = load_recipes()
    labels = load_labels()
    anomalies = score_anomalies(entries, recipes, labels)

    write_report(anomalies, args.out)
    print(f"Report written to {args.out}")
    print(f"Anomaly candidates: {len(anomalies)}")

    if args.interactive and anomalies:
        interactive_label(anomalies, labels)


if __name__ == "__main__":
    main()
