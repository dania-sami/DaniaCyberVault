from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Any, List

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"

TERRAFORM_STATE = DATA_DIR / "terraform_state.json"
CLOUD_STATE = DATA_DIR / "cloud_state.json"


def load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def analyse_drift(desired: Dict[str, Any], actual: Dict[str, Any]) -> List[str]:
    findings: List[str] = []
    desired_resources = {r["id"]: r for r in desired.get("resources", [])}
    actual_resources = {r["id"]: r for r in actual.get("resources", [])}

    for rid, desired_res in desired_resources.items():
        actual_res = actual_resources.get(rid)
        if not actual_res:
            findings.append(f"{rid}: MISSING in actual cloud (resource may have been deleted).")
            continue

        if desired_res.get("type") == "security_group":
            dp = set(desired_res.get("open_ports", []))
            ap = set(actual_res.get("open_ports", []))
            new_ports = ap - dp
            closed_ports = dp - ap
            if new_ports:
                severity = "HIGH" if any(p in (22, 3389) for p in new_ports) else "MEDIUM"
                findings.append(
                    f"{rid}: NEW open ports in cloud {sorted(new_ports)} (risk={severity})."
                )
            if closed_ports:
                findings.append(f"{rid}: ports {sorted(closed_ports)} were closed in cloud (risk decrease).")

        if desired_res.get("type") == "storage_bucket":
            if desired_res.get("public") is False and actual_res.get("public") is True:
                findings.append(f"{rid}: bucket became PUBLIC in cloud (risk=HIGH).")
            if desired_res.get("logging_enabled") and not actual_res.get("logging_enabled"):
                findings.append(f"{rid}: logging disabled in cloud (risk=MEDIUM).")

    for rid in actual_resources.keys():
        if rid not in desired_resources:
            findings.append(f"{rid}: unmanaged resource exists only in cloud (potential shadow resource).")

    return findings


def main() -> None:
    desired = load_json(TERRAFORM_STATE)
    actual = load_json(CLOUD_STATE)

    print("IaC Drift and Risk Detector")
    print("===========================\n")

    findings = analyse_drift(desired, actual)
    if not findings:
        print("No drift detected between desired and actual state.")
        return

    for f in findings:
        print(f"- {f}")


if __name__ == "__main__":
    main()
