# Infrastructure-as-Code Drift and Risk Detector

Hi, I am Dania 👋

This project is my **IaC drift + risk detector**:

- I compare a mock Terraform-style state file with a mock cloud state.
- I highlight **drift** (manual changes in the cloud).
- I classify drifts as risk-increasing (open ports, disabled logging, new public exposure).

It is a clear way to talk about **config drift and risk** without any real cloud access.

## How to run

```bash
cd iac_drift_risk_detector

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt   # stdlib only

python -m src.scan
```

The tool prints a list of drifts and a simple risk rating for each.
