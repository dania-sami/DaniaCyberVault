"""
SOC Copilot for Alert Summaries

This script reads a JSON lines file with alerts
groups related alerts into incidents
and writes a JSON file plus a Markdown report

The aim is to help a human analyst by turning noisy alerts
into a small set of incident stories
"""

import argparse
import json
import os
from dataclasses import dataclass, asdict, field
from datetime import datetime, timedelta
from typing import List, Dict, Optional


@dataclass
class Alert:
    timestamp: datetime
    raw_timestamp: str
    host: str
    user: str
    rule: str
    severity: str
    message: str
    raw: dict


@dataclass
class Incident:
    id: str
    host: str
    start: datetime
    end: datetime
    alerts: List[Alert] = field(default_factory=list)

    @property
    def users(self) -> List[str]:
        return sorted({a.user for a in self.alerts if a.user})

    @property
    def rules(self) -> List[str]:
        return sorted({a.rule for a in self.alerts if a.rule})

    @property
    def severities(self) -> List[str]:
        return sorted({a.severity for a in self.alerts if a.severity})

    @property
    def max_severity(self) -> str:
        rank = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}
        best = "info"
        best_score = -1
        for s in self.severities:
            score = rank.get(s.lower(), 0)
            if score > best_score:
                best = s
                best_score = score
        return best


def parse_timestamp(value: str) -> datetime:
    """
    Try to parse a timestamp in a few common ISO like formats
    """
    for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(value, fmt)
        except ValueError:
            continue
    # fallback to fromisoformat
    try:
        return datetime.fromisoformat(value)
    except Exception:
        # last resort current time
        return datetime.utcnow()


def load_alerts(path: str) -> List[Alert]:
    alerts: List[Alert] = []
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue
            ts_raw = str(obj.get("timestamp", ""))
            ts = parse_timestamp(ts_raw) if ts_raw else datetime.utcnow()
            host = str(obj.get("host", "unknown_host"))
            user = str(obj.get("user", "") or "")
            rule = str(obj.get("rule", "generic alert"))
            sev = str(obj.get("severity", "info")).lower()
            msg = str(obj.get("message", "") or "")
            alerts.append(
                Alert(
                    timestamp=ts,
                    raw_timestamp=ts_raw,
                    host=host,
                    user=user,
                    rule=rule,
                    severity=sev,
                    message=msg,
                    raw=obj,
                )
            )
    alerts.sort(key=lambda a: a.timestamp)
    return alerts


def group_incidents(alerts: List[Alert], window_minutes: int = 15) -> List[Incident]:
    """
    Group alerts by host and time window

    If two alerts on the same host are within window_minutes of each other
    they are placed into the same incident
    """
    incidents: List[Incident] = []
    window = timedelta(minutes=window_minutes)

    # group by host first
    by_host: Dict[str, List[Alert]] = {}
    for a in alerts:
        by_host.setdefault(a.host, []).append(a)

    incident_counter = 1

    for host, host_alerts in by_host.items():
        current_incident: Optional[Incident] = None

        for a in host_alerts:
            if current_incident is None:
                current_incident = Incident(
                    id=f"INC{incident_counter:04d}",
                    host=host,
                    start=a.timestamp,
                    end=a.timestamp,
                    alerts=[a],
                )
                incident_counter += 1
                continue

            # same host always true here, check time gap
            gap = a.timestamp - current_incident.end
            if gap <= window:
                current_incident.alerts.append(a)
                if a.timestamp > current_incident.end:
                    current_incident.end = a.timestamp
            else:
                incidents.append(current_incident)
                current_incident = Incident(
                    id=f"INC{incident_counter:04d}",
                    host=host,
                    start=a.timestamp,
                    end=a.timestamp,
                    alerts=[a],
                )
                incident_counter += 1

        if current_incident is not None:
            incidents.append(current_incident)

    # sort all incidents by start time
    incidents.sort(key=lambda inc: inc.start)
    return incidents


def build_summary(incidents: List[Incident]) -> str:
    total_incidents = len(incidents)
    total_alerts = sum(len(i.alerts) for i in incidents)

    # severity distribution
    sev_counts: Dict[str, int] = {}
    for inc in incidents:
        s = inc.max_severity.lower()
        sev_counts[s] = sev_counts.get(s, 0) + 1

    lines: List[str] = []
    lines.append(f"The run found {total_incidents} incident(s) made up of {total_alerts} alert(s) in total.")
    if sev_counts:
        sev_parts = [f"{v} {k}" for k, v in sorted(sev_counts.items(), key=lambda t: t[0])]
        lines.append("Incidents by highest severity: " + ", ".join(sev_parts) + ".")
    if total_incidents == 0:
        lines.append("No incidents were found. The alert stream may be quiet or filtering may be too strict.")
    return " ".join(lines)


def triage_hint(incident: Incident) -> str:
    """
    Produce a small human style triage suggestion
    based on the incident content
    """
    sev = incident.max_severity.lower()
    rules = [r.lower() for r in incident.rules]

    if "ransomware" in " ".join(rules):
        return "Prioritise this incident. Check for encryption activity, isolate the host and collect forensic data."

    if any("powershell" in r for r in rules):
        return "Review recent PowerShell commands on this host and confirm whether the activity is expected by IT."

    if any("logon" in r or "login" in r for r in rules):
        return "Check for unusual login locations or times and consider forcing a password reset for the affected user."

    if sev in {"critical", "high"}:
        return "Treat this as a high priority incident and involve the on call analyst or incident handler."

    if sev in {"medium"}:
        return "Review this incident during the current shift and decide if a deeper investigation is needed."

    return "Can be reviewed during routine monitoring unless additional context raises the priority."


def generate_markdown_report(incidents: List[Incident], window_minutes: int) -> str:
    lines: List[str] = []
    lines.append("# SOC copilot incident summary")
    lines.append("")
    lines.append(f"_Incidents built with a correlation window of {window_minutes} minute(s)_")
    lines.append("")
    lines.append("## 1 Overview")
    lines.append("")
    lines.append(build_summary(incidents))
    lines.append("")

    lines.append("## 2 Incidents")
    lines.append("")
    if not incidents:
        lines.append("No incidents to show.")
        return "\n".join(lines)

    for inc in incidents:
        lines.append(f"### {inc.id} on host {inc.host}")
        lines.append("")
        lines.append(f"- Time window: `{inc.start.isoformat()} to {inc.end.isoformat()}`")
        lines.append(f"- Alert count: `{len(inc.alerts)}`")
        if inc.users:
            lines.append(f"- Users: {', '.join(inc.users)}")
        if inc.rules:
            lines.append(f"- Rules: {', '.join(inc.rules)}")
        lines.append(f"- Highest severity: **{inc.max_severity}**")
        lines.append("")
        lines.append("**Triage hint**")
        lines.append("")
        lines.append(triage_hint(inc))
        lines.append("")
        lines.append("**Timeline**")
        lines.append("")
        for a in inc.alerts:
            lines.append(f"* `{a.timestamp.isoformat()}` `{a.severity}` `{a.rule}` user `{a.user or '-'}'")
            if a.message:
                lines.append(f"  - {a.message}")
        lines.append("")

    return "\n".join(lines)


def incidents_to_json(incidents: List[Incident]) -> Dict:
    return {
        "incidents": [
            {
                "id": inc.id,
                "host": inc.host,
                "start": inc.start.isoformat(),
                "end": inc.end.isoformat(),
                "max_severity": inc.max_severity,
                "users": inc.users,
                "rules": inc.rules,
                "alerts": [
                    {
                        "timestamp": a.timestamp.isoformat(),
                        "raw_timestamp": a.raw_timestamp,
                        "host": a.host,
                        "user": a.user,
                        "rule": a.rule,
                        "severity": a.severity,
                        "message": a.message,
                        "raw": a.raw,
                    }
                    for a in inc.alerts
                ],
            }
            for inc in incidents
        ]
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Group alerts into incidents and generate summaries for SOC style work."
    )
    parser.add_argument(
        "--alerts",
        required=True,
        help="Path to a JSON lines file with alerts.",
    )
    parser.add_argument(
        "--out-dir",
        default="runs",
        help="Directory prefix for outputs (default: runs).",
    )
    parser.add_argument(
        "--window-minutes",
        type=int,
        default=15,
        help="Time window in minutes for grouping alerts into incidents (default: 15).",
    )

    args = parser.parse_args()

    alerts_path = args.alerts
    if not os.path.isfile(alerts_path):
        raise SystemExit(f"Alerts file not found: {alerts_path}")

    alerts = load_alerts(alerts_path)
    incidents = group_incidents(alerts, window_minutes=args.window_minutes)

    # Build output paths
    base = args.out_dir.rstrip("/")

    os.makedirs(base, exist_ok=True)

    json_path = f"{base}_incidents.json"
    md_path = f"{base}_incidents_report.md"

    # Write JSON
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(incidents_to_json(incidents), f, indent=2)
    print(f"Wrote incidents JSON to {json_path}")

    # Write Markdown
    report_md = generate_markdown_report(incidents, args.window_minutes)
    with open(md_path, "w", encoding="utf-8") as f:
        f.write(report_md)
    print(f"Wrote Markdown report to {md_path}")


if __name__ == "__main__":
    main()
