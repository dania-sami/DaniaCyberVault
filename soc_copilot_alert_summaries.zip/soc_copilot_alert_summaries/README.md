# SOC Copilot for Alert Summaries

Hi

This is a small sidecar style tool I built to practice security operations work

It reads a stream of alerts from a SIEM or EDR export
groups related alerts into incidents
and then writes short human summaries with a rough incident timeline

It does not connect to any live system
You give it a JSON lines file with alerts
and it produces a Markdown report and a JSON file with incidents

The main goal is to show that I understand how alert correlation works
and how to turn noisy alerts into something a human analyst can actually read

## What it expects as input

The tool expects a simple JSON lines file
Each line is one alert
For example

{"timestamp": "2025-10-01T10:00:01", "host": "win10-client-01", "user": "ALICE", "rule": "Suspicious PowerShell", "severity": "high", "message": "Encoded PowerShell command executed"}

At minimum it understands these fields

* timestamp ISO style string
* host name or endpoint id
* user optional
* rule an alert name or id
* severity low medium high critical info
* message free text description

If some fields are missing it still tries to work with what it has

## What it actually does

* Reads all alerts from the file
* Sorts them by time
* Groups alerts into incidents by host and time window
  * if alerts on the same host are close in time they go into the same incident
* For each incident it
  * collects unique users rules and severities
  * finds the earliest and latest timestamps
  * builds a small human summary with suggested triage steps
  * builds a simple timeline of the alerts

It then writes

* incidents.json structured incidents for scripting and automation
* incidents_report.md a human readable report

## How to run

1 Clone or unzip this project somewhere

2 Make sure you have Python 3 installed

3 Optional but nice

   pip install -r requirements.txt

   The script uses only the Python standard library

4 Look at the example alerts file

   examples_alerts_sample.jsonl

5 Run the tool on the example file

   python soc_copilot.py \
       --alerts examples_alerts_sample.jsonl \
       --out-dir runs_demo

6 Open runs_demo_incidents_report.md

You will see

* a short summary of how many incidents were found
* each incident with host severity users and rules
* a small timeline of the related alerts

## Why this project is interesting

Most real SOC work is not about one huge fancy detection
It is about pulling together many small alerts into a story

With this project I can show that I

* understand basic alert fields and severities
* know how to correlate alerts into incidents
* can create clear written summaries for analysts and stakeholders
* can structure Python code that would be easy to extend with real SIEM exports

Future ideas

* add support for CSV input and Sysmon style event fields
* plug this into a small web dashboard to browse incidents
* add basic machine learning on top for incident classification

