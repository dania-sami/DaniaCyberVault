from __future__ import annotations

import argparse
from typing import List

import requests


def scan_url(url: str) -> None:
    print(f"\n=== Scanning {url} ===")
    try:
        resp = requests.options(
            url,
            headers={
                "Origin": "https://evil.example",
                "Access-Control-Request-Method": "GET",
            },
            timeout=10,
        )
    except Exception as e:
        print(f"[ERROR] Request failed: {e}")
        return

    acao = resp.headers.get("Access-Control-Allow-Origin", "")
    acac = resp.headers.get("Access-Control-Allow-Credentials", "")
    vary = resp.headers.get("Vary", "")

    print(f"Status: {resp.status_code}")
    print(f"Access-Control-Allow-Origin: {acao!r}")
    print(f"Access-Control-Allow-Credentials: {acac!r}")
    print(f"Vary: {vary!r}")

    origin = "https://evil.example"

    if acao == "*":
        print("[HIGH] ACAO is '*', which is often unsafe for sensitive endpoints.")
    elif acao == origin:
        print("[WARN] ACAO reflects the potentially untrusted Origin.")
    elif not acao:
        print("[INFO] No ACAO header; CORS is not enabled here.")

    if acac.lower() == "true" and acao in ("*", origin):
        print("[HIGH] Credentials allowed with overly permissive ACAO.")

    if acao and "Origin" not in vary and "*" not in acao:
        print("[WARN] Vary: Origin is missing; caching proxies may create issues.")


def main() -> None:
    parser = argparse.ArgumentParser(description="CORS misconfiguration hunter")
    parser.add_argument("--url", type=str, help="Single URL to test")
    parser.add_argument("--file", type=str, help="File with list of URLs")
    args = parser.parse_args()

    urls: List[str] = []
    if args.url:
        urls.append(args.url)
    if args.file:
        with open(args.file, "r", encoding="utf-8") as f:
            for line in f:
                u = line.strip()
                if u:
                    urls.append(u)

    if not urls:
        print("No URLs provided. Use --url or --file.")
        return

    for u in urls:
        scan_url(u)


if __name__ == "__main__":
    main()
