# Web App CORS Misconfiguration Hunter

Hi, I am Dania Sami 👋

Cross-Origin Resource Sharing (CORS) misconfigurations are a very common
web security issue. Sometimes a single wrong header can expose sensitive APIs
to untrusted origins.

I built this tool as a small **CORS misconfiguration hunter** that:

- sends test requests with different `Origin` values
- inspects `Access-Control-Allow-Origin` and friends
- reports patterns that look unsafe (like `*` or overly broad origins)

This is designed as a **command-line helper for security reviews**, not a
massive scanner.

---

## What this tool does

1. **Takes a target URL or list of URLs**

   - A single `--url` argument
   - Or a `targets.txt` file with one URL per line in the `data/` directory

2. **Sends an `OPTIONS` preflight request**

   It adds headers:

   - `Origin: https://evil.example`
   - `Access-Control-Request-Method: GET`

3. **Examines CORS response headers**

   It checks for:

   - `Access-Control-Allow-Origin` with `*`
   - `Access-Control-Allow-Origin` mirroring the attacker origin
   - missing `Vary: Origin`
   - overly permissive `Access-Control-Allow-Credentials`

4. **Prints a verdict per URL**

   The output groups issues into `INFO`, `WARN`, and `HIGH` for quick reading.

---

## How to run

You need Python 3.10+ and network access for the URLs you want to test.

```bash
python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt
```

### Scan a single URL

```bash
python -m src.hunt --url https://example.com/api
```

### Scan a list of URLs

Put them into `data/targets.txt`, then:

```bash
python -m src.hunt --file data/targets.txt
```

---

## Project structure

```text
cors_misconfig_hunter/
  ├─ README.md
  ├─ requirements.txt
  ├─ data/
  │    └─ targets.txt
  └─ src/
       ├─ __init__.py
       └─ hunt.py
```

---

## Why I built this

CORS is subtle and often misunderstood. This tool lets me demonstrate that I:

- understand how browsers enforce CORS
- know what "bad" patterns look like
- can build small, focused tools that help with manual web security reviews
