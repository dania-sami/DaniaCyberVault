
from fastapi import FastAPI
from pydantic import BaseModel
from typing import Dict
from .engine import Engine

app=FastAPI(title="spectrarf-rogue-frequency-sentinel",description="Dania's project",version="1.0")
engine=Engine()

class Input(BaseModel):
    metrics: Dict[str,float]

class Output(BaseModel):
    score: float
    label: str
    reasons: list

@app.post("/analyse",response_model=Output)
def analyse(inp:Input):
    r=engine.analyse(inp.metrics)
    return Output(score=r.score,label=r.label,reasons=r.reasons)
