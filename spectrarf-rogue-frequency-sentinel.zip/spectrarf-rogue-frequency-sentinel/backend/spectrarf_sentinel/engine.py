
from dataclasses import dataclass
from typing import Dict, List

@dataclass
class AnalysisResult:
    score: float
    label: str
    reasons: List[str]

class Engine:
    def analyse(self, data: Dict) -> AnalysisResult:
        score=0; reasons=[]
        for k,v in data.items():
            if isinstance(v,(int,float)) and v>0.7:
                score+=20; reasons.append(f"High anomaly in {k}")
        score=min(100,score)
        label="low"
        if score>70: label="critical"
        elif score>40: label="high"
        elif score>20: label="medium"
        return AnalysisResult(score,label,reasons or ["No strong indicators"])
