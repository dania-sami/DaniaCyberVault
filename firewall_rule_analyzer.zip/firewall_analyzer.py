import argparse
import json
from typing import List, Dict, Any

def load_rules(path: str) -> List[Dict[str, Any]]:
    with open(path) as f:
        return json.load(f)

def find_duplicates(rules: List[Dict[str, Any]]):
    seen = {}
    duplicates = []
    for r in rules:
        key = (
            r.get("action", ""),
            r.get("src", ""),
            r.get("dst", ""),
            r.get("protocol", ""),
            r.get("port", ""),
        )
        if key in seen:
            duplicates.append((seen[key], r))
        else:
            seen[key] = r
    return duplicates

def find_broad_allows(rules: List[Dict[str, Any]]):
    broad = []
    for r in rules:
        if r.get("action") != "allow":
            continue
        src = r.get("src", "").lower()
        dst = r.get("dst", "").lower()
        proto = r.get("protocol", "").lower()
        port = str(r.get("port", "")).lower()

        if src in ("any", "0.0.0.0/0") and dst in ("any", "0.0.0.0/0"):
            broad.append(r)
            continue

        if port in ("any", "0-65535") and proto in ("any", "all"):
            broad.append(r)
    return broad

def main():
    parser = argparse.ArgumentParser(description="Firewall Rule Analyzer by Dania")
    parser.add_argument("--rules", required=True, help="Path to rules JSON file")
    args = parser.parse_args()

    rules = load_rules(args.rules)
    print(f"[+] Loaded {len(rules)} rules\n")

    # Duplicates
    dups = find_duplicates(rules)
    if dups:
        print("[+] Duplicate rules:")
        for r1, r2 in dups:
            print(f"    Rules {r1.get('id')} and {r2.get('id')} look identical")
        print()
    else:
        print("[+] No exact duplicate rules found.\n")

    # Broad allows
    broad = find_broad_allows(rules)
    if broad:
        print("[!] Broad allow rules:")
        for r in broad:
            print(
                f"    Rule {r.get('id')} looks very broad: "
                f"{r.get('action')} {r.get('src')} -> {r.get('dst')} "
                f"{r.get('protocol')}/{r.get('port')}"
            )
    else:
        print("[+] No obviously broad allow rules found.")

if __name__ == "__main__":
    main()
