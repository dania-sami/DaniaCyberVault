# Firewall Rule Analyzer

This project is a small helper script I use to review firewall rule sets.

The script reads a JSON file with firewall rules and looks for a few things that are interesting from a security point of view, like duplicate rules and very broad allow rules that can be risky if they sit near the top of the list.

It is not a full blown firewall manager, but it shows that I understand how rules are processed and what can go wrong with misconfiguration.

## What it checks

- Duplicate rules (same action, src, dst, protocol and port)
- "Any to any allow" rules (very broad allow)
- Rules that allow all ports on all protocols

## Rule format

Rules live in a JSON file like this:

```json
[
  {
    "id": 1,
    "action": "allow",
    "src": "10.0.0.0/24",
    "dst": "10.0.1.10",
    "protocol": "tcp",
    "port": "22"
  }
]
```

The `sample_rules.json` file in this project shows a more complete example.

## Usage

```bash
python firewall_analyzer.py --rules sample_rules.json
```

Example output:

```text
[+] Loaded 6 rules

[+] Duplicate rules:
    Rules 2 and 3 look identical

[!] Broad allow rules:
    Rule 4 looks very broad: allow any -> any any/any
```

## Why I like this project

- It is small but clearly security focused
- It shows thinking about misconfiguration and least privilege
- It is easy to extend with more checks in the future
