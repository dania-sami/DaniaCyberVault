import json, argparse

def load_env(path):
    with open(path) as f: return json.load(f)

def analyze(env):
    findings=[]
    resources=env["resources"]
    for r in resources:
        if r["type"]=="bucket" and r.get("public") and r.get("contains_sensitive"):
            findings.append(("High",f"Public bucket {r['name']} contains sensitive data"))
        if r["type"]=="role" and r.get("is_admin") and r.get("reachable_from_exposed"):
            findings.append(("High",f"Admin role {r['name']} reachable from exposed asset"))
        if r["type"]=="service" and "*" in r.get("permissions",[]):
            findings.append(("Medium",f"Service {r['name']} has wildcard permissions"))
    return findings

def write_report(findings,out):
    with open(out,"w") as f:
        f.write("# Misconfiguration Report

")
        if not findings:
            f.write("No critical misconfigurations found
")
            return
        for sev,msg in findings:
            f.write(f"**{sev}** {msg}

")

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--config",required=True)
    ap.add_argument("--out",default="misconfig_report.md")
    a=ap.parse_args()
    env=load_env(a.config)
    fnds=analyze(env)
    write_report(fnds,a.out)

if __name__=="__main__":
    main()
