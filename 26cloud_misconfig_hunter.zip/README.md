# Smart Cloud Misconfiguration Hunter

This tool reads a simplified cloud inventory and detects only high impact misconfigurations:
* publicly exposed storage with sensitive data
* admin roles reachable from exposed assets
* critical services without MFA or with wildcard permissions

It outputs a Markdown report ranking findings by real world risk.
