# LLM Prompt Injection Firewall – Dania

Hi

I am Dania and this is my small firewall for prompts before they hit an LLM

It does not try to be perfect  but it catches common jailbreak tricks  system override attempts and obvious prompt injection patterns

You can point it at a file of prompts or send a single prompt and it will tell you

* allow or block
* which rules fired
* a short reason

I imagine this sitting in front of chatbots or agents as a safety layer that is easy to tune and extend
