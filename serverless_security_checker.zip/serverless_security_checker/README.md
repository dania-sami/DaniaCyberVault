# Serverless Security Checker – Dania

Hi

I am Dania and this checker looks at serverless function configs and highlights risky patterns

It reads a JSON description of functions and flags things like

* secrets hardcoded in environment variables
* overly broad IAM actions
* functions that are public and can reach sensitive services

The goal is to make a quick offline review tool that is easy to explain and extend
