"""
Serverless Security Checker – Dania

Offline static analysis for serverless configuration JSON.
No interaction with any real cloud provider.
"""

import argparse
import json
from dataclasses import dataclass, asdict
from typing import List, Dict


SUS_ENV_KEYS = ["password", "secret", "token", "key"]
WILDCARD_ACTION = "*"


@dataclass
class FunctionConfig:
    name: str
    runtime: str
    public: bool
    env: Dict[str, str]
    iam_actions: List[str]
    touches_sensitive_data: bool


@dataclass
class Finding:
    function: str
    category: str
    details: str
    severity: str


def load_functions(path: str) -> List[FunctionConfig]:
    with open(path, "r", encoding="utf-8") as f:
        raw = json.load(f)
    out: List[FunctionConfig] = []
    for fn in raw.get("functions", []):
        out.append(
            FunctionConfig(
                name=fn["name"],
                runtime=fn.get("runtime", "unknown"),
                public=bool(fn.get("public", False)),
                env=fn.get("env", {}),
                iam_actions=[str(a) for a in fn.get("iam_actions", [])],
                touches_sensitive_data=bool(fn.get("touches_sensitive_data", False)),
            )
        )
    return out


def analyse(funcs: List[FunctionConfig]) -> List[Finding]:
    findings: List[Finding] = []
    for fn in funcs:
        # env secrets
        for k, v in fn.env.items():
            lk = k.lower()
            if any(s in lk for s in SUS_ENV_KEYS):
                if v and v.lower() not in ["placeholder", "example"]:
                    findings.append(
                        Finding(
                            function=fn.name,
                            category="env_secret",
                            details=f"Environment variable {k} looks like it may contain a secret.",
                            severity="high",
                        )
                    )
        # wildcard actions
        if any(a.strip() == WILDCARD_ACTION for a in fn.iam_actions):
            findings.append(
                Finding(
                    function=fn.name,
                    category="iam_wildcard",
                    details="IAM actions contain a wildcard *  consider scoping to specific APIs.",
                    severity="high",
                )
            )

        # public + sensitive
        if fn.public and fn.touches_sensitive_data:
            findings.append(
                Finding(
                    function=fn.name,
                    category="public_sensitive",
                    details="Function is public and touches sensitive data.",
                    severity="high",
                )
            )

    return findings


def write_outputs(findings: List[Finding], md_path: str, json_path: str) -> None:
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump([asdict(x) for x in findings], f, indent=2)

    with open(md_path, "w", encoding="utf-8") as f:
        f.write("# Serverless security findings\n\n")
        f.write(f"* Total findings: {len(findings)}\n\n")
        for fd in findings:
            f.write(f"- {fd.function}  [{fd.severity}] {fd.category} – {fd.details}\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's serverless security checker")
    parser.add_argument("--config", default="example_functions.json", help="Functions config JSON")
    parser.add_argument("--out-prefix", default="serverless", help="Output prefix")
    args = parser.parse_args()

    funcs = load_functions(args.config)
    findings = analyse(funcs)
    md_path = f"{args.out_prefix}_findings.md"
    json_path = f"{args.out_prefix}_findings.json"
    write_outputs(findings, md_path, json_path)

    print(f"Analysed {len(funcs)} functions  produced {len(findings)} findings.")
    print(f"Wrote Markdown to {md_path}")


if __name__ == "__main__":
    main()
