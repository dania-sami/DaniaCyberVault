
import argparse
import csv
import random
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path

DATA_DIR = Path("data")


def gen_demo_events():
    random.seed(42)
    DATA_DIR.mkdir(exist_ok=True)
    base_time = datetime(2025, 1, 1, 12, 0, 0)
    rows = []
    victims = ["10.0.0.10", "10.0.0.20"]
    src_ips = [f"203.0.113.{i}" for i in range(1, 6)]

    for i in range(200):
        t = base_time + timedelta(seconds=i * random.randint(1, 5))
        src = random.choice(src_ips)
        dst = random.choice(victims)
        kind = random.choices(
            ["normal", "sql_injection", "xss", "malware_beacon"],
            weights=[0.7, 0.1, 0.1, 0.1],
        )[0]

        if kind == "normal":
            path = random.choice(["/", "/home", "/products", "/blog"])
            ua = random.choice(["Mozilla/5.0", "Chrome/122", "Safari/17"])
        elif kind == "sql_injection":
            path = "/search?q=' OR 1=1 --"
            ua = "sqlmap/1.5"
        elif kind == "xss":
            path = "/profile?name=<script>alert(1)</script>"
            ua = "Mozilla/5.0"
        else:
            path = "/beacon"
            ua = "malware-bot/0.1"

        rows.append({
            "timestamp": t.isoformat(),
            "src_ip": src,
            "dst_ip": dst,
            "event_type": kind,
            "http_path": path,
            "user_agent": ua,
        })

    rows.sort(key=lambda r: r["timestamp"])
    out_path = DATA_DIR / "events.csv"
    with out_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    print(f"[info] Demo events written to {out_path}")


def correlate():
    in_path = DATA_DIR / "events.csv"
    if not in_path.is_file():
        raise SystemExit(f"Events file not found: {in_path} (run demo first)")

    with in_path.open("r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        events = list(reader)

    by_src = defaultdict(list)
    for e in events:
        by_src[e["src_ip"]].append(e)

    incidents = []
    for src, evs in by_src.items():
        types = [e["event_type"] for e in evs]
        counts = {t: types.count(t) for t in set(types)}
        has_malware = counts.get("malware_beacon", 0) >= 3
        has_sqli = counts.get("sql_injection", 0) >= 3
        has_xss = counts.get("xss", 0) >= 3

        if has_malware:
            incidents.append({
                "src_ip": src,
                "category": "C2_activity",
                "detail": f"{counts.get('malware_beacon', 0)} malware beacons observed",
            })
        if has_sqli or has_xss:
            incidents.append({
                "src_ip": src,
                "category": "web_attack",
                "detail": f"SQLi={counts.get('sql_injection', 0)}, XSS={counts.get('xss', 0)} attempts",
            })
        if has_malware and (has_sqli or has_xss):
            incidents.append({
                "src_ip": src,
                "category": "multi_stage_campaign",
                "detail": "Web exploitation combined with C2-like beacons",
            })

    out_path = DATA_DIR / "incidents.csv"
    if incidents:
        with out_path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(incidents[0].keys()))
            writer.writeheader()
            writer.writerows(incidents)
        print(f"[info] Wrote {len(incidents)} incidents to {out_path}")
        print("[info] Incidents:")
        for inc in incidents:
            print(f"  {inc['src_ip']:15} {inc['category']:20} {inc['detail']}")
    else:
        print("[info] No correlated incidents for this dataset.")


def main():
    parser = argparse.ArgumentParser(description="Network threat replay sandbox")
    parser.add_argument("mode", choices=["demo"], help="Run demo generation and correlation")
    args = parser.parse_args()

    if args.mode == "demo":
        gen_demo_events()
        correlate()


if __name__ == "__main__":
    import argparse
    main()
