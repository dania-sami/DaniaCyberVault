
# Network Threat Replay Sandbox (Mini SIEM Simulation)

Hi, I am Dania and I built this project to simulate **replaying attack traces into a mini SIEM**.

Instead of using real PCAPs, I model events like:

- SQL injection requests
- XSS attempts
- malware beaconing to C2
- normal web requests

and then “replay” them into a simple correlation engine.

---

## What this project does

The main script is `replay_sandbox.py`. It:

1. Creates a demo event file `data/events.csv` with columns:
   - `timestamp`
   - `src_ip`
   - `dst_ip`
   - `event_type` (sql_injection, xss, malware_beacon, normal)
   - `http_path`
   - `user_agent`
2. Replays events in timestamp order and:
   - sends them into a rule engine that groups by `src_ip`
   - raises incidents when an IP:
     - performs multiple SQLi/XSS attempts
     - shows periodic malware beaconing
     - mixes web browsing with C2 like behaviour
3. Writes incidents to:
   - `data/incidents.csv`
   - and prints a small timeline.

---

## Project structure

```text
network_threat_replay_sandbox/
  README.md
  requirements.txt
  replay_sandbox.py
  data/
```

I only use the standard library.

---

## Installation

```bash
python3 -m venv venv
source venv/bin/activate            # Windows  venv\Scripts\activate
pip install -r requirements.txt
```

---

## Usage

```bash
python replay_sandbox.py demo
```

You will see:

- events being “replayed” in order
- a final list of correlated incidents per source IP

You can then open the CSV files to see exactly why each incident was raised.

---

## Why this project matters to me

Replay and correlation are key ideas in security operations and SIEM design.

With this project I can show that I:

- understand the difference between raw events and higher level incidents
- can express simple but powerful correlation logic
- can think in timelines, not just single alerts

This is exactly the mindset needed when working with real SOC tools.
