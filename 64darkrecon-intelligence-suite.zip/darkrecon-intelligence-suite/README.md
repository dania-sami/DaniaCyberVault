
# DarkRecon Intelligence Suite

DarkRecon Intelligence Suite is my compact threat intelligence workbench.

I wanted something that sits between random text files full of indicators and
heavy commercial platforms. For learning and portfolio work I only need a clean
place where I can

* collect indicators from different sources
* merge duplicates
* see which indicators are supported by multiple feeds
* quickly spot the ones that deserve attention first

DarkRecon does exactly that.

## What this service does

* accepts batches of indicators, each with a type for example ip or domain
* records first seen and last seen times
* keeps track of which sources mentioned each indicator
* calculates a simple score based on number of sources and freshness
* returns all indicators sorted by score so I can focus on the most promising ones

All logic stays in memory inside a single process, which is enough for
demonstrations and local experimentation.

## Project layout

```text
darkrecon-intelligence-suite
└── backend
    ├── darkrecon_suite
    │   ├── __init__.py
    │   ├── engine.py  Indicator model and scoring logic
    │   └── main.py    FastAPI endpoints
    ├── requirements.txt
    └── example_requests.http
```

## How I run it locally

From the backend folder

```bash
python -m venv .venv
source .venv/bin/activate        # On Windows I use .venv\Scripts\activate
pip install -r requirements.txt
uvicorn darkrecon_suite.main:app --reload --port 9403
```

Then I open

* http://localhost:9403/docs to interact with the API

## Example flow I like to show

First I send indicators from one open source feed

```bash
curl -X POST http://localhost:9403/indicators   -H "Content-Type: application/json"   -d '{
    "type": "ip",
    "values": ["203.0.113.10", "203.0.113.11"],
    "source": "osint_feed_a"
  }'
```

Then I add overlapping indicators from another source for example a darknet
scraper.

```bash
curl -X POST http://localhost:9403/indicators   -H "Content-Type: application/json"   -d '{
    "type": "ip",
    "values": ["203.0.113.11", "198.51.100.77"],
    "source": "darknet_forum_scraper"
  }'
```

Now when I list indicators

```bash
curl http://localhost:9403/indicators
```

I can see that 203.0.113.11 has a higher score because it appears in more than
one source, while others look weaker. This simple scoring captures a pattern I
often care about in real intelligence work.

## Why I like DarkRecon

It is small but very real in intent. The code shows how I think about

* data modelling of indicators
* merging and deduplication
* simple scoring for triage
* clean APIs that other tools can call

If I want to expand it I can

* add indicator types like urls, file hashes, or email addresses
* connect it to real feeds
* store data in a database
* add tagging for campaigns or threat actors

Even in this focused version it is a good demonstration of my mindset around
threat intelligence engineering.
