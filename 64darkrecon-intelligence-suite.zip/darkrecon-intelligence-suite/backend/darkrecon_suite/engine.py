
from dataclasses import dataclass
from datetime import datetime
from typing import Dict, List


@dataclass
class Indicator:
    id: int
    type: str
    value: str
    first_seen: datetime
    last_seen: datetime
    sources: List[str]
    score: float


class IntelBrain:
    """
    DarkRecon is my small threat intelligence workbench.

    It collects indicators from different sources, merges them, and calculates
    a confidence style score so that I can quickly see which indicators look
    more serious.
    """

    def __init__(self) -> None:
        self.indicators: Dict[str, Indicator] = {}
        self._next_id = 1

    def _key(self, type_: str, value: str) -> str:
        return f"{type_.lower()}|{value.strip()}"

    def add_indicators(self, type_: str, values: List[str], source: str) -> List[Indicator]:
        created: List[Indicator] = []
        for v in values:
            key = self._key(type_, v)
            now = datetime.utcnow()
            if key not in self.indicators:
                ind = Indicator(
                    id=self._next_id,
                    type=type_,
                    value=v.strip(),
                    first_seen=now,
                    last_seen=now,
                    sources=[source],
                    score=0.0,
                )
                self._next_id += 1
                self.indicators[key] = ind
            else:
                ind = self.indicators[key]
                if source not in ind.sources:
                    ind.sources.append(source)
                ind.last_seen = now
            # Update score based on number of sources and recency
            base = min(50.0, 10.0 * len(ind.sources))
            age_hours = (now - ind.first_seen).total_seconds() / 3600.0
            freshness_bonus = 20.0 if age_hours < 1 else 10.0 if age_hours < 24 else 0.0
            ind.score = min(100.0, base + freshness_bonus)
            created.append(ind)
        return created

    def list_all(self) -> List[Indicator]:
        return sorted(self.indicators.values(), key=lambda i: i.score, reverse=True)
