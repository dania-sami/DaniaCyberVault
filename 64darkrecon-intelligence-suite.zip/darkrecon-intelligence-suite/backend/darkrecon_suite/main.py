
from fastapi import FastAPI
from pydantic import BaseModel, Field
from typing import List

from .engine import IntelBrain, Indicator


brain = IntelBrain()


class IndicatorsIn(BaseModel):
    type: str = Field(..., example="ip")
    values: List[str]
    source: str = Field(..., example="osint_feed_a")


class IndicatorOut(BaseModel):
    id: int
    type: str
    value: str
    first_seen: str
    last_seen: str
    sources: List[str]
    score: float


app = FastAPI(
    title="DarkRecon Intelligence Suite",
    version="0.1.0",
    description="My threat intelligence workbench for indicators from many sources.",
)


@app.post("/indicators", response_model=List[IndicatorOut])
def add_indicators(payload: IndicatorsIn) -> List[IndicatorOut]:
    items: List[IndicatorOut] = []
    for ind in brain.add_indicators(type_=payload.type, values=payload.values, source=payload.source):
        items.append(
            IndicatorOut(
                id=ind.id,
                type=ind.type,
                value=ind.value,
                first_seen=ind.first_seen.isoformat() + "Z",
                last_seen=ind.last_seen.isoformat() + "Z",
                sources=ind.sources,
                score=ind.score,
            )
        )
    return items


@app.get("/indicators", response_model=List[IndicatorOut])
def list_indicators() -> List[IndicatorOut]:
    items: List[IndicatorOut] = []
    for ind in brain.list_all():
        items.append(
            IndicatorOut(
                id=ind.id,
                type=ind.type,
                value=ind.value,
                first_seen=ind.first_seen.isoformat() + "Z",
                last_seen=ind.last_seen.isoformat() + "Z",
                sources=ind.sources,
                score=ind.score,
            )
        )
    return items
