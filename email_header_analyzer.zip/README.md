# Email Header Analyzer (Spoofing Indicators)

This project is a small helper script I use when I want to look at raw email headers and talk about spoofing indicators.

The script expects a text file that contains only the headers (from a copy pasted email or saved from a mail client). It then looks for a few things:

- `From` and `Reply-To` differences
- Presence of SPF, DKIM and DMARC results in the `Authentication-Results` header
- Suspicious looking `Received` chain length

It does not connect to any mail server. It just parses local text files so I can reason about trust and mail hygiene.

## Files

- `email_header_analyzer.py` – main script
- `demo_headers.txt` – simple demo headers so it runs out of the box

## Usage

```bash
python email_header_analyzer.py --file demo_headers.txt
```
