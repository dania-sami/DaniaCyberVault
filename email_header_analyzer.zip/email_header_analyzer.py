import argparse
import re

def parse_headers(path: str) -> dict:
    headers = {}
    current = None
    with open(path, "r", errors="ignore") as f:
        for line in f:
            if line.strip() == "":
                break
            if line[0].isspace() and current:
                headers[current] += " " + line.strip()
                continue
            if ":" in line:
                name, value = line.split(":", 1)
                headers[name.strip()] = value.strip()
                current = name.strip()
    return headers

def analyse_headers(headers: dict):
    from_h = headers.get("From", "")
    reply_to = headers.get("Reply-To", "")
    auth_res = headers.get("Authentication-Results", "")
    received = [v for k, v in headers.items() if k.lower() == "received"]

    print("[+] Basic fields:")
    print(f"    From     : {from_h}")
    if reply_to:
        print(f"    Reply-To : {reply_to}")
    else:
        print("    Reply-To : (none)")
    print()

    if reply_to and reply_to != from_h:
        print("[!] Note: From and Reply-To differ. This can be legitimate but is worth checking.")
        print()

    print("[+] Authentication-Results:")
    if auth_res:
        print(f"    {auth_res}")
        lower = auth_res.lower()
        if "spf=fail" in lower or "dkim=fail" in lower or "dmarc=fail" in lower:
            print("    [!] One or more auth checks failed according to this header.")
    else:
        print("    (no Authentication-Results header found)")
    print()

    print(f"[+] Received headers: {len(received)}")
    if len(received) > 10:
        print("    [!] Long Received chain. For real incidents I would walk this carefully.")

def main():
    parser = argparse.ArgumentParser(description="Email Header Analyzer by Dania")
    parser.add_argument("--file", required=True, help="Path to text file with raw email headers")
    args = parser.parse_args()
    headers = parse_headers(args.file)
    analyse_headers(headers)

if __name__ == "__main__":
    main()
