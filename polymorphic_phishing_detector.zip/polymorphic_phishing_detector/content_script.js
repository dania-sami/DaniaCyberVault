// Polymorphic Phishing Detector content script

// This script runs in the context of each page
// It does two main things
// 1  Watches for calls to LLM style APIs
// 2  Watches for dynamic creation of suspicious login forms

(function() {
  const suspiciousHosts = [
    "api.openai.com",
    "openai.azure.com",
    "anthropic.com",
    "claude.ai",
    "generativelanguage.googleapis.com",
    "api.groq.com",
    "cohere.ai"
  ];

  let llmActivitySeen = false;
  let bannerShown = false;

  function hostLooksLikeLLM(url) {
    try {
      const u = new URL(url, window.location.href);
      return suspiciousHosts.some(h => u.hostname.includes(h));
    } catch (e) {
      return false;
    }
  }

  function logDebug(msg) {
    console.log("[PolymorphicPhishingDetector]", msg);
  }

  function showWarningBanner(reason) {
    if (bannerShown) {
      return;
    }
    bannerShown = true;

    const banner = document.createElement("div");
    banner.id = "ppd-warning-banner";
    banner.textContent = "Warning dynamic login form detected after LLM style activity  Treat this page with caution";
    if (reason) {
      banner.setAttribute("data-reason", reason);
    }

    document.documentElement.appendChild(banner);
  }

  // Hook fetch
  if (window.fetch) {
    const originalFetch = window.fetch.bind(window);
    window.fetch = async function(input, init) {
      try {
        const url = typeof input === "string" ? input : input.url;
        if (hostLooksLikeLLM(url)) {
          llmActivitySeen = true;
          logDebug("LLM style fetch detected to " + url);
        }
      } catch (e) {
        // ignore
      }
      return originalFetch(input, init);
    };
  }

  // Hook XMLHttpRequest
  if (window.XMLHttpRequest) {
    const OriginalXHR = window.XMLHttpRequest;
    function WrappedXHR() {
      const xhr = new OriginalXHR();
      const originalOpen = xhr.open;
      xhr.open = function(method, url, async, user, password) {
        try {
          if (hostLooksLikeLLM(url)) {
            llmActivitySeen = true;
            logDebug("LLM style XHR detected to " + url);
          }
        } catch (e) {
          // ignore
        }
        return originalOpen.apply(xhr, arguments);
      };
      return xhr;
    }
    window.XMLHttpRequest = WrappedXHR;
  }

  function looksLikeLoginForm(form) {
    const inputs = Array.from(form.querySelectorAll("input"));
    if (!inputs.length) {
      return false;
    }

    const hasPassword = inputs.some(i => (i.type || "").toLowerCase() === "password");
    const hasEmailOrUser = inputs.some(i => {
      const t = (i.type || "").toLowerCase();
      const name = (i.name || "").toLowerCase();
      const id = (i.id || "").toLowerCase();
      return t === "email" || name.includes("user") || name.includes("email") || id.includes("user") || id.includes("email");
    });

    if (hasPassword && hasEmailOrUser) {
      return true;
    }

    const text = (form.innerText || "").toLowerCase();
    if (text.includes("login") || text.includes("log in") || text.includes("sign in")) {
      return true;
    }

    return false;
  }

  function checkForSuspiciousForms(nodes) {
    if (!llmActivitySeen) {
      return;
    }

    for (const node of nodes) {
      if (!(node instanceof HTMLElement)) {
        continue;
      }

      if (node.tagName === "FORM") {
        if (looksLikeLoginForm(node)) {
          logDebug("Suspicious form detected");
          showWarningBanner("form");
          return;
        }
      }

      const forms = Array.from(node.querySelectorAll("form"));
      for (const f of forms) {
        if (looksLikeLoginForm(f)) {
          logDebug("Suspicious form detected in subtree");
          showWarningBanner("form-subtree");
          return;
        }
      }
    }
  }

  const observer = new MutationObserver(mutations => {
    const addedNodes = [];
    for (const m of mutations) {
      if (m.addedNodes && m.addedNodes.length) {
        addedNodes.push(...m.addedNodes);
      }
    }
    if (addedNodes.length) {
      checkForSuspiciousForms(addedNodes);
    }
  });

  observer.observe(document.documentElement || document.body, {
    childList: true,
    subtree: true
  });

  logDebug("Content script initialised");
})();
