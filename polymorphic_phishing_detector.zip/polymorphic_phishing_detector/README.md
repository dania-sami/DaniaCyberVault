# Polymorphic Phishing Detector for Browser Scripts

Hi

This project is a small browser extension idea I used to explore AI assisted phishing

The goal is simple

* watch JavaScript activity on a page
* notice when it talks to common LLM style APIs
* keep an eye on the DOM for new login forms or password fields that appear dynamically
* show a local warning banner if this looks suspicious

It is not meant to be a production ready security product
It is a learning project that gives me something concrete to talk about
when I say I understand browser security and AI based phishing

## What it actually does

This is a manifest v3 extension for Chromium style browsers

The content script

* hooks window.fetch and XMLHttpRequest
* records when a page calls LLM style endpoints such as api.openai.com or anthropic
* starts a MutationObserver that watches for newly added form elements
  * especially input fields of type password email or text near words like login or sign in
* if a page both
  * calls one of the LLM endpoints and
  * creates a new suspicious looking login form
  the extension shows a small red warning banner at the top of the page

All detection is local and heuristic based
The idea is to have a starting point for defending against polymorphic AI generated phishing pages

## How to install for testing

These steps are for Chrome or any Chromium based browser

1 Unzip the folder somewhere on your machine

2 In the browser open

   chrome_extensions

   and enable Developer mode

3 Click Load unpacked and select the unzipped folder that contains manifest.json

4 Open a test page and watch the console and the banner behaviour

You can simulate LLM calls by opening the console and running for example

   fetch("https_colon__slash__slash_api.openai.com_v1_chat_completions", { method "POST" })

Then dynamically add a simple login form with JavaScript and you should see the warning banner appear

## Files

* manifest.json extension definition
* content_script.js main logic
* styles.css simple styles for the banner

## Why this project is interesting

Most news about AI and phishing talks about emails
but an interesting frontier is AI generated web pages that morph in real time

With this project I can show that I

* understand basic browser extension structure
* know how to hook fetch and XMLHttpRequest in a safe way
* know how to use MutationObserver to watch for suspicious DOM changes
* can turn a research idea into a concrete proof of concept

It can be extended with

* a small popup UI to show recent alerts
* more advanced heuristics and allow lists
* export of local findings to a backend for analysis

