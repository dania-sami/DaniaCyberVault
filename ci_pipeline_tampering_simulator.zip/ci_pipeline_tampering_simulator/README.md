# CI Pipeline Tampering Simulator

Hi, I am Dania 👋

This project is my **CI pipeline tampering simulator**:

- I model a CI pipeline as a small DAG of jobs (build, test, deploy).
- Each job has security flags like:
  - runs untrusted PR code,
  - publishes artefacts,
  - uses privileged runners.
- I enumerate possible **attacker paths** from untrusted PR to production artefact.

It is a simple but strong way to talk about **supply chain and CI hardening**.

## How to run

```bash
cd ci_pipeline_tampering_simulator

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt   # stdlib only

python -m src.simulate --config data/pipeline.json
```

The simulator prints the pipeline graph and any risky attacker paths it finds.
