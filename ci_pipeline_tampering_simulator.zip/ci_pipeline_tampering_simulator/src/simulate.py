from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List


@dataclass
class Job:
    id: str
    runs_untrusted_code: bool
    publishes_artifact: bool
    privileged: bool
    depends_on: List[str]


def load_pipeline(path: Path) -> Dict[str, Job]:
    raw = json.loads(path.read_text(encoding="utf-8"))
    jobs: Dict[str, Job] = {}
    for j in raw.get("jobs", []):
        job = Job(
            id=j["id"],
            runs_untrusted_code=bool(j.get("runs_untrusted_code", False)),
            publishes_artifact=bool(j.get("publishes_artifact", False)),
            privileged=bool(j.get("privileged", False)),
            depends_on=list(j.get("depends_on", [])),
        )
        jobs[job.id] = job
    return jobs


def find_attack_paths(jobs: Dict[str, Job]):
    entries = [j for j in jobs.values() if j.runs_untrusted_code]
    goals = {j.id for j in jobs.values() if j.publishes_artifact}

    children: Dict[str, List[str]] = {jid: [] for jid in jobs.keys()}
    for j in jobs.values():
        for dep in j.depends_on:
            children.setdefault(dep, []).append(j.id)

    paths = []

    def dfs(current: Job, visited: List[str], chain: List[Job]):
        if current.id in visited:
            return
        visited.append(current.id)
        chain.append(current)

        if current.id in goals:
            paths.append(list(chain))

        for ch_id in children.get(current.id, []):
            dfs(jobs[ch_id], visited, chain)

        chain.pop()
        visited.pop()

    for entry in entries:
        dfs(entry, [], [])

    return paths


def describe_path(path: List[Job]) -> str:
    parts = []
    for job in path:
        flags = []
        if job.runs_untrusted_code:
            flags.append("untrusted_code")
        if job.privileged:
            flags.append("privileged")
        if job.publishes_artifact:
            flags.append("publishes_artifact")
        label = f"{job.id} ({', '.join(flags)})" if flags else job.id
        parts.append(label)
    return " -> ".join(parts)


def main() -> None:
    parser = argparse.ArgumentParser(description="CI pipeline tampering simulator")
    parser.add_argument("--config", type=str, required=True, help="Path to pipeline JSON")
    args = parser.parse_args()

    path = Path(args.config)
    if not path.exists():
        print(f"Config not found: {path}")
        return

    jobs = load_pipeline(path)
    print("CI Pipeline Graph")
    print("=================")
    for j in jobs.values():
        print(
            f"- {j.id}: depends_on={j.depends_on}, "
            f"runs_untrusted_code={j.runs_untrusted_code}, "
            f"publishes_artifact={j.publishes_artifact}, "
            f"privileged={j.privileged}"
        )
    print()

    attack_paths = find_attack_paths(jobs)
    if not attack_paths:
        print("No risky attacker paths from untrusted PR to publishing jobs found.")
        return

    print("Potential attacker paths (from untrusted code to artefact publication):")
    for idx, path in enumerate(attack_paths, start=1):
        print(f"Path {idx}: {describe_path(path)}")


if __name__ == "__main__":
    main()
