# Security Awareness Quiz CLI

This is a tiny CLI quiz I wrote to practise turning basic security awareness into something interactive.

Questions are stored in a JSON file with:

- `question`
- `options`
- `answer` (index of the correct option)

The script asks each question, reads my input and shows the score at the end.

## Files

- `security_quiz.py` – main script
- `questions.json` – example questions

## Usage

```bash
python security_quiz.py
```
