import json

def load_questions(path: str):
    with open(path) as f:
        return json.load(f)

def run_quiz(path: str):
    questions = load_questions(path)
    score = 0
    total = len(questions)
    for idx, q in enumerate(questions, start=1):
        print(f"Q{idx}. {q['question']}")
        for i, opt in enumerate(q["options"], start=1):
            print(f"   {i}. {opt}")
        ans = input("Your answer (number): ").strip()
        try:
            ans_idx = int(ans) - 1
        except ValueError:
            ans_idx = -1
        if ans_idx == q["answer"]:
            print("   Correct!\n")
            score += 1
        else:
            print(f"   Wrong. Correct answer was: {q['options'][q['answer']]}\n")
    print(f"Score: {score}/{total}")

def main():
    run_quiz("questions.json")

if __name__ == "__main__":
    main()
