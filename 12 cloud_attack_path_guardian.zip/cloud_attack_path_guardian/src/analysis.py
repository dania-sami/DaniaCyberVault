from __future__ import annotations

from dataclasses import dataclass
from typing import List

import networkx as nx

from .config import Settings


@dataclass
class AttackPath:
    nodes: List[str]
    score: float
    description: str


def _is_critical_node(g: nx.DiGraph, node: str) -> bool:
    data = g.nodes[node]
    if data.get("type") == "ec2":
        return bool(data.get("critical")) or bool(data.get("public_ip"))
    return False


def find_attack_paths(g: nx.DiGraph, settings: Settings, max_paths: int = 10) -> List[AttackPath]:
    attack_paths: List[AttackPath] = []

    # Entry points: internet and IAM users
    entry_nodes = ["internet"] + [n for n, d in g.nodes(data=True) if d.get("type") == "iam-user"]

    for entry in entry_nodes:
        # Simple bounded DFS/BFS: find all simple paths up to a small length
        for target in g.nodes:
            if not _is_critical_node(g, target):
                continue
            if entry == target:
                continue
            try:
                all_paths = list(nx.all_simple_paths(g, source=entry, target=target, cutoff=5))
            except nx.NetworkXNoPath:
                continue
            for path in all_paths:
                # Compute a simple score: sum of edge weights, shorter is better
                weight_sum = 0.0
                for u, v in zip(path, path[1:]):
                    w = g.edges[u, v].get("weight", 1.0)
                    weight_sum += w
                # Lower weight (shorter, stronger) is worse from a defender perspective
                score = 1.0 / (1.0 + weight_sum)
                descr = f"Path from {entry} to {target} via {len(path)-1} steps"
                attack_paths.append(AttackPath(nodes=path, score=score, description=descr))

    # Sort by score descending (highest score = most concerning)
    attack_paths.sort(key=lambda p: p.score, reverse=True)
    # Deduplicate by nodes sequence
    unique_paths: List[AttackPath] = []
    seen = set()
    for p in attack_paths:
        key = tuple(p.nodes)
        if key in seen:
            continue
        seen.add(key)
        unique_paths.append(p)
        if len(unique_paths) >= max_paths:
            break
    return unique_paths
