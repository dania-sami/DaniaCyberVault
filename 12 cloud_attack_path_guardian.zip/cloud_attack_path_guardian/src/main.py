from __future__ import annotations

import argparse

from rich import print

from .analysis import find_attack_paths
from .aws_fetch import fetch_cloud_snapshot
from .config import Settings
from .graph_model import build_attack_graph
from .report import write_report


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Cloud Attack Path Guardian - build a simple attack graph for an AWS account "
            "and highlight risky paths to critical assets."
        )
    )
    parser.add_argument(
        "--region",
        default="eu-north-1",
        help="AWS region for EC2 and Security Group lookups (default: eu-north-1)",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    settings = Settings(region_name=args.region)

    print(f"[bold blue][*] Collecting AWS data from region {settings.region_name}...[/bold blue]")
    snapshot = fetch_cloud_snapshot(settings)
    print(f"[+] Collected {len(snapshot.users)} IAM users, {len(snapshot.roles)} roles, "
          f"{len(snapshot.security_groups)} security groups, {len(snapshot.instances)} EC2 instances.")

    print("[*] Building attack graph...")
    g = build_attack_graph(snapshot, settings)
    print(f"[+] Graph has {g.number_of_nodes()} nodes and {g.number_of_edges()} edges.")

    print("[*] Searching for risky attack paths...")
    paths = find_attack_paths(g, settings, max_paths=10)
    print(f"[+] Found {len(paths)} interesting path(s).")

    print("[*] Writing report...")
    write_report(g, paths)

    print("[bold green]Done.[/bold green]")


if __name__ == "__main__":
    main()
