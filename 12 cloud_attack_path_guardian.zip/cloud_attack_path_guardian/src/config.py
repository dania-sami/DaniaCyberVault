from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import List


BASE_DIR = Path(__file__).resolve().parent.parent
REPORT_DIR = BASE_DIR / "reports"
REPORT_FILE = REPORT_DIR / "attack_path_report.txt"


@dataclass
class Settings:
    region_name: str = "eu-north-1"
    max_instances: int = 200
    max_iam_users: int = 200
    max_iam_roles: int = 200

    # Tags that mark an EC2 instance as critical
    critical_tags: List[str] = None

    def __post_init__(self) -> None:
        if self.critical_tags is None:
            self.critical_tags = ["Critical", "critical"]


def ensure_report_dir() -> None:
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
