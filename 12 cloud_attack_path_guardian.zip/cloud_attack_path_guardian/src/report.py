from __future__ import annotations

from datetime import datetime
from typing import List

import networkx as nx

from .analysis import AttackPath
from .config import REPORT_FILE, ensure_report_dir


def _format_node(g: nx.DiGraph, node: str) -> str:
    data = g.nodes[node]
    label = data.get("label", node)
    ntype = data.get("type", "unknown")
    if ntype == "ec2":
        return f"{label} ({node}, public_ip={data.get('public_ip')})"
    return f"{label} ({node})"


def write_report(g: nx.DiGraph, paths: List[AttackPath]) -> None:
    ensure_report_dir()

    lines: List[str] = []
    lines.append("Cloud Attack Path Guardian Report")
    lines.append(f"Generated at: {datetime.utcnow().isoformat()}Z")
    lines.append("")

    lines.append(f"Total nodes in graph: {g.number_of_nodes()}")
    lines.append(f"Total edges in graph: {g.number_of_edges()}")
    lines.append("")

    if not paths:
        lines.append("No risky paths from entry points to critical assets were found with the current logic.")
    else:
        lines.append("Top risky attack paths:")
        lines.append("")
        for idx, p in enumerate(paths, start=1):
            lines.append(f"[{idx}] Score: {p.score:.3f}")
            lines.append(f"    {p.description}")
            pretty_nodes = " -> ".join(_format_node(g, n) for n in p.nodes)
            lines.append(f"    Path: {pretty_nodes}")
            lines.append("")

    lines.append("")
    lines.append("Hardening hints (general):")
    lines.append("- Restrict SSH/RDP from 0.0.0.0/0; use VPN or bastion hosts instead.")
    lines.append("- Review Security Groups that are reachable from the internet and narrow CIDR ranges.")
    lines.append("- Ensure IAM users have only the minimum policies required.")
    lines.append("- Consider tagging business critical instances and monitoring paths to them explicitly.")

    REPORT_FILE.write_text("\n".join(lines), encoding="utf-8")
    print(f"[+] Report written to: {REPORT_FILE}")
