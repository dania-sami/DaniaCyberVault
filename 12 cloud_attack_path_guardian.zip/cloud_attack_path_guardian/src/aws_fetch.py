from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

import boto3
from botocore.exceptions import BotoCoreError, ClientError

from .config import Settings


@dataclass
class IAMUserInfo:
    user_name: str
    arn: str
    attached_policies: List[str] = field(default_factory=list)


@dataclass
class IAMRoleInfo:
    role_name: str
    arn: str
    attached_policies: List[str] = field(default_factory=list)


@dataclass
class SecurityGroupRule:
    sg_id: str
    from_port: Optional[int]
    to_port: Optional[int]
    cidr: str
    description: str = ""


@dataclass
class SecurityGroupInfo:
    sg_id: str
    name: str
    inbound_rules: List[SecurityGroupRule] = field(default_factory=list)


@dataclass
class EC2InstanceInfo:
    instance_id: str
    name: str
    public_ip: Optional[str]
    private_ip: Optional[str]
    security_groups: List[str]
    tags: Dict[str, str]


@dataclass
class CloudSnapshot:
    users: List[IAMUserInfo]
    roles: List[IAMRoleInfo]
    security_groups: List[SecurityGroupInfo]
    instances: List[EC2InstanceInfo]


def _safe_paginate(client, method_name: str, result_key: str, **kwargs):
    method = getattr(client, method_name)
    paginator = client.get_paginator(method_name)
    try:
        for page in paginator.paginate(**kwargs):
            for item in page.get(result_key, []):
                yield item
    except (BotoCoreError, ClientError) as e:
        print(f"[!] AWS error during {method_name}: {e}")
        return


def fetch_cloud_snapshot(settings: Settings) -> CloudSnapshot:
    iam = boto3.client("iam")
    ec2 = boto3.client("ec2", region_name=settings.region_name)

    users: List[IAMUserInfo] = []
    roles: List[IAMRoleInfo] = []
    sgs: List[SecurityGroupInfo] = []
    instances: List[EC2InstanceInfo] = []

    # IAM users
    try:
        for user in _safe_paginate(iam, "list_users", "Users"):
            if len(users) >= settings.max_iam_users:
                break
            user_name = user["UserName"]
            arn = user["Arn"]
            attached_policies: List[str] = []
            for ap in _safe_paginate(
                iam,
                "list_attached_user_policies",
                "AttachedPolicies",
                UserName=user_name,
            ):
                attached_policies.append(ap["PolicyArn"])
            users.append(IAMUserInfo(user_name=user_name, arn=arn, attached_policies=attached_policies))
    except Exception as e:
        print(f"[!] Failed to fetch IAM users: {e}")

    # IAM roles
    try:
        for role in _safe_paginate(iam, "list_roles", "Roles"):
            if len(roles) >= settings.max_iam_roles:
                break
            role_name = role["RoleName"]
            arn = role["Arn"]
            attached_policies: List[str] = []
            for ap in _safe_paginate(
                iam,
                "list_attached_role_policies",
                "AttachedPolicies",
                RoleName=role_name,
            ):
                attached_policies.append(ap["PolicyArn"])
            roles.append(IAMRoleInfo(role_name=role_name, arn=arn, attached_policies=attached_policies))
    except Exception as e:
        print(f"[!] Failed to fetch IAM roles: {e}")

    # Security groups
    try:
        resp = ec2.describe_security_groups()
        for sg in resp.get("SecurityGroups", []):
            sg_id = sg["GroupId"]
            name = sg.get("GroupName", sg_id)
            inbound_rules: List[SecurityGroupRule] = []
            for perm in sg.get("IpPermissions", []):
                from_port = perm.get("FromPort")
                to_port = perm.get("ToPort")
                for ip_range in perm.get("IpRanges", []):
                    cidr = ip_range.get("CidrIp", "unknown")
                    desc = ip_range.get("Description", "")
                    inbound_rules.append(
                        SecurityGroupRule(
                            sg_id=sg_id,
                            from_port=from_port,
                            to_port=to_port,
                            cidr=cidr,
                            description=desc,
                        )
                    )
            sgs.append(SecurityGroupInfo(sg_id=sg_id, name=name, inbound_rules=inbound_rules))
    except Exception as e:
        print(f"[!] Failed to fetch Security Groups: {e}")

    # EC2 instances
    try:
        paginator = ec2.get_paginator("describe_instances")
        for page in paginator.paginate():
            for reservation in page.get("Reservations", []):
                for inst in reservation.get("Instances", []):
                    if len(instances) >= settings.max_instances:
                        break
                    instance_id = inst["InstanceId"]
                    public_ip = inst.get("PublicIpAddress")
                    private_ip = inst.get("PrivateIpAddress")
                    tags = {t["Key"]: t["Value"] for t in inst.get("Tags", [])}
                    name = tags.get("Name", instance_id)
                    sg_ids = [sg["GroupId"] for sg in inst.get("SecurityGroups", [])]
                    instances.append(
                        EC2InstanceInfo(
                            instance_id=instance_id,
                            name=name,
                            public_ip=public_ip,
                            private_ip=private_ip,
                            security_groups=sg_ids,
                            tags=tags,
                        )
                    )
    except Exception as e:
        print(f"[!] Failed to fetch EC2 instances: {e}")

    return CloudSnapshot(users=users, roles=roles, security_groups=sgs, instances=instances)
