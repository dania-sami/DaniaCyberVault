from __future__ import annotations

from typing import Dict, Tuple

import networkx as nx

from .aws_fetch import CloudSnapshot, SecurityGroupRule
from .config import Settings


def build_attack_graph(snapshot: CloudSnapshot, settings: Settings) -> nx.DiGraph:
    g = nx.DiGraph()

    # Add a generic 'internet' node
    g.add_node("internet", type="internet", label="Internet")

    # IAM users and roles
    for user in snapshot.users:
        node_id = f"iam-user:{user.user_name}"
        g.add_node(node_id, type="iam-user", arn=user.arn, label=user.user_name)
        # For now, we just store that policies exist. Deep IAM analysis can be added later.

    for role in snapshot.roles:
        node_id = f"iam-role:{role.role_name}"
        g.add_node(node_id, type="iam-role", arn=role.arn, label=role.role_name)

    # SecurityGroups
    sg_index: Dict[str, SecurityGroupRule] = {}
    for sg in snapshot.security_groups:
        sg_node = f"sg:{sg.sg_id}"
        g.add_node(sg_node, type="sg", label=sg.name)

        for rule in sg.inbound_rules:
            sg_index[(sg.sg_id, rule.cidr, rule.from_port, rule.to_port)] = rule
            # Very simplified: treat any 0.0.0.0/0 inbound as reachable from internet
            if rule.cidr == "0.0.0.0/0":
                g.add_edge(
                    "internet",
                    sg_node,
                    relation="inbound",
                    weight=1.0,
                    info=f"inbound {rule.from_port}-{rule.to_port} from internet",
                )

    # EC2 instances
    for inst in snapshot.instances:
        inst_node = f"ec2:{inst.instance_id}"
        is_critical = any(tag in inst.tags for tag in settings.critical_tags)
        g.add_node(
            inst_node,
            type="ec2",
            label=inst.name,
            public_ip=inst.public_ip,
            private_ip=inst.private_ip,
            critical=is_critical,
        )

        # Attach instance to its security groups
        for sg_id in inst.security_groups:
            sg_node = f"sg:{sg_id}"
            if g.has_node(sg_node):
                g.add_edge(
                    sg_node,
                    inst_node,
                    relation="attached",
                    weight=1.0,
                    info="sg attached to instance",
                )

        # Treat publicly reachable SSH or RDP as more dangerous
        if inst.public_ip:
            # Edge from internet to instance if any of its SGs allow SSH from 0.0.0.0/0
            # We approximate by checking if the SG already has an edge from internet.
            for sg_id in inst.security_groups:
                sg_node = f"sg:{sg_id}"
                if g.has_edge("internet", sg_node):
                    g.add_edge(
                        "internet",
                        inst_node,
                        relation="public-access",
                        weight=2.0,
                        info="instance reachable from internet via SG",
                    )

    return g
