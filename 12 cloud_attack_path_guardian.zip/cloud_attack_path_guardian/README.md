# Cloud Attack Path Guardian for AWS

Hi, I am Dania Sami 👋

In this project I wanted to go beyond simple “misconfiguration checkers” and
build something that thinks more like an attacker.

**Cloud Attack Path Guardian** is a small framework that:

- pulls information from an AWS account (IAM, EC2 and Security Groups),
- builds an **attack graph** showing how access can move through the cloud
  environment,
- ranks the **most dangerous paths** to high value targets,
- and generates a human friendly report with concrete hardening suggestions.

It is inspired by how modern cloud security posture tools and research papers
model *attack paths* instead of just isolated misconfigurations.

> ⚠️ This is an educational, read only tool. It does not change anything in your
> AWS account. You should only run it against accounts you own or are allowed
> to assess.

---

## What this tool does

At a high level, the tool:

1. **Collects cloud data (read only)**

   Using the AWS SDK (`boto3`), it collects a subset of information from your
   account:

   - IAM users and roles
   - which policies are attached to them
   - EC2 instances and their security groups
   - Security Group rules (especially inbound rules from the internet)

   The focus is on getting just enough data to reason about attack paths, not
   to fully map every service.

2. **Builds an attack graph**

   I model the environment as a directed graph:

   - nodes can be things like `iam-user:alice`, `iam-role:AdminRole`,
     `ec2:i-1234`, `sg:public-web-sg`, `internet`.
   - edges represent possible movement or influence, for example:
     - an IAM user can *assume* a role,
     - a Security Group allows the internet to reach a port on an instance,
     - an instance is tagged as a critical asset.

   Each edge has a simple weight that roughly represents how “powerful” that
   step is for an attacker.

3. **Finds risky paths to critical assets**

   You can mark critical assets via tags or by providing a small YAML / JSON
   config later. In this minimal version I treat:

   - instances with a `Critical=true` tag as high value,
   - and instances with both a **public IP** and **open SSH** as important.

   Then I search for paths from low privilege entry points (internet, or IAM
   users) towards those critical nodes and compute a simple risk score based
   on path length and edge weights.

4. **Generates a report**

   Finally, the tool writes a text report to the `reports/` folder that
   includes:

   - a short summary of the environment,
   - the top N risky paths with explanations,
   - and simple human readable hardening suggestions,
     for example “close SSH from 0.0.0.0/0 on sg-1234 or restrict to a VPN”.

The goal is not to cover every possible cloud attack, but to show that I can:

- think in terms of **graphs and attack paths**,
- use the AWS SDK safely,
- and turn raw data into **actionable security insights**.

---

## Quick start

```bash
# 1. Create and activate a virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Make sure your AWS credentials are configured (for example using awscli)
aws sts get-caller-identity

# 4. Run the attack path analysis
python -m src.main --region eu-north-1
```

A summary is printed in the terminal and a detailed report is written to
`reports/attack_path_report.txt`.

> Note: you can change the region with `--region`.
> The tool only reads from AWS, it does not modify resources.

---

## Project structure

- `src/`
  - `config.py`      basic settings and helper functions
  - `aws_fetch.py`   read only AWS collectors (IAM, EC2, Security Groups)
  - `graph_model.py` builds the attack graph using NetworkX
  - `analysis.py`    finds risky paths and scores them
  - `report.py`      generates a human readable text report
  - `main.py`        command line entry point
- `reports/`
  - generated reports are written here

---

## Ideas to extend this project

If I was turning this into a bigger thesis or company internal tool, I would:

- Add support for more services (RDS, S3, Lambda) and more relationships.
- Parse IAM policies more deeply to detect privilege escalation patterns.
- Export the graph as JSON and build a small visual frontend to explore it.
- Integrate it into a CI pipeline to catch dangerous attack paths before
  changes are deployed.

This repository is intentionally compact and focused so that someone reviewing
my GitHub profile can quickly understand:

- how I think about **cloud security**,
- how I use **graphs** to model attack paths,
- and how I communicate security findings in a clear way.
