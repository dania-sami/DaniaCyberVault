
import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest

DATA_DIR = Path("data")


def build_features(df: pd.DataFrame) -> pd.DataFrame:
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    df["hour"] = df["timestamp"].dt.hour
    df["off_hours"] = ((df["hour"] < 8) | (df["hour"] > 18)).astype(int)

    def sum_bytes(event_type):
        subset = df[df["event_type"] == event_type]
        return subset.groupby("user")["bytes"].sum()

    total_events = df.groupby("user")["event_type"].count().rename("total_events")

    total_file_read_bytes = sum_bytes("file_read").rename("total_file_read_bytes")
    total_file_write_bytes = sum_bytes("file_write").rename("total_file_write_bytes")
    total_email_bytes = sum_bytes("email_send").rename("total_email_bytes")
    total_usb_bytes = sum_bytes("usb_copy").rename("total_usb_bytes")

    off_hours_events = df.groupby("user")["off_hours"].sum().rename("off_hours_events")
    distinct_devices = df.groupby("user")["device"].nunique().rename("distinct_devices")
    distinct_locations = df.groupby("user")["location"].nunique().rename("distinct_locations")

    features = pd.concat(
        [
            total_events,
            total_file_read_bytes,
            total_file_write_bytes,
            total_email_bytes,
            total_usb_bytes,
            off_hours_events,
            distinct_devices,
            distinct_locations,
        ],
        axis=1,
    ).fillna(0)

    return features.reset_index().rename(columns={"user": "user"})


def verdict(score: float) -> str:
    if score < 0.4:
        return "Typical"
    if score < 0.7:
        return "Suspicious"
    return "Highly suspicious"


def main():
    parser = argparse.ArgumentParser(description="Insider threat detection analyser")
    parser.add_argument(
        "--input",
        type=str,
        default=str(DATA_DIR / "activity_events.csv"),
        help="CSV file with simulated activity events",
    )
    parser.add_argument(
        "--output",
        type=str,
        default=str(DATA_DIR / "user_risk_report.csv"),
        help="Where to write per-user risk scores",
    )
    args = parser.parse_args()

    in_path = Path(args.input)
    if not in_path.is_file():
        raise SystemExit(f"Input file not found: {in_path}")

    df = pd.read_csv(in_path)
    print(f"[info] Loaded {len(df)} events from {in_path}")

    features = build_features(df)
    print(f"[info] Built feature table for {len(features)} users")

    feature_cols = [
        "total_events",
        "total_file_read_bytes",
        "total_file_write_bytes",
        "total_email_bytes",
        "total_usb_bytes",
        "off_hours_events",
        "distinct_devices",
        "distinct_locations",
    ]

    X = features[feature_cols].astype(float).values

    model = IsolationForest(
        n_estimators=200,
        contamination=0.15,
        random_state=42,
    )
    model.fit(X)

    # IsolationForest decision_function: larger = more normal, smaller = more anomalous
    scores_raw = model.decision_function(X)
    # convert to anomaly score 0..1 (higher = more anomalous)
    min_s = scores_raw.min()
    max_s = scores_raw.max()
    if max_s - min_s > 1e-9:
        anomaly_scores = (min_s - scores_raw) / (min_s - max_s)
    else:
        anomaly_scores = np.zeros_like(scores_raw)

    features["anomaly_score"] = anomaly_scores
    features["verdict"] = features["anomaly_score"].apply(verdict)

    out_path = Path(args.output)
    features.to_csv(out_path, index=False)
    print(f"[info] Full user risk report written to {out_path}")

    top = features.sort_values("anomaly_score", ascending=False).head(10)
    print("[info] Top suspicious users based on anomaly score:")
    for _, row in top.iterrows():
        print(
            f"  user={row['user']}  score={row['anomaly_score']:.2f}  "
            f"total_usb_bytes={int(row['total_usb_bytes'])}  "
            f"total_email_bytes={int(row['total_email_bytes'])}  "
            f"off_hours_events={int(row['off_hours_events'])}"
        )


if __name__ == "__main__":
    main()
