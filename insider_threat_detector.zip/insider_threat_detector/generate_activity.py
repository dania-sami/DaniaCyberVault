
from pathlib import Path
import random
import csv
from datetime import datetime, timedelta

DATA_DIR = Path("data")


def random_choice_weighted(items):
    # items: list of (value, weight)
    total = sum(w for _, w in items)
    r = random.uniform(0, total)
    upto = 0
    for value, weight in items:
        if upto + weight >= r:
            return value
        upto += weight
    return items[-1][0]


def main():
    random.seed(42)
    DATA_DIR.mkdir(exist_ok=True)

    users = [f"user_{i:03d}" for i in range(1, 31)]
    suspicious_users = set(random.sample(users, 5))

    devices = ["laptop-01", "laptop-02", "desktop-01", "vpn-01", "terminal-01"]
    extra_devices = ["unknown-laptop", "personal-device"]
    locations_normal = ["office", "remote", "vpn"]
    locations_susp = ["unknown", "foreign"]

    start = datetime(2025, 1, 10, 8, 0, 0)
    events = []

    for user in users:
        # base line events per day
        days = random.randint(5, 10)
        for d in range(days):
            day_base = start + timedelta(days=d)
            # normal working hours
            for _ in range(random.randint(10, 30)):
                ts = day_base + timedelta(minutes=random.randint(8 * 60, 18 * 60))
                event_type = random_choice_weighted(
                    [
                        ("login", 2),
                        ("file_read", 5),
                        ("file_write", 3),
                        ("email_send", 2),
                    ]
                )
                if event_type == "login":
                    b = 0
                elif event_type == "file_read":
                    b = random.randint(1_000, 500_000)
                elif event_type == "file_write":
                    b = random.randint(1_000, 300_000)
                else:
                    b = random.randint(2_000, 1_000_000)

                events.append(
                    {
                        "timestamp": ts.strftime("%Y-%m-%d %H:%M:%S"),
                        "user": user,
                        "event_type": event_type,
                        "bytes": b,
                        "device": random.choice(devices),
                        "location": random.choice(locations_normal),
                    }
                )

        # if suspicious, add exfiltration-like behaviour
        if user in suspicious_users:
            # many late night events
            for _ in range(random.randint(20, 60)):
                day = random.randint(0, days - 1)
                ts = start + timedelta(days=day, minutes=random.randint(22 * 60, 23 * 60 + 59))
                event_type = random_choice_weighted(
                    [
                        ("file_read", 5),
                        ("usb_copy", 3),
                        ("email_send", 2),
                    ]
                )
                if event_type == "file_read":
                    b = random.randint(5_000_000, 50_000_000)
                elif event_type == "usb_copy":
                    b = random.randint(20_000_000, 200_000_000)
                else:
                    b = random.randint(5_000_000, 100_000_000)

                events.append(
                    {
                        "timestamp": ts.strftime("%Y-%m-%d %H:%M:%S"),
                        "user": user,
                        "event_type": event_type,
                        "bytes": b,
                        "device": random.choice(devices + extra_devices),
                        "location": random.choice(locations_normal + locations_susp),
                    }
                )

            # also add logins from multiple devices/locations
            for _ in range(random.randint(5, 15)):
                ts = start + timedelta(days=random.randint(0, days - 1), hours=random.randint(0, 23), minutes=random.randint(0, 59))
                events.append(
                    {
                        "timestamp": ts.strftime("%Y-%m-%d %H:%M:%S"),
                        "user": user,
                        "event_type": "login",
                        "bytes": 0,
                        "device": random.choice(devices + extra_devices),
                        "location": random.choice(locations_normal + locations_susp),
                    }
                )

    events.sort(key=lambda e: e["timestamp"])

    out_path = DATA_DIR / "activity_events.csv"
    fieldnames = ["timestamp", "user", "event_type", "bytes", "device", "location"]
    with out_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for e in events:
            w.writerow(e)

    print(f"[info] Wrote {len(events)} events for {len(users)} users to {out_path}")


if __name__ == "__main__":
    main()
