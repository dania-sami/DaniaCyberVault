
# Insider Threat Detection System (Simulation Lab)

Hi, I am Dania and I built this project to practise how security teams think about **insider threats** using data and anomaly detection.

Instead of using any real company data, I simulate user activity and then analyse it like a security data scientist would.

The idea is simple:

- simulate realistic user behaviour over time (logins, file access, email sending, data movement)
- add a few “insider-like” cases with data exfiltration and odd behaviour
- aggregate this into per user features
- use anomaly detection to find users that do not behave like the others

This gives me a safe, research-style lab for insider threat detection.

---

## What this project does

There are two main scripts.

1. **`generate_activity.py` — simulate user activity events**

   It creates a CSV file `data/activity_events.csv` with events like:

   - `timestamp`
   - `user`
   - `event_type` (login, file_read, file_write, email_send, usb_copy)
   - `bytes`
   - `device`
   - `location`

   Normal users have realistic patterns across working hours, while a few users are made intentionally suspicious:

   - huge file reads and USB copies late at night
   - unusually high outbound email bytes
   - logins from many different devices and locations

2. **`analyze_activity.py` — build features and detect anomalies**

   This script:

   - groups events per user
   - computes features such as:
     - `total_events`
     - `total_file_read_bytes`
     - `total_file_write_bytes`
     - `total_email_bytes`
     - `total_usb_bytes`
     - `off_hours_events`
     - `distinct_devices`
     - `distinct_locations`
   - trains an `IsolationForest` anomaly detection model
   - calculates an `anomaly_score` for each user
   - assigns a simple verdict:
     - Typical
     - Suspicious
     - Highly suspicious

   Results are written to `data/user_risk_report.csv` and a table of the most suspicious users is printed in the terminal.

---

## Project structure

```text
insider_threat_detector/
  README.md
  requirements.txt
  generate_activity.py   # simulate user activity events
  analyze_activity.py    # aggregate and run anomaly detection
  data/
```

The data is fully synthetic and safe. The focus is on the **thinking and modelling**.

---

## Installation

```bash
python3 -m venv venv
source venv/bin/activate           # Windows  venv\Scripts\activate
pip install -r requirements.txt
```

---

## Step 1  Generate synthetic user activity

```bash
python generate_activity.py
```

This will create:

- `data/activity_events.csv` with thousands of events from multiple users

You can open the CSV to see the raw activity log.

---

## Step 2  Detect insider like behaviour

```bash
python analyze_activity.py --input data/activity_events.csv
```

Example style of output:

```text
[info] Loaded 5000 events from data/activity_events.csv
[info] Built feature table for 30 users
[info] Top suspicious users based on anomaly score:
  user=user_023  score=0.96  total_usb_bytes=254321000  total_email_bytes=132000000  off_hours_events=43
  user=user_017  score=0.91  total_file_read_bytes=842110000  off_hours_events=38
  user=user_029  score=0.87  distinct_devices=7  distinct_locations=4

[info] Full user risk report written to data/user_risk_report.csv
```

The CSV contains:

- user level features
- `anomaly_score` (0..1)
- `verdict` (Typical / Suspicious / Highly suspicious)

---

## Feature design

For each user, I compute:

- `total_events`
- `total_file_read_bytes`
- `total_file_write_bytes`
- `total_email_bytes`
- `total_usb_bytes`
- `off_hours_events` (events outside typical 08:00–18:00)
- `distinct_devices`
- `distinct_locations`

In a real environment you would add even more context (department, role, data classification, HR signals).  
Here I focus on a clean and explainable core that still feels realistic.

---

## Why I like this project

Insider threat detection is not only about technology — it is about behaviour, context and subtle signals.

With this project I can show that I:

- understand different types of user activity (logins, file access, USB, email)
- can design meaningful features for insider threat analysis
- know how to apply anomaly detection (IsolationForest) in a security context
- and can present the result as a simple “user risk report”

It is intentionally small and readable so that I can discuss it in detail during applications or interviews.
