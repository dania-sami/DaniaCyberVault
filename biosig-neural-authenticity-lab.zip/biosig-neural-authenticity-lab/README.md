
# BioSig Neural Authenticity Lab

BioSig is my small lab for thinking about biometric authenticity and spoofing
risk without touching raw biometric data.

In real systems we would deal with fingerprints, facial templates, iris
patterns or voice features. For a portfolio project I want something safer and
easier to share, so BioSig works on abstract metrics like

* `spoof_texture_score`
* `liveness_score`
* `noise_level`
* `replay_pattern_score`
* `device_trust_level`

Based on these numbers it estimates how likely a sample is to be forged and
how confident that estimate is.

## What BioSig does

* registers biometric samples by subject, modality and capture device
* stores a dictionary of metrics that describe quality and possible artefacts
* calculates
  * a forgery likelihood between zero and one hundred
  * a confidence value between 0.5 and 0.95
  * a label for example `likely_genuine_sample` or `high_spoof_risk`
* returns a list of reasons in plain language

The scoring logic is in a single file and designed to be easy to audit and
extend.

## Project layout

```text
biosig-neural-authenticity-lab
└── backend
    ├── biosig_lab
    │   ├── __init__.py
    │   ├── engine.py  Biometric sample model and spoof scoring
    │   └── main.py    FastAPI HTTP API
    ├── requirements.txt
    └── example_requests.http
```

## How I run it locally

From the backend folder

```bash
python -m venv .venv
source .venv/bin/activate        # On Windows I use .venv\Scripts\activate
pip install -r requirements.txt
uvicorn biosig_lab.main:app --reload --port 9818
```

Then I open

* http://localhost:9818/docs to register samples and run analysis

## Example scenario I like to demo

First I register a face sample with some metrics that suggest a possible spoof

```bash
curl -X POST http://localhost:9818/samples   -H "Content-Type: application/json"   -d '{
    "subject_id": "user-123",
    "modality": "face",
    "capture_device": "front_camera_v1",
    "meta": {
      "spoof_texture_score": 0.7,
      "liveness_score": 0.35,
      "noise_level": 0.4,
      "replay_pattern_score": 0.2,
      "device_trust_level": 0.6
    }
  }'
```

The service returns a sample id, for example 1. Then I ask BioSig to analyse it

```bash
curl -X POST "http://localhost:9818/analyse?sample_id=1"
```

The result includes

* a forgery likelihood score
* a label, for example `elevated_spoof_risk`
* reasons that explain which metrics drove the decision

This makes it very easy to discuss how I would think about deepfake faces,
presentation attacks or replayed voice samples in a system design, without
needing to distribute biometric data.

## How I see this evolving

If I want to extend BioSig in the future I can

* add modality specific metrics
* integrate with a real model that produces these metrics
* attach policy decisions such as step up authentication

Right now this version already demonstrates how I approach biometric spoof
risk in a transparent and explainable way.
