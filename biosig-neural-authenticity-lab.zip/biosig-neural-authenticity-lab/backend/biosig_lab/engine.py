
from dataclasses import dataclass
from typing import Dict, List


@dataclass
class BiometricSample:
    id: int
    subject_id: str
    modality: str
    capture_device: str
    meta: Dict[str, float]


@dataclass
class AuthenticityReport:
    sample_id: int
    modality: str
    forgery_likelihood: float
    confidence: float
    label: str
    reasons: List[str]


class BioSigBrain:
    """
    BioSig is my lab for thinking about biometric spoofing and authenticity.

    It does NOT process raw biometric templates or images. Instead it works on
    abstract quality metrics and artefact indicators for different modalities
    (fingerprint, face, voice, iris, etc).

    The goal is to decide how likely it is that the sample could be forged or
    spoofed given those signals.
    """

    def __init__(self) -> None:
        self.samples: Dict[int, BiometricSample] = {}
        self._next_id = 1

    def register_sample(self, subject_id: str, modality: str, capture_device: str, meta: Dict[str, float]) -> BiometricSample:
        sid = self._next_id
        self._next_id += 1
        sample = BiometricSample(
            id=sid,
            subject_id=subject_id,
            modality=modality.lower(),
            capture_device=capture_device,
            meta=meta,
        )
        self.samples[sid] = sample
        return sample

    def _metric(self, sample: BiometricSample, name: str, default: float = 0.0) -> float:
        return float(sample.meta.get(name, default))

    def analyse(self, sample_id: int) -> AuthenticityReport:
        sample = self.samples[sample_id]
        m = self._metric
        reasons: List[str] = []

        spoof_texture_score = m(sample, "spoof_texture_score")
        liveness_score = m(sample, "liveness_score")
        noise_level = m(sample, "noise_level")
        replay_pattern_score = m(sample, "replay_pattern_score")
        device_trust = m(sample, "device_trust_level", 0.5)

        forgery = 0.0

        if spoof_texture_score > 0.6:
            forgery += (spoof_texture_score - 0.6) * 60.0
            reasons.append("Surface artefacts resemble known spoof textures.")
        if replay_pattern_score > 0.5:
            forgery += (replay_pattern_score - 0.5) * 80.0
            reasons.append("Temporal pattern looks similar to a replayed sample.")
        if liveness_score < 0.4:
            forgery += (0.4 - liveness_score) * 70.0
            reasons.append("Liveness indicators are weak for this sample.")
        if noise_level > 0.7:
            forgery += (noise_level - 0.7) * 30.0
            reasons.append("Signal noise is high which can hide spoof artefacts or real features.")

        forgery *= (1.0 - device_trust * 0.4)

        forgery = max(0.0, min(100.0, forgery))

        if forgery >= 75.0:
            label = "high_spoof_risk"
        elif forgery >= 50.0:
            label = "elevated_spoof_risk"
        elif forgery >= 25.0:
            label = "mostly_genuine_but_watch"
        else:
            label = "likely_genuine_sample"

        confidence = 0.5 + abs(forgery - 50.0) / 200.0
        confidence = max(0.5, min(0.95, confidence))

        if not reasons:
            reasons.append("No strong spoof indicators in the provided metrics.")

        return AuthenticityReport(
            sample_id=sample.id,
            modality=sample.modality,
            forgery_likelihood=round(forgery, 2),
            confidence=round(confidence, 2),
            label=label,
            reasons=reasons,
        )
