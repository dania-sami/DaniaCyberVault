
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Dict, List

from .engine import BioSigBrain, BiometricSample, AuthenticityReport


brain = BioSigBrain()


class SampleIn(BaseModel):
    subject_id: str = Field(..., example="user-123")
    modality: str = Field(..., example="face")
    capture_device: str = Field(..., example="front_camera_v1")
    meta: Dict[str, float] = Field(
        default_factory=dict,
        description="Metrics such as spoof_texture_score, liveness_score, noise_level, replay_pattern_score, device_trust_level",
    )


class SampleOut(BaseModel):
    id: int
    subject_id: str
    modality: str
    capture_device: str
    meta: Dict[str, float]


class ReportOut(BaseModel):
    sample_id: int
    modality: str
    forgery_likelihood: float
    confidence: float
    label: str
    reasons: List[str]


app = FastAPI(
    title="BioSig Neural Authenticity Lab",
    version="0.1.0",
    description="My biometric spoofing and authenticity reasoning lab based on abstract metrics.",
)


@app.post("/samples", response_model=SampleOut)
def register_sample(payload: SampleIn) -> SampleOut:
    sample: BiometricSample = brain.register_sample(
        subject_id=payload.subject_id,
        modality=payload.modality,
        capture_device=payload.capture_device,
        meta=payload.meta,
    )
    return SampleOut(
        id=sample.id,
        subject_id=sample.subject_id,
        modality=sample.modality,
        capture_device=sample.capture_device,
        meta=sample.meta,
    )


@app.post("/analyse", response_model=ReportOut)
def analyse(sample_id: int) -> ReportOut:
    if sample_id not in brain.samples:
        raise HTTPException(status_code=404, detail="Sample not found")
    rep: AuthenticityReport = brain.analyse(sample_id)
    return ReportOut(
        sample_id=rep.sample_id,
        modality=rep.modality,
        forgery_likelihood=rep.forgery_likelihood,
        confidence=rep.confidence,
        label=rep.label,
        reasons=rep.reasons,
    )
