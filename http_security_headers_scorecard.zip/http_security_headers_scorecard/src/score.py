from __future__ import annotations

import argparse
from pathlib import Path
from typing import Dict, Tuple, List

import requests


def evaluate_headers(headers: Dict[str, str]) -> Tuple[int, List[str]]:
    score = 0
    notes: List[str] = []

    csp = headers.get("Content-Security-Policy") or headers.get("content-security-policy")
    if csp:
        score += 2
    else:
        notes.append("Missing Content-Security-Policy.")

    hsts = headers.get("Strict-Transport-Security") or headers.get("strict-transport-security")
    if hsts:
        score += 2
    else:
        notes.append("Missing Strict-Transport-Security.")

    xfo = headers.get("X-Frame-Options") or headers.get("x-frame-options")
    if xfo:
        score += 1
    else:
        notes.append("Missing X-Frame-Options (clickjacking risk).")

    xcto = headers.get("X-Content-Type-Options") or headers.get("x-content-type-options")
    if xcto and xcto.lower() == "nosniff":
        score += 1
    else:
        notes.append("Missing or weak X-Content-Type-Options.")

    refpol = headers.get("Referrer-Policy") or headers.get("referrer-policy")
    if refpol:
        score += 1
    else:
        notes.append("Missing Referrer-Policy.")

    return score, notes


def score_site(url: str, timeout: int = 10) -> None:
    try:
        resp = requests.get(url, timeout=timeout)
    except Exception as e:
        print(f"{url}: ERROR fetching site: {e}")
        return

    score, notes = evaluate_headers(resp.headers)
    max_score = 7
    print(f"Site: {url}")
    print(f"  Status: {resp.status_code}")
    print(f"  Security header score: {score}/{max_score}")
    if notes:
        print("  Observations:")
        for n in notes:
            print(f"    - {n}")
    else:
        print("  All key headers present with basic strength.")
    print()


def main() -> None:
    parser = argparse.ArgumentParser(description="HTTP Security Headers Scorecard")
    parser.add_argument("--url", type=str, help="Single URL to test")
    parser.add_argument("--list", type=str, help="Path to file with one URL per line")
    args = parser.parse_args()

    urls: List[str] = []
    if args.url:
        urls.append(args.url)
    if args.list:
        path = Path(args.list)
        if not path.exists():
            print(f"List file not found: {path}")
        else:
            for line in path.read_text(encoding='utf-8').splitlines():
                line = line.strip()
                if line:
                    urls.append(line)

    if not urls:
        parser.error("Provide --url or --list")

    for u in urls:
        score_site(u)


if __name__ == "__main__":
    main()
