# HTTP Security Headers Scorecard

Hi, I am Dania 👋

This project is my **HTTP security headers scorecard**:

- I send a GET request to one or more URLs.
- I inspect headers like:
  - `Content-Security-Policy`,
  - `Strict-Transport-Security`,
  - `X-Frame-Options`,
  - `X-Content-Type-Options`,
  - `Referrer-Policy`.
- I compute a simple score and show missing or weak headers.

It is a practical tool to start conversations about **basic web hardening**.

## How to run

```bash
cd http_security_headers_scorecard

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt

# Score a single site
python -m src.score --url https://example.com

# Or score multiple sites from a file
python -m src.score --list data/sites.txt
```

The tool prints a small report per site, with a score and quick tips.
