# Phishing URL Scoring Tool

This is a small script I wrote to practise thinking about phishing indicators in URLs.

It does not block anything or visit the URLs. Instead, it reads URLs from a text file and gives each of them a simple score based on a few signals like:

- Length of the URL
- Use of `@` in the URL
- Use of an IP address instead of a domain
- Presence of suspicious words like "login", "verify", "update", "secure"

## Usage

```bash
python phishing_scoring.py --file demo_urls.txt
```

Example output (shortened):

```text
https://example.com                  score=  5  verdict=low
http://198.51.100.10/login.php       score= 45  verdict=medium
http://secure-update.example-login.com/verify  score= 70  verdict=high
```

This is not meant to be a classifier, just a way to show my thinking around phishing detection.
