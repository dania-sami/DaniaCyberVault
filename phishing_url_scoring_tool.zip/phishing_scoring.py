import argparse
import re
from urllib.parse import urlparse

SUSPICIOUS_WORDS = ["login", "verify", "update", "secure", "account", "confirm"]
IP_RE = re.compile(r"^\d+\.\d+\.\d+\.\d+$")

def score_url(url: str) -> int:
    score = 0
    parsed = urlparse(url)

    host = parsed.hostname or ""
    path = parsed.path or ""

    if len(url) > 60:
        score += 10

    if "@" in url:
        score += 20

    if IP_RE.match(host):
        score += 20

    lower = url.lower()
    for w in SUSPICIOUS_WORDS:
        if w in lower:
            score += 5

    if parsed.scheme == "http":
        score += 10

    return min(score, 100)

def verdict(score: int) -> str:
    if score < 20:
        return "low"
    if score < 50:
        return "medium"
    return "high"

def analyse_file(path: str):
    with open(path) as f:
        for line in f:
            url = line.strip()
            if not url:
                continue
            s = score_url(url)
            v = verdict(s)
            print(f"{url:40s} score={s:3d}  verdict={v}")

def main():
    parser = argparse.ArgumentParser(description="Phishing URL Scoring Tool by Dania")
    parser.add_argument("--file", required=True, help="Path to text file with one URL per line")
    args = parser.parse_args()
    analyse_file(args.file)

if __name__ == "__main__":
    main()
