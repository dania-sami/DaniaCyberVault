import argparse
from scapy.all import IP, TCP, sr1, conf

def syn_scan(target: str, ports: list[int], timeout: float = 1.0):
    conf.verb = 0  # keep scapy quiet
    open_ports = []

    for port in ports:
        pkt = IP(dst=target) / TCP(dport=port, flags="S")
        resp = sr1(pkt, timeout=timeout)

        if resp is None:
            continue

        if resp.haslayer(TCP):
            tcp_layer = resp.getlayer(TCP)
            # SYN/ACK flags means open
            if tcp_layer.flags == 0x12:
                open_ports.append(port)
                # send RST to be polite
                rst_pkt = IP(dst=target) / TCP(dport=port, flags="R")
                sr1(rst_pkt, timeout=0.5)
            # RST means closed, ignore
    return open_ports

def parse_ports(port_str: str) -> list[int]:
    ports: list[int] = []
    for part in port_str.split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            start, end = part.split("-", 1)
            try:
                s = int(start)
                e = int(end)
            except ValueError:
                continue
            for p in range(s, e + 1):
                if 1 <= p <= 65535:
                    ports.append(p)
        else:
            try:
                p = int(part)
            except ValueError:
                continue
            if 1 <= p <= 65535:
                ports.append(p)
    return sorted(set(ports))

def main():
    parser = argparse.ArgumentParser(description="Stealth SYN Scan Tool by Dania")
    parser.add_argument("--target", required=True, help="Target IP or hostname")
    parser.add_argument(
        "--ports",
        required=True,
        help="Ports to scan, example: 22,80,443 or 20-25,80,443",
    )
    args = parser.parse_args()

    ports = parse_ports(args.ports)
    if not ports:
        print("No valid ports to scan.")
        return

    print(f"[+] SYN scan on {args.target}")
    print(f"[+] Ports: {','.join(str(p) for p in ports)}")

    open_ports = syn_scan(args.target, ports)

    if open_ports:
        print("\n[+] Open ports (SYN scan):")
        for p in open_ports:
            print(f"    {p}")
    else:
        print("\n[+] No open ports detected on these ports.")

if __name__ == "__main__":
    main()
