# Stealth SYN Scan Tool

This is a small SYN scan script I built to practice more low level network security concepts.

Instead of doing a full TCP handshake, the tool sends a SYN packet and looks at the response. This is sometimes called a half open scan. It is slower than my normal TCP scanner but it teaches me how packets really work.

## Features

- Uses raw SYN packets instead of connect calls
- Identifies open ports using SYN plus ACK logic
- Lets me specify target and ports from the command line
- Uses `scapy` so the code stays readable

## Usage

You will need Python 3 and `scapy` installed:

```bash
pip install scapy
```

Run the scan (usually with sudo because of raw packets):

```bash
sudo python syn_scanner.py --target 192.168.1.10 --ports 22,80,443
```

## Important note

This is for learning, labs and environments where I have permission. I do not run this on networks or systems where I am not allowed to test.
