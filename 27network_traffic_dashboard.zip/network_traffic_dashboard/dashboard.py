
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

DATA_DIR = Path("data")
OUTPUT_DIR = Path("output")


def build_heatmap(df: pd.DataFrame, out_path: Path) -> None:
    pivot = df.pivot_table(
        index="src_ip",
        columns="dst_country",
        values="bytes",
        aggfunc="sum",
        fill_value=0,
    )

    fig, ax = plt.subplots(figsize=(8, 5))
    im = ax.imshow(pivot.values)

    ax.set_xticks(range(len(pivot.columns)))
    ax.set_xticklabels(pivot.columns, rotation=45, ha="right")
    ax.set_yticks(range(len(pivot.index)))
    ax.set_yticklabels(pivot.index)

    ax.set_xlabel("Destination country")
    ax.set_ylabel("Source IP")
    ax.set_title("Network traffic heatmap (total bytes)")

    for i in range(pivot.shape[0]):
        for j in range(pivot.shape[1]):
            value = pivot.values[i, j]
            if value > 0:
                ax.text(j, i, str(int(value / 1000)) + "k", ha="center", va="center", fontsize=7)

    fig.tight_layout()
    out_path.parent.mkdir(exist_ok=True)
    fig.savefig(out_path)
    plt.close(fig)


def print_top_sources(df: pd.DataFrame, n: int = 5) -> None:
    grouped = df.groupby("src_ip")["bytes"].sum().sort_values(ascending=False).head(n)
    print("[info] Top sources by total bytes:")
    rank = 1
    for src, total in grouped.items():
        print(f"  {rank}. {src:<15} total_bytes={total:8d}")
        rank += 1
    print()


def print_anomalies(df: pd.DataFrame, n: int = 5) -> None:
    grouped = df.groupby(["src_ip", "dst_country"])["bytes"].sum().reset_index()
    mean = grouped["bytes"].mean()
    std = grouped["bytes"].std(ddof=0) or 1.0
    grouped["z_score"] = (grouped["bytes"] - mean) / std

    # join labels for context (best effort)
    labels = (
        df.groupby(["src_ip", "dst_country"])["label"]
        .agg(lambda x: x.value_counts().idxmax())
        .reset_index()
    )
    merged = grouped.merge(labels, on=["src_ip", "dst_country"], how="left")

    top = merged.sort_values("z_score", ascending=False).head(n)

    print("[info] Flows with highest anomaly scores (per src,dst_country):")
    for _, row in top.iterrows():
        print(
            f"  src={row['src_ip']:<15} dst_country={row['dst_country']:<3}  "
            f"total_bytes={int(row['bytes']):8d}  z_score={row['z_score']:.2f}  label={row.get('label','')}"
        )
    print()


def main():
    path = DATA_DIR / "flows.csv"
    if not path.is_file():
        raise SystemExit(f"Data file not found. Run generate_flows.py first ({path}).")

    df = pd.read_csv(path)
    print(f"[info] Loaded {len(df)} flows from {path}")

    print_top_sources(df)
    print_anomalies(df)

    heatmap_path = OUTPUT_DIR / "traffic_heatmap.png"
    build_heatmap(df, heatmap_path)
    print(f"[info] Saved heatmap to {heatmap_path}")


if __name__ == "__main__":
    main()
