
from pathlib import Path
import random
import csv
from datetime import datetime, timedelta

DATA_DIR = Path("data")


def random_ip(prefix=None):
    if prefix:
        return prefix + "." + ".".join(str(random.randint(0, 255)) for _ in range(2))
    return ".".join(str(random.randint(1, 254)) for _ in range(4))


def main():
    random.seed(42)
    DATA_DIR.mkdir(exist_ok=True)

    src_ips_internal = ["10.0.0.5", "10.0.0.23", "192.168.1.10", "192.168.1.50"]
    src_ips_external = ["198.51.100.23", "203.0.113.10"]
    countries_normal = ["SE", "DE", "US", "NL", "FR"]
    countries_suspicious = ["RU", "CN"]

    start = datetime.now().replace(microsecond=0) - timedelta(hours=1)
    rows = []

    # normal traffic
    for i in range(900):
        ts = start + timedelta(seconds=random.randint(0, 3600))
        src = random.choice(src_ips_internal)
        dst = random_ip()
        dst_country = random.choice(countries_normal)
        bytes_sent = random.randint(1000, 50000)
        rows.append(
            {
                "timestamp": ts.isoformat(),
                "src_ip": src,
                "dst_ip": dst,
                "dst_country": dst_country,
                "bytes": bytes_sent,
                "label": "normal",
            }
        )

    # suspicious style traffic
    for i in range(100):
        ts = start + timedelta(seconds=random.randint(0, 3600))
        src = random.choice(src_ips_external)
        dst = random_ip()
        dst_country = random.choice(countries_suspicious)
        bytes_sent = random.randint(80000, 350000)
        rows.append(
            {
                "timestamp": ts.isoformat(),
                "src_ip": src,
                "dst_ip": dst,
                "dst_country": dst_country,
                "bytes": bytes_sent,
                "label": "suspicious",
            }
        )

    out_path = DATA_DIR / "flows.csv"
    fieldnames = ["timestamp", "src_ip", "dst_ip", "dst_country", "bytes", "label"]
    with out_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for r in rows:
            writer.writerow(r)

    print(f"[info] Wrote {len(rows)} flows to {out_path}")


if __name__ == "__main__":
    main()
