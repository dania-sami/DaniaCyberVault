
# Network Traffic Visualization Dashboard (Cyber Heatmap Lab)

Hi, I am Dania and I built this project to practise looking at network traffic the way a defender or SOC analyst would do it.

Instead of only printing logs, I wanted something that can

- aggregate flows
- draw a simple **traffic heatmap**
- highlight unusual sources and connections

This is my small network traffic visualization and anomaly scoring lab in Python.

---

## What this project does

The lab has three pieces.

1. **Synthetic flow generator**  
   I generate a CSV file `data/flows.csv` with network flow style records:
   - timestamp
   - source IP
   - destination IP
   - destination country (code)
   - bytes sent
   - label (normal or suspicious in the synthetic world)

2. **Traffic dashboard script**  
   A script loads the flows and:
   - computes total bytes per `(source, destination_country)` pair
   - identifies top talkers
   - computes a simple anomaly score (z score on bytes per source)
   - prints text summaries for a quick SOC style overview

3. **Cyber heatmap**  
   The same dashboard script also creates a heatmap image
   `output/traffic_heatmap.png` where
   - rows are source IPs
   - columns are destination countries
   - cell values are total bytes

This gives me a very visual way to talk about network patterns and suspicious traffic.

---

## Project structure

```text
network_traffic_dashboard/
  README.md
  requirements.txt
  generate_flows.py     # create synthetic network flows
  dashboard.py          # build summaries and a heatmap image
  data/
  output/
```

---

## Installation

```bash
python3 -m venv venv
source venv/bin/activate           # Windows  venv\Scripts\activate
pip install -r requirements.txt
```

---

## Step 1  Generate synthetic flows

```bash
python generate_flows.py
```

This creates:

- `data/flows.csv` with normal and suspicious looking flows

You can open the CSV to see how the data is structured.

---

## Step 2  Run the dashboard

```bash
python dashboard.py
```

The script will:

- load `data/flows.csv`
- print:
  - top source IPs by total bytes
  - a few flows with high anomaly scores
- save:

- `output/traffic_heatmap.png` — a heatmap of bytes by source and destination country

Example console output:

```text
[info] Loaded 1000 flows from data/flows.csv
[info] Top sources by total bytes:
  1. 10.0.0.5           total_bytes=  832104
  2. 10.0.0.23          total_bytes=  601992
  3. 192.168.1.50       total_bytes=  512340

[info] Flows with highest anomaly scores (per source):
  src=198.51.100.23  dst_country=RU  total_bytes= 320000  z_score= 3.10  label=suspicious
  src=203.0.113.10   dst_country=CN  total_bytes= 280000  z_score= 2.85  label=suspicious

[info] Saved heatmap to output/traffic_heatmap.png
```

You can open the PNG file to see the traffic heatmap visually.

---

## How I see this project

Network traffic analysis and visualisation are important in detection and threat hunting.

With this lab I show that I can

- work with flow style data
- aggregate and score traffic patterns
- and create a simple visual “dashboard” that could be extended into a web UI later

The code is intentionally small and easy to read so it can become a base for more advanced ideas like protocol specific views, live streaming data, or integration with real PCAP to flow tools.
