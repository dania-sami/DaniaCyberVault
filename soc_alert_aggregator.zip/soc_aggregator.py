import argparse
import json
from collections import Counter

def aggregate(path: str):
    sev_counter = Counter()
    host_counter = Counter()
    rule_counter = Counter()

    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                alert = json.loads(line)
            except json.JSONDecodeError:
                continue
            sev = alert.get("severity", "unknown")
            host = alert.get("host", "unknown")
            rule = alert.get("rule", "unknown")

            sev_counter[sev] += 1
            host_counter[host] += 1
            rule_counter[rule] += 1

    print(f"[+] Aggregated alerts from {path}\n")

    print("[+] Alerts by severity:")
    for sev, count in sev_counter.most_common():
        print(f"    {sev}: {count}")
    print()

    print("[+] Alerts by host:")
    for host, count in host_counter.most_common():
        print(f"    {host}: {count}")
    print()

    print("[+] Top rules:")
    for rule, count in rule_counter.most_common(10):
        print(f"    {rule}: {count}")

def main():
    parser = argparse.ArgumentParser(description="Simple SOC Alert Aggregator by Dania")
    parser.add_argument("--file", required=True, help="Path to JSONL alerts file")
    args = parser.parse_args()
    aggregate(args.file)

if __name__ == "__main__":
    main()
