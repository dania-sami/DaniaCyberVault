# Simple SOC Alert Aggregator

This is a small script I use to play with the idea of aggregating alerts like a tiny SOC tool.

It reads a JSON lines file where each line is an alert with fields like:

- `timestamp`
- `host`
- `severity`
- `rule`

Then it prints:

- Count of alerts per severity
- Count of alerts per host
- Top rules by frequency

## Files

- `soc_aggregator.py` – main script
- `demo_alerts.jsonl` – example alerts

## Usage

```bash
python soc_aggregator.py --file demo_alerts.jsonl
```
