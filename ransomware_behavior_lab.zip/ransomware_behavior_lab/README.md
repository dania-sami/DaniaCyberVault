# Ransomware Behavior Emulator and Detector (Safe Lab)

Hi, I am Dania 👋

This project is my **safe ransomware behavior lab**:

- I simulate ransomware-style activity only inside a local `test_data/` folder:
  lots of file renames and fake "encryption".
- Every action is logged to `logs/events.csv`.
- A detector script analyses the log and decides if the pattern looks
  like a ransomware run.

It is a controlled way to talk about **ransomware behaviour and detection**
without touching any real files on the system.

## How to run

```bash
cd ransomware_behavior_lab

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt   # stdlib only, this is a no-op

# 1) Simulate a ransomware-like run in the lab folder
python -m src.simulate

# 2) Analyse the activity log
python -m src.detect
```

The detector prints whether the activity looks ransomware-like plus a few stats.
