from __future__ import annotations

import csv
import time
from pathlib import Path
from typing import List

BASE_DIR = Path(__file__).resolve().parent.parent
TEST_DATA_DIR = BASE_DIR / "test_data"
LOGS_DIR = BASE_DIR / "logs"
LOGS_DIR.mkdir(parents=True, exist_ok=True)

LOG_PATH = LOGS_DIR / "events.csv"


def ensure_test_files() -> List[Path]:
    TEST_DATA_DIR.mkdir(parents=True, exist_ok=True)
    files = list(TEST_DATA_DIR.glob("*.txt"))
    if files:
        return files

    # Create some dummy files we are allowed to touch
    contents = [
        "Quarterly report draft\nConfidential demo text.\n",
        "Customer notes\nSample content for ransomware lab.\n",
        "Internal memo\nThis is only a test file.\n",
        "Backup config\nNot real data – for lab only.\n",
        "Random notes\nLorem ipsum for ransomware simulation.\n",
    ]
    created = []
    for i, text in enumerate(contents, start=1):
        path = TEST_DATA_DIR / f"lab_file_{i}.txt"
        path.write_text(text, encoding="utf-8")
        created.append(path)
    return created


def append_log(action: str, src: Path, dst: Path | None, size_before: int, size_after: int) -> None:
    header = ["timestamp", "action", "src", "dst", "size_before", "size_after"]
    write_header = not LOG_PATH.exists()
    with LOG_PATH.open("a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        if write_header:
            writer.writerow(header)
        writer.writerow(
            [
                time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime()),
                action,
                str(src),
                str(dst) if dst is not None else "",
                size_before,
                size_after,
            ]
        )


def simulate_ransomware_like_behaviour() -> None:
    files = ensure_test_files()
    print(f"Working only in lab folder: {TEST_DATA_DIR}")
    print(f"Found {len(files)} files to "encrypt".")

    for idx, path in enumerate(files, start=1):
        content = path.read_text(encoding="utf-8")
        size_before = path.stat().st_size

        # Fake "encryption": reverse text and add a marker
        encrypted = content[::-1] + "\n[LAB_ONLY_FAKE_ENCRYPTION]\n"
        target = path.with_suffix(path.suffix + ".locked")

        target.write_text(encrypted, encoding="utf-8")
        size_after = target.stat().st_size

        # Optionally, keep the original around for safety
        # In a real attack the original would be deleted.
        append_log("fake_encrypt", path, target, size_before, size_after)
        print(f"[{idx}/{len(files)}] Encrypted-like: {path.name} -> {target.name}")
        time.sleep(0.1)


def main() -> None:
    simulate_ransomware_like_behaviour()
    print(f"All actions logged to: {LOG_PATH}")


if __name__ == "__main__":
    main()
