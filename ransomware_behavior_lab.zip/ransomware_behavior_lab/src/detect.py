from __future__ import annotations

import csv
from pathlib import Path
from typing import List, Dict, Tuple

BASE_DIR = Path(__file__).resolve().parent.parent
LOGS_DIR = BASE_DIR / "logs"
LOG_PATH = LOGS_DIR / "events.csv"


def load_events() -> List[Dict[str, str]]:
    if not LOG_PATH.exists():
        print("No events log found. Run the simulator first with `python -m src.simulate`.")
        return []
    rows: List[Dict[str, str]] = []
    with LOG_PATH.open("r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            rows.append(row)
    return rows


def score_ransomware_pattern(events: List[Dict[str, str]]) -> Tuple[float, float]:
    if not events:
        return 0.0, 0.0
    total = len(events)
    encrypt_like = [e for e in events if e.get("action") == "fake_encrypt"]
    enc_count = len(encrypt_like)
    unique_src = {e.get("src") for e in encrypt_like}
    file_coverage = len(unique_src)

    # Very simple heuristic:
    # - density: ratio of encrypt-like actions to total actions
    density = enc_count / float(total)
    # - coverage: fraction of unique files touched (relative to log entries)
    coverage = file_coverage / float(max(file_coverage, 1))

    return density, coverage


def main() -> None:
    events = load_events()
    if not events:
        return

    density, coverage = score_ransomware_pattern(events)
    total = len(events)
    print(f"Analysed {total} logged actions.")
    print(f"Encrypt-like action density: {density:.2f}")
    print(f"Approx file coverage: {coverage:.2f}")

    # Decide on risk label
    if total >= 5 and density > 0.8 and coverage >= 0.8:
        verdict = "HIGH – behaviour strongly resembles a ransomware run in this folder."
    elif total >= 3 and density > 0.5:
        verdict = "MEDIUM – suspicious concentration of encrypt-like actions."
    else:
        verdict = "LOW – pattern does not look like ransomware here."

    print(f"Detector verdict: {verdict}")
    print("Note: this is a lab-only heuristic, not production detection logic.")


if __name__ == "__main__":
    main()
