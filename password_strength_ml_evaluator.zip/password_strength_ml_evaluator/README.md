# Password Strength Evaluator (ML-based)

Hi, I am Dania Sami 👋

There are many "password strength meters", but most of them are just
regex-based. I wanted to build a small, explainable **ML-flavoured evaluator**
that predicts how crackable a password might be based on simple features.

This is not a replacement for full cracking simulations, but it shows how
to turn security intuition into an ML pipeline.

---

## What this project does

1. **Uses a tiny synthetic training set**

   For demonstration, I include a small set of passwords with labels
   `weak`, `medium`, `strong` in `data/passwords.csv`.

   The important part is the **feature engineering**, not the dataset size.

2. **Extracts simple features**

   In `src/features.py` I compute:

   - length
   - count of digits
   - count of lowercase letters
   - count of uppercase letters
   - count of special characters

3. **Trains a classifier**

   `src/train.py` trains a `LogisticRegression` classifier on these features
   and saves the model to `models/password_model.joblib`.

4. **Scores user-provided passwords**

   `src/evaluate.py` provides a CLI where I can type:

   ```bash
   python -m src.evaluate --password "MyP@ssw0rd123"
   ```

   and get a label and a probability distribution.

---

## How to run

```bash
cd password_strength_ml_evaluator

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt
```

### Train the model

```bash
python -m src.train
```

### Evaluate a password

```bash
python -m src.evaluate --password "MyP@ssw0rd123"
```

---

## Project structure

```text
password_strength_ml_evaluator/
  ├─ README.md
  ├─ requirements.txt
  ├─ data/
  │    └─ passwords.csv
  ├─ models/
  │    └─ password_model.joblib
  └─ src/
       ├─ __init__.py
       ├─ config.py
       ├─ features.py
       ├─ train.py
       └─ evaluate.py
```

---

## Why I built this

This project lets me talk about:

- password cracking intuition
- feature engineering for security problems
- using ML in a **lightweight, transparent way**

It combines security thinking with hands-on data science skills.
