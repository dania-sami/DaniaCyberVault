from __future__ import annotations

import argparse

import joblib
import pandas as pd

from .config import MODEL_PATH
from .features import extract_features


def main() -> None:
    parser = argparse.ArgumentParser(description="Password strength evaluator")
    parser.add_argument("--password", type=str, required=True)
    args = parser.parse_args()

    feats = extract_features(args.password)
    X = pd.DataFrame([feats])

    clf = joblib.load(MODEL_PATH)
    proba = clf.predict_proba(X)[0]
    classes = clf.classes_
    idx = int(proba.argmax())

    print(f"Password: {args.password}")
    print(f"Predicted strength: {classes[idx]} (p={proba[idx]:.2f})")
    print("Full distribution:")
    for c, p in zip(classes, proba):
        print(f"  {c}: {p:.2f}")


if __name__ == "__main__":
    main()
