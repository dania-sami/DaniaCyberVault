from __future__ import annotations

import string


def extract_features(pw: str) -> dict:
    digits = sum(ch.isdigit() for ch in pw)
    lower = sum(ch.islower() for ch in pw)
    upper = sum(ch.isupper() for ch in pw)
    specials = sum(ch in string.punctuation for ch in pw)
    return {
        "length": len(pw),
        "digits": digits,
        "lower": lower,
        "upper": upper,
        "specials": specials,
    }
