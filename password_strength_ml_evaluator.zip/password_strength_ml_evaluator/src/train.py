from __future__ import annotations

import pandas as pd
import joblib
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split

from .config import PASSWORDS_CSV, MODEL_PATH
from .features import extract_features


def main() -> None:
    df = pd.read_csv(PASSWORDS_CSV)
    feature_rows = [extract_features(pw) for pw in df["password"]]
    X = pd.DataFrame(feature_rows)
    y = df["label"]

    X_train, X_val, y_train, y_val = train_test_split(
        X, y, test_size=0.3, random_state=42, stratify=y
    )

    clf = LogisticRegression(max_iter=1000, multi_class="auto")
    clf.fit(X_train, y_train)

    y_pred = clf.predict(X_val)
    print("Validation report:")
    print(classification_report(y_val, y_pred))

    joblib.dump(clf, MODEL_PATH)
    print(f"Model saved to {MODEL_PATH}")


if __name__ == "__main__":
    main()
