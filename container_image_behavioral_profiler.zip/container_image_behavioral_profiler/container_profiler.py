"""
Container Image Behavioral Profiler – Dania

Analyses simulated container runtime traces
and produces a simple behavioural risk profile.
"""

import argparse
import json
from dataclasses import dataclass, asdict
from typing import List, Dict


SENSITIVE_PATHS = ["/etc", "/root", "/var/log"]
SUSPICIOUS_PROCESSES = ["nc", "ncat", "netcat", "bash", "powershell", "curl", "wget"]
UNUSUAL_PORTS = [22, 23, 4444]


@dataclass
class ProcEvent:
    ts: str
    exe: str
    args: str


@dataclass
class FileEvent:
    ts: str
    path: str
    op: str  # read, write, delete


@dataclass
class NetEvent:
    ts: str
    dst_ip: str
    dst_port: int


@dataclass
class Profile:
    suspicious_process_count: int
    sensitive_writes: int
    unusual_network: int
    score: int


def load_trace(path: str):
    with open(path, "r", encoding="utf-8") as f:
        raw = json.load(f)
    procs = [ProcEvent(**e) for e in raw.get("process_events", [])]
    files = [FileEvent(**e) for e in raw.get("file_events", [])]
    nets = [NetEvent(**e) for e in raw.get("net_events", [])]
    return procs, files, nets


def build_profile(procs: List[ProcEvent], files: List[FileEvent], nets: List[NetEvent]) -> Profile:
    sus_procs = 0
    for p in procs:
        exe_name = p.exe.split("/")[-1].lower()
        if exe_name in SUSPICIOUS_PROCESSES:
            sus_procs += 1

    sens_writes = 0
    for f in files:
        if f.op == "write":
            for pref in SENSITIVE_PATHS:
                if f.path.startswith(pref):
                    sens_writes += 1
                    break

    unusual_net = 0
    for n in nets:
        if n.dst_port in UNUSUAL_PORTS:
            unusual_net += 1

    score = sus_procs * 2 + sens_writes * 3 + unusual_net * 2
    return Profile(
        suspicious_process_count=sus_procs,
        sensitive_writes=sens_writes,
        unusual_network=unusual_net,
        score=score,
    )


def write_outputs(profile: Profile, md_path: str, json_path: str) -> None:
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(asdict(profile), f, indent=2)

    with open(md_path, "w", encoding="utf-8") as f:
        f.write("# Container behavioural profile\n\n")
        f.write(f"* Suspicious process launches: {profile.suspicious_process_count}\n")
        f.write(f"* Writes to sensitive paths: {profile.sensitive_writes}\n")
        f.write(f"* Unusual network connections: {profile.unusual_network}\n")
        f.write(f"* Combined score: {profile.score}\n\n")

        if profile.score == 0:
            f.write("The trace looks calm with the current simple rules.\n")
        elif profile.score < 5:
            f.write("Some potentially interesting events were observed  worth a quick manual review.\n")
        else:
            f.write("Multiple signals of risky behaviour were found  this image or workload deserves a deeper analysis.\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's container image behavioural profiler")
    parser.add_argument("--trace", default="example_trace.json", help="Trace JSON file")
    parser.add_argument("--out-prefix", default="profile", help="Output prefix")
    args = parser.parse_args()

    procs, files, nets = load_trace(args.trace)
    profile = build_profile(procs, files, nets)
    md_path = f"{args.out_prefix}_report.md"
    json_path = f"{args.out_prefix}_profile.json"
    write_outputs(profile, md_path, json_path)

    print(f"Wrote behaviour profile to {md_path}")


if __name__ == "__main__":
    main()
