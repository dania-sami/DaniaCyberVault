# Container Image Behavioral Profiler – Dania

Hi

I am Dania and this profiler looks at simulated runtime traces for a container image

It takes a JSON file with process and network events and then scores the behaviour on

* file system writes to sensitive paths
* outbound network to unusual destinations
* use of suspicious binaries

The goal is to reason about container risk in a transparent way without running real containers from this tool
