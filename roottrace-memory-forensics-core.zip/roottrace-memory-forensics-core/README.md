
# RootTrace Memory Forensics Core

RootTrace is my way to talk about memory forensics without asking anyone to run
raw kernel tools on a live machine.

In real investigations we often use dedicated frameworks to pull memory,
scan for hooks, hidden processes, and strange drivers, and then we still need
to convert that raw output into a story that makes sense for incident response.

RootTrace focuses exactly on that second step. It takes structured findings
from external tools and turns them into

* a score for each snapshot
* clear findings with severity
* hints for next actions

This keeps the core clean and safe while still reflecting how I think about
kernel level threats.

## What the core does

* records memory snapshots per host with simple metadata
* accepts boolean style flags that describe what an external tool saw for example
  * kernel hooks
  * hidden processes
  * unsigned drivers
  * injected code
  * suspicious handles
* uses those signals to build a risk style score
* generates human readable findings with a description and a practical hint

The engine is not a replacement for real tools. It is a bridge between those
tools and the people who need to act on the results.

## Project layout

```text
roottrace-memory-forensics-core
└── backend
    ├── roottrace_core
    │   ├── __init__.py
    │   ├── engine.py  Snapshot model and scoring logic
    │   └── main.py    FastAPI HTTP API
    ├── requirements.txt
    └── example_requests.http
```

## How I run it locally

From the backend folder

```bash
python -m venv .venv
source .venv/bin/activate        # On Windows I use .venv\Scripts\activate
pip install -r requirements.txt
uvicorn roottrace_core.main:app --reload --port 9605
```

Then I open

* http://localhost:9605/docs to work with the endpoints

## Example flow I like to show

First I create a snapshot entry for a host

```bash
curl -X POST http://localhost:9605/snapshots   -H "Content-Type: application/json"   -d '{
    "host": "win10-lab-01",
    "meta": {"tool": "external_memory_collector", "case": "investigation-001"}
  }'
```

Then I simulate the output of a real memory analysis tool with some flags

```bash
curl -X POST http://localhost:9605/analyse   -H "Content-Type: application/json"   -d '{
    "snapshot_id": 1,
    "flags": {
      "kernel_hooks": true,
      "hidden_processes": true,
      "unsigned_drivers": false,
      "injected_code": true,
      "suspicious_handles": false
    }
  }'
```

RootTrace responds with a report that includes

* a score between zero and one hundred
* one finding per signal
* severity and plain language hints for each finding

Later I can list all reports to get a quick overview of which hosts look most
concerning.

```bash
curl http://localhost:9605/reports
```

## Why I built it this way

I want to be able to talk confidently about memory forensics as part of
incident response without pretending I always have full kernel access in every
environment. RootTrace lets me stay honest about the boundary

* external tools extract and detect
* this core explains and prioritises

It is simple to extend and a good foundation for a future pipeline where real
forensics tools push structured findings straight into this engine.
