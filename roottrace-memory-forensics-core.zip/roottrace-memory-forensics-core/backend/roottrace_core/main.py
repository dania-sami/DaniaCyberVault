
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Dict, List

from .engine import RootTraceBrain, MemorySnapshot, SnapshotReport, Finding


brain = RootTraceBrain()


class SnapshotIn(BaseModel):
    host: str = Field(..., example="win10-lab-01")
    meta: Dict[str, str] = Field(default_factory=dict)


class SnapshotOut(BaseModel):
    id: int
    host: str
    taken_at: str
    meta: Dict[str, str]


class AnalyseIn(BaseModel):
    snapshot_id: int
    flags: Dict[str, bool] = Field(
        default_factory=dict,
        description="Flags such as kernel_hooks, hidden_processes, unsigned_drivers, injected_code, suspicious_handles",
    )


class FindingOut(BaseModel):
    id: int
    snapshot_id: int
    type: str
    severity: str
    description: str
    hint: str


class ReportOut(BaseModel):
    snapshot_id: int
    host: str
    score: float
    findings: List[FindingOut]


app = FastAPI(
    title="RootTrace Memory Forensics Core",
    version="0.1.0",
    description="My safe memory forensics core based on structured findings from external tools.",
)


@app.post("/snapshots", response_model=SnapshotOut)
def create_snapshot(payload: SnapshotIn) -> SnapshotOut:
    snap: MemorySnapshot = brain.add_snapshot(host=payload.host, meta=payload.meta)
    return SnapshotOut(
        id=snap.id,
        host=snap.host,
        taken_at=snap.taken_at.isoformat() + "Z",
        meta=snap.meta,
    )


@app.post("/analyse", response_model=ReportOut)
def analyse(payload: AnalyseIn) -> ReportOut:
    if payload.snapshot_id not in brain.snapshots:
        raise HTTPException(status_code=404, detail="Snapshot not found")
    report: SnapshotReport = brain.analyse_snapshot(snapshot_id=payload.snapshot_id, flags=payload.flags)
    return ReportOut(
        snapshot_id=report.snapshot_id,
        host=report.host,
        score=report.score,
        findings=[
            FindingOut(
                id=f.id,
                snapshot_id=f.snapshot_id,
                type=f.type,
                severity=f.severity,
                description=f.description,
                hint=f.hint,
            )
            for f in report.findings
        ],
    )


@app.get("/reports", response_model=List[ReportOut])
def reports() -> List[ReportOut]:
    items: List[ReportOut] = []
    for rep in brain.list_reports():
        items.append(
            ReportOut(
                snapshot_id=rep.snapshot_id,
                host=rep.host,
                score=rep.score,
                findings=[
                    FindingOut(
                        id=f.id,
                        snapshot_id=f.snapshot_id,
                        type=f.type,
                        severity=f.severity,
                        description=f.description,
                        hint=f.hint,
                    )
                    for f in rep.findings
                ],
            )
        )
    return items
