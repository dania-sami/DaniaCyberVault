
from dataclasses import dataclass
from typing import Dict, List
from datetime import datetime


@dataclass
class MemorySnapshot:
    id: int
    host: str
    taken_at: datetime
    meta: Dict[str, str]


@dataclass
class Finding:
    id: int
    snapshot_id: int
    type: str
    severity: str
    description: str
    hint: str


@dataclass
class SnapshotReport:
    snapshot_id: int
    host: str
    score: float
    findings: List[Finding]


class RootTraceBrain:
    """
    This is my safe memory forensics core.

    It does not touch real live memory. Instead it works with structured
    summaries of what a separate memory tool may have discovered, for example

    * suspicious hooks
    * hidden processes
    * drivers without signatures
    * anomalies in kernel structures

    From these signals it produces a risk style score and findings that
    are easy to read in incident work.
    """

    def __init__(self) -> None:
        self.snapshots: Dict[int, MemorySnapshot] = {}
        self.findings: Dict[int, Finding] = {}
        self._next_snapshot_id = 1
        self._next_finding_id = 1

    def add_snapshot(self, host: str, meta: Dict[str, str]) -> MemorySnapshot:
        sid = self._next_snapshot_id
        self._next_snapshot_id += 1
        snap = MemorySnapshot(
            id=sid,
            host=host,
            taken_at=datetime.utcnow(),
            meta=meta,
        )
        self.snapshots[sid] = snap
        return snap

    def analyse_snapshot(self, snapshot_id: int, flags: Dict[str, bool]) -> SnapshotReport:
        snap = self.snapshots[snapshot_id]
        findings: List[Finding] = []
        score = 0.0

        def add_finding(type_: str, severity: str, description: str, hint: str, weight: float) -> None:
            nonlocal score
            fid = self._next_finding_id
            self._next_finding_id += 1
            f = Finding(
                id=fid,
                snapshot_id=snapshot_id,
                type=type_,
                severity=severity,
                description=description,
                hint=hint,
            )
            self.findings[fid] = f
            findings.append(f)
            score += weight

        if flags.get("kernel_hooks"):
            add_finding(
                type_="kernel_hooks",
                severity="critical",
                description="Potential kernel level hooks detected in system structures.",
                hint="Use a dedicated memory forensic tool set to validate hooks and compare to a known good baseline.",
                weight=35.0,
            )

        if flags.get("hidden_processes"):
            add_finding(
                type_="hidden_processes",
                severity="high",
                description="Processes referenced by kernel structures were not present in the normal process list.",
                hint="Investigate these processes with special care, collect artefacts and cross check with endpoint telemetry.",
                weight=25.0,
            )

        if flags.get("unsigned_drivers"):
            add_finding(
                type_="unsigned_drivers",
                severity="high",
                description="Unsigned or unknown drivers were present in memory.",
                hint="Check whether these drivers are expected, and if not, export them for further analysis.",
                weight=20.0,
            )

        if flags.get("injected_code"):
            add_finding(
                type_="injected_code",
                severity="high",
                description="Evidence of code injection within a user space process was reported.",
                hint="Dump the affected process for offline analysis and check for credential theft or remote access behaviour.",
                weight=20.0,
            )

        if flags.get("suspicious_handles"):
            add_finding(
                type_="suspicious_handles",
                severity="medium",
                description="Unusual handle relationships were found between processes.",
                hint="Review handle tables and see if they grant access that should not normally exist between processes.",
                weight=10.0,
            )

        score = min(100.0, score)
        report = SnapshotReport(
            snapshot_id=snap.id,
            host=snap.host,
            score=float(round(score, 1)),
            findings=findings,
        )
        return report

    def list_reports(self) -> List[SnapshotReport]:
        reports: List[SnapshotReport] = []
        for snap in self.snapshots.values():
            related = [f for f in self.findings.values() if f.snapshot_id == snap.id]
            score = 0.0
            for f in related:
                if f.severity == "critical":
                    score += 35.0
                elif f.severity == "high":
                    score += 20.0
                elif f.severity == "medium":
                    score += 10.0
            score = min(100.0, score)
            reports.append(
                SnapshotReport(
                    snapshot_id=snap.id,
                    host=snap.host,
                    score=float(round(score, 1)),
                    findings=related,
                )
            )
        return reports
