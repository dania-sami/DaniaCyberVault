# Cloud Cost Anomaly + Security Correlation Lab

Hi, I am Dania 👋

This project is my **cloud cost + security anomaly lab**:

- I generate synthetic daily cloud billing data and security events.
- I detect **cost spikes** using simple statistics.
- For each anomaly day, I show matching security events
  (new instances, GPU nodes, big egress, etc).

It is a concrete example of **FinOps x security analytics**.

## How to run

```bash
cd cloud_cost_security_anomaly_lab

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt

python -m src.analyse
```

The script prints anomaly days, their costs, and correlated events.
