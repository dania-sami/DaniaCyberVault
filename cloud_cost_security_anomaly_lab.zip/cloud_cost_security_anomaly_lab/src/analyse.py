from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"

BILLING_CSV = DATA_DIR / "billing.csv"
EVENTS_CSV = DATA_DIR / "events.csv"


def generate_data() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    # 30 days of synthetic billing
    days = pd.date_range("2026-01-01", periods=30, freq="D")
    rng = np.random.RandomState(42)
    base_cost = rng.normal(100, 5, size=len(days))
    spikes = np.zeros(len(days))
    spikes[10] = 120  # cryptomining day
    spikes[22] = 90   # data exfil day
    total_cost = base_cost + spikes

    billing = pd.DataFrame({"date": days, "total_cost": total_cost})
    billing.to_csv(BILLING_CSV, index=False)

    events = [
        ("2026-01-11", "new_gpu_fleet", "suspicious GPU node creation in unused region"),
        ("2026-01-11", "policy_change", "IAM policy changed for compute role"),
        ("2026-01-23", "egress_spike", "unusual outbound data transfer from storage bucket"),
        ("2026-01-23", "new_access_key", "new access key created for service account"),
        ("2026-01-05", "normal_scale_up", "legit auto-scaling event"),
    ]
    events_df = pd.DataFrame(events, columns=["date", "event_type", "details"])
    events_df.to_csv(EVENTS_CSV, index=False)


def load_data():
    if not BILLING_CSV.exists() or not EVENTS_CSV.exists():
        generate_data()
    billing = pd.read_csv(BILLING_CSV, parse_dates=["date"])
    events = pd.read_csv(EVENTS_CSV, parse_dates=["date"])
    return billing, events


def detect_anomalies(billing: pd.DataFrame, z_threshold: float = 2.0) -> pd.DataFrame:
    mean = billing["total_cost"].mean()
    std = billing["total_cost"].std(ddof=0)
    billing["z_score"] = (billing["total_cost"] - mean) / (std if std > 0 else 1.0)
    anomalies = billing[billing["z_score"].abs() >= z_threshold].copy()
    return anomalies.sort_values("date")


def main() -> None:
    billing, events = load_data()
    anomalies = detect_anomalies(billing)

    print("Cloud Cost Anomaly + Security Correlation Report")
    print("================================================\n")
    print(f"Analysed {len(billing)} days.")
    if anomalies.empty:
        print("No anomalies detected with current threshold.")
        return

    for _, row in anomalies.iterrows():
        day = row["date"].date()
        cost = row["total_cost"]
        z = row["z_score"]
        print(f"Anomaly on {day}: cost={cost:.2f}, z-score={z:.2f}")
        day_events = events[events["date"].dt.date == day]
        if day_events.empty:
            print("  No recorded security events.")
        else:
            print("  Correlated security events:")
            for _, ev in day_events.iterrows():
                print(f"    - {ev['event_type']}: {ev['details']}")
        print()


if __name__ == "__main__":
    main()
