
from dataclasses import dataclass
from typing import Dict, List, Literal, Optional


ActionType = Literal["allow", "deny"]


@dataclass
class Service:
    id: str
    name: str
    env: str                 # dev, staging, prod
    labels: Dict[str, str]   # for example {"tier": "frontend", "data": "public"}


@dataclass
class Policy:
    id: int
    src_service_id: str
    dst_service_id: str
    port: int
    protocol: str
    action: ActionType
    reason: str


@dataclass
class ConnectionRequest:
    src_service_id: str
    dst_service_id: str
    port: int
    protocol: str


@dataclass
class Decision:
    action: ActionType
    rationale: str
    matched_policy_id: Optional[int]
    suggested_policy: Optional[Policy]
    risk_score: float        # zero to one hundred
    notes: List[str]


class PolicyEngine:
    """
    Tiny but expressive zero trust policy engine for service to service connections.

    The logic is opinionated
    * deny by default
    * allow within the same environment for non sensitive ports
    * treat connections into production as high risk unless explicitly allowed
    """

    def decide(
        self,
        request: ConnectionRequest,
        services: Dict[str, Service],
        policies: List[Policy],
    ) -> Decision:
        notes: List[str] = []

        src = services.get(request.src_service_id)
        dst = services.get(request.dst_service_id)

        if not src or not dst:
            notes.append("Source or destination service is unknown. Hard deny.")
            return Decision(
                action="deny",
                rationale="Either the source or destination service is not registered.",
                matched_policy_id=None,
                suggested_policy=None,
                risk_score=95.0,
                notes=notes,
            )

        # First check explicit policies
        for p in policies:
            if (
                p.src_service_id == request.src_service_id
                and p.dst_service_id == request.dst_service_id
                and p.port == request.port
                and p.protocol.lower() == request.protocol.lower()
            ):
                notes.append(f"Matched explicit policy {p.id} with action {p.action}.")
                risk = 20.0 if p.action == "allow" else 5.0
                return Decision(
                    action=p.action,
                    rationale=f"Explicit policy {p.id} applied. {p.reason}",
                    matched_policy_id=p.id,
                    suggested_policy=None,
                    risk_score=risk,
                    notes=notes,
                )

        # No explicit policy found apply opinionated defaults
        same_env = src.env == dst.env
        sensitive_port = request.port in (22, 3306, 5432, 6379, 27017)

        notes.append(f"Source is in env {src.env}, destination is in env {dst.env}.")
        if sensitive_port:
            notes.append(f"Port {request.port} is treated as sensitive.")

        # Default risk baseline
        risk_score = 60.0

        if not same_env:
            notes.append("Cross environment traffic is not allowed by default.")
            risk_score = 90.0
            rationale = "Zero trust rule denies cross environment calls without explicit policy."
            suggested = Policy(
                id=-1,
                src_service_id=src.id,
                dst_service_id=dst.id,
                port=request.port,
                protocol=request.protocol,
                action="allow",
                reason="Manually reviewed and approved cross environment flow",
            )
            return Decision(
                action="deny",
                rationale=rationale,
                matched_policy_id=None,
                suggested_policy=suggested,
                risk_score=risk_score,
                notes=notes,
            )

        # Same environment
        if same_env and not sensitive_port:
            notes.append("Same environment and non sensitive port. Safe to allow with low risk.")
            risk_score = 15.0
            suggested = Policy(
                id=-1,
                src_service_id=src.id,
                dst_service_id=dst.id,
                port=request.port,
                protocol=request.protocol,
                action="allow",
                reason="Baseline same environment non sensitive flow",
            )
            return Decision(
                action="allow",
                rationale="No conflicting policy. Same environment non sensitive traffic.",
                matched_policy_id=None,
                suggested_policy=suggested,
                risk_score=risk_score,
                notes=notes,
            )

        # Same environment but sensitive
        if same_env and sensitive_port:
            notes.append("Same environment but sensitive port. Deny by default and ask for review.")
            risk_score = 75.0
            suggested = Policy(
                id=-1,
                src_service_id=src.id,
                dst_service_id=dst.id,
                port=request.port,
                protocol=request.protocol,
                action="allow",
                reason="Security team has verified this sensitive flow is required",
            )
            return Decision(
                action="deny",
                rationale="Sensitive port traffic requires explicit approval.",
                matched_policy_id=None,
                suggested_policy=suggested,
                risk_score=risk_score,
                notes=notes,
            )

        # Fallback
        notes.append("Reached fallback rule. Deny until reviewed.")
        return Decision(
            action="deny",
            rationale="No rule matched and defaults recommend denial.",
            matched_policy_id=None,
            suggested_policy=None,
            risk_score=risk_score,
            notes=notes,
        )
