
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Dict, List, Literal

from .store import store
from .policy_engine import Service, Policy, ConnectionRequest


app = FastAPI(
    title="ZeroTrust Orchestrator",
    version="0.1.0",
    description="Opinionated zero trust policy brain for service to service connections.",
)


class ServiceIn(BaseModel):
    id: str = Field(..., example="payments-api")
    name: str = Field(..., example="Payments API")
    env: str = Field(..., example="prod")
    labels: Dict[str, str] = Field(default_factory=dict)


class ServiceOut(ServiceIn):
    pass


class PolicyIn(BaseModel):
    src_service_id: str
    dst_service_id: str
    port: int
    protocol: str
    action: Literal["allow", "deny"]
    reason: str


class PolicyOut(BaseModel):
    id: int
    src_service_id: str
    dst_service_id: str
    port: int
    protocol: str
    action: Literal["allow", "deny"]
    reason: str


class ConnectionRequestIn(BaseModel):
    src_service_id: str
    dst_service_id: str
    port: int
    protocol: str = "tcp"


class SuggestedPolicyOut(PolicyOut):
    pass


class DecisionOut(BaseModel):
    action: Literal["allow", "deny"]
    rationale: str
    matched_policy_id: int | None
    suggested_policy: SuggestedPolicyOut | None
    risk_score: float
    notes: List[str]


@app.post("/services", response_model=ServiceOut)
def register_service(payload: ServiceIn) -> ServiceOut:
    svc = Service(
        id=payload.id,
        name=payload.name,
        env=payload.env,
        labels=payload.labels,
    )
    store.services[svc.id] = svc
    return ServiceOut(**payload.dict())


@app.get("/services", response_model=List[ServiceOut])
def list_services() -> List[ServiceOut]:
    return [
        ServiceOut(
            id=s.id,
            name=s.name,
            env=s.env,
            labels=s.labels,
        )
        for s in store.services.values()
    ]


@app.post("/policies", response_model=PolicyOut)
def create_policy(payload: PolicyIn) -> PolicyOut:
    if payload.src_service_id not in store.services or payload.dst_service_id not in store.services:
        raise HTTPException(status_code=400, detail="Both services must be registered before adding a policy.")
    pid = next(store.policy_id_counter)
    policy = Policy(
        id=pid,
        src_service_id=payload.src_service_id,
        dst_service_id=payload.dst_service_id,
        port=payload.port,
        protocol=payload.protocol,
        action=payload.action,
        reason=payload.reason,
    )
    store.policies.append(policy)
    return PolicyOut(
        id=policy.id,
        src_service_id=policy.src_service_id,
        dst_service_id=policy.dst_service_id,
        port=policy.port,
        protocol=policy.protocol,
        action=policy.action,
        reason=policy.reason,
    )


@app.get("/policies", response_model=List[PolicyOut])
def list_policies() -> List[PolicyOut]:
    return [
        PolicyOut(
            id=p.id,
            src_service_id=p.src_service_id,
            dst_service_id=p.dst_service_id,
            port=p.port,
            protocol=p.protocol,
            action=p.action,
            reason=p.reason,
        )
        for p in store.policies
    ]


@app.post("/simulate_connection", response_model=DecisionOut)
def simulate_connection(payload: ConnectionRequestIn) -> DecisionOut:
    req = ConnectionRequest(
        src_service_id=payload.src_service_id,
        dst_service_id=payload.dst_service_id,
        port=payload.port,
        protocol=payload.protocol,
    )
    result = store.engine.decide(req, store.services, store.policies)
    suggested = None
    if result.suggested_policy is not None:
        p = result.suggested_policy
        suggested = SuggestedPolicyOut(
            id=p.id,
            src_service_id=p.src_service_id,
            dst_service_id=p.dst_service_id,
            port=p.port,
            protocol=p.protocol,
            action=p.action,
            reason=p.reason,
        )

    return DecisionOut(
        action=result.action,
        rationale=result.rationale,
        matched_policy_id=result.matched_policy_id,
        suggested_policy=suggested,
        risk_score=result.risk_score,
        notes=result.notes,
    )
