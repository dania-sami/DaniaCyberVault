
from typing import Dict, List
from dataclasses import dataclass
import itertools

from .policy_engine import Service, Policy, PolicyEngine


@dataclass
class Store:
    services: Dict[str, Service]
    policies: List[Policy]
    policy_id_counter: itertools.count
    engine: PolicyEngine


store = Store(
    services={},
    policies=[],
    policy_id_counter=itertools.count(start=1),
    engine=PolicyEngine(),
)
