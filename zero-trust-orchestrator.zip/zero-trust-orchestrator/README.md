
# ZeroTrust Orchestrator

ZeroTrust Orchestrator is a small but opinionated policy brain for service to service communication.

Instead of managing firewall rules by hand you register your services once then ask the orchestrator whether a given connection should be allowed. It applies simple zero trust logic deny by default respect explicit policies and treat cross environment and sensitive traffic as high risk.

This prototype is ideal for labs demos and portfolios because you can clearly show

* services in different environments
* explicit allow or deny policies
* connection simulations with risk score and rationale

## Project layout

```text
zero-trust-orchestrator
└── backend
    ├── zero_trust_orchestrator
    │   ├── __init__.py
    │   ├── main.py          FastAPI app with HTTP endpoints
    │   ├── policy_engine.py Core decision logic
    │   └── store.py         In memory store for services and policies
    ├── requirements.txt
    └── example_requests.http
```

## Running the backend

From the backend folder

```bash
python -m venv .venv
source .venv/bin/activate        # On Windows use .venv\Scripts\activate
pip install -r requirements.txt
uvicorn zero_trust_orchestrator.main:app --reload --port 9400
```

The API will be reachable at

* http://localhost:9400
* interactive docs at http://localhost:9400/docs

## Typical workflow

### Step one register services

For example a frontend web service and a payments API in the same environment

```bash
curl -X POST http://localhost:9400/services   -H "Content-Type: application/json"   -d '{
    "id": "frontend-web",
    "name": "Web frontend",
    "env": "prod",
    "labels": {
      "tier": "frontend",
      "data": "public"
    }
  }'
```

```bash
curl -X POST http://localhost:9400/services   -H "Content-Type: application/json"   -d '{
    "id": "payments-api",
    "name": "Payments API",
    "env": "prod",
    "labels": {
      "tier": "backend",
      "data": "sensitive"
    }
  }'
```

### Step two add explicit policies where needed

Allow HTTPS traffic from frontend to payments

```bash
curl -X POST http://localhost:9400/policies   -H "Content-Type: application/json"   -d '{
    "src_service_id": "frontend-web",
    "dst_service_id": "payments-api",
    "port": 443,
    "protocol": "tcp",
    "action": "allow",
    "reason": "User traffic from web to payments API over TLS"
  }'
```

### Step three simulate a connection

```bash
curl -X POST http://localhost:9400/simulate_connection   -H "Content-Type: application/json"   -d '{
    "src_service_id": "frontend-web",
    "dst_service_id": "payments-api",
    "port": 443,
    "protocol": "tcp"
  }'
```

The response tells you

* whether the connection is allowed or denied
* which policy if any was matched
* suggested policy if none exists yet
* a risk score between zero and one hundred
* notes that describe how the decision was reached

If you change the port to a sensitive one such as twenty two the orchestrator will deny the request by default and suggest that you create an explicit policy only after review.

## Ideas for extending this project

You can grow this prototype into a serious zero trust orchestration system

* persist services and policies in a database
* expose a stream of decisions for auditing
* add support for groups such as all backends in prod
* generate firewall or service mesh rules from the policies
* integrate with a CI CD pipeline to block risky policies before deployment

This base already demonstrates a strong understanding of modern network security and zero trust thinking.
