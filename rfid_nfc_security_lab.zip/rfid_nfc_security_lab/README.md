
# RFID / NFC Security Testing Framework (Simulation Lab)

Hi, I am Dania and I built this project to simulate the security side of **RFID / NFC systems** without any physical hardware.

The framework focuses on four classic attack scenarios:

- **Replay** — an attacker reuses a previously captured tag response
- **Relay** — an attacker relays messages between a genuine tag and reader
- **Cloning** — an attacker creates a copy of a tag identifier
- **Basic detection** — simple logic to detect suspicious behaviour patterns

Everything is implemented in Python as a learning and demonstration lab.

---

## What this project does

The main script is `rfid_lab.py`. It lets me:

1. Create tags and readers

   - tags have `id`, `secret` and basic access control
   - readers can issue random challenges and verify responses

2. Simulate three common attack types:

   - **Replay attack**: reuse an old authentic response to a new challenge
   - **Relay attack**: attacker sits between tag and reader and forwards messages
   - **Clone attack**: attacker creates a cloned tag with the same ID as a genuine one

3. Run simple detection logic:

   - detect cloned tags based on impossible movement patterns
   - detect replay/relay behaviour based on inconsistent challenge/response pairs

All interactions are logged to the console so I can walk through each scenario step by step.

---

## Project structure

```text
rfid_nfc_security_lab/
  README.md
  requirements.txt
  rfid_lab.py          # main simulation and scenarios
  data/
```

No external hardware or libraries are needed, just pure Python.

---

## Installation

```bash
python3 -m venv venv
source venv/bin/activate       # Windows  venv\Scripts\activate
pip install -r requirements.txt
```

`requirements.txt` is empty because I only use the standard library.

---

## Usage

Run the demo scenarios:

```bash
python rfid_lab.py demo
```

This will:

- create a genuine tag and reader
- perform a normal authentication
- simulate a replay attack
- simulate a relay attack
- simulate a clone and then detect suspicious behaviour

You will see logs explaining what is happening in each step.

You can also run individual scenarios:

```bash
python rfid_lab.py replay
python rfid_lab.py relay
python rfid_lab.py clone
```

---

## How the protocol is modelled (simplified)

The challenge-response protocol is intentionally simple:

- Reader sends a random number `nonce`
- Tag computes `H = HMAC(secret, nonce)` (simulated with a hash)
- Reader verifies `H`

An attacker without the secret can:

- capture `(nonce, H)` once and reuse it later (replay)
- forward `nonce` to a real tag and send back the real `H` (relay)
- clone the ID of the tag and attempt to behave like it (clone)

The lab then shows which cases can be detected with basic logic.

---

## Why this project matters to me

RFID and NFC are everywhere: access cards, transport systems, payments.

With this project I can show that I:

- understand classic RFID/NFC attack patterns
- can model challenge-response authentication
- can simulate replay, relay and cloning attacks
- and can reason about simple detection strategies

It is a nice bridge between hardware security concepts and Python simulations.
