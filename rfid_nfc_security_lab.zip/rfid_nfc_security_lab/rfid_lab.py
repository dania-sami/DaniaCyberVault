
import argparse
import hashlib
import hmac
import os
import secrets
from dataclasses import dataclass

@dataclass
class Tag:
    tag_id: str
    secret: bytes

    def respond(self, nonce: bytes) -> bytes:
        return hmac.new(self.secret, nonce, hashlib.sha256).digest()

@dataclass
class Reader:
    name: str

    def issue_challenge(self) -> bytes:
        return secrets.token_bytes(16)

    def verify(self, tag: Tag, nonce: bytes, response: bytes) -> bool:
        expected = hmac.new(tag.secret, nonce, hashlib.sha256).digest()
        return hmac.compare_digest(expected, response)

def log(msg: str):
    print(msg)

def normal_auth_demo():
    log("[normal] Setting up reader and genuine tag")
    reader = Reader(name="Gate-A")
    tag = Tag(tag_id="TAG-001", secret=secrets.token_bytes(16))

    nonce = reader.issue_challenge()
    log(f"[normal] Reader -> Tag: nonce={nonce.hex()}")
    resp = tag.respond(nonce)
    log(f"[normal] Tag -> Reader: resp={resp.hex()}")
    ok = reader.verify(tag, nonce, resp)
    log(f"[normal] Verification result: {ok}")
    log("")

def replay_attack_demo():
    log("=== Replay attack demo ===")
    reader = Reader(name="Gate-A")
    tag = Tag(tag_id="TAG-001", secret=secrets.token_bytes(16))

    # attacker eavesdrops one valid session
    nonce1 = reader.issue_challenge()
    resp1 = tag.respond(nonce1)
    log(f"[replay] Captured pair: nonce={nonce1.hex()} resp={resp1.hex()}")

    # later, reader uses a NEW nonce
    nonce2 = reader.issue_challenge()
    log(f"[replay] Later challenge: nonce2={nonce2.hex()}")
    # attacker replays old response
    log("[replay] Attacker replays old response resp1")
    ok = reader.verify(tag, nonce2, resp1)
    log(f"[replay] Verification result with replayed response: {ok}")
    log("")

def relay_attack_demo():
    log("=== Relay attack demo ===")
    reader = Reader(name="Gate-A")
    tag = Tag(tag_id="TAG-REAL", secret=secrets.token_bytes(16))

    # attacker sits between reader and real tag
    nonce = reader.issue_challenge()
    log(f"[relay] Reader -> Attacker: nonce={nonce.hex()}")
    log("[relay] Attacker forwards nonce to real tag")
    resp = tag.respond(nonce)
    log("[relay] Real tag generates resp, attacker forwards to reader")
    ok = reader.verify(tag, nonce, resp)
    log(f"[relay] Verification result (relay succeeds): {ok}")
    log("")

def clone_attack_demo():
    log("=== Clone attack + simple detection demo ===")
    # Genuine tag at Door-1
    genuine_tag = Tag(tag_id="TAG-001", secret=secrets.token_bytes(16))
    reader1 = Reader(name="Door-1")
    reader2 = Reader(name="Door-2")

    # Attacker clones the ID but does NOT know secret
    cloned_tag = Tag(tag_id="TAG-001", secret=secrets.token_bytes(16))  # wrong secret

    # History of uses (location, tag_id)
    history = []

    # Genuine tag used at Door-1
    nonce1 = reader1.issue_challenge()
    resp1 = genuine_tag.respond(nonce1)
    ok1 = reader1.verify(genuine_tag, nonce1, resp1)
    history.append((reader1.name, genuine_tag.tag_id))
    log(f"[clone] Genuine use at {reader1.name}, ok={ok1}")

    # Clone tries access at Door-2 shortly after
    nonce2 = reader2.issue_challenge()
    resp2 = cloned_tag.respond(nonce2)
    ok2 = reader2.verify(genuine_tag, nonce2, resp2)  # verify against genuine secret
    history.append((reader2.name, cloned_tag.tag_id))
    log(f"[clone] Clone use at {reader2.name}, ok={ok2}")

    # Simple detection: same tag ID at two locations within a short time window
    # In this simple demo we just check if same tag_id appears at multiple locations.
    locations = {loc for loc, tid in history if tid == "TAG-001"}
    if len(locations) > 1:
        log(f"[detect] Suspicious: tag TAG-001 used at multiple locations {locations} in short time window")
    else:
        log("[detect] No suspicious movement detected")
    log("")

def main():
    parser = argparse.ArgumentParser(description="RFID / NFC security simulation lab")
    parser.add_argument(
        "mode",
        choices=["demo", "normal", "replay", "relay", "clone"],
        help="Which scenario to run",
    )
    args = parser.parse_args()

    if args.mode == "demo":
        normal_auth_demo()
        replay_attack_demo()
        relay_attack_demo()
        clone_attack_demo()
    elif args.mode == "normal":
        normal_auth_demo()
    elif args.mode == "replay":
        replay_attack_demo()
    elif args.mode == "relay":
        relay_attack_demo()
    elif args.mode == "clone":
        clone_attack_demo()

if __name__ == "__main__":
    main()
