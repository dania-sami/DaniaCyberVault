# Port Knocking Sequence Detector

This project is a small script I use to explore the idea of port knocking and simple pattern detection in connection logs.

It takes a CSV file with:

- `timestamp`
- `src_ip`
- `dst_port`

and tries to spot a specific knock sequence like `7000, 8000, 9000` from the same IP in order.

## Files

- `port_knock_detector.py` – main script
- `demo_knocks.csv` – demo data

## Usage

```bash
python port_knock_detector.py --csv demo_knocks.csv --sequence 7000,8000,9000
```
