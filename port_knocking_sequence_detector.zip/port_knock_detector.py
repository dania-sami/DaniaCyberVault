import argparse
import csv
from collections import defaultdict
from typing import List

def parse_sequence(seq: str) -> List[int]:
    return [int(x.strip()) for x in seq.split(",") if x.strip()]

def detect_knocks(path: str, seq: list):
    events_by_ip = defaultdict(list)
    with open(path, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            ip = row.get("src_ip", "")
            port = int(row.get("dst_port", "0"))
            ts = row.get("timestamp", "")
            events_by_ip[ip].append((ts, port))

    for ip, events in events_by_ip.items():
        events.sort(key=lambda e: e[0])
        ports = [p for _, p in events]
        n = len(seq)
        for i in range(len(ports) - n + 1):
            if ports[i:i+n] == seq:
                print(f"[+] Detected knock sequence from {ip}")
                for j in range(n):
                    ts, p = events[i+j]
                    print(f"    {ts}  port {p}")
                print()
                break

def main():
    parser = argparse.ArgumentParser(description="Port Knocking Sequence Detector by Dania")
    parser.add_argument("--csv", required=True, help="CSV file with timestamp,src_ip,dst_port")
    parser.add_argument("--sequence", required=True, help="Comma separated port sequence, e.g. 7000,8000,9000")
    args = parser.parse_args()
    seq = parse_sequence(args.sequence)
    detect_knocks(args.csv, seq)

if __name__ == "__main__":
    main()
