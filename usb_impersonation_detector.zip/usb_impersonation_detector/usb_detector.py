
import argparse
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import List

import pandas as pd

DATA_DIR = Path("data")

@dataclass
class USBDevice:
    name: str
    vendor_id: str
    product_id: str
    declared_class: str
    claimed_type: str
    keystrokes_per_second: float
    files_per_minute: float
    time_to_first_action_ms: int

def score_device(dev: USBDevice) -> dict:
    risk = 0.0
    reasons = []

    # very fast keyboards
    if dev.claimed_type == "keyboard":
        if dev.keystrokes_per_second > 15:
            risk += 0.5
            reasons.append("keyboard typing faster than humanly possible")
        if dev.time_to_first_action_ms < 200:
            risk += 0.3
            reasons.append("keyboard starts typing immediately after connect")

    # suspicious storage
    if dev.claimed_type == "thumb_drive":
        if dev.files_per_minute == 0:
            risk += 0.4
            reasons.append("storage device with no file activity")
        if dev.time_to_first_action_ms < 500:
            risk += 0.2
            reasons.append("storage device interacts unusually fast")

    # generic very fast start
    if dev.time_to_first_action_ms < 100:
        risk += 0.3
        reasons.append("device acts almost instantly after connect")

    if risk < 0:
        risk = 0.0
    if risk > 1:
        risk = 1.0

    if risk < 0.3:
        verdict = "Benign"
    elif risk < 0.7:
        verdict = "Suspicious"
    else:
        verdict = "Highly suspicious"

    row = asdict(dev)
    row.update({"risk_score": risk, "verdict": verdict, "reasons": "; ".join(reasons)})
    return row

def demo_devices() -> List[USBDevice]:
    return [
        USBDevice(
            name="normal_keyboard",
            vendor_id="0x046D",
            product_id="0xC31C",
            declared_class="HID",
            claimed_type="keyboard",
            keystrokes_per_second=3,
            files_per_minute=0,
            time_to_first_action_ms=1500,
        ),
        USBDevice(
            name="normal_thumb_drive",
            vendor_id="0x0781",
            product_id="0x5567",
            declared_class="STORAGE",
            claimed_type="thumb_drive",
            keystrokes_per_second=0,
            files_per_minute=20,
            time_to_first_action_ms=2000,
        ),
        USBDevice(
            name="rubber_ducky_sim",
            vendor_id="0xFFFF",
            product_id="0x0001",
            declared_class="HID",
            claimed_type="keyboard",
            keystrokes_per_second=30,
            files_per_minute=0,
            time_to_first_action_ms=50,
        ),
        USBDevice(
            name="ghost_storage",
            vendor_id="0x1234",
            product_id="0x5678",
            declared_class="STORAGE",
            claimed_type="thumb_drive",
            keystrokes_per_second=0,
            files_per_minute=0,
            time_to_first_action_ms=300,
        ),
    ]

def main():
    parser = argparse.ArgumentParser(description="USB device impersonation detection simulator")
    parser.add_argument("mode", choices=["demo"], help="Currently only 'demo' mode is implemented")
    args = parser.parse_args()

    DATA_DIR.mkdir(exist_ok=True)

    if args.mode == "demo":
        devs = demo_devices()
        scored = [score_device(d) for d in devs]
        df = pd.DataFrame(scored)
        out_path = DATA_DIR / "devices_scored.csv"
        df.to_csv(out_path, index=False)

        print(f"[info] Analysed {len(df)} devices, results written to {out_path}")
        print("device_name              verdict             risk_score")
        print("----------------------   ------------------  ----------")
        for _, row in df.iterrows():
            print(f"{row['name']:<22}   {row['verdict']:<18}  {row['risk_score']:<.2f}")

if __name__ == "__main__":
    main()
