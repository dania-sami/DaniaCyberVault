
# USB Device Impersonation Detection Simulator

Hi, I am Dania and I built this project to think about **malicious USB devices** and how to detect them from behaviour.

Instead of touching the OS USB stack, I simulate USB devices as records with:

- vendor and product IDs
- declared class (keyboard, storage, hub, etc.)
- behavioural features such as:
  - keystrokes per second
  - files accessed per minute
  - time to first action after connect

Then I run simple detection logic to flag “Rubber Ducky” style devices.

---

## What this project does

The main script is `usb_detector.py`. It:

1. Defines a small schema for USB devices, including:

   - `vendor_id`, `product_id`
   - `declared_class` (e.g. HID, STORAGE)
   - `claimed_type` (e.g. keyboard, thumb_drive)
   - `keystrokes_per_second`
   - `files_per_minute`
   - `time_to_first_action_ms`

2. Implements a scoring engine that:

   - flags “keyboards” that type extremely fast right after connect
   - flags “storage” devices that do no storage activity
   - flags any device that starts activity in under a suspicious threshold
   - assigns a `risk_score` (0..1) and `verdict` (Benign / Suspicious / Highly suspicious)

3. Includes a `demo` mode that simulates:

   - a normal keyboard
   - a normal thumb drive
   - a Rubber Ducky style HID injector
   - a suspicious “storage” device that never reads or writes

All results are printed and written to `data/devices_scored.csv`.

---

## Project structure

```text
usb_impersonation_detector/
  README.md
  requirements.txt
  usb_detector.py
  data/
```

---

## Installation

```bash
python3 -m venv venv
source venv/bin/activate          # Windows  venv\Scripts\activate
pip install -r requirements.txt
```

---

## Usage (demo mode)

```bash
python usb_detector.py demo
```

You will see output like:

```text
[info] Analysed 4 devices, results written to data/devices_scored.csv
device_name              verdict             risk_score
----------------------   ------------------  ----------
normal_keyboard          Benign              0.10
normal_thumb_drive       Benign              0.15
rubber_ducky_sim         Highly suspicious   0.92
ghost_storage            Suspicious          0.65
```

You can also imagine plugging in your own device data by editing the `demo_devices` list in the script.

---

## Why this project matters to me

Malicious USB devices are a classic physical interface attack.

With this project I can show that I:

- understand the difference between identity (what the device claims to be) and behaviour
- can design behavioural heuristics to spot “impossible” or risky patterns
- can present risk in a clear, data driven way

It is a nice bridge between hardware interfaces and behavioural security analytics.
