"""
Multi Cloud Secret Exposure Monitor – Dania

Recursively walks a directory and scans text files for:

* AWS style access keys
* generic API key patterns
* high-entropy strings that look secret-like

This is offline and best effort  not a replacement for specialised scanners.
"""

import argparse
import os
import re
import json
from dataclasses import dataclass, asdict
from typing import List


# crude AWS access key id pattern
AWS_ACCESS_KEY_RE = re.compile(r"AKIA[0-9A-Z]{16}")
GENERIC_KEY_RE = re.compile(r"(api[-_ ]?key|secret|token)[^\\n]{0,40}", re.IGNORECASE)


@dataclass
class SecretHit:
    path: str
    line_no: int
    kind: str
    snippet: str


def is_text_file(path: str, max_bytes: int = 4096) -> bool:
    try:
        with open(path, "rb") as f:
            chunk = f.read(max_bytes)
        # if null byte present  probably binary
        if b"\x00" in chunk:
            return False
        # try decode
        chunk.decode("utf-8", errors="ignore")
        return True
    except Exception:
        return False


def scan_file(path: str) -> List[SecretHit]:
    hits: List[SecretHit] = []
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            for idx, line in enumerate(f, start=1):
                stripped = line.strip()
                if not stripped:
                    continue
                for m in AWS_ACCESS_KEY_RE.finditer(line):
                    snippet = line[m.start():m.end()]
                    hits.append(SecretHit(path=path, line_no=idx, kind="aws_access_key", snippet=snippet))

                if GENERIC_KEY_RE.search(line):
                    snippet = stripped[:120]
                    hits.append(SecretHit(path=path, line_no=idx, kind="generic_key_pattern", snippet=snippet))
    except Exception:
        # ignore unreadable files
        pass
    return hits


def walk_and_scan(root: str) -> List[SecretHit]:
    all_hits: List[SecretHit] = []
    for dirpath, dirnames, filenames in os.walk(root):
        for name in filenames:
            full = os.path.join(dirpath, name)
            if not is_text_file(full):
                continue
            all_hits.extend(scan_file(full))
    return all_hits


def write_outputs(hits: List[SecretHit], md_path: str, json_path: str, root: str) -> None:
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump([asdict(h) for h in hits], f, indent=2)

    with open(md_path, "w", encoding="utf-8") as f:
        f.write("# Multi cloud secret exposure report\n\n")
        f.write(f"* Root scanned: `{root}`\n")
        f.write(f"* Total hits: {len(hits)}\n\n")
        current_file = None
        for h in hits:
            rel = os.path.relpath(h.path, root)
            if rel != current_file:
                current_file = rel
                f.write(f"## {rel}\n\n")
            f.write(f"- line {h.line_no}  [{h.kind}]  `{h.snippet}`\n")
        if not hits:
            f.write("No patterns were detected with the current simple rules.\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's multi cloud secret exposure monitor")
    parser.add_argument("--root", default="example_workspace", help="Root directory to scan")
    parser.add_argument("--out-prefix", default="secret_scan", help="Output prefix")
    args = parser.parse_args()

    hits = walk_and_scan(args.root)
    md_path = f"{args.out_prefix}_report.md"
    json_path = f"{args.out_prefix}_hits.json"
    write_outputs(hits, md_path, json_path, args.root)
    print(f"Scanned root {args.root}  hits={len(hits)}")
    print(f"Wrote report to {md_path}")


if __name__ == "__main__":
    main()
