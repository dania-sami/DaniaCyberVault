# Multi Cloud Secret Exposure Monitor – Dania

Hi

I am Dania and this monitor walks a directory that represents code  logs or container layers and scans for secrets

It looks for patterns like

* AWS style access keys
* obvious API key and token variables
* high entropy strings that look secret like

The output is a JSON and Markdown report so I can talk about secret exposure risk across repos  logs and images from one simple tool
