
import re, json, argparse

AWS=re.compile(r"AKIA[0-9A-Z]{16}")
AZURE=re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}")
GCP=re.compile(r"AIza[0-9A-Za-z\-_]{35}")

def scan(text):
    found=[]
    for name,rx in [("aws",AWS),("azure",AZURE),("gcp",GCP)]:
        for m in rx.findall(text):
            found.append({"provider":name,"secret":m})
    return found

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--file",required=True)
    p.add_argument("--out",default="secret_report.json")
    a=p.parse_args()
    txt=open(a.file,"r",encoding="utf-8").read()
    f=scan(txt)
    with open(a.out,"w",encoding="utf-8") as fd:
        json.dump(f,fd,indent=2)
    print("Wrote",a.out)

if __name__=="__main__":
    main()
