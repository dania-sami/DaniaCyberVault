# JWT Token Inspector

This is a tiny script I wrote to inspect JSON Web Tokens (JWTs) in a safe way.

It does not verify the signature or talk to any server. It simply:

- Splits the token into header, payload and signature
- Decodes header and payload from base64url
- Prints them nicely as JSON
- Warns if the algorithm is set to `none`

This is enough to talk about JWT structure and common pitfalls in interviews.

## Usage

```bash
python jwt_inspector.py --token "<your_jwt_here>"
```

I only use it with tokens from my own test apps or lab material.
