import argparse
import base64
import json

def b64url_decode(s: str) -> bytes:
    pad = "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode(s + pad)

def inspect_token(token: str):
    parts = token.split(".")
    if len(parts) != 3:
        print("[-] Not a valid JWT format (expected 3 parts)")
        return

    header_b64, payload_b64, signature_b64 = parts

    try:
        header = json.loads(b64url_decode(header_b64).decode("utf-8"))
    except Exception:
        header = None
    try:
        payload = json.loads(b64url_decode(payload_b64).decode("utf-8"))
    except Exception:
        payload = None

    print("[+] Header:")
    if header is not None:
        print(json.dumps(header, indent=2))
    else:
        print("  (could not decode header)")

    print("\n[+] Payload:")
    if payload is not None:
        print(json.dumps(payload, indent=2))
    else:
        print("  (could not decode payload)")

    if isinstance(header, dict):
        alg = header.get("alg")
        if alg == "none":
            print("\n[!] Warning: alg=none is unsafe in many scenarios.")

def main():
    parser = argparse.ArgumentParser(description="JWT Token Inspector by Dania")
    parser.add_argument("--token", required=True, help="JWT token string")
    args = parser.parse_args()
    inspect_token(args.token)

if __name__ == "__main__":
    main()
