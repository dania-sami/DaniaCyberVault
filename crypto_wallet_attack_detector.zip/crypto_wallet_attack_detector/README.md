# Crypto Wallet Heuristic Attack Detector

Hi, I am Dania Sami 👋

Crypto wallets can be drained very quickly once compromised.  
In real life you would monitor blockchain events, but for this project I
wanted a **safe, offline lab** that still shows solid reasoning.

This project is a **heuristic attack detector for wallet activity**:

- consumes a CSV file with synthetic transactions
- computes simple behavioural metrics per wallet
- flags wallets that look like they are under attack or being abused

No real blockchain connection is needed. Everything runs on local data.

---

## What this tool looks at

For each wallet address it calculates:

- total outgoing amount
- number of outgoing transactions
- ratio of outgoing to incoming transactions
- number of distinct destination addresses
- presence of a single "drain" transaction (very large percentage of balance)

It then assigns a simple risk level:

- `HIGH` – behaviour looks like a drain / exfil
- `MEDIUM` – many small outgoing tx to many destinations
- `LOW` – normal-looking pattern in this simplified model

---

## How to run

```bash
cd crypto_wallet_attack_detector

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt
```

Run the detector on the sample data:

```bash
python -m src.detect --path data/transactions.csv
```

You will see one line per wallet with:

- address
- risk level
- a short explanation

---

## Project structure

```text
crypto_wallet_attack_detector/
  ├─ README.md
  ├─ requirements.txt
  ├─ data/
  │    └─ transactions.csv
  └─ src/
       ├─ __init__.py
       └─ detect.py
```

---

## Why I built this

On the detection side, crypto is just another stream of events. This project
shows that I can:

- think in terms of **behavioural heuristics**
- aggregate transaction data per entity (wallet)
- provide human-readable risk explanations that analysts can trust
