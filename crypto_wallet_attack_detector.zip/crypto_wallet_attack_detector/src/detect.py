from __future__ import annotations

import argparse
from collections import defaultdict
from typing import Dict, List, Tuple

import pandas as pd


def assess_wallet(tx: pd.DataFrame) -> Tuple[str, List[str]]:
    reasons: List[str] = []

    outgoing = tx[tx["direction"] == "out"]
    incoming = tx[tx["direction"] == "in"]

    out_count = len(outgoing)
    in_count = len(incoming)
    out_sum = outgoing["amount"].sum()
    in_sum = incoming["amount"].sum()

    ratio = out_count / max(1, in_count)
    distinct_dests = outgoing["to"].nunique()

    risk = "LOW"

    if out_sum > 0 and in_sum > 0 and out_sum > 0.8 * (in_sum + out_sum):
        risk = "HIGH"
        reasons.append("Outgoing volume dominates total flow (possible drain).")

    if out_count >= 10 and distinct_dests >= 5:
        if risk != "HIGH":
            risk = "MEDIUM"
        reasons.append("Many outgoing tx to many destinations (possible scattering).")

    if ratio > 3 and out_count > 5:
        if risk == "LOW":
            risk = "MEDIUM"
        reasons.append("Outgoing tx count much higher than incoming.")

    if not reasons:
        reasons.append("No strong attack pattern detected in this simplified model.")

    return risk, reasons


def main() -> None:
    parser = argparse.ArgumentParser(description="Crypto wallet heuristic attack detector")
    parser.add_argument("--path", type=str, required=True, help="Path to transactions CSV")
    args = parser.parse_args()

    df = pd.read_csv(args.path)
    # expected columns: txid, wallet, direction, amount, to
    grouped: Dict[str, pd.DataFrame] = {addr: g for addr, g in df.groupby("wallet")}

    for wallet, tx in grouped.items():
        risk, reasons = assess_wallet(tx)
        print(f"Wallet: {wallet}")
        print(f"  Risk: {risk}")
        for r in reasons:
            print(f"   - {r}")
        print()


if __name__ == "__main__":
    main()
