from __future__ import annotations

import argparse

import joblib
import pandas as pd

from .config import MODEL_PATH


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="IoT device fingerprint classifier")
    p.add_argument("--avg-pkt-size", type=float, required=True)
    p.add_argument("--pkt-rate", type=float, required=True)
    p.add_argument("--protocol", type=str, choices=["TCP", "UDP"], required=True)
    p.add_argument("--directionality", type=float, required=True)
    return p.parse_args()


def main() -> None:
    args = parse_args()
    model = joblib.load(MODEL_PATH)

    df = pd.DataFrame(
        [
            {
                "avg_pkt_size": args.avg_pkt_size,
                "pkt_rate": args.pkt_rate,
                "protocol": args.protocol,
                "directionality": args.directionality,
            }
        ]
    )

    proba = model.predict_proba(df)[0]
    classes = model.classes_
    idx = int(proba.argmax())
    print(f"Predicted device type: {classes[idx]} (p={proba[idx]:.2f})")


if __name__ == "__main__":
    main()
