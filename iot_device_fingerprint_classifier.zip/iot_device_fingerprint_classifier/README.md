# IoT Device Fingerprint Classifier

Hi, I am Dania Sami 👋

Many IoT environments have **dozens of different device types** on the same
network. Being able to recognise which traffic belongs to which device type is
very powerful for security monitoring.

In this project I built a small **IoT traffic fingerprint classifier** that:

- works on simple flow-level features
- trains a multi-class ML model
- can predict the probable device type for new flows

The focus is on **structure and capability**, not on using real PCAPs, so I
keep the dataset synthetic and safe.

---

## What this project does

1. **Uses a synthetic flows dataset**

   In `data/flows.csv` I include records with:

   - `avg_pkt_size`
   - `pkt_rate`
   - `protocol` (TCP/UDP)
   - `directionality` (client_to_server ratio)
   - `device_type` (`camera`, `thermostat`, `speaker`, ...)

2. **Trains a classifier**

   `src/train.py`:

   - encodes the `protocol` column with `OneHotEncoder`
   - trains a `RandomForestClassifier`
   - writes the pipeline to `models/iot_model.joblib`

3. **Runs predictions from the command line**

   `src/predict.py` lets me call:

   ```bash
   python -m src.predict \
     --avg-pkt-size 700 \
     --pkt-rate 120 \
     --protocol TCP \
     --directionality 0.8
   ```

   and get a best guess like `camera (p=0.87)`.

---

## How to run

You need Python 3.10+.

```bash
python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt
```

### Train the model

```bash
python -m src.train
```

### Predict a device type

```bash
python -m src.predict   --avg-pkt-size 750   --pkt-rate 90   --protocol UDP   --directionality 0.4
```

---

## Project structure

```text
iot_device_fingerprint_classifier/
  ├─ README.md
  ├─ requirements.txt
  ├─ data/
  │    └─ flows.csv
  ├─ models/
  │    └─ iot_model.joblib
  └─ src/
       ├─ __init__.py
       ├─ config.py
       ├─ train.py
       └─ predict.py
```

---

## Why I built this

Device identity is a big deal in IoT security. This project shows that I can:

- think in terms of **traffic fingerprints**
- design features that separate device types
- train and ship a multi-class classifier for network telemetry
