
# TLS Handshake Analyzer (Security Posture Lab)

Hi, I am Dania and I built this project to explore **TLS client and server handshake security**.

I simulate TLS handshakes and then analyse them for:

- protocol version (TLS1.0, TLS1.2, TLS1.3)
- weak ciphersuites (RC4, 3DES, NULL)
- missing features (no SNI, no ALPN)
- insecure configuration patterns

The result is a small report that feels like a mini TLS audit.

---

## What this project does

The main script is `tls_analyzer.py`. It can:

1. Generate a demo dataset `data/handshakes.json` with entries for different servers, including:
   - `server_name`
   - `ip`
   - `protocol_version`
   - `offered_ciphers`
   - `selected_cipher`
   - `sni_present`
   - `alpn_protocols`
2. Analyse each handshake and flag issues such as:
   - use of TLS1.0 or TLS1.1
   - use of RC4, 3DES or NULL ciphers
   - no SNI for public looking servers
   - no ALPN for web like hosts
3. Write results to:
   - `data/tls_report.csv`
   - and print a concise summary sorted by risk score.

---

## Project structure

```text
tls_handshake_analyzer/
  README.md
  requirements.txt
  tls_analyzer.py
  data/
```

I use only the Python standard library.

---

## Installation

```bash
python3 -m venv venv
source venv/bin/activate            # Windows  venv\Scripts\activate
pip install -r requirements.txt
```

---

## Usage

```bash
python tls_analyzer.py demo
```

This will:

- generate synthetic handshake data
- run the analyzer
- write `data/handshakes.json` and `data/tls_report.csv`
- print the riskiest servers and why.

---

## Why this project matters to me

TLS configuration is a big part of practical security engineering.

With this project I can show that I:

- know what to look for in TLS handshakes
- can express those checks as code
- and can explain TLS risks to both engineers and non experts

It is a perfect conversation starter for crypto and protocol security.
