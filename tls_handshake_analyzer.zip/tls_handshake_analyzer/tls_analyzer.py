
import argparse
import csv
import json
from pathlib import Path

DATA_DIR = Path("data")
HANDSHAKES_FILE = DATA_DIR / "handshakes.json"


def gen_demo():
    DATA_DIR.mkdir(exist_ok=True)
    handshakes = [
        {
            "server_name": "modern-api",
            "ip": "203.0.113.10",
            "protocol_version": "TLS1.3",
            "offered_ciphers": ["TLS_AES_256_GCM_SHA384", "TLS_CHACHA20_POLY1305_SHA256"],
            "selected_cipher": "TLS_AES_256_GCM_SHA384",
            "sni_present": True,
            "alpn_protocols": ["h2", "http/1.1"],
        },
        {
            "server_name": "legacy-web",
            "ip": "203.0.113.20",
            "protocol_version": "TLS1.0",
            "offered_ciphers": ["TLS_RSA_WITH_3DES_EDE_CBC_SHA", "TLS_RSA_WITH_RC4_128_SHA"],
            "selected_cipher": "TLS_RSA_WITH_3DES_EDE_CBC_SHA",
            "sni_present": False,
            "alpn_protocols": [],
        },
        {
            "server_name": "internal-admin",
            "ip": "10.0.0.5",
            "protocol_version": "TLS1.2",
            "offered_ciphers": ["TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256", "TLS_RSA_WITH_AES_128_CBC_SHA"],
            "selected_cipher": "TLS_RSA_WITH_AES_128_CBC_SHA",
            "sni_present": False,
            "alpn_protocols": ["http/1.1"],
        },
        {
            "server_name": "payments-gateway",
            "ip": "198.51.100.50",
            "protocol_version": "TLS1.2",
            "offered_ciphers": ["TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384"],
            "selected_cipher": "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384",
            "sni_present": True,
            "alpn_protocols": ["h2"],
        },
    ]
    with HANDSHAKES_FILE.open("w", encoding="utf-8") as f:
        json.dump(handshakes, f, indent=2)
    print(f"[info] Demo handshakes written to {HANDSHAKES_FILE}")


def analyze():
    if not HANDSHAKES_FILE.is_file():
        raise SystemExit(f"Handshake file not found: {HANDSHAKES_FILE} (run demo first)")

    with HANDSHAKES_FILE.open("r", encoding="utf-8") as f:
        handshakes = json.load(f)

    reports = []
    weak_cipher_keywords = ["3des", "rc4", "null"]
    for h in handshakes:
        issues = []
        risk = 0.0
        version = h["protocol_version"].upper()
        selected = h["selected_cipher"].lower()
        is_public = not h["ip"].startswith("10.") and not h["ip"].startswith("192.168")

        if version in ("TLS1.0", "TLS1.1"):
            risk += 0.5
            issues.append(f"old protocol version {version}")
        if any(k in selected for k in weak_cipher_keywords):
            risk += 0.4
            issues.append(f"weak selected cipher {h['selected_cipher']}")
        if is_public and not h.get("sni_present", False):
            risk += 0.3
            issues.append("no SNI for public facing server")
        if is_public and not h.get("alpn_protocols"):
            risk += 0.2
            issues.append("no ALPN configured for web like host")

        reports.append({
            "server_name": h["server_name"],
            "ip": h["ip"],
            "protocol_version": h["protocol_version"],
            "selected_cipher": h["selected_cipher"],
            "sni_present": h["sni_present"],
            "alpn_protocols": ",".join(h["alpn_protocols"]),
            "risk_score": round(min(risk, 1.0), 2),
            "issues": "; ".join(issues) or "none",
        })

    out_path = DATA_DIR / "tls_report.csv"
    with out_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(reports[0].keys()))
        writer.writeheader()
        writer.writerows(reports)
    print(f"[info] TLS report written to {out_path}")
    print("[info] Servers sorted by risk:")
    for r in sorted(reports, key=lambda x: x["risk_score"], reverse=True):
        print(f"  {r['server_name']:16} ip={r['ip']:15} risk={r['risk_score']:.2f} issues={r['issues']}")


def main():
    parser = argparse.ArgumentParser(description="TLS handshake analyzer (simulated)")
    parser.add_argument("mode", choices=["demo"], help="Run demo generation + analysis")
    args = parser.parse_args()

    if args.mode == "demo":
        gen_demo()
        analyze()


if __name__ == "__main__":
    import argparse
    main()
