import argparse
from scapy.all import sniff, ARP

ip_mac_map: dict[str, str] = {}

def process_arp(pkt):
    if ARP in pkt and pkt[ARP].op == 2:  # is-at (reply)
        ip = pkt[ARP].psrc
        mac = pkt[ARP].hwsrc

        if ip in ip_mac_map:
            if ip_mac_map[ip] != mac:
                print("\n[!] Possible ARP spoof detected!")
                print(f"    IP: {ip}")
                print(f"    Old MAC: {ip_mac_map[ip]}")
                print(f"    New MAC: {mac}\n")
        else:
            print(f"[+] Learned ARP entry: {ip} -> {mac}")
        ip_mac_map[ip] = mac

def main():
    parser = argparse.ArgumentParser(description="ARP Spoofing Detection System by Dania")
    parser.add_argument("--iface", required=True, help="Interface to listen on, for example: eth0, wlan0, en0")
    args = parser.parse_args()

    print(f"[+] Watching ARP traffic on {args.iface}")
    print("[+] Press Ctrl+C to stop.\n")

    sniff(
        iface=args.iface,
        filter="arp",
        store=False,
        prn=process_arp,
    )

if __name__ == "__main__":
    main()
