# ARP Spoofing Detection System

This script is my small defensive tool to watch for ARP spoofing on a local network.

It listens for ARP replies and keeps track of which IP address belongs to which MAC address. If the mapping suddenly changes, it prints a clear warning so I can see that something suspicious might be happening.

## Features

- Monitors ARP traffic in real time
- Tracks IP to MAC mappings
- Warns when an IP appears with a new MAC address
- Simple console output that I can easily extend later

## Usage

Install `scapy` first:

```bash
pip install scapy
```

Run the detector (usually with sudo):

```bash
sudo python arp_watch.py --iface eth0
```

When a possible spoof is detected, the script prints a message showing the old and new MAC addresses for that IP.

## Why I like this project

This project helps me connect theory with practice:
- ARP spoofing is a classic attack
- Seeing it in packets makes it real
- Writing a small detector shows how defenders can react

Like my other projects, I only use this on my own network or in lab environments.
