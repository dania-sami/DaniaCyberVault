import argparse
import re
from collections import defaultdict

LINE_RE = re.compile(
    r"""^(?P<date>[A-Z][a-z]{2}\s+\d+\s+\d{2}:\d{2}:\d{2}).*Failed password for(?: invalid user)? (?P<user>\S+) from (?P<ip>\S+)"""
)

def analyse_log(path: str):
    stats = {}
    with open(path) as f:
        for line in f:
            m = LINE_RE.search(line)
            if not m:
                continue
            date = m.group("date")
            ip = m.group("ip")
            if ip not in stats:
                stats[ip] = {
                    "count": 0,
                    "first": date,
                    "last": date,
                }
            stats[ip]["count"] += 1
            stats[ip]["last"] = date

    print(f"[+] Analysing {path}\n")
    if not stats:
        print("[+] No failed SSH logins found with this pattern.")
        return

    for ip, info in stats.items():
        print(f"IP: {ip}")
        print(f"  attempts : {info['count']}")
        print(f"  first    : {info['first']}")
        print(f"  last     : {info['last']}\n")

def main():
    parser = argparse.ArgumentParser(description="SSH Failed Login Log Analyzer by Dania")
    parser.add_argument("--log", required=True, help="Path to SSH log file")
    args = parser.parse_args()
    analyse_log(args.log)

if __name__ == "__main__":
    main()
