# SSH Failed Login Log Analyzer

Hi, I am Dania and this is a small log analysis script I use to practice blue team thinking around SSH brute force attempts.

The script reads a log file (for example from `sshd`) and pulls out failed login attempts. It then aggregates them per source IP and prints a short summary with counts and timestamps.

## Features

- Simple pattern based parsing
- Counts failed attempts per IP
- Shows first and last seen time per IP
- Includes a small demo log so the script works right away

## Usage

With the included demo log:

```bash
python ssh_failed_logins.py --log demo_ssh_log.txt
```

Example output (shortened):

```text
[+] Analysing demo_ssh_log.txt

IP: 10.0.0.5
  attempts : 3
  first    : 2025-01-01 12:00:01
  last     : 2025-01-01 12:05:45

IP: 203.0.113.10
  attempts : 5
  first    : 2025-01-01 12:10:10
  last     : 2025-01-01 12:15:22
```

This is just for learning and practising log analysis. It does not touch any live system.
