# Supply Chain Dependency Risk Mapper – Dania’s package risk map

Hi

I am Dania and this project is my way of making software dependencies a bit less mysterious

Instead of just saying that supply chain risk is a problem
I wanted to build a small tool that actually reads a dependency list
computes a simple risk score for each package
and shows me which ones are the real troublemakers

It does not call any external APIs
Everything is offline and based on the metadata that I feed it

## Data model

The tool expects a JSON file with a list of packages
Each package has fields like

{
  "name": "fastjson",
  "version": "1.2.3",
  "direct": true,
  "critical": true,
  "known_vulns": 3,
  "last_release_year": 2016,
  "transitive_depth": 1
}

Fields

* name  package name
* version  version string
* direct  true if it is a direct dependency
* critical  true if the package is on a critical path for the system
* known_vulns  simple count of known issues from your own tracking
* last_release_year  rough year of last update
* transitive_depth  zero for direct dependencies deeper numbers for transitive ones

You can export this kind of structure from tools like dependency scanners or your own scripts

## How the risk score works

I keep the scoring model intentionally simple and transparent

For each package I add

* base score for being critical
* extra weight per known vulnerability
* age penalty if the package has not seen a release for many years
* bonus if it is deep in the dependency tree but still critical
* small bonus if it is a direct dependency because it is your responsibility

At the end I normalise the score into a simple float and sort packages from highest to lowest risk

The Markdown report shows the top packages first with a short explanation of why they scored high

## How I run it

1 Optional create and activate a virtual environment

   python3 -m venv venv
   source venv_bin_activate

2 Install requirements

   pip install -r requirements.txt

3 Look at the example dependency file

   examples_deps_sample.json

4 Run the mapper

   python dep_risk_mapper.py \
       --deps examples_deps_sample.json \
       --out deps_risk_report.md \
       --json-out deps_risk_scores.json

This will generate

* deps_risk_report.md  human friendly report
* deps_risk_scores.json  machine friendly scores for scripting

## Why this is useful for me

I like to think of this as a mini risk lens on top of a dependency tree

With this project I can talk about

* how to pick simple and explainable risk factors
* why age and known vulns matter in supply chain security
* how to present results in a way that a developer can actually act on
* ideas for integrating this into CI to warn about risky upgrades

It is a small but concrete step from buzzwords about supply chain risk to code that gives me a ranked list of what to fix first

