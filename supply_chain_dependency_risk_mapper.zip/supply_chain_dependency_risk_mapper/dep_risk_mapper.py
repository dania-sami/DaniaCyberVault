"""
Supply Chain Dependency Risk Mapper – Dania's risk lens

Reads a JSON dependency list
computes simple risk scores
and outputs a Markdown report and optional JSON
"""

import argparse
import json
from dataclasses import dataclass, asdict
from typing import List
from datetime import datetime


CURRENT_YEAR = datetime.utcnow().year


@dataclass
class Package:
    name: str
    version: str
    direct: bool
    critical: bool
    known_vulns: int
    last_release_year: int
    transitive_depth: int
    risk_score: float = 0.0
    reasons: str = ""


def load_deps(path: str) -> List[Package]:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    packages: List[Package] = []
    for obj in data:
        packages.append(
            Package(
                name=str(obj.get("name", "")),
                version=str(obj.get("version", "")),
                direct=bool(obj.get("direct", True)),
                critical=bool(obj.get("critical", False)),
                known_vulns=int(obj.get("known_vulns", 0)),
                last_release_year=int(obj.get("last_release_year", CURRENT_YEAR)),
                transitive_depth=int(obj.get("transitive_depth", 0)),
            )
        )
    return packages


def score_package(pkg: Package) -> None:
    score = 0.0
    reasons = []

    if pkg.critical:
        score += 3.0
        reasons.append("critical component")

    if pkg.direct:
        score += 1.0
        reasons.append("direct dependency")

    if pkg.known_vulns > 0:
        add = 1.5 * pkg.known_vulns
        score += add
        reasons.append(f"{pkg.known_vulns} known vulnerabilities")

    age = max(0, CURRENT_YEAR - pkg.last_release_year)
    if age >= 5:
        score += 2.0
        reasons.append(f"old package last updated around {pkg.last_release_year}")
    elif age >= 2:
        score += 1.0
        reasons.append(f"package has not been updated recently {pkg.last_release_year}")

    if pkg.transitive_depth > 1 and pkg.critical:
        score += 1.0
        reasons.append(f"critical but buried at depth {pkg.transitive_depth}")

    pkg.risk_score = round(score, 2)
    pkg.reasons = ", ".join(reasons) if reasons else "no obvious red flags"


def score_all(packages: List[Package]) -> None:
    for p in packages:
        score_package(p)
    packages.sort(key=lambda p: p.risk_score, reverse=True)


def write_report(packages: List[Package], out_path: str) -> None:
    with open(out_path, "w", encoding="utf-8") as f:
        f.write("# Dependency risk report\n\n")
        if not packages:
            f.write("No dependencies were provided.\n")
            return

        f.write("The following table shows dependencies ordered by descending risk score.\n\n")
        f.write("| Package | Version | Risk score | Notes |\n")
        f.write("|--------|---------|-----------|-------|\n")
        for p in packages:
            f.write(f"| `{p.name}` | `{p.version}` | {p.risk_score} | {p.reasons} |\n")


def write_json_scores(packages: List[Package], out_path: str) -> None:
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump([asdict(p) for p in packages], f, indent=2)


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's supply chain dependency risk mapper")
    parser.add_argument("--deps", required=True, help="Path to JSON file with dependency list")
    parser.add_argument("--out", default="deps_risk_report.md", help="Markdown report path")
    parser.add_argument("--json-out", help="Optional JSON output path for scores")
    args = parser.parse_args()

    packages = load_deps(args.deps)
    score_all(packages)
    write_report(packages, args.out)
    print(f"Wrote report to {args.out}")

    if args.json_out:
        write_json_scores(packages, args.json_out)
        print(f"Wrote JSON scores to {args.json_out}")


if __name__ == "__main__":
    main()
