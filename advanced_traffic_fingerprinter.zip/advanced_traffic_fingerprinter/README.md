
# Advanced Traffic Fingerprinting System (Metadata ML Lab)

Hi, I am Dania and I built this project to practise **classifying network traffic types from metadata only**.

Instead of using payloads, I simulate flows with features like:

- `packet_count`
- `avg_packet_size`
- `duration_s`
- `inter_arrival_jitter_ms`
- `dst_port`

and then train a ML model to distinguish between:

- VPN
- Tor
- SSH
- VoIP
- Web

This is the same mindset you need for encrypted traffic classification and privacy aware analytics.

---

## What this project does

The main script is `fingerprinter.py`. It:

1. Generates a synthetic dataset of flows with labels:
   - `vpn`
   - `tor`
   - `ssh`
   - `voip`
   - `web`
2. Assigns realistic-ish ranges for each class (e.g. Tor small packets, VoIP low jitter, SSH medium ports)
3. Trains a `RandomForestClassifier` using `scikit-learn`
4. Evaluates the model and prints:
   - accuracy
   - classification report
   - feature importances
5. Writes the dataset and predictions to:
   - `data/traffic_dataset.csv`
   - `data/traffic_predictions.csv`

Everything is contained in one script so it is easy to run and discuss.

---

## Project structure

```text
advanced_traffic_fingerprinter/
  README.md
  requirements.txt
  fingerprinter.py
  data/
```

---

## Installation

```bash
python3 -m venv venv
source venv/bin/activate            # Windows  venv\Scripts\activate
pip install -r requirements.txt
```

---

## Usage

```bash
python fingerprinter.py
```

You will see:

- dataset size
- accuracy and per class metrics
- which metadata features were most important

You can open the CSV files in any tool to inspect the flows.

---

## Why this project matters to me

Traffic fingerprinting on metadata is very relevant when payloads are encrypted.

With this project I can show that I:

- understand what metadata features actually matter
- can encode those assumptions into synthetic data
- can train and evaluate a machine learning model

It is a good bridge between network engineering, security and data science.
