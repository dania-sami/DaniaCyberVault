
from pathlib import Path
import random

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score
from sklearn.model_selection import train_test_split

DATA_DIR = Path("data")


def make_flow(label: str):
    # Simple hand tuned distributions per class
    if label == "vpn":
        packet_count = random.randint(200, 2000)
        avg_packet_size = random.uniform(600, 1100)
        duration_s = random.uniform(30, 600)
        jitter = random.uniform(10, 50)
        dst_port = random.choice([1194, 1197, 443])
    elif label == "tor":
        packet_count = random.randint(300, 4000)
        avg_packet_size = random.uniform(200, 600)
        duration_s = random.uniform(60, 1800)
        jitter = random.uniform(20, 80)
        dst_port = random.choice([9001, 9003, 443])
    elif label == "ssh":
        packet_count = random.randint(50, 1000)
        avg_packet_size = random.uniform(80, 400)
        duration_s = random.uniform(10, 3600)
        jitter = random.uniform(5, 40)
        dst_port = random.choice([22, 2222])
    elif label == "voip":
        packet_count = random.randint(100, 5000)
        avg_packet_size = random.uniform(60, 250)
        duration_s = random.uniform(30, 3600)
        jitter = random.uniform(1, 30)
        dst_port = random.choice([5060, 10000, 10001])
    else:  # web
        packet_count = random.randint(10, 2000)
        avg_packet_size = random.uniform(300, 1400)
        duration_s = random.uniform(1, 300)
        jitter = random.uniform(5, 60)
        dst_port = random.choice([80, 443, 8080])

    return {
        "packet_count": packet_count,
        "avg_packet_size": avg_packet_size,
        "duration_s": duration_s,
        "inter_arrival_jitter_ms": jitter,
        "dst_port": dst_port,
        "label": label,
    }


def build_dataset(n_per_class=400):
    random.seed(42)
    rows = []
    classes = ["vpn", "tor", "ssh", "voip", "web"]
    for cls in classes:
        for _ in range(n_per_class):
            rows.append(make_flow(cls))
    random.shuffle(rows)
    return pd.DataFrame(rows)


def main():
    DATA_DIR.mkdir(exist_ok=True)
    df = build_dataset()
    dataset_path = DATA_DIR / "traffic_dataset.csv"
    df.to_csv(dataset_path, index=False)
    print(f"[info] Generated dataset with {len(df)} flows at {dataset_path}")

    X = df[["packet_count", "avg_packet_size", "duration_s", "inter_arrival_jitter_ms", "dst_port"]]
    y = df["label"]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)

    clf = RandomForestClassifier(n_estimators=200, random_state=42)
    clf.fit(X_train, y_train)
    y_pred = clf.predict(X_test)

    acc = accuracy_score(y_test, y_pred)
    print(f"[info] Accuracy: {acc:.3f}")
    print("[info] Classification report:")
    print(classification_report(y_test, y_pred))

    importances = clf.feature_importances_
    for name, imp in zip(X.columns, importances):
        print(f"[info] Feature importance: {name:24} {imp:.3f}")

    preds = X_test.copy()
    preds["true_label"] = y_test.values
    preds["predicted_label"] = y_pred
    preds_path = DATA_DIR / "traffic_predictions.csv"
    preds.to_csv(preds_path, index=False)
    print(f"[info] Predictions written to {preds_path}")


if __name__ == "__main__":
    main()
