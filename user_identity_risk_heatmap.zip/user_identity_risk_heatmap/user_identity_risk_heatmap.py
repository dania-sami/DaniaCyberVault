"""
User Identity Risk Heatmap – Dania

Input JSONL risk signals, one per line:

{"ts":"2025-01-01T09:00:00","user":"alice","signal":"impossible_travel"}
{"ts":"2025-01-01T09:05:00","user":"alice","signal":"many_failures"}

Signals are mapped to weights and aggregated into a risk score per user.
"""

import argparse
import json
from dataclasses import dataclass, asdict
from typing import List, Dict

SIGNAL_WEIGHTS = {
    "many_failures": 2,
    "impossible_travel": 4,
    "new_geo": 2,
    "new_device": 2,
    "mfa_bypass": 5,
    "disabled_mfa": 5,
    "suspicious_inbox_rule": 3,
    "privilege_escalation": 4,
}


@dataclass
class RiskEvent:
    ts: str
    user: str
    signal: str


@dataclass
class UserRisk:
    user: str
    score: int
    signals: Dict[str, int]


def load_events(path: str) -> List[RiskEvent]:
    events: List[RiskEvent] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            events.append(
                RiskEvent(
                    ts=obj.get("ts", ""),
                    user=obj.get("user", "unknown"),
                    signal=obj.get("signal", "unknown"),
                )
            )
    return events


def compute_risk(events: List[RiskEvent]) -> List[UserRisk]:
    by_user: Dict[str, Dict[str, int]] = {}
    for e in events:
        if e.user not in by_user:
            by_user[e.user] = {}
        by_user[e.user][e.signal] = by_user[e.user].get(e.signal, 0) + 1

    risks: List[UserRisk] = []
    for user, signals in by_user.items():
        score = 0
        for signal, count in signals.items():
            weight = SIGNAL_WEIGHTS.get(signal, 1)
            score += weight * count
        risks.append(UserRisk(user=user, score=score, signals=signals))

    risks.sort(key=lambda r: r.score, reverse=True)
    return risks


def write_outputs(risks: List[UserRisk], md_path: str, json_path: str) -> None:
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump([asdict(r) for r in risks], f, indent=2)

    with open(md_path, "w", encoding="utf-8") as f:
        f.write("# User identity risk heatmap\n\n")
        f.write(f"* Users with any risk: {len(risks)}\n\n")
        if not risks:
            f.write("No risk signals were found.\n")
            return

        f.write("| user | score | top signals |\n")
        f.write("|------|-------|-------------|\n")
        for r in risks:
            sorted_signals = sorted(r.signals.items(), key=lambda kv: kv[1], reverse=True)
            top = ", ".join(f"{name}×{count}" for name, count in sorted_signals[:4])
            f.write(f"| {r.user} | {r.score} | {top} |\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's user identity risk heatmap")
    parser.add_argument("--signals", default="example_signals.jsonl", help="Risk signals JSONL")
    parser.add_argument("--out-prefix", default="identity_risk", help="Output prefix")
    args = parser.parse_args()

    events = load_events(args.signals)
    risks = compute_risk(events)
    md_path = f"{args.out_prefix}_report.md"
    json_path = f"{args.out_prefix}_scores.json"
    write_outputs(risks, md_path, json_path)
    print(f"Analysed {len(events)} signals  users={len(risks)}")
    print(f"Wrote report to {md_path}")


if __name__ == "__main__":
    main()
