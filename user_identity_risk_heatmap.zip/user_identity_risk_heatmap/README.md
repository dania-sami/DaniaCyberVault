# User Identity Risk Heatmap – Dania

Hi

I am Dania and this project turns raw identity risk signals into a simple per user heatmap

It ingests JSON events like new device  new location  many failures and mfa bypass and then rolls them into one risk score per account

The result is a Markdown table plus JSON data that makes it easier to spot which identities I should look at first
