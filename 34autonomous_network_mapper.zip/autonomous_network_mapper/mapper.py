
import json
import random
from pathlib import Path

DATA_DIR = Path("data")
TARGETS_FILE = Path("targets.json")

ORG_POOL = [
    {"org": "CoreNet Operations", "asn": "AS64500", "country": "SE"},
    {"org": "Edge Services", "asn": "AS64510", "country": "SE"},
    {"org": "3rdParty Hosting", "asn": "AS64520", "country": "DE"},
    {"org": "Legacy Segment", "asn": "AS64530", "country": "US"},
]

SERVICE_BANNERS = {
    22: ["OpenSSH_9.3p1", "OpenSSH_7.4", "Dropbear_2016.74"],
    80: ["Apache/2.4.57", "Apache/2.2.31", "nginx/1.24.0"],
    443: ["nginx/1.22.0 (TLS1.2)", "nginx/1.14.2 (TLS1.0)", "Envoy edge proxy"],
    3306: ["MySQL 8.0.36", "MySQL 5.5.62"],
    5432: ["PostgreSQL 16.0", "PostgreSQL 9.3"],
}

DEFAULT_TARGETS = [
    {"hostname": "app-frontend", "ip": "10.0.1.10", "tags": ["public", "web"]},
    {"hostname": "app-backend", "ip": "10.0.2.20", "tags": ["internal", "api"]},
    {"hostname": "db-primary", "ip": "10.0.3.30", "tags": ["internal", "db"]},
    {"hostname": "legacy-admin", "ip": "10.0.4.40", "tags": ["admin", "legacy"]},
]

random.seed(42)


def load_targets():
    if TARGETS_FILE.is_file():
        with TARGETS_FILE.open("r", encoding="utf-8") as f:
            return json.load(f)
    return DEFAULT_TARGETS


def simulate_traceroute(ip: str):
    hop_count = random.randint(3, 6)
    hops = []
    for i in range(hop_count):
        hops.append({
            "hop": i + 1,
            "ip": f"192.0.2.{random.randint(1, 254)}",
            "rtt_ms": round(random.uniform(1.0, 40.0), 2),
        })
    hops.append({"hop": hop_count + 1, "ip": ip, "rtt_ms": round(random.uniform(5.0, 10.0), 2)})
    return hops


def simulate_org_info(ip: str):
    return random.choice(ORG_POOL)


def simulate_services(tags):
    services = []
    candidate_ports = [22, 80, 443, 3306, 5432]
    for port in candidate_ports:
        # simple rule: internal/db hosts more likely to expose db ports
        base_prob = 0.15
        if port in (3306, 5432) and "db" in tags:
            base_prob = 0.7
        if port in (80, 443) and "web" in tags:
            base_prob = 0.8
        if port == 22 and "admin" in tags:
            base_prob = 0.9

        if random.random() < base_prob:
            banner = random.choice(SERVICE_BANNERS[port])
            services.append({
                "port": port,
                "protocol": "tcp",
                "banner": banner,
            })
    return services


def risk_from_services(services, tags, org):
    score = 0.0
    reasons = []

    for s in services:
        port = s["port"]
        banner = s["banner"]
        # risky ports exposed
        if port in (22, 3306, 5432) and "public" in tags:
            score += 0.3
            reasons.append(f"public {port}/tcp exposed")
        if "OpenSSH_7" in banner or "OpenSSH_6" in banner:
            score += 0.2
            reasons.append("old SSH banner")
        if "Apache/2.2" in banner:
            score += 0.25
            reasons.append("legacy Apache 2.2 banner")
        if "TLS1.0" in banner:
            score += 0.2
            reasons.append("weak TLS 1.0 in banner")
        if "MySQL 5.5" in banner or "PostgreSQL 9.3" in banner:
            score += 0.2
            reasons.append("old database version")

    if org["org"] == "Legacy Segment":
        score += 0.2
        reasons.append("host in legacy segment org")

    return min(score, 1.0), reasons


def main():
    DATA_DIR.mkdir(exist_ok=True)
    targets = load_targets()

    nodes = []
    csv_rows = []

    for t in targets:
        traceroute = simulate_traceroute(t["ip"])
        org_info = simulate_org_info(t["ip"])
        services = simulate_services(t["tags"])
        risk_score, reasons = risk_from_services(services, t["tags"], org_info)

        node = {
            "hostname": t["hostname"],
            "ip": t["ip"],
            "tags": t["tags"],
            "org": org_info["org"],
            "asn": org_info["asn"],
            "country": org_info["country"],
            "traceroute": traceroute,
            "services": services,
            "risk_score": round(risk_score, 2),
            "risk_reasons": reasons,
        }
        nodes.append(node)
        csv_rows.append({
            "hostname": t["hostname"],
            "ip": t["ip"],
            "org": org_info["org"],
            "asn": org_info["asn"],
            "country": org_info["country"],
            "tags": ",".join(t["tags"]),
            "risk_score": round(risk_score, 2),
            "risk_reasons": "; ".join(reasons),
            "services": "; ".join(f"{s['port']}/{s['protocol']} {s['banner']}" for s in services),
        })

    graph = {
        "nodes": nodes,
    }
    json_path = DATA_DIR / "attack_surface.json"
    with json_path.open("w", encoding="utf-8") as f:
        json.dump(graph, f, indent=2)

    import csv
    csv_path = DATA_DIR / "attack_surface.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(csv_rows[0].keys()))
        writer.writeheader()
        for row in csv_rows:
            writer.writerow(row)

    print(f"[info] Mapped {len(nodes)} targets.")
    print(f"[info] JSON graph: {json_path}")
    print(f"[info] CSV summary: {csv_path}")
    print("[info] Top risky hosts:")
    for node in sorted(nodes, key=lambda n: n["risk_score"], reverse=True):
        print(
            f"  {node['hostname']:15}  ip={node['ip']:12}  "
            f"risk={node['risk_score']:.2f}  reasons={', '.join(node['risk_reasons']) or 'none'}"
        )


if __name__ == "__main__":
    main()
