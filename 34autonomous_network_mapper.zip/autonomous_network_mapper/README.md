
# Autonomous Network Mapping AI (Simulation Lab)

Hi, I am Dania and I built this project to simulate how **modern network mapping and attack surface discovery** works, but in a safe, self contained way.

Instead of actually touching the internet, I:

- take a small list of target hosts
- simulate traceroute hops, WHOIS-like ownership and ASN info
- simulate service banner grabbing on common ports
- build a combined **attack surface map** and risk score per host

This is exactly the kind of thinking behind real recon tools, just with fully synthetic data.

---

## What this project does

The main script is `mapper.py`. It:

1. Loads a small list of targets from `targets.json` (or uses a built in default list)
2. For each target, simulates:
   - traceroute path (`hops`)
   - WHOIS / ASN style info (`org`, `asn`, `country`)
   - open services with banners (e.g. `ssh`, `http`, `db`)
3. Calculates a simple **risk score** based on:
   - exposed services on risky ports
   - old looking banners (e.g. `OpenSSH_6`, `Apache/2.2`)
   - whether the host is in an “unmanaged” org segment
4. Writes the full structured map to:
   - `data/attack_surface.json` (graph style data)
   - `data/attack_surface.csv` (table per host)
5. Prints a short human readable summary to the console.

Everything is simulated so I can run it anywhere without needing real network access.

---

## Project structure

```text
autonomous_network_mapper/
  README.md
  requirements.txt      # empty, standard library only
  mapper.py
  targets.json          # optional input list of targets
  data/
```

---

## Installation

```bash
python3 -m venv venv
source venv/bin/activate            # Windows  venv\Scripts\activate
pip install -r requirements.txt
```

---

## Usage

From inside `autonomous_network_mapper`:

```bash
python mapper.py
```

This will:

- use the sample `targets.json` (or built in defaults)
- generate synthetic mapping data
- write `data/attack_surface.json` and `data/attack_surface.csv`
- print a small “top risky hosts” view

You can edit `targets.json` to customise hostnames, IPs, and tags, then run the script again.

---

## Why this project matters to me

Autonomous recon and attack surface mapping is how many assessments begin today.

With this project I can show that I:

- understand the core building blocks (traceroute, WHOIS/ASN, banners, risk scoring)
- can combine them into a unified view of a network
- and can think like both a defender and an attacker when talking about exposure

Even though the data is synthetic, the pipeline mirrors real world workflows.
