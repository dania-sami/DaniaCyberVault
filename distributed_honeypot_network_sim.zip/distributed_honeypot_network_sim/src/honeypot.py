from __future__ import annotations

import socket
import threading
from datetime import datetime
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
LOG_DIR = BASE_DIR / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)


def log_line(service: str, text: str) -> None:
    ts = datetime.utcnow().isoformat()
    path = LOG_DIR / f"{service}.log"
    with path.open("a", encoding="utf-8") as f:
        f.write(f"[{ts}] {text}\n")


def handle_client(conn: socket.socket, addr, service: str) -> None:
    try:
        conn.settimeout(30)
        if service == "ssh":
            banner = b"SSH-2.0-OpenSSH_7.9p1 Debian-10\r\n"
            conn.sendall(banner)
        elif service == "http":
            conn.sendall(b"HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\nHello from honeypot.\n")
        elif service == "db":
            conn.sendall(b"Fake DB server ready. Type commands.\n")

        data = conn.recv(4096)
        text = data.decode(errors="ignore").strip()
        log_line(service, f"from={addr} data={text}")
    except Exception as e:
        log_line(service, f"error handling {addr}: {e}")
    finally:
        try:
            conn.close()
        except Exception:
            pass


def run_server(port: int, service: str) -> None:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("0.0.0.0", port))
    s.listen(5)
    log_line(service, f"{service} honeypot listening on {port}")
    print(f"{service.upper()} honeypot listening on port {port}")
    while True:
        conn, addr = s.accept()
        log_line(service, f"connection from {addr}")
        t = threading.Thread(target=handle_client, args=(conn, addr, service), daemon=True)
        t.start()


def main() -> None:
    threads = []
    config = [
        (2222, "ssh"),
        (8081, "http"),
        (5433, "db"),
    ]
    for port, name in config:
        t = threading.Thread(target=run_server, args=(port, name), daemon=True)
        t.start()
        threads.append(t)

    print("Distributed honeypot network is running.")
    print("Press Ctrl+C to stop.")
    try:
        for t in threads:
            t.join()
    except KeyboardInterrupt:
        print("Stopping honeypots.")


if __name__ == "__main__":
    main()
