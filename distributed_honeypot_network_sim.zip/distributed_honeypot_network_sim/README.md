# Distributed Honeypot Network (Simulated)

Hi, I am Dania Sami 👋

I wanted a way to talk about honeypots and attacker behaviour without needing
complex infrastructure. So I built a **simulated distributed honeypot
network**:

- a fake SSH service
- a fake HTTP service
- a fake DB service

All run locally, listen on different ports, and log any connections and input
to a `logs/` directory.

This is **not** a high-performance honeypot, but it is perfect for demos,
testing scripts, and reasoning about attacker behaviour.

---

## Services and ports

By default:

- Fake SSH:  2222/tcp
- Fake HTTP: 8081/tcp
- Fake DB:   5433/tcp

You can change ports easily inside the code if needed.

---

## How to run

```bash
cd distributed_honeypot_network_sim

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt   # stdlib only
```

Start all honeypots:

```bash
python -m src.honeypot
```

You will see a message that servers are listening.

Now, from another terminal, try:

```bash
nc 127.0.0.1 2222
```

Type something and hit enter, then Ctrl+C.  
You can also:

```bash
curl http://127.0.0.1:8081/
nc 127.0.0.1 5433
```

All interactions will be logged under `logs/` as simple text files.

---

## Project structure

```text
distributed_honeypot_network_sim/
  ├─ README.md
  ├─ requirements.txt
  ├─ logs/
  │    └─ (generated log files)
  └─ src/
       ├─ __init__.py
       └─ honeypot.py
```

---

## Why I built this

Honeypots are a powerful educational and detection tool. With this project,
I can show that I understand:

- how to build simple network daemons in Python
- how to log attacker behaviour safely
- how to simulate multiple services with different personalities
