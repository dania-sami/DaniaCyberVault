
# ArbiterAI Policy Reasoning Engine

I built ArbiterAI because I often see the same gap in organisations. The policy
document says one thing, the actual technical rules say something else, and
no one has a clear bridge between the two.

This project is my small step toward that bridge.

ArbiterAI reads natural language security policies and turns them into draft
rules with explicit fields

* condition
* action
* scope
* severity
* rationale

The rules are not meant to be blindly enforced. They are a starting point that
a security engineer or architect can review, refine, and then translate into
firewall rules, identity provider settings, or checks in CI pipelines.

## What the engine does

* stores raw policies with title and full text
* breaks policy text into sentences
* uses heuristics and keywords to guess
  * where the action is
  * which scope is affected for example production or systems with personal data
  * which conditions are relevant for example internet facing or high privilege
  * how serious the rule is
* produces a list of rules with a clear rationale that points back to the
  original sentence

All this logic lives in a single file so I can explain every step during an
interview or a workshop.

## Project layout

```text
arbiterai-policy-reasoning-engine
└── backend
    ├── arbiterai_engine
    │   ├── __init__.py
    │   ├── engine.py  Policy model and rule derivation
    │   └── main.py    FastAPI HTTP API
    ├── requirements.txt
    └── example_requests.http
```

## How I run it locally

From the backend folder

```bash
python -m venv .venv
source .venv/bin/activate        # On Windows I use .venv\Scripts\activate
pip install -r requirements.txt
uvicorn arbiterai_engine.main:app --reload --port 9504
```

Then I open

* http://localhost:9504/docs to interact with the API

## Example that I like to show

I send in a compact policy statement

```bash
curl -X POST http://localhost:9504/policies   -H "Content-Type: application/json"   -d '{
    "title": "Production access control",
    "text": "All access to production systems must use multi factor authentication. Logging of security relevant events is required. Personal data must be encrypted in transit and at rest."
  }'
```

Then I ask for the derived rules

```bash
curl http://localhost:9504/rules
```

The engine replies with rule candidates such as

* enforce multi factor authentication for this scope with scope set to production
* enable detailed logging for security relevant events
* mark systems that handle personal data with critical severity and a rule about encryption

Each rule carries a rationale so I can trace it back to the sentence that
triggered it.

## Why this matters to me

As an engineer I want policies to be more than static PDF documents. I want
them to be close to code. ArbiterAI is a small but honest prototype that shows
how I think about that transformation and how I would structure the data for a
future policy as code platform.
