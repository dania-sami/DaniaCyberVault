
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import List, Optional, Literal

from .engine import PolicyBrain, RawPolicy, Rule


brain = PolicyBrain()


class PolicyIn(BaseModel):
    title: str = Field(..., example="Access control for production systems")
    text: str = Field(..., example="All access to production systems must use multi factor authentication.")


class PolicyOut(BaseModel):
    id: int
    title: str
    text: str
    created_at: str


class RuleOut(BaseModel):
    id: int
    policy_id: int
    condition: str
    action: str
    scope: str
    severity: Literal["low", "medium", "high", "critical"]
    rationale: str


app = FastAPI(
    title="ArbiterAI Policy Reasoning Engine",
    version="0.1.0",
    description="My policy reasoning core that turns text policies into clear rule candidates.",
)


@app.post("/policies", response_model=PolicyOut)
def create_policy(payload: PolicyIn) -> PolicyOut:
    pol: RawPolicy = brain.add_policy(title=payload.title, text=payload.text)
    return PolicyOut(
        id=pol.id,
        title=pol.title,
        text=pol.text,
        created_at=pol.created_at.isoformat() + "Z",
    )


@app.get("/policies", response_model=List[PolicyOut])
def get_policies() -> List[PolicyOut]:
    items: List[PolicyOut] = []
    for pol in brain.list_policies():
        items.append(
            PolicyOut(
                id=pol.id,
                title=pol.title,
                text=pol.text,
                created_at=pol.created_at.isoformat() + "Z",
            )
        )
    return items


@app.get("/rules", response_model=List[RuleOut])
def get_rules(policy_id: Optional[int] = None) -> List[RuleOut]:
    rules: List[Rule] = brain.list_rules(policy_id)
    out: List[RuleOut] = []
    for r in rules:
        out.append(
            RuleOut(
                id=r.id,
                policy_id=r.policy_id,
                condition=r.condition,
                action=r.action,
                scope=r.scope,
                severity=r.severity,
                rationale=r.rationale,
            )
        )
    return out
