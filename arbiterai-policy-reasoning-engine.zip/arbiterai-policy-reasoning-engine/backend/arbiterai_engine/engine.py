
from dataclasses import dataclass
from typing import Dict, List, Literal
from datetime import datetime


@dataclass
class RawPolicy:
    id: int
    title: str
    text: str
    created_at: datetime


@dataclass
class Rule:
    id: int
    policy_id: int
    condition: str
    action: str
    scope: str
    severity: Literal["low", "medium", "high", "critical"]
    rationale: str


class PolicyBrain:
    """
    This is my small policy reasoning core.

    It does not try to understand every detail of natural language. Instead it
    uses structured heuristics to turn long text policies into clear rule
    candidates that are easy to review and later implement in tools such as
    firewalls, identity systems, or CI checks.
    """

    def __init__(self) -> None:
        self.policies: Dict[int, RawPolicy] = {}
        self.rules: Dict[int, Rule] = {}
        self._next_policy_id = 1
        self._next_rule_id = 1

    def add_policy(self, title: str, text: str) -> RawPolicy:
        pid = self._next_policy_id
        self._next_policy_id += 1
        pol = RawPolicy(
            id=pid,
            title=title,
            text=text,
            created_at=datetime.utcnow(),
        )
        self.policies[pid] = pol
        # When we add a policy we also try to generate rules
        self._derive_rules(pol)
        return pol

    def list_policies(self) -> List[RawPolicy]:
        return list(self.policies.values())

    def list_rules(self, policy_id: int | None = None) -> List[Rule]:
        rules = list(self.rules.values())
        if policy_id is None:
            return rules
        return [r for r in rules if r.policy_id == policy_id]

    def _derive_rules(self, policy: RawPolicy) -> None:
        text = policy.text.lower()
        title = policy.title

        sentences = [s.strip() for s in policy.text.split(".") if s.strip()]
        for sent in sentences:
            lower = sent.lower()
            condition = ""
            action = ""
            scope = "general"
            severity: Literal["low", "medium", "high", "critical"] = "medium"
            rationale = f"Derived from sentence: {sent}"

            if "must" in lower or "shall" in lower or "required" in lower:
                action = sent
            elif "should" in lower:
                action = sent

            if "production" in lower or "prod" in lower:
                scope = "production"
            if "development" in lower or "dev" in lower or "test" in lower:
                if scope == "general":
                    scope = "development and test"

            if "internet" in lower or "public" in lower or "external" in lower:
                condition = "traffic to or from internet"
            if "admin" in lower or "privileged" in lower or "root" in lower:
                if condition:
                    condition += " and "
                condition += "high privilege accounts"

            if "mfa" in lower or "multi factor" in lower:
                action = "enforce multi factor authentication for this scope"
                severity = "high"

            if "encryption" in lower or "encrypt" in lower:
                severity = "high"
            if "personal data" in lower or "sensitive" in lower or "pii" in lower:
                scope = "systems handling personal data"
                severity = "critical"

            if "log" in lower or "logging" in lower or "audit" in lower:
                if not action:
                    action = "enable detailed security logging for this scope"
                if not condition:
                    condition = "security relevant events"

            if not action:
                continue

            rid = self._next_rule_id
            self._next_rule_id += 1
            rule = Rule(
                id=rid,
                policy_id=policy.id,
                condition=condition or "not explicitly specified",
                action=action,
                scope=scope,
                severity=severity,
                rationale=rationale,
            )
            self.rules[rid] = rule
