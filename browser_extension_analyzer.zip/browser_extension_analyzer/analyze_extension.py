
import argparse
import json
import os
import re
from pathlib import Path
from typing import List, Dict

import pandas as pd

DATA_DIR = Path("data")

DANGEROUS_PERMISSIONS = {
    "<all_urls>": "HIGH",
    "tabs": "MEDIUM",
    "history": "HIGH",
    "downloads": "MEDIUM",
    "clipboardRead": "MEDIUM",
    "proxy": "HIGH",
    "management": "HIGH",
    "nativeMessaging": "HIGH",
}

SUSPICIOUS_JS_PATTERNS = {
    "eval(": "uses eval(), which is dangerous in extensions",
    "new Function(": "uses new Function(), which can hide dynamic code execution",
    "document.write(": "uses document.write(), which can be abused for injection",
    "chrome.tabs.executeScript": "injects scripts into pages (executeScript)",
}


def load_manifest(ext_dir: Path):
    manifest_path = ext_dir / "manifest.json"
    if not manifest_path.is_file():
        raise SystemExit(f"manifest.json not found in {ext_dir}")
    with manifest_path.open("r", encoding="utf-8") as f:
        return json.load(f), manifest_path


def analyze_manifest(manifest: dict, manifest_path: Path) -> List[Dict]:
    findings: List[Dict] = []
    permissions = manifest.get("permissions", [])
    host_permissions = manifest.get("host_permissions", [])
    if isinstance(permissions, str):
        permissions = [permissions]
    if isinstance(host_permissions, str):
        host_permissions = [host_permissions]

    # Dangerous permissions
    for p in permissions:
        sev = DANGEROUS_PERMISSIONS.get(p)
        if sev:
            findings.append(
                {
                    "path": str(manifest_path),
                    "kind": "PERMISSION",
                    "severity": sev,
                    "detail": f"uses highly sensitive permission: {p}",
                }
            )

    # Broad host access
    all_hosts = list(permissions) + list(host_permissions)
    for pattern in all_hosts:
        if pattern in ("<all_urls>", "*://*/*"):
            findings.append(
                {
                    "path": str(manifest_path),
                    "kind": "PERMISSION",
                    "severity": "HIGH",
                    "detail": f"has very broad host access: {pattern}",
                }
            )

    # Content Security Policy
    mv = manifest.get("manifest_version", 2)
    csp_value = None
    if mv == 2:
        csp_value = manifest.get("content_security_policy")
    else:
        csp = manifest.get("content_security_policy", {})
        if isinstance(csp, dict):
            csp_value = csp.get("extension_pages")

    if not csp_value:
        findings.append(
            {
                "path": str(manifest_path),
                "kind": "CSP",
                "severity": "MEDIUM",
                "detail": "no content security policy defined",
            }
        )
    else:
        if "unsafe-eval" in csp_value or "unsafe-inline" in csp_value:
            findings.append(
                {
                    "path": str(manifest_path),
                    "kind": "CSP",
                    "severity": "MEDIUM",
                    "detail": f"CSP contains unsafe directives: {csp_value}",
                }
            )

    return findings


def analyze_js_files(ext_dir: Path) -> List[Dict]:
    findings: List[Dict] = []
    for root, dirs, files in os.walk(ext_dir):
        for fname in files:
            if not fname.endswith(".js"):
                continue
            full = Path(root) / fname
            try:
                text = full.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue
            for pattern, message in SUSPICIOUS_JS_PATTERNS.items():
                if pattern in text:
                    findings.append(
                        {
                            "path": str(full),
                            "kind": "JS",
                            "severity": "MEDIUM",
                            "detail": message,
                        }
                    )
    return findings


def main():
    parser = argparse.ArgumentParser(description="Browser Extension Security Analyzer")
    parser.add_argument("extension_dir", help="Path to unpacked extension directory (with manifest.json)")
    parser.add_argument(
        "--output",
        default=str(DATA_DIR / "findings.csv"),
        help="CSV file to write findings (default data/findings.csv)",
    )
    args = parser.parse_args()

    ext_dir = Path(args.extension_dir)
    if not ext_dir.is_dir():
        raise SystemExit(f"Extension directory is not a folder: {ext_dir}")

    DATA_DIR.mkdir(exist_ok=True)

    manifest, manifest_path = load_manifest(ext_dir)
    print(f"[info] Analysing extension at {ext_dir}")

    findings: List[Dict] = []
    findings.extend(analyze_manifest(manifest, manifest_path))
    findings.extend(analyze_js_files(ext_dir))

    if not findings:
        print("[info] No issues found for current rules. Extension looks clean.")
        return

    for f in findings:
        prefix = "[warn]" if f["severity"] in ("HIGH", "MEDIUM") else "[info]"
        print(f"{prefix} [{f['kind']:<10}] {Path(f['path']).name:<15} {f['detail']}")

    df = pd.DataFrame(findings)
    out_path = Path(args.output)
    df.to_csv(out_path, index=False)
    print()
    print(f"[info] Findings written to {out_path} ({len(df)} rows)")


if __name__ == "__main__":
    main()
