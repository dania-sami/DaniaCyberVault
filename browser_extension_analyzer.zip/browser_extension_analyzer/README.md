
# Browser Extension Security Analyzer

Hi, I am Dania and I built this project to practise thinking about browser extension security, which is a very hot topic right now.

Instead of building a full static analyser, I wanted a focused tool that:

- reads a Chrome/Firefox extension folder
- inspects `manifest.json` and JavaScript files
- flags dangerous permissions
- warns about very broad URL access
- highlights missing or weak content security policy
- detects suspicious JavaScript patterns like `eval`

This lets me talk about extension security in a concrete, code-based way.

---

## What this project does

Given a folder that contains a browser extension (with `manifest.json`), the analyzer:

1. Parses `manifest.json` and extracts:

   - `manifest_version`
   - `permissions`
   - `host_permissions` or `permissions` that include URL patterns
   - `content_security_policy` (for MV2) or `content_security_policy.extension_pages` (for MV3)

2. Flags potential issues, for example:

   - use of highly sensitive permissions:
     - `<all_urls>`
     - `tabs`, `history`, `downloads`, `clipboardRead`, `proxy`, `management`, `nativeMessaging`
   - overly broad host permissions such as `*://*/*`
   - missing content security policy
   - very permissive CSPs using `unsafe-eval` or `unsafe-inline`

3. Scans `.js` files for suspicious patterns:

   - `eval(`
   - `new Function(`
   - `document.write(`
   - `chrome.tabs.executeScript` (MV2 style)

4. Writes a findings report:

   - console summary
   - `data/findings.csv` with:
     - `path`
     - `kind`
     - `severity`
     - `detail`

I also include two small sample extensions, one mostly safe and one intentionally risky.

---

## Project structure

```text
browser_extension_analyzer/
  README.md
  requirements.txt
  analyze_extension.py
  sample_extensions/
    good_extension/manifest.json
    risky_extension/manifest.json
    risky_extension/background.js
  data/
```

---

## Installation

```bash
python3 -m venv venv
source venv/bin/activate           # Windows  venv\Scripts\activate
pip install -r requirements.txt
```

---

## Quick start with the sample extensions

Analyse the risky demo extension:

```bash
python analyze_extension.py sample_extensions/risky_extension
```

Example style of output:

```text
[info] Analysing extension at sample_extensions/risky_extension
[warn] [PERMISSION] manifest.json    uses highly sensitive permission: <all_urls>
[warn] [PERMISSION] manifest.json    uses highly sensitive permission: history
[warn] [CSP]       manifest.json    no content security policy defined
[warn] [JS]        background.js    uses eval(), which is dangerous in extensions
[warn] [JS]        background.js    uses document.write(), which can be abused

[info] Findings written to data/findings.csv (5 rows)
```

You can also point it to any other extension folder on your machine:

```bash
python analyze_extension.py /path/to/unzipped/extension
```

*(Only do this for extensions you are allowed to inspect.)*

---

## Checks implemented

The current rules include:

1. **Dangerous permissions**
   - flags a set of high risk permissions
   - marks them as `HIGH` or `MEDIUM` severity

2. **Broad host access**
   - warns if `<all_urls>` or `*://*/*` are present

3. **Content Security Policy**
   - warns if CSP is missing
   - warns if CSP contains `unsafe-eval` or `unsafe-inline`

4. **JavaScript patterns**
   - `eval(` or `new Function(`
   - `document.write(` with string literals
   - `chrome.tabs.executeScript`

The rules are intentionally simple but map well to real-world extension review guidance.

---

## Why this project matters to me

Browser extensions live very close to user data.

With this project I can show that I:

- understand which permissions are sensitive
- can reason about CSP inside extension manifests
- know which JavaScript patterns are red flags

It is a small but very relevant security engineering project, and it is easy to extend with more rules in the future.
