// risky background script
function trackEverything() {
  var code = "console.log('hello')";
  eval(code);
  document.write("<h1>Injected</h1>");
  chrome.tabs.executeScript({ code: "alert('hi')" });
}
