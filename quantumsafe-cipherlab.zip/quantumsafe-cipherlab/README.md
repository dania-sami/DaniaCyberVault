
# QuantumSafe CipherLab

QuantumSafe CipherLab is a small lab service for exploring the performance side of post quantum style algorithms without heavy cryptographic dependencies.

It simulates families of algorithms such as key encapsulation and signatures by combining simple hashing and controlled CPU work. The goal is to help you reason about trade offs between security level key sizes and performance not to provide real cryptographic security.

## Project layout

```text
quantumsafe-cipherlab
└── backend
    ├── quantumsafe_lab
    │   ├── __init__.py
    │   ├── main.py    FastAPI HTTP API
    │   └── engine.py  Simulation of algorithms and benchmarking
    ├── requirements.txt
    └── example_requests.http
```

## Running the backend

From the backend folder

```bash
python -m venv .venv
source .venv/bin/activate        # On Windows use .venv\Scripts\activate
pip install -r requirements.txt
uvicorn quantumsafe_lab.main:app --reload --port 9700
```

The API will be available at

* http://localhost:9700
* interactive docs at http://localhost:9700/docs

## Available algorithms

By default the lab exposes three algorithm profiles

* kyber_like_light a lighter key encapsulation style profile
* kyber_like_strong a heavier higher security style profile
* dilithium_like_sign a signature style profile with larger keys

You can list them with

```bash
curl http://localhost:9700/algorithms
```

Each profile reports

* family
* advertised security bits
* key size in bytes
* simulated cost factor that controls how expensive operations are

## Running a benchmark

To run a small benchmark for one profile

```bash
curl -X POST http://localhost:9700/benchmark   -H "Content-Type: application/json"   -d '{
    "algorithm": "kyber_like_light",
    "iterations": 3
  }'
```

The response contains average times in milliseconds for

* key generation
* encapsulation
* decapsulation
* total per round

For example you can compare

```bash
curl -X POST http://localhost:9700/benchmark   -H "Content-Type: application/json"   -d "{"algorithm": "kyber_like_light", "iterations": 3}"
```

with

```bash
curl -X POST http://localhost:9700/benchmark   -H "Content-Type: application/json"   -d "{"algorithm": "kyber_like_strong", "iterations": 3}"
```

to see how a stronger profile changes the cost.

## Important note about security

This project does not implement real post quantum cryptography. It is a performance and sizing simulator only. Never use it to protect real secrets.

For real deployments you would replace the simulated functions in engine.py with calls into libraries that implement NIST selected algorithms and keep this service as your benchmarking or experiment harness.

## Ideas for extending QuantumSafe CipherLab

There are many directions you can take this project

* add real bindings to post quantum libraries for lab only use
* allow users to define their own custom profiles
* store benchmark runs to compare environments or hardware generations
* expose a small front end that plots timing distributions
* add memory usage estimates and simple network cost calculations from key and ciphertext sizes

Even in its basic form this project already shows that you understand both security and performance aspects of modern cryptography experiments.
