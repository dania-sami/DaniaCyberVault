
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import List

from .engine import CipherLab, AlgorithmProfile, BenchmarkResult


lab = CipherLab()


class AlgorithmOut(BaseModel):
    name: str
    family: str
    security_bits: int
    key_size_bytes: int
    simulated_cost_factor: int


class BenchmarkIn(BaseModel):
    algorithm: str = Field(..., example="kyber_like_light")
    iterations: int = Field(3, ge=1, le=20)


class BenchmarkOut(BaseModel):
    algorithm: str
    keygen_ms: float
    encaps_ms: float
    decaps_ms: float
    total_ms: float
    iterations: int


app = FastAPI(
    title="QuantumSafe CipherLab",
    version="0.1.0",
    description="Lightweight lab for exploring simulated post quantum algorithm performance.",
)


@app.get("/algorithms", response_model=List[AlgorithmOut])
def list_algorithms() -> List[AlgorithmOut]:
    items: List[AlgorithmOut] = []
    for p in lab.list_algorithms():
        items.append(
            AlgorithmOut(
                name=p.name,
                family=p.family,
                security_bits=p.security_bits,
                key_size_bytes=p.key_size_bytes,
                simulated_cost_factor=p.simulated_cost_factor,
            )
        )
    return items


@app.post("/benchmark", response_model=BenchmarkOut)
def run_benchmark(payload: BenchmarkIn) -> BenchmarkOut:
    try:
        result: BenchmarkResult = lab.benchmark(payload.algorithm, payload.iterations)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return BenchmarkOut(
        algorithm=result.algorithm,
        keygen_ms=result.keygen_ms,
        encaps_ms=result.encaps_ms,
        decaps_ms=result.decaps_ms,
        total_ms=result.total_ms,
        iterations=result.iterations,
    )
