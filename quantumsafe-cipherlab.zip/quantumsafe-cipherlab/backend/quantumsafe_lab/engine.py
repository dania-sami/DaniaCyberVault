
from dataclasses import dataclass
from typing import Dict, List
import time
import secrets
import hashlib


@dataclass
class AlgorithmProfile:
    name: str
    family: str
    security_bits: int
    key_size_bytes: int
    simulated_cost_factor: int


@dataclass
class BenchmarkResult:
    algorithm: str
    keygen_ms: float
    encaps_ms: float
    decaps_ms: float
    total_ms: float
    iterations: int


class CipherLab:
    """
    QuantumSafe CipherLab is a tiny lab simulator for post quantum like algorithms.

    It does not implement real PQ crypto. Instead it uses simple operations and
    controlled loops to approximate the idea of heavier and lighter algorithms.

    This makes it safe and dependency free while still allowing useful experiments
    with relative performance and key size trade offs.
    """

    def __init__(self) -> None:
        self.algorithms: Dict[str, AlgorithmProfile] = {}
        self._seed_default_profiles()

    def _seed_default_profiles(self) -> None:
        self.add_algorithm(
            AlgorithmProfile(
                name="kyber_like_light",
                family="kem",
                security_bits=128,
                key_size_bytes=800,
                simulated_cost_factor=2,
            )
        )
        self.add_algorithm(
            AlgorithmProfile(
                name="kyber_like_strong",
                family="kem",
                security_bits=192,
                key_size_bytes=1184,
                simulated_cost_factor=4,
            )
        )
        self.add_algorithm(
            AlgorithmProfile(
                name="dilithium_like_sign",
                family="signature",
                security_bits=128,
                key_size_bytes=2048,
                simulated_cost_factor=5,
            )
        )

    def add_algorithm(self, profile: AlgorithmProfile) -> None:
        self.algorithms[profile.name] = profile

    def list_algorithms(self) -> List[AlgorithmProfile]:
        return list(self.algorithms.values())

    def _simulate_work(self, factor: int) -> None:
        # Simple CPU bound loop based on factor
        acc = 0
        limit = 50_000 * factor
        for i in range(limit):
            acc ^= i * 2654435761
        # Use result so that Python does not optimise it away
        if acc == 42:
            print("")

    def _fake_keygen(self, profile: AlgorithmProfile) -> bytes:
        self._simulate_work(profile.simulated_cost_factor)
        seed = secrets.token_bytes(32)
        return hashlib.sha256(seed + profile.name.encode("utf8")).digest()

    def _fake_encaps(self, profile: AlgorithmProfile, pk: bytes) -> bytes:
        self._simulate_work(profile.simulated_cost_factor)
        return hashlib.sha512(pk + b"encaps" + profile.name.encode("utf8")).digest()

    def _fake_decaps(self, profile: AlgorithmProfile, ct: bytes) -> bytes:
        self._simulate_work(profile.simulated_cost_factor)
        return hashlib.sha256(ct + b"decaps").digest()

    def benchmark(self, algorithm_name: str, iterations: int = 3) -> BenchmarkResult:
        if algorithm_name not in self.algorithms:
            raise ValueError(f"Unknown algorithm profile {algorithm_name}")
        if iterations < 1:
            raise ValueError("Iterations must be at least one")

        profile = self.algorithms[algorithm_name]

        keygen_total = 0.0
        encaps_total = 0.0
        decaps_total = 0.0

        for _ in range(iterations):
            t0 = time.perf_counter()
            pk = self._fake_keygen(profile)
            t1 = time.perf_counter()
            ct = self._fake_encaps(profile, pk)
            t2 = time.perf_counter()
            _ = self._fake_decaps(profile, ct)
            t3 = time.perf_counter()

            keygen_total += (t1 - t0) * 1000.0
            encaps_total += (t2 - t1) * 1000.0
            decaps_total += (t3 - t2) * 1000.0

        return BenchmarkResult(
            algorithm=profile.name,
            keygen_ms=round(keygen_total / iterations, 2),
            encaps_ms=round(encaps_total / iterations, 2),
            decaps_ms=round(decaps_total / iterations, 2),
            total_ms=round((keygen_total + encaps_total + decaps_total) / iterations, 2),
            iterations=iterations,
        )
