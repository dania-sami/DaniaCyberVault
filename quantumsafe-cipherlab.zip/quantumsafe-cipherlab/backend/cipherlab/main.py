
from fastapi import FastAPI
from pydantic import BaseModel

from .engine import PQEngine, PQEncryptionResult


class EncryptIn(BaseModel):
    algorithm: str
    plaintext: str


class EncryptOut(BaseModel):
    algorithm: str
    ciphertext: str
    performance_ms: float


app = FastAPI(title="QuantumSafe CipherLab", version="0.1")
engine = PQEngine()


@app.post("/encrypt", response_model=EncryptOut)
def encrypt(payload: EncryptIn):
    result: PQEncryptionResult = engine.encrypt(payload.algorithm, payload.plaintext)
    return EncryptOut(**result.__dict__)
