# API Rate-Limit Bypass Tester

Hi, I am Dania Sami 👋

Rate limiting is one of the simplest but most important protections on APIs.
Unfortunately, it is often implemented incorrectly or inconsistently.

I built this project as a **framework to simulate rate-limit bypass attempts**
in a safe and structured way.

It does not try to break any terms of service. The idea is to give security
teams and developers a local tool to test **their own APIs** under different
client patterns.

---

## What this tool can simulate

Each strategy is just a Python function in `src/strategies.py`. Right now I
include:

- `baseline` – send N requests in a tight loop
- `rotating_header` – send requests with changing `X-Forwarded-For`
- `burst_then_pause` – bursts followed by cooldown pauses

The framework in `src/run_test.py`:

- takes a target URL and number of requests
- runs the chosen strategy
- records response status codes and timings
- prints a small summary at the end

---

## Important note

This tool is meant for **testing APIs you own or have explicit permission to
test**. It is not a DDoS tool and it is not designed for aggressive load.

By default the request rate is modest and sleeps are included between requests.

---

## How to run

You need Python 3.10+ and network access to your target API.

```bash
python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt
```

### Run a baseline test

```bash
python -m src.run_test --url https://httpbin.org/get --strategy baseline --count 10
```

### Run a rotating header test

```bash
python -m src.run_test --url https://httpbin.org/get --strategy rotating_header --count 10
```

### Run a burst-then-pause test

```bash
python -m src.run_test --url https://httpbin.org/get --strategy burst_then_pause --count 20
```

The script prints the status code distribution and basic timing stats.

---

## Project structure

```text
api_rate_limit_bypass_tester/
  ├─ README.md
  ├─ requirements.txt
  └─ src/
       ├─ __init__.py
       ├─ strategies.py
       └─ run_test.py
```

---

## Why I built this

Rate limiting is often assumed to be "done" once added, but attackers can play
with headers, IPs and timing. This project shows that I know how to:

- think about client behaviour patterns
- encode them as reusable strategies
- build a small framework that teams can extend with their own ideas
