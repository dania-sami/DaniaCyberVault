from __future__ import annotations

import random
import time
from typing import Callable, Dict, List

import requests


def baseline(url: str, count: int) -> List[requests.Response]:
    responses: List[requests.Response] = []
    for _ in range(count):
        r = requests.get(url, timeout=10)
        responses.append(r)
    return responses


def rotating_header(url: str, count: int) -> List[requests.Response]:
    responses: List[requests.Response] = []
    for _ in range(count):
        fake_ip = ".".join(str(random.randint(1, 254)) for _ in range(4))
        headers = {"X-Forwarded-For": fake_ip}
        r = requests.get(url, headers=headers, timeout=10)
        responses.append(r)
    return responses


def burst_then_pause(url: str, count: int) -> List[requests.Response]:
    responses: List[requests.Response] = []
    burst_size = max(1, count // 4)
    remaining = count

    while remaining > 0:
        current_burst = min(burst_size, remaining)
        for _ in range(current_burst):
            r = requests.get(url, timeout=10)
            responses.append(r)
            remaining -= 1
        if remaining > 0:
            time.sleep(2.0)
    return responses


STRATEGIES: Dict[str, Callable[[str, int], List[requests.Response]]] = {
    "baseline": baseline,
    "rotating_header": rotating_header,
    "burst_then_pause": burst_then_pause,
}
