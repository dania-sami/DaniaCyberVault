from __future__ import annotations

import argparse
import statistics
import time
from collections import Counter

from .strategies import STRATEGIES


def main() -> None:
    parser = argparse.ArgumentParser(description="API rate-limit bypass tester (safe patterns)")
    parser.add_argument("--url", type=str, required=True, help="Target API URL")
    parser.add_argument(
        "--strategy",
        type=str,
        choices=list(STRATEGIES.keys()),
        default="baseline",
        help="Traffic pattern strategy to use",
    )
    parser.add_argument("--count", type=int, default=10, help="Number of requests to send")
    args = parser.parse_args()

    strategy = STRATEGIES[args.strategy]
    print(f"Running strategy '{args.strategy}' against {args.url} with {args.count} requests")

    start = time.monotonic()
    responses = strategy(args.url, args.count)
    end = time.monotonic()

    statuses = [r.status_code for r in responses]
    duration = end - start
    per_request = duration / max(1, len(responses))

    print(f"Total requests: {len(responses)}")
    print(f"Total duration: {duration:.2f}s (avg {per_request:.2f}s per request)")
    print("Status code distribution:")
    for code, cnt in sorted(Counter(statuses).items()):
        print(f"  {code}: {cnt}")

    try:
        sizes = [len(r.content) for r in responses]
        print(f"Avg response size: {statistics.mean(sizes):.1f} bytes")
    except Exception:
        pass


if __name__ == "__main__":
    main()
