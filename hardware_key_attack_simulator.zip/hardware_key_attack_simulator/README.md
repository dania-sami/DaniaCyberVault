
# Hardware Key Extraction Attack Simulator (Glitching PIN Check)

Hi, I am Dania and I built this project to model **voltage glitching / fault injection** against a simple PIN verification routine.

Instead of real hardware, I simulate:

- a device with a secret 4 digit PIN
- a normal verification function that checks all digits
- a fault injection that occasionally **skips part of the comparison**
- an attacker strategy that uses repeated glitches to bypass the check and/or learn the PIN progressively

This lets me talk about fault injection and why naive PIN checks are not enough.

---

## What this project does

The main script is `pin_attack_sim.py`. It:

1. Picks a random secret 4 digit PIN (e.g. `"4821"`)
2. Implements a vulnerable `check_pin` function where a glitch may:

   - skip one of the digit comparisons
   - treat a partial match as success

3. Simulates an attacker that:

   - repeatedly tries random PINs
   - occasionally triggers a glitch (with configurable probability)
   - records when a wrong PIN is still accepted
   - gradually learns the correct digits from these partial successes

4. Prints:

   - the real secret PIN
   - how many attempts were needed to bypass the check
   - how many attempts were needed to fully reconstruct the PIN

---

## Project structure

```text
hardware_key_attack_simulator/
  README.md
  requirements.txt      # empty, stdlib only
  pin_attack_sim.py
  data/
```

---

## Installation

```bash
python3 -m venv venv
source venv/bin/activate          # Windows  venv\Scripts\activate
pip install -r requirements.txt
```

---

## Usage

```bash
python pin_attack_sim.py
```

Example style of output:

```text
[info] Secret PIN on device: 4821
[info] Starting glitch attack simulation (glitch_probability=0.05)
[info] First bypass of PIN check after 320 attempts using guess 4021
[info] Learned digits so far: ['4', '?', '2', '1']
[info] Fully recovered PIN after 2103 total attempts
[info] Final recovered PIN: 4821
```

You can tweak parameters inside the script:

- `GLITCH_PROB` — how often a glitch happens
- `MAX_ATTEMPTS` — how long the attacker keeps trying

---

## Why this project matters to me

Fault injection and glitching are classic hardware attacks.

With this project I can show that I:

- understand how simple comparisons can be broken by faults
- can model the attacker strategy as a search over states
- can measure “security” in number of attempts and glitch probability

It is a clean, safe way to reason about hardware key extraction.
