
import random

PIN_LENGTH = 4
GLITCH_PROB = 0.05
MAX_ATTEMPTS = 100000

def generate_secret_pin():
    return "".join(str(random.randint(0, 9)) for _ in range(PIN_LENGTH))

def check_pin(secret: str, guess: str) -> bool:
    # Simulated vulnerable check with possible glitch.
    # Normally it compares all digits.
    # When a glitch occurs, it may skip a random index.
    if len(guess) != len(secret):
        return False

    indices = list(range(len(secret)))
    # glitch: randomly remove one index from the comparison
    if random.random() < GLITCH_PROB:
        skip_index = random.choice(indices)
        indices.remove(skip_index)

    for i in indices:
        if guess[i] != secret[i]:
            return False
    return True

def attack(secret: str):
    random.seed(42)
    attempts = 0
    first_bypass_attempts = None
    learned = ["?"] * len(secret)

    while attempts < MAX_ATTEMPTS and "?" in learned:
        attempts += 1
        guess = "".join(str(random.randint(0, 9)) for _ in range(len(secret)))
        ok = check_pin(secret, guess)
        if ok:
            # treat as partial information: any matching digit is likely correct
            if first_bypass_attempts is None:
                first_bypass_attempts = attempts
                print(f"[info] First bypass of PIN check after {attempts} attempts using guess {guess}")
            for i in range(len(secret)):
                if guess[i] == secret[i]:
                    learned[i] = secret[i]

    return first_bypass_attempts, attempts, "".join(learned)

def main():
    secret = generate_secret_pin()
    print(f"[info] Secret PIN on device: {secret}")
    print(f"[info] Starting glitch attack simulation (glitch_probability={GLITCH_PROB})")
    first_bypass, total_attempts, recovered = attack(secret)
    if first_bypass is None:
        print("[info] No successful bypass within attempt limit.")
        return
    print(f"[info] Learned digits so far: {list(recovered)}")
    if "?" in recovered:
        print(f"[info] Could not fully recover PIN within {total_attempts} attempts. Partial recovery: {recovered}")
    else:
        print(f"[info] Fully recovered PIN after {total_attempts} total attempts")
        print(f"[info] Final recovered PIN: {recovered}")

if __name__ == "__main__":
    main()
