# SSH Config Linter

This is a small script I use to talk about SSH hardening using a real `sshd_config` style file.

The script reads a config file and checks a few key options:

- `PermitRootLogin`
- `PasswordAuthentication`
- `X11Forwarding`
- `AllowTcpForwarding`

It prints the current values and suggests if something might need attention.

## Files

- `ssh_config_linter.py` – main script
- `demo_sshd_config` – example config

## Usage

```bash
python ssh_config_linter.py --config demo_sshd_config
```
