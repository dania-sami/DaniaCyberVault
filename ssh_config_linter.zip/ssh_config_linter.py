import argparse

KEYS = [
    "PermitRootLogin",
    "PasswordAuthentication",
    "X11Forwarding",
    "AllowTcpForwarding",
]

def parse_config(path: str):
    values = {}
    with open(path, "r", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) >= 2:
                key, val = parts[0], " ".join(parts[1:])
                if key in KEYS:
                    values[key] = val
    return values

def analyse(values):
    print("[+] SSH config quick review:")
    pr = values.get("PermitRootLogin", "(not set)")
    print(f"    PermitRootLogin       : {pr}")

    pa = values.get("PasswordAuthentication", "(not set)")
    print(f"    PasswordAuthentication: {pa}")

    x11 = values.get("X11Forwarding", "(not set)")
    print(f"    X11Forwarding         : {x11}")

    tf = values.get("AllowTcpForwarding", "(not set)")
    print(f"    AllowTcpForwarding    : {tf}")

def main():
    parser = argparse.ArgumentParser(description="SSH Config Linter by Dania")
    parser.add_argument("--config", required=True, help="Path to sshd_config style file")
    args = parser.parse_args()
    values = parse_config(args.config)
    analyse(values)

if __name__ == "__main__":
    main()
