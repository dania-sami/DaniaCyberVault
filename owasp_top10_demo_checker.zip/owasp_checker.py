import argparse
import json

def load_config(path: str) -> dict:
    with open(path) as f:
        return json.load(f)

def analyse(cfg: dict):
    print()

    # Very simplified checks, just for learning discussions
    inj = not cfg.get("uses_prepared_statements", False)
    auth = not cfg.get("has_rate_limiting", False)
    xss = not cfg.get("has_output_encoding", False)
    misconfig = cfg.get("detailed_error_pages", False) or not cfg.get("has_security_headers", False)
    logging = not cfg.get("has_audit_logging", False)

    print(f"[Injection]              : {'at risk' if inj else 'ok'}")
    print(f"[Broken Authentication]  : {'somewhat exposed' if auth else 'ok'}")
    print(f"[XSS]                    : {'at risk' if xss else 'ok'}")
    print(f"[Security Misconfig]     : {'at risk' if misconfig else 'ok'}")
    print(f"[Insufficient Logging]   : {'at risk' if logging else 'ok'}")

def main():
    parser = argparse.ArgumentParser(description="OWASP Top Ten Demo Checker by Dania")
    parser.add_argument("--config", required=True, help="Path to app config JSON")
    args = parser.parse_args()

    cfg = load_config(args.config)
    print(f"[+] Checking app configuration: {args.config}")
    analyse(cfg)

if __name__ == "__main__":
    main()
