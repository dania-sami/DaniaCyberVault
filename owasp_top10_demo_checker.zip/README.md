# OWASP Top Ten Demo Checker (Config Based)

This project is a small script I use to talk about the OWASP Top Ten in a practical way.

Instead of scanning a real app, I keep things simple: I describe an application in a JSON file with a few booleans like `has_input_validation`, `has_rate_limiting`, `uses_prepared_statements`, etc. The script reads the file and prints a short report mapped to OWASP Top Ten style risks.

It is a tiny tool, but it gives me a nice way to structure conversations about web risks and controls.

## Files

- `owasp_checker.py` – main script
- `app_config_example.json` – demo configuration of a web app

## Usage

```bash
python owasp_checker.py --config app_config_example.json
```

Example output (shortened):

```text
[+] Checking app configuration: app_config_example.json

[Injection]              : at risk (uses_prepared_statements = false)
[Broken Authentication]  : somewhat exposed (has_rate_limiting = false)
[Security Misconfig]     : at risk (detailed_error_pages = true)
...
```

I like this project because it shows that I understand OWASP concepts and how they connect to real settings and design choices, even in a very small script.
