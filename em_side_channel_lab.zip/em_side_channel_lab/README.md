
# EM Side-Channel Signal Simulator (AES S-box Correlation Lab)

Hi, I am Dania and I built this project to explore **electromagnetic (EM) side channel analysis** in a safe way.

I simulated EM traces for one byte of the AES S-box and then used correlation to recover the secret key byte.

The idea is:

- generate many traces with 50 time samples each
- hide the real leakage in a small time window with noise
- run a correlation power analysis (CPA) across time and key guesses
- find the time sample and key that best explain the traces

---

## What this project does

There are two scripts:

1. `simulate_em.py`

   - chooses a random secret key byte
   - generates random plaintext bytes
   - computes `S = SBOX[plaintext ^ key]`
   - uses the Hamming weight of `S` as the leakage
   - embeds this leakage into a 50-sample EM trace with Gaussian noise
   - writes all traces to `data/em_traces.csv` with columns:
     - `plaintext_byte`
     - `sample_0`, `sample_1`, ..., `sample_49`
     - `secret_key_byte` (for reference)

2. `em_attack.py`

   - loads `data/em_traces.csv`
   - for each key guess 0..255:
     - recomputes hypothetical Hamming weight traces
     - correlates them with every time sample
   - finds the key and time sample that give maximum correlation
   - prints the recovered key guess and a summary of the strongest correlations

This is conceptually close to how real EM power analysis works, just much smaller and safer.

---

## Project structure

```text
em_side_channel_lab/
  README.md
  requirements.txt
  simulate_em.py
  em_attack.py
  data/
```

---

## Installation

```bash
python3 -m venv venv
source venv/bin/activate          # Windows  venv\Scripts\activate
pip install -r requirements.txt
```

---

## Step 1  Simulate EM traces

```bash
python simulate_em.py
```

This will generate (by default) 500 traces and write them to `data/em_traces.csv`.

---

## Step 2  Run the EM correlation attack

```bash
python em_attack.py
```

Example style of output:

```text
[info] Loaded 500 traces with 50 samples each
[info] Best key guess: 0x5c at sample 23 (corr=0.81)
Top 5 key guesses:
  key=0x5c  best_corr=0.81  best_sample=23
  key=0xa2  best_corr=0.22  best_sample=19
  ...
[info] Real key byte was: 0x5c
```

You can change the number of traces or noise level directly in `simulate_em.py` to see how it affects the attack.

---

## Why this project matters to me

EM side channels are a natural extension of power side channels.

With this project I can show that I:

- understand the link between Hamming weight and leakage
- can model leakage as a time-series trace
- can implement correlation-based key recovery across time

It is a great way to talk about both signal processing and cryptographic side channels.
