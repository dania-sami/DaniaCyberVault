# Malicious AI Output Detector – Dania

Hi

I am Dania and this tool is my quick detector for risky AI outputs before they reach a user or another system

It scans responses for things like direct shell commands dangerous Python snippets and suspicious URLs and then labels them as safe or needs review

The rules are simple and transparent so they are easy to tune in a real pipeline
