"""
Malicious AI Output Detector – Dania

Rule based scanner for AI responses
flags clearly risky looking content
"""

import argparse
import json
from dataclasses import dataclass, asdict
from typing import List


SHELL_MARKERS = [
    "rm -rf",
    "curl ",
    "wget ",
    "| sh",
    "|bash",
    "nc -e",
    "powershell ",
]
PYTHON_MARKERS = [
    "import os",
    "import subprocess",
    "os.system(",
    "subprocess.run(",
    "subprocess.Popen(",
]
WINDOWS_MARKERS = [
    "reg add",
    "schtasks /create",
    "powershell -enc",
]
URL_MARKER = "http://"


@dataclass
class OutputVerdict:
    text: str
    severity: str
    reasons: List[str]


def analyse(text: str) -> OutputVerdict:
    lower = text.lower()
    reasons: List[str] = []

    if any(m in lower for m in SHELL_MARKERS):
        reasons.append("shell_command_pattern")
    if any(m in lower for m in PYTHON_MARKERS):
        reasons.append("dangerous_python_api")
    if any(m in lower for m in WINDOWS_MARKERS):
        reasons.append("windows_persistence_like")
    if URL_MARKER in lower or "https://" in lower:
        reasons.append("contains_url")

    if not reasons:
        severity = "safe"
    elif any(r in ["shell_command_pattern", "dangerous_python_api", "windows_persistence_like"] for r in reasons):
        severity = "needs_immediate_review"
    else:
        severity = "needs_review"

    return OutputVerdict(text=text, severity=severity, reasons=reasons)


def process_file(path: str) -> List[OutputVerdict]:
    out: List[OutputVerdict] = []
    with open(path, "r", encoding="utf-8") as f:
        for block in f.read().split("\n---\n"):
            block = block.strip()
            if not block:
                continue
            out.append(analyse(block))
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's malicious AI output detector")
    parser.add_argument("--responses-file", help="Text file with responses separated by --- lines")
    parser.add_argument("--response", help="Single response string to check")
    parser.add_argument("--json-out", help="Optional JSON output path")
    args = parser.parse_args()

    verdicts: List[OutputVerdict] = []

    if args.responses_file:
        verdicts.extend(process_file(args.responses_file))
    if args.response:
        verdicts.append(analyse(args.response))

    if not verdicts:
        print("Provide --response or --responses-file.")
        return

    for v in verdicts:
        print("-----")
        print("Severity:", v.severity)
        if v.reasons:
            print("Reasons:", ", ".join(v.reasons))
        print("Text snippet:", (v.text[:200] + "...") if len(v.text) > 200 else v.text)

    if args.json_out:
        with open(args.json_out, "w", encoding="utf-8") as f:
            json.dump([asdict(v) for v in verdicts], f, indent=2)
        print(f"Wrote JSON verdicts to {args.json_out}")


if __name__ == "__main__":
    main()
