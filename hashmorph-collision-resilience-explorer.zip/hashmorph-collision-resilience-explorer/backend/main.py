
from fastapi import FastAPI
app=FastAPI(title="hashmorph-collision-resilience-explorer")
@app.get("/status")
def status():
    return {"project":"hashmorph-collision-resilience-explorer","status":"working"}
