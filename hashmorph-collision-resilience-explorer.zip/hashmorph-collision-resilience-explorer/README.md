# hashmorph-collision-resilience-explorer
I built hashmorph-collision-resilience-explorer as a simple working prototype.
Run it and check /status.
