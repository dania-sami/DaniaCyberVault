"""
Adversarial ML Attack Sandbox – Dania

Tiny 2D classifier with simple adversarial perturbation search
No external ML libraries  just basic maths
"""

import argparse
import json
import random
import math
from dataclasses import dataclass, asdict
from typing import List, Tuple


@dataclass
class Point:
    x: float
    y: float
    label: int


@dataclass
class AdversarialExample:
    original: Point
    perturbed: Point
    distance: float


def generate_dataset(n: int) -> List[Point]:
    data: List[Point] = []
    for _ in range(n):
        x = random.uniform(-3, 3)
        y = random.uniform(-3, 3)
        # simple decision boundary: x + y > 0
        label = 1 if x + y > 0 else 0
        data.append(Point(x, y, label))
    return data


def predict(point: Point) -> int:
    return 1 if point.x + point.y > 0 else 0


def find_adversarial(point: Point, max_steps: int = 100, step_size: float = 0.05):
    original_label = predict(point)
    x, y = point.x, point.y
    for _ in range(max_steps):
        s = 1 if x + y > 0 else -1
        x_new = x - s * step_size
        y_new = y - s * step_size
        cand_point = Point(x_new, y_new, predict(Point(x_new, y_new, 0)))
        if cand_point.label != original_label:
            dist = math.sqrt((x_new - point.x) ** 2 + (y_new - point.y) ** 2)
            return True, AdversarialExample(original=point, perturbed=cand_point, distance=dist)
        x, y = x_new, y_new
    return False, None


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's adversarial ML attack sandbox")
    parser.add_argument("--samples", type=int, default=50, help="Number of points to test")
    parser.add_argument("--json-out", default="adv_examples.json", help="Where to write adversarial examples")
    args = parser.parse_args()

    random.seed(42)
    data = generate_dataset(args.samples)

    adv_examples: List[AdversarialExample] = []
    for p in data:
        success, adv = find_adversarial(p)
        if success and adv is not None:
            adv_examples.append(adv)

    with open(args.json_out, "w", encoding="utf-8") as f:
        json.dump(
            [
                {
                    "original": asdict(a.original),
                    "perturbed": asdict(a.perturbed),
                    "distance": a.distance,
                }
                for a in adv_examples
            ],
            f,
            indent=2,
        )

    print(f"Generated {len(data)} samples")
    print(f"Found {len(adv_examples)} adversarial examples")
    print(f"Wrote examples to {args.json_out}")


if __name__ == "__main__":
    main()
