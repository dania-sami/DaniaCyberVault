# Adversarial ML Attack Sandbox – Dania

Hi

I am Dania and this sandbox is my way of explaining adversarial examples with a tiny numeric model

It trains a super simple classifier on 2D points then generates small perturbations to see when labels flip so I can talk about robustness and sensitivity in a hands on way

It is not about production strength ML  it is about intuition and learning
