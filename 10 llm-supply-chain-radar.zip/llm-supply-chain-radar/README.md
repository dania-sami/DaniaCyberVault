
# LLM Supply Chain Radar

Live view over the full life of every model you use and early warning when a model starts to behave in a suspicious way.

This project gives you a focused supply chain view for language models

* which model
* based on which base model
* trained or tuned on which data
* where is the serving endpoint
* what happens when we run behavioural tests against it today

The goal is to treat models like serious assets not just mystery black boxes.

---

## What this prototype does

The radar service lets you

* register a model together with base model identity and data sets
* keep a small software bill of materials for the model
* run behavioural canary tests on the model through its HTTP endpoint
* store and query the latest canary results

It is small enough to read in one sitting but structured so that you can grow it into a proper platform.

---

## Quick start

### Backend service

```bash
cd backend
python -m venv .venv
source .venv/bin/activate    # On Windows use .venv\Scripts\activate
pip install -r requirements.txt
uvicorn radar_backend.main:app --reload --port 9100
```

The service is now reachable at

* API root http://localhost:9100
* Swagger UI http://localhost:9100/docs
* ReDoc http://localhost:9100/redoc

---

## Running through an example flow

You can use the file `example_requests.http` with a REST client or you can follow the flow below.

### Step one register a model

Imagine you have a small internal model that you host on http://localhost:8080/mock-model

```bash
curl -X POST http://localhost:9100/models   -H "Content-Type: application/json"   -d '{
    "name": "fraud assistant v1",
    "provider": "local",
    "base_model": "llama 3 8b",
    "version": "1.0.0",
    "owner": "ml-team",
    "endpoint": "http://localhost:8080/mock-model",
    "datasets": [
      {
        "name": "customer-faq-jan",
        "version": "2026-01",
        "source": "s3://data-lake/customer-faq-jan",
        "checksum": "sha256:example"
      }
    ],
    "tags": ["customer", "support"]
  }'
```

The response returns an `id` for this asset. You will use that id in later calls.

### Step two see all known models

```bash
curl http://localhost:9100/models
```

This is effectively your language model inventory. For production you can group or label models by owner system environment or risk tier.

### Step three view a simple model bill of materials

```bash
curl http://localhost:9100/models/{asset_id}/sbom
```

This returns a small document that captures

* model identity
* base model
* owner
* list of data sets and sources
* registration time
* tags

You can store these documents in version control or an asset registry.

### Step four run canary tests

```bash
curl -X POST http://localhost:9100/models/{asset_id}/canary
```

The radar calls the model endpoint with several behavioural tests

* prompt injection resistance
* harmful content requests
* memory based data exfiltration

Each test returns

* a name
* a boolean flag that tells if the test was passed
* a short sample of the reply so that you can understand what happened

Results are saved in a small json store so later you can query the last run

```bash
curl http://localhost:9100/models/{asset_id}/canary
```

---

## Project layout

```text
llm-supply-chain-radar
└── backend
    ├── radar_backend
    │   ├── __init__.py
    │   ├── main.py        FastAPI app with routes
    │   ├── sbom.py        Model asset structure and bill of materials generator
    │   ├── canary.py      Behavioural tests that call model endpoints
    │   └── store.py       Tiny json file store for assets and canary runs
    ├── example_requests.http
    └── requirements.txt
```

---

## How to extend this into something serious

This repository is deliberately light so you can show your own creativity. Here are next steps that make it enterprise grade

* Replace the json file store with a database and add audit history for all changes
* Add authentication and role based access so only approved people can register or test models
* Store each canary run as a time series and show trends for a model over time
* Allow custom canary suites per risk tier for example extra strict tests for models that can reach payment systems
* Export a standard software bill of materials format so that you can plug into existing risk tools
* Add a small web dashboard that lists models and shows traffic light visuals for their last canary result

---

## Why this is a strong security project

Many teams are now calling external and internal language models from production apps. Very few have real visibility into

* which models are live today
* what data and training sources influenced them
* whether the behaviour has drifted into risky territory

This project treats those questions as a first class security concern. With only a few endpoints you get

* a clear inventory of your models
* a live view into behavioural safety through canaries
* a base to build more policy checks and investigations


Use this as your starting point then plug it into your own systems and stories.
