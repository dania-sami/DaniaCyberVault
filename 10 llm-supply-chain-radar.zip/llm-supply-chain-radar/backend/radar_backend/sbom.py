
from dataclasses import dataclass, asdict
from typing import List, Dict, Any
from datetime import datetime
import uuid


@dataclass
class DatasetRef:
    name: str
    version: str
    source: str  # for example "s3://bucket/path" or "git://repo"
    checksum: str


@dataclass
class ModelAsset:
    id: str
    name: str
    provider: str            # for example "openai", "local", "hf"
    base_model: str          # for example "gpt 4.1", "llama 3 8b"
    version: str
    owner: str
    registered_at: str
    datasets: List[DatasetRef]
    tags: List[str]


def new_model_asset(
    name: str,
    provider: str,
    base_model: str,
    version: str,
    owner: str,
    datasets: List[Dict[str, str]],
    tags: List[str] | None = None,
) -> ModelAsset:
    dataset_objs = [
        DatasetRef(
            name=d.get("name", "unknown"),
            version=d.get("version", "unknown"),
            source=d.get("source", ""),
            checksum=d.get("checksum", ""),
        )
        for d in datasets
    ]

    return ModelAsset(
        id=str(uuid.uuid4()),
        name=name,
        provider=provider,
        base_model=base_model,
        version=version,
        owner=owner,
        registered_at=datetime.utcnow().isoformat() + "Z",
        datasets=dataset_objs,
        tags=tags or [],
    )


def asset_to_sbom(asset: ModelAsset) -> Dict[str, Any]:
    """Return a software bill of materials style document for the model."""
    doc: Dict[str, Any] = {
        "sbom_version": "0.1",
        "model": asdict(asset),
    }
    return doc
