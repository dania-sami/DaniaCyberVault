
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, AnyUrl
from typing import List, Optional

from .sbom import new_model_asset
from .store import RadarStore
from .canary import run_default_canaries


app = FastAPI(
    title="LLM Supply Chain Radar",
    version="0.1.0",
    description="Track models and run canary security tests for LLM supply chain health.",
)

store = RadarStore()


class DatasetIn(BaseModel):
    name: str
    version: str
    source: str
    checksum: str


class RegisterModelIn(BaseModel):
    name: str
    provider: str
    base_model: str
    version: str
    owner: str
    endpoint: AnyUrl
    datasets: List[DatasetIn] = []
    tags: List[str] = []


class RegisteredModelOut(BaseModel):
    id: str
    name: str
    provider: str
    base_model: str
    version: str
    owner: str
    endpoint: AnyUrl
    tags: List[str]


class CanaryRunOut(BaseModel):
    asset_id: str
    results: List[dict]


@app.post("/models", response_model=RegisteredModelOut)
def register_model(payload: RegisterModelIn) -> RegisteredModelOut:
    asset = new_model_asset(
        name=payload.name,
        provider=payload.provider,
        base_model=payload.base_model,
        version=payload.version,
        owner=payload.owner,
        datasets=[d.dict() for d in payload.datasets],
        tags=payload.tags,
    )
    store.save_asset(asset, str(payload.endpoint))

    return RegisteredModelOut(
        id=asset.id,
        name=asset.name,
        provider=asset.provider,
        base_model=asset.base_model,
        version=asset.version,
        owner=asset.owner,
        endpoint=payload.endpoint,
        tags=asset.tags,
    )


@app.get("/models", response_model=List[RegisteredModelOut])
def list_models() -> List[RegisteredModelOut]:
    assets = store.list_assets()
    out: List[RegisteredModelOut] = []
    for a in assets:
        endpoint = store.get_endpoint(a["id"]) or "http://localhost:8080/mock-model"
        out.append(
            RegisteredModelOut(
                id=a["id"],
                name=a["name"],
                provider=a["provider"],
                base_model=a["base_model"],
                version=a["version"],
                owner=a["owner"],
                endpoint=endpoint,
                tags=a.get("tags", []),
            )
        )
    return out


@app.get("/models/{asset_id}/sbom")
def get_model_sbom(asset_id: str):
    asset = store.get_asset(asset_id)
    if not asset:
        raise HTTPException(status_code=404, detail="Model asset not found")
    return {
        "sbom_version": "0.1",
        "model": asset,
    }


@app.post("/models/{asset_id}/canary", response_model=CanaryRunOut)
def run_canary(asset_id: str) -> CanaryRunOut:
    asset = store.get_asset(asset_id)
    if not asset:
        raise HTTPException(status_code=404, detail="Model asset not found")

    endpoint = store.get_endpoint(asset_id)
    if not endpoint:
        raise HTTPException(status_code=400, detail="No endpoint registered for this model")

    results = run_default_canaries(endpoint)
    results_dicts = [dict(r) for r in results]
    store.save_canary_result(asset_id, results_dicts)

    return CanaryRunOut(asset_id=asset_id, results=results_dicts)


@app.get("/models/{asset_id}/canary", response_model=Optional[CanaryRunOut])
def get_canary(asset_id: str) -> Optional[CanaryRunOut]:
    result = store.get_canary_result(asset_id)
    if not result:
        return None
    return CanaryRunOut(asset_id=result["asset_id"], results=result["results"])
