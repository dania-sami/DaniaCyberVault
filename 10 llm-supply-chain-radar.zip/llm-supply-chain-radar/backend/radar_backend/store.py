
from typing import Dict, List, Any
from pathlib import Path
import json
from .sbom import ModelAsset


class RadarStore:
    """Very small file based store ideal for a prototype.
    Stores assets and their latest canary runs in a json file.
    """

    def __init__(self, path: str = "radar_store.json") -> None:
        self.path = Path(path)
        if not self.path.exists():
            self._write({"assets": {}, "canaries": {}, "endpoints": {}})

    def _read(self) -> Dict[str, Any]:
        return json.loads(self.path.read_text(encoding="utf8"))

    def _write(self, data: Dict[str, Any]) -> None:
        self.path.write_text(json.dumps(data, indent=2), encoding="utf8")

    def save_asset(self, asset: ModelAsset, endpoint: str) -> None:
        data = self._read()
        data["assets"][asset.id] = {
            "id": asset.id,
            "name": asset.name,
            "provider": asset.provider,
            "base_model": asset.base_model,
            "version": asset.version,
            "owner": asset.owner,
            "registered_at": asset.registered_at,
            "datasets": [d.__dict__ for d in asset.datasets],
            "tags": asset.tags,
        }
        data["endpoints"][asset.id] = endpoint
        self._write(data)

    def list_assets(self) -> List[Dict[str, Any]]:
        return list(self._read().get("assets", {}).values())

    def get_asset(self, asset_id: str) -> Dict[str, Any] | None:
        return self._read().get("assets", {}).get(asset_id)

    def get_endpoint(self, asset_id: str) -> str | None:
        return self._read().get("endpoints", {}).get(asset_id)

    def save_canary_result(self, asset_id: str, results: List[Dict[str, Any]]) -> None:
        data = self._read()
        canaries = data.setdefault("canaries", {})
        canaries[asset_id] = {
            "asset_id": asset_id,
            "results": results,
        }
        self._write(data)

    def get_canary_result(self, asset_id: str) -> Dict[str, Any] | None:
        return self._read().get("canaries", {}).get(asset_id)
