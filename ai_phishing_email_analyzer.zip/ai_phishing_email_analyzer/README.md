# AI-Powered Phishing Email Auto-Analyzer

Hi, I am Dania Sami 👋

This project is my practical take on building an **AI-assisted phishing email analyzer**.

Instead of manually eyeballing suspicious emails, I wanted a small tool that can:

- ingest raw email samples (subject + body + simple headers)
- extract features with TF–IDF NLP
- train a machine learning model to classify **phishing vs. legitimate**
- run a quick prediction on new samples from the command line

It is a compact version of what real mail gateways do, but transparent and easy
to extend for experiments.

---

## What this tool does

1. **Loads a tiny demo dataset**

   Under `data/emails.csv` I ship a small synthetic dataset with:

   - `subject`
   - `body`
   - `from_addr`
   - `has_reply_to`
   - `label` (`phishing` or `legit`)

   In a real setup, this can be replaced by a larger dataset.

2. **Builds NLP features**

   In `src/features.py` I use `TfidfVectorizer` over:

   - subject
   - body
   - and a few simple header-derived tokens

3. **Trains a classifier**

   In `src/train.py` I train a `LogisticRegression` classifier and evaluate it
   on a hold-out split. The trained pipeline is stored with `joblib` under
   `models/phishing_model.joblib`.

4. **Runs predictions from the command line**

   `src/predict.py` lets me quickly test emails like this:

   ```bash
   python -m src.predict \
     --subject "Urgent: Your account will be closed" \
     --body "Click the link to verify your account immediately" \
     --from-addr "support@secure-check.com"
   ```

   It prints the predicted label and probability.

This is not a production anti-spam system, but it clearly demonstrates how to
pipeline **NLP + ML for phishing detection**.

---

## How to run

You need Python 3.10+.

```bash
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

pip install -r requirements.txt
```

### Train the model

```bash
python -m src.train
```

This will:

- train the model on `data/emails.csv`
- print validation accuracy
- save the trained model into `models/phishing_model.joblib`

### Run a test prediction

```bash
python -m src.predict \
  --subject "Verify your password immediately" \
  --body "We noticed unusual login activity. Login now to avoid suspension." \
  --from-addr "security@accounts-team.com"
```

You will see something like:

```text
Predicted: phishing (p=0.92)
```

---

## Project structure

```text
ai_phishing_email_analyzer/
  ├─ README.md
  ├─ requirements.txt
  ├─ data/
  │    └─ emails.csv
  ├─ models/
  │    └─ phishing_model.joblib        # generated
  └─ src/
       ├─ __init__.py
       ├─ config.py
       ├─ features.py
       ├─ train.py
       └─ predict.py
```

---

## How I would extend this

If I wanted to grow this into a bigger research project, I would:

- add real-world datasets and more header fields (Return-Path, DKIM results, etc.)
- switch the classifier to a transformer model for richer text understanding
- export explanations for each decision (which words contributed most)
- integrate this with a mail gateway simulator and my other security projects

For now, this project lets me show that I can **design, train and ship an
ML-based phishing analyzer end-to-end**.
