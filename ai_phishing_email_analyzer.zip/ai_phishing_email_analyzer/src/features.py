from __future__ import annotations

from sklearn.feature_extraction.text import TfidfVectorizer


def build_text_vectorizer() -> TfidfVectorizer:
    return TfidfVectorizer(
        ngram_range=(1, 2),
        min_df=1,
        max_features=500,
        stop_words="english",
    )


def join_fields(subject: str, body: str, from_addr: str, has_reply_to: bool) -> str:
    header_tokens = []
    domain = from_addr.split("@")[-1] if "@" in from_addr else from_addr
    header_tokens.append(f"from_domain={domain}")
    header_tokens.append(f"has_reply_to={has_reply_to}")
    return " ".join(
        [
            subject or "",
            body or "",
            " ".join(header_tokens),
        ]
    )
