from __future__ import annotations

import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline

import joblib

from .config import EMAIL_CSV, MODEL_PATH
from .features import build_text_vectorizer, join_fields


def main() -> None:
    df = pd.read_csv(EMAIL_CSV)

    texts = [
        join_fields(s, b, f, bool(r))
        for s, b, f, r in zip(
            df["subject"], df["body"], df["from_addr"], df["has_reply_to"]
        )
    ]
    y = df["label"]

    X_train, X_val, y_train, y_val = train_test_split(
        texts, y, test_size=0.25, random_state=42, stratify=y
    )

    pipeline = Pipeline(
        steps=[
            ("tfidf", build_text_vectorizer()),
            (
                "clf",
                LogisticRegression(
                    max_iter=1000,
                    class_weight="balanced",
                ),
            ),
        ]
    )

    pipeline.fit(X_train, y_train)
    y_pred = pipeline.predict(X_val)
    print("Validation report:")
    print(classification_report(y_val, y_pred))

    joblib.dump(pipeline, MODEL_PATH)
    print(f"Model saved to {MODEL_PATH}")


if __name__ == "__main__":
    main()
