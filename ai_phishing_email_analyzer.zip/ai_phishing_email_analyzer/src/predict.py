from __future__ import annotations

import argparse

import joblib

from .config import MODEL_PATH
from .features import join_fields


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Phishing email predictor")
    parser.add_argument("--subject", type=str, required=True)
    parser.add_argument("--body", type=str, required=True)
    parser.add_argument("--from-addr", type=str, default="")
    parser.add_argument("--has-reply-to", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    text = join_fields(
        args.subject,
        args.body,
        args.from_addr,
        bool(args.has_reply_to),
    )
    model = joblib.load(MODEL_PATH)
    proba = model.predict_proba([text])[0]
    classes = model.classes_
    idx = int(proba.argmax())
    print(f"Predicted: {classes[idx]} (p={proba[idx]:.2f})")


if __name__ == "__main__":
    main()
