
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Dict, List

from .store import store
from .engine import TargetSurface


class TargetIn(BaseModel):
    id: str = Field(..., example="web-shop")
    name: str = Field(..., example="Customer web shop")
    env: str = Field(..., example="prod")
    tags: Dict[str, str] = Field(default_factory=dict)


class TargetOut(TargetIn):
    pass


class CampaignOut(BaseModel):
    id: int
    target_id: str
    created_at: str
    current_index: int
    total_steps: int


class StepOut(BaseModel):
    phase: str
    description: str
    technique: str
    precondition: str
    detection_hint: str


app = FastAPI(
    title="HydraRed Adaptive Attack Engine",
    version="0.1.0",
    description="My red team style playbook generator for safe attack planning.",
)


@app.post("/targets", response_model=TargetOut)
def register_target(payload: TargetIn) -> TargetOut:
    surface = TargetSurface(
        id=payload.id,
        name=payload.name,
        env=payload.env,
        tags=payload.tags,
    )
    store.targets[surface.id] = surface
    return TargetOut(**payload.dict())


@app.get("/targets", response_model=List[TargetOut])
def list_targets() -> List[TargetOut]:
    return [TargetOut(**dict(id=t.id, name=t.name, env=t.env, tags=t.tags)) for t in store.targets.values()]


@app.post("/campaigns", response_model=CampaignOut)
def create_campaign(target_id: str) -> CampaignOut:
    surface = store.targets.get(target_id)
    if not surface:
        raise HTTPException(status_code=404, detail="Target not found")
    camp = store.brain.build_campaign(surface)
    cid = next(store.campaign_ids)
    camp.id = cid
    store.campaigns[cid] = camp
    return CampaignOut(
        id=camp.id,
        target_id=camp.target_id,
        created_at=camp.created_at.isoformat() + "Z",
        current_index=camp.current_index,
        total_steps=len(camp.history),
    )


@app.get("/campaigns", response_model=List[CampaignOut])
def list_campaigns() -> List[CampaignOut]:
    out: List[CampaignOut] = []
    for c in store.campaigns.values():
        out.append(
            CampaignOut(
                id=c.id,
                target_id=c.target_id,
                created_at=c.created_at.isoformat() + "Z",
                current_index=c.current_index,
                total_steps=len(c.history),
            )
        )
    return out


@app.post("/campaigns/{campaign_id}/next", response_model=StepOut)
def next_step(campaign_id: int) -> StepOut:
    camp = store.campaigns.get(campaign_id)
    if not camp:
        raise HTTPException(status_code=404, detail="Campaign not found")
    step = store.brain.next_step(camp)
    if not step:
        raise HTTPException(status_code=400, detail="Campaign has finished all steps")
    return StepOut(
        phase=step.phase,
        description=step.description,
        technique=step.technique,
        precondition=step.precondition,
        detection_hint=step.detection_hint,
    )
