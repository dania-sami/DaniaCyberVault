
from dataclasses import dataclass
from typing import Dict
import itertools

from .engine import HydraBrain, TargetSurface, Campaign


@dataclass
class HydraStore:
    brain: HydraBrain
    targets: Dict[str, TargetSurface]
    campaigns: Dict[int, Campaign]
    campaign_ids: itertools.count


store = HydraStore(
    brain=HydraBrain(),
    targets={},
    campaigns={},
    campaign_ids=itertools.count(start=1),
)
