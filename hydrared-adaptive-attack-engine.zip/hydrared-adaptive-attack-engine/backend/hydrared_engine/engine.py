
from dataclasses import dataclass
from typing import Dict, List, Literal
from datetime import datetime


Phase = Literal["recon", "initial_access", "persistence", "lateral_movement", "impact"]


@dataclass
class TargetSurface:
    id: str
    name: str
    env: str
    tags: Dict[str, str]


@dataclass
class AttackStep:
    phase: Phase
    description: str
    technique: str
    precondition: str
    detection_hint: str


@dataclass
class Campaign:
    id: int
    target_id: str
    created_at: datetime
    current_index: int
    history: List[AttackStep]


class HydraBrain:
    """
    HydraRed is my adaptive attack planner for red team style simulations.

    It does not connect to real systems. Instead it generates evolving playbooks
    based on a high level view of the target surface so I can discuss offensive
    thinking in a safe way.
    """

    def __init__(self) -> None:
        self.templates: Dict[Phase, List[AttackStep]] = {}
        self._seed_templates()

    def _seed_templates(self) -> None:
        self.templates = {
            "recon": [
                AttackStep(
                    phase="recon",
                    description="Map public endpoints and note which ones look custom versus vendor hosted.",
                    technique="External recon by passive scanning and DNS records.",
                    precondition="Target has at least one public hostname or IP.",
                    detection_hint="Look for unusual DNS queries and repeated access to robots.txt or status pages.",
                ),
                AttackStep(
                    phase="recon",
                    description="Identify which cloud provider and regions the target uses.",
                    technique="Cloud fingerprinting based on IP ranges and TLS certificates.",
                    precondition="Target uses public cloud hosting.",
                    detection_hint="Review cloud logs for unauthenticated calls to metadata or discovery endpoints.",
                ),
            ],
            "initial_access": [
                AttackStep(
                    phase="initial_access",
                    description="Try password spraying against a low sensitivity application that uses company SSO.",
                    technique="Credential guessing with low noise password spraying.",
                    precondition="Login portal is internet reachable and lacks inline CAPTCHA or strict lockout.",
                    detection_hint="Watch for low rate failed logins across many accounts against the same app.",
                ),
                AttackStep(
                    phase="initial_access",
                    description="Send a carefully crafted phishing email that mirrors an existing internal notification.",
                    technique="Social engineering through phishing.",
                    precondition="Email addresses for staff are reachable from the internet.",
                    detection_hint="Filter for look alike domains and unexpected login flows after email opens.",
                ),
            ],
            "persistence": [
                AttackStep(
                    phase="persistence",
                    description="Abuse legitimate scheduled tasks or startup scripts instead of installing new services.",
                    technique="Living off the land persistence.",
                    precondition="Compromised host allows user level task scheduling.",
                    detection_hint="Search for new scheduled tasks created by non admin accounts.",
                )
            ],
            "lateral_movement": [
                AttackStep(
                    phase="lateral_movement",
                    description="Reuse cached credentials to move from a workstation to a more privileged internal service.",
                    technique="Pass the hash or token replay in internal network.",
                    precondition="Initial host has cached credentials or long lived tokens.",
                    detection_hint="Monitor for authentication from unusual workstation to admin only resources.",
                )
            ],
            "impact": [
                AttackStep(
                    phase="impact",
                    description="Target backups before production data so that recovery is harder.",
                    technique="Destruction or tampering with backup repositories.",
                    precondition="Backups are reachable from the compromised environment.",
                    detection_hint="Watch for deletions or policy changes in backup systems especially from new identities.",
                )
            ],
        }

    def build_campaign(self, surface: TargetSurface) -> Campaign:
        steps: List[AttackStep] = []
        for phase in ("recon", "initial_access", "persistence", "lateral_movement", "impact"):
            steps.extend(self.templates[phase])
        return Campaign(
            id=0,
            target_id=surface.id,
            created_at=datetime.utcnow(),
            current_index=0,
            history=steps,
        )

    def next_step(self, campaign: Campaign) -> AttackStep | None:
        if campaign.current_index >= len(campaign.history):
            return None
        step = campaign.history[campaign.current_index]
        campaign.current_index += 1
        return step
