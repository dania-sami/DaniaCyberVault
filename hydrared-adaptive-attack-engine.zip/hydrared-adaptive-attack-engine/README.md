
# HydraRed Adaptive Attack Engine

HydraRed is my way of showing offensive security thinking in a safe and controlled way.

I wanted something better than a static list of attack ideas. I wanted an engine that can look at a description of a target surface and then walk through a realistic sequence of steps

* recon
* initial access
* persistence
* lateral movement
* impact

without ever touching a real system.

So I built HydraRed Adaptive Attack Engine as a small playbook generator that feels like a red team brain but stays completely lab focused.

## What HydraRed does

* lets me register high level target surfaces for example a customer web shop in production
* builds an ordered attack campaign for each target based on templates I can read and extend
* exposes an API to move through the campaign step by step so it feels like running a live exercise

Each attack step includes

* the phase it belongs to
* a description in natural language
* the technique in plain terms
* a precondition that explains when the step makes sense
* a detection hint to help the blue team side

That last part is important for me because I always want to connect offensive ideas back to detection and defence.

## Project layout

```text
hydrared-adaptive-attack-engine
└── backend
    ├── hydrared_engine
    │   ├── __init__.py
    │   ├── main.py    FastAPI HTTP API
    │   └── engine.py  Target model and campaign logic
    ├── requirements.txt
    └── example_requests.http
```

## How I run it locally

From the backend folder

```bash
python -m venv .venv
source .venv/bin/activate        # On Windows I use .venv\Scripts\activate
pip install -r requirements.txt
uvicorn hydrared_engine.main:app --reload --port 9800
```

Then I open

* http://localhost:9800/docs to experiment with the endpoints

## Example flow I use in demos

First I register a target surface

```bash
curl -X POST http://localhost:9800/targets   -H "Content-Type: application/json"   -d '{
    "id": "web-shop",
    "name": "Customer web shop",
    "env": "prod",
    "tags": {
      "stack": "web",
      "auth": "sso"
    }
  }'
```

Then I create a campaign for this target

```bash
curl -X POST "http://localhost:9800/campaigns?target_id=web-shop"
```

When I want to walk through the exercise I keep calling

```bash
curl -X POST http://localhost:9800/campaigns/1/next
```

Each call returns the next attack step with clear text about

* what I as a red teamer try to do
* which preconditions must be true
* what kind of signals the defenders could watch for

This makes HydraRed a nice bridge between offensive and defensive minds and a good storytelling tool when I explain how I think about cyber security.

## Future ideas I would like to add

* tags that influence which steps are used for example cloud native or internal only
* scoring for each step to show how risky it is for the business
* a simple front end that visualises the campaign as a path
* export of the steps into markdown or slide decks for tabletop exercises

Right now the code is intentionally compact and easy to read so I can open engine.py and talk through my approach to structured attack planning during interviews or presentations.
