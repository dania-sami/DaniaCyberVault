import argparse
import json
import os
from typing import Dict
from cryptography.fernet import Fernet

def load_key(path: str) -> Fernet:
    with open(path, "rb") as f:
        key = f.read().strip()
    return Fernet(key)

def gen_key(path: str):
    key = Fernet.generate_key()
    with open(path, "wb") as f:
        f.write(key)
    print(f"[+] Key written to {path}")

def load_store(path: str) -> Dict[str, str]:
    if not os.path.exists(path):
        return {}
    with open(path) as f:
        return json.load(f)

def save_store(path: str, data: Dict[str, str]):
    with open(path, "w") as f:
        json.dump(data, f, indent=2)

def add_note(key_path: str, store_path: str, title: str, text: str):
    f = load_key(key_path)
    store = load_store(store_path)
    token = f.encrypt(text.encode("utf-8")).decode("utf-8")
    store[title] = token
    save_store(store_path, store)
    print(f"[+] Stored encrypted note with title: {title}")

def list_notes(store_path: str):
    store = load_store(store_path)
    if not store:
        print("[+] No notes in store yet.")
        return
    print("[+] Note titles:")
    for title in store.keys():
        print(f"    {title}")

def show_note(key_path: str, store_path: str, title: str):
    f = load_key(key_path)
    store = load_store(store_path)
    if title not in store:
        print("[-] No such note title in store.")
        return
    token = store[title].encode("utf-8")
    text = f.decrypt(token).decode("utf-8")
    print(f"[+] Note: {title}")
    print(text)

def main():
    parser = argparse.ArgumentParser(description="Secure Notes Vault by Dania")
    sub = parser.add_subparsers(dest="command", required=True)

    p_key = sub.add_parser("gen-key", help="Generate a new key file")
    p_key.add_argument("--key", required=True, help="Path to key file")

    p_add = sub.add_parser("add", help="Add a new encrypted note")
    p_add.add_argument("--key", required=True, help="Path to key file")
    p_add.add_argument("--store", required=True, help="Path to JSON note store")
    p_add.add_argument("--title", required=True, help="Title of the note")
    p_add.add_argument("--text", required=True, help="Text content of the note")

    p_list = sub.add_parser("list", help="List note titles")
    p_list.add_argument("--store", required=True, help="Path to JSON note store")

    p_show = sub.add_parser("show", help="Show and decrypt a note")
    p_show.add_argument("--key", required=True, help="Path to key file")
    p_show.add_argument("--store", required=True, help="Path to JSON note store")
    p_show.add_argument("--title", required=True, help="Title of the note to show")

    args = parser.parse_args()

    if args.command == "gen-key":
        gen_key(args.key)
    elif args.command == "add":
        add_note(args.key, args.store, args.title, args.text)
    elif args.command == "list":
        list_notes(args.store)
    elif args.command == "show":
        show_note(args.key, args.store, args.title)

if __name__ == "__main__":
    main()
