# Secure Notes Vault (Encrypted Notes CLI)

Hi, I am Dania and this project is my small encrypted notes tool.

It lets me store short text notes in a JSON file, but the content of each note is encrypted with a symmetric key. The idea is to practise using existing crypto libraries in a correct way, not to invent new encryption.

## What it can do

- Generate a new key file
- Add a new encrypted note with a title
- List note titles
- Show and decrypt a note by title

## Requirements

- Python 3
- `cryptography`

Install:

```bash
pip install cryptography
```

## Usage

Generate a key:

```bash
python secure_notes.py gen-key --key key.key
```

Add a note:

```bash
python secure_notes.py add --key key.key --store notes.json --title "vpn keys" --text "Notes about my lab VPN setup"
```

List notes:

```bash
python secure_notes.py list --store notes.json
```

Show a note:

```bash
python secure_notes.py show --key key.key --store notes.json --title "vpn keys"
```

Everything stays in local files, this is just a learning tool for me.
