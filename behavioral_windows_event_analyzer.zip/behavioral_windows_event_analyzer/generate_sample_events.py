
from pathlib import Path
import random
import csv
from datetime import datetime, timedelta

DATA_DIR = Path("data")


def main():
    random.seed(42)
    DATA_DIR.mkdir(exist_ok=True)

    users = ["admin", "analyst1", "analyst2", "testuser1", "testuser2", "testuser3"]
    base_ips = ["10.0.0.", "192.168.1.", "172.16.0."]
    external_ips = ["203.0.113.", "198.51.100."]

    start = datetime(2025, 1, 10, 8, 0, 0)
    rows = []

    def random_internal_ip():
        prefix = random.choice(base_ips)
        return prefix + str(random.randint(1, 254))

    def random_external_ip():
        prefix = random.choice(external_ips)
        return prefix + str(random.randint(1, 254))

    current = start
    for i in range(1200):
        user = random.choice(users)
        # mostly internal, sometimes external
        src_ip = random_internal_ip() if random.random() < 0.85 else random_external_ip()

        # choose event type
        r = random.random()
        if r < 0.6:
            event_id = 4624  # success logon
            logon_type = random.choice([2, 3, 10])
        elif r < 0.85:
            event_id = 4625  # failed logon
            logon_type = random.choice([2, 3, 10])
        elif r < 0.95:
            event_id = 4634  # logoff
            logon_type = 2
        else:
            event_id = 4672  # special privilege assigned
            logon_type = 2

        is_admin = user == "admin"

        rows.append(
            {
                "timestamp": current.strftime("%Y-%m-%d %H:%M:%S"),
                "user": user,
                "event_id": event_id,
                "logon_type": logon_type,
                "source_ip": src_ip,
                "is_admin": int(is_admin),
            }
        )

        # advance time irregularly
        current += timedelta(seconds=random.randint(5, 120))

    # add a few clearly suspicious patterns
    # 1. many failed logons for admin at night from external IP
    night_base = datetime(2025, 1, 10, 2, 0, 0)
    for i in range(12):
        rows.append(
            {
                "timestamp": (night_base + timedelta(seconds=i * 30)).strftime("%Y-%m-%d %H:%M:%S"),
                "user": "admin",
                "event_id": 4625,
                "logon_type": 3,
                "source_ip": random_external_ip(),
                "is_admin": 1,
            }
        )
    rows.append(
        {
            "timestamp": (night_base + timedelta(minutes=10)).strftime("%Y-%m-%d %H:%M:%S"),
            "user": "admin",
            "event_id": 4624,
            "logon_type": 3,
            "source_ip": random_external_ip(),
            "is_admin": 1,
        }
    )

    # 2. testuser3 with many late night logons from multiple IPs
    night_base2 = datetime(2025, 1, 10, 3, 0, 0)
    for i in range(15):
        rows.append(
            {
                "timestamp": (night_base2 + timedelta(seconds=i * 40)).strftime("%Y-%m-%d %H:%M:%S"),
                "user": "testuser3",
                "event_id": random.choice([4624, 4625]),
                "logon_type": random.choice([2, 3, 10]),
                "source_ip": random_external_ip(),
                "is_admin": 0,
            }
        )

    out_path = DATA_DIR / "sample_events.csv"
    fieldnames = ["timestamp", "user", "event_id", "logon_type", "source_ip", "is_admin"]
    with out_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for r in rows:
            writer.writerow(r)

    print(f"[info] Wrote {len(rows)} synthetic events to {out_path}")


if __name__ == "__main__":
    main()
