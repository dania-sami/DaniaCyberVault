
# Behavioral Windows Event Log Analyzer (Simulation Lab)

Hi, I am Dania and I built this project to practise looking at Windows event logs the way a SOC or incident responder would: not just single events, but **behaviour patterns**.

To keep it safe and portable, I work on a **simulated log export** instead of raw EVTX, but the ideas are the same:

- group events into user sessions
- extract features such as logon spikes and privilege use
- use anomaly detection to find unusual sessions

This is my Windows event log behaviour analysis lab.

---

## What this project does

The lab has two main steps.

1. **Generate synthetic Windows-style events**  
   I create a CSV file `data/sample_events.csv` with columns such as:
   - timestamp
   - user
   - event_id (e.g. logon, logoff, failure, privilege use)
   - logon_type
   - source_ip
   - is_admin

   Some sessions are normal, and a few are made intentionally suspicious (many failures, admin logon from new IP, late night admin activity, etc.).

2. **Analyse behaviour per user session**  
   The analyser script:
   - groups events into sessions per user and hour
   - computes features:
     - number of events
     - successful logons
     - failed logons
     - admin logons
     - unique source IPs
     - late night flag
   - trains an `IsolationForest` model on all sessions
   - outputs a list of sessions with an anomaly score and verdict

The results are stored in `data/sessions_enriched.csv` and a small table is printed to the console.

---

## Project structure

```text
behavioral_windows_event_analyzer/
  README.md
  requirements.txt
  generate_sample_events.py   # create synthetic event log export
  analyze_events.py           # build sessions and detect anomalies
  data/
```

The design is ready to be extended to real EVTX by adding a parser that converts EVTX to the same CSV structure.

---

## Installation

```bash
python3 -m venv venv
source venv/bin/activate           # Windows  venv\Scripts\activate
pip install -r requirements.txt
```

---

## Step 1  Generate synthetic sample events

```bash
python generate_sample_events.py
```

This will create `data/sample_events.csv` with a mix of users and behaviours.

---

## Step 2  Run the behavioural analysis

```bash
python analyze_events.py --input data/sample_events.csv
```

The script will:

- build per-user, per-hour sessions
- compute the behavioural features
- train an IsolationForest
- score each session as typical or unusual
- write all results to `data/sessions_enriched.csv`

Example console output:

```text
[info] Loaded 1500 events from data/sample_events.csv
[info] Built 120 sessions
[info] Top suspicious sessions:
  user=admin         window_start=2025-01-10 02:00  score=0.98  failed_logons=12  admin_logons=1  late_night=True
  user=testuser3     window_start=2025-01-10 03:00  score=0.95  failed_logons=9   admin_logons=0  late_night=True
```

---

## Event and feature model

The synthetic log events mimic some common Windows patterns:

- event_id 4624 — successful logon
- event_id 4625 — failed logon
- event_id 4634 — logoff
- event_id 4672 — special privileges assigned

For each user+time window we derive:

- `event_count`
- `success_logons`
- `failed_logons`
- `admin_logons`
- `unique_source_ips`
- `late_night` (activity between 01:00 and 05:00)

These are exactly the kind of features used in real detection content for abnormal authentication behaviour.

---

## How to extend this to real EVTX

Right now I focus on the behaviour logic, not the file format.

In a real deployment you could:

1. Export security logs from Windows to CSV using Event Viewer or a SIEM agent  
2. Map the fields into the same columns as `sample_events.csv`  
3. Point `analyze_events.py` at that file

Optionally, one could integrate an EVTX parsing library and reuse the same feature extraction pipeline.

---

## Why this project matters to me

Windows event logs are everywhere in incident response.

With this project I can show that I:

- know common security event IDs and concepts
- can turn noisy logs into structured sessions and features
- can apply anomaly detection to highlight suspicious behaviour

It connects strongly to SOC work, detection engineering and threat hunting, which are areas I am very interested in.
