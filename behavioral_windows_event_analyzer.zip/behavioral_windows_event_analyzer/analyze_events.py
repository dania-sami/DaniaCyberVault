
import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest

DATA_DIR = Path("data")


def build_sessions(df: pd.DataFrame) -> pd.DataFrame:
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    df["window"] = df["timestamp"].dt.floor("1H")

    sessions = (
        df.groupby(["user", "window"])
        .agg(
            event_count=("event_id", "count"),
            success_logons=("event_id", lambda x: (x == 4624).sum()),
            failed_logons=("event_id", lambda x: (x == 4625).sum()),
            admin_logons=("event_id", lambda x: (x == 4672).sum()),
            unique_source_ips=("source_ip", "nunique"),
            any_admin=("is_admin", "max"),
        )
        .reset_index()
    )

    # late night flag
    sessions["late_night"] = sessions["window"].dt.hour.apply(lambda h: 1 if 1 <= h <= 5 else 0)
    return sessions


def main():
    parser = argparse.ArgumentParser(description="Behavioural Windows Event Log Analyzer")
    parser.add_argument(
        "--input",
        type=str,
        default=str(DATA_DIR / "sample_events.csv"),
        help="CSV file with Windows style events",
    )
    parser.add_argument(
        "--output",
        type=str,
        default=str(DATA_DIR / "sessions_enriched.csv"),
        help="Where to store session enriched CSV",
    )
    args = parser.parse_args()

    path = Path(args.input)
    if not path.is_file():
        raise SystemExit(f"Input file not found: {path}")

    df = pd.read_csv(path)
    print(f"[info] Loaded {len(df)} events from {path}")

    sessions = build_sessions(df)
    print(f"[info] Built {len(sessions)} sessions")

    feature_cols = [
        "event_count",
        "success_logons",
        "failed_logons",
        "admin_logons",
        "unique_source_ips",
        "any_admin",
        "late_night",
    ]

    X = sessions[feature_cols].astype(float).values

    model = IsolationForest(
        n_estimators=200,
        contamination=0.1,
        random_state=42,
    )
    model.fit(X)

    scores = model.decision_function(X)
    # lower scores = more anomalous; convert to anomaly score 0..1
    # normalise scores
    scores_min = scores.min()
    scores_max = scores.max()
    if scores_max - scores_min > 1e-6:
        anomaly_score = (scores_min - scores) / (scores_min - scores_max)
    else:
        anomaly_score = np.zeros_like(scores)
    sessions["anomaly_score"] = anomaly_score

    # simple verdict
    def verdict(s: float) -> str:
        if s < 0.4:
            return "Typical"
        elif s < 0.7:
            return "Suspicious"
        else:
            return "Highly suspicious"

    sessions["verdict"] = sessions["anomaly_score"].apply(verdict)

    out_path = Path(args.output)
    sessions.to_csv(out_path, index=False)
    print(f"[info] Sessions with anomaly scores written to {out_path}")

    # print top suspicious
    top = sessions.sort_values("anomaly_score", ascending=False).head(10)
    print("[info] Top suspicious sessions:")
    for _, row in top.iterrows():
        print(
            f"  user={row['user']:<12} window_start={row['window']}  "
            f"score={row['anomaly_score']:.2f}  failed_logons={int(row['failed_logons'])}  "
            f"admin_logons={int(row['admin_logons'])}  late_night={bool(row['late_night'])}"
        )


if __name__ == "__main__":
    main()
