# Autonomous Patch Priority Recommender – Dania’s risk based patch helper

Hi

I am Dania and this project is a small engine that turns vulnerability scan output plus a few business tags into **patching priorities** that humans can actually work with

Instead of just sorting by CVSS alone
it combines

* technical severity
* exploit information
* asset importance
* simple business context like
  * internet facing
  * holds customer data

and then groups findings into buckets such as

* `Immediate`
* `High`
* `Normal`
* `Low`

The whole thing is intentionally transparent and file based
so it is easy to tune and discuss

## Input format

The tool expects a JSON file with a list of findings
Each finding looks like

{
  "id": "finding_1",
  "cve": "CVE-2024-0001",
  "asset": "web01",
  "cvss": 9.1,
  "has_known_exploit": true,
  "internet_facing": true,
  "holds_customer_data": false,
  "business_criticality": "high"
}

Fields:

* `id`                   unique id from your scanner
* `cve`                  optional CVE
* `asset`                asset name or id
* `cvss`                 numeric base score
* `has_known_exploit`    boolean
* `internet_facing`      boolean
* `holds_customer_data`  boolean
* `business_criticality` `low`, `medium`, or `high`

I include `examples_vulns_sample.json` so the project runs immediately.

## How scores are built

For each finding the recommender computes a score like this

* start with `cvss`
* if `has_known_exploit`       add +2
* if `internet_facing`         add +1.5
* if `holds_customer_data`     add +1.5
* if `business_criticality` is
  * `high`                     add +1.5
  * `medium`                   add +0.5

Then the final numeric score is mapped to a priority bucket

* score >= 9.5         → `Immediate`
* 8.0 <= score < 9.5   → `High`
* 6.0 <= score < 8.0   → `Normal`
* else                 → `Low`

All of this is encoded in a small function
and easy to tweak for a different environment.

## Outputs

For each run it writes

1. `*_patch_recommendations.json`

   * one object per finding with
     * id, cve, asset
     * final score
     * priority bucket
     * short rationale

2. `*_patch_recommendations.md`

   * summary counts per priority
   * top findings in each bucket
   * a narrative paragraph you can copy into a change meeting

## How I run it

From the project root

1. Optional  virtual environment

       python -m venv venv
       source venv_bin_activate

2. Install requirements (standard library only)

       pip install -r requirements.txt

3. Look at the example file

       examples_vulns_sample.json

4. Run the recommender

       python patch_recommender.py \
           --findings examples_vulns_sample.json \
           --out-prefix runs_demo

This creates

* `runs_demo_patch_recommendations.json`
* `runs_demo_patch_recommendations.md`

## Why I like this project

Patch management is where technical risk meets real world constraints

With this system I can show that I

* think in terms of business context not just raw CVSS
* can turn scans into small prioritised queues for teams
* prefer clear simple scoring logic that people can challenge and improve

It is small but very extensible
You could plug it into a CI pipeline
attach it to a ticketing system
or use it as a teaching tool for junior analysts who are learning how to prioritise.
