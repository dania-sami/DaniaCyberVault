"""
Autonomous Patch Priority Recommender – Dania's risk based patch helper

Reads vulnerability findings from JSON
computes risk scores with simple transparent logic
and groups them into priority buckets
"""

import argparse
import json
from dataclasses import dataclass, asdict
from typing import List, Dict


@dataclass
class Finding:
    id: str
    cve: str
    asset: str
    cvss: float
    has_known_exploit: bool
    internet_facing: bool
    holds_customer_data: bool
    business_criticality: str


@dataclass
class Recommendation:
    id: str
    cve: str
    asset: str
    score: float
    priority: str
    rationale: str


def load_findings(path: str) -> List[Finding]:
    with open(path, "r", encoding="utf-8") as f:
        raw = json.load(f)
    findings: List[Finding] = []
    for item in raw:
        findings.append(
            Finding(
                id=str(item.get("id")),
                cve=str(item.get("cve", "")),
                asset=str(item.get("asset", "")),
                cvss=float(item.get("cvss", 0.0)),
                has_known_exploit=bool(item.get("has_known_exploit", False)),
                internet_facing=bool(item.get("internet_facing", False)),
                holds_customer_data=bool(item.get("holds_customer_data", False)),
                business_criticality=str(item.get("business_criticality", "low")).lower(),
            )
        )
    return findings


def score_finding(f: Finding) -> float:
    score = f.cvss
    if f.has_known_exploit:
        score += 2.0
    if f.internet_facing:
        score += 1.5
    if f.holds_customer_data:
        score += 1.5
    if f.business_criticality == "high":
        score += 1.5
    elif f.business_criticality == "medium":
        score += 0.5
    return round(score, 2)


def bucket_priority(score: float) -> str:
    if score >= 9.5:
        return "Immediate"
    if score >= 8.0:
        return "High"
    if score >= 6.0:
        return "Normal"
    return "Low"


def build_rationale(f: Finding, score: float) -> str:
    parts = [f"Base CVSS {f.cvss}"]
    if f.has_known_exploit:
        parts.append("known exploit available")
    if f.internet_facing:
        parts.append("internet facing asset")
    if f.holds_customer_data:
        parts.append("handles customer data")
    if f.business_criticality == "high":
        parts.append("high business criticality")
    elif f.business_criticality == "medium":
        parts.append("medium business criticality")
    text = ", ".join(parts)
    return f"{text} → combined score {score}"


def recommend(findings: List[Finding]) -> List[Recommendation]:
    recs: List[Recommendation] = []
    for f in findings:
        score = score_finding(f)
        priority = bucket_priority(score)
        rationale = build_rationale(f, score)
        recs.append(
            Recommendation(
                id=f.id,
                cve=f.cve,
                asset=f.asset,
                score=score,
                priority=priority,
                rationale=rationale,
            )
        )
    return recs


def write_json_recs(recs: List[Recommendation], path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump([asdict(r) for r in recs], f, indent=2)


def write_report(recs: List[Recommendation], path: str) -> None:
    by_priority: Dict[str, List[Recommendation]] = {}
    for r in recs:
        by_priority.setdefault(r.priority, []).append(r)

    with open(path, "w", encoding="utf-8") as f:
        f.write("# Patch priority recommendations\n\n")
        total = len(recs)
        f.write(f"* Total findings: {total}\n\n")

        f.write("## Findings by priority\n\n")
        for p in ["Immediate", "High", "Normal", "Low"]:
            count = len(by_priority.get(p, []))
            f.write(f"* {p}: {count}\n")
        f.write("\n")

        for p in ["Immediate", "High", "Normal", "Low"]:
            bucket = by_priority.get(p, [])
            if not bucket:
                continue
            f.write(f"## {p} priority\n\n")
            for r in sorted(bucket, key=lambda x: x.score, reverse=True)[:10]:
                f.write(f"* {r.id}  {r.cve}  on asset {r.asset}  score {r.score}\n")
                f.write(f"  - {r.rationale}\n")
            f.write("\n")

        f.write("## Narrative summary\n\n")
        if not recs:
            f.write("No findings were provided in the input file.\n")
        else:
            imm = len(by_priority.get("Immediate", []))
            high = len(by_priority.get("High", []))
            if imm == 0 and high == 0:
                f.write("The current set of findings does not contain any items in the immediate or high buckets with the default thresholds. ")
                f.write("It still makes sense to plan patches for the normal bucket as part of regular maintenance.\n")
            else:
                f.write(
                    f"There are {imm} immediate and {high} high priority findings where high CVSS, exploit information and business context align. "
                )
                f.write("These should be scheduled first, preferably in the next patch window, while normal and low priority items can follow afterwards.\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's autonomous patch priority recommender")
    parser.add_argument("--findings", required=True, help="Path to JSON file with vulnerability findings")
    parser.add_argument("--out-prefix", default="patch_run", help="Prefix for output files")
    args = parser.parse_args()

    findings = load_findings(args.findings)
    recs = recommend(findings)

    json_path = f"{args.out_prefix}_patch_recommendations.json"
    md_path = f"{args.out_prefix}_patch_recommendations.md"

    write_json_recs(recs, json_path)
    write_report(recs, md_path)

    print(f"Wrote {len(recs)} recommendations to {json_path}")
    print(f"Wrote Markdown report to {md_path}")


if __name__ == "__main__":
    main()
