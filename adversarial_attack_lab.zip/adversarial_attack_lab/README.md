# Adversarial Attack Lab for Security Models

Hi, I am Dania 👋

This project is my small **adversarial ML lab** for security:

- I train a simple classifier on synthetic "security" data.
- Then I generate FGSM-style adversarial examples.
- Finally I show how the model accuracy drops under attack.

It is a compact but real example of **robustness testing** for security models.

## How to run

```bash
cd adversarial_attack_lab

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt

# Train baseline model
python -m src.train_model

# Run adversarial attack
python -m src.fgsm_attack
```

The scripts will print clean vs adversarial accuracy and save a small plot
under `outputs/`.
