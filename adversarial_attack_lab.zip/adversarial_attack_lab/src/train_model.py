from __future__ import annotations

from pathlib import Path

import joblib
import numpy as np
from sklearn.datasets import make_classification
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
MODELS_DIR = BASE_DIR / "models"
OUTPUT_DIR = BASE_DIR / "outputs"

for d in (DATA_DIR, MODELS_DIR, OUTPUT_DIR):
    d.mkdir(parents=True, exist_ok=True)

RANDOM_STATE = 42


def generate_data() -> tuple[np.ndarray, np.ndarray]:
    X, y = make_classification(
        n_samples=600,
        n_features=6,
        n_informative=4,
        n_redundant=0,
        n_clusters_per_class=1,
        flip_y=0.03,
        random_state=RANDOM_STATE,
    )
    return X, y


def main() -> None:
    X, y = generate_data()
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, random_state=RANDOM_STATE, stratify=y
    )

    clf = LogisticRegression(max_iter=200)
    clf.fit(X_train, y_train)

    y_pred = clf.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    print(f"Clean test accuracy: {acc:.3f}")

    joblib.dump(
        {
            "model": clf,
            "X_test": X_test,
            "y_test": y_test,
        },
        MODELS_DIR / "adv_lab_model.joblib",
    )
    print(f"Model and test set saved to {MODELS_DIR/'adv_lab_model.joblib'}")


if __name__ == "__main__":
    main()
