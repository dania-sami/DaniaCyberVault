from __future__ import annotations

from pathlib import Path

import joblib
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score

BASE_DIR = Path(__file__).resolve().parent.parent
MODELS_DIR = BASE_DIR / "models"
OUTPUT_DIR = BASE_DIR / "outputs"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def fgsm_attack(X: np.ndarray, y: np.ndarray, coef: np.ndarray, eps: float) -> np.ndarray:
    grad_sign = np.sign(coef).reshape(1, -1)
    direction = np.where(y.reshape(-1, 1) == 1, -grad_sign, grad_sign)
    return X + eps * direction


def main() -> None:
    bundle = joblib.load(MODELS_DIR / "adv_lab_model.joblib")
    clf = bundle["model"]
    X_test = bundle["X_test"]
    y_test = bundle["y_test"]

    clean_acc = accuracy_score(y_test, clf.predict(X_test))
    print(f"Clean accuracy (re-check): {clean_acc:.3f}")

    eps_values = [0.0, 0.05, 0.1, 0.2, 0.3]
    accs = []

    coef = clf.coef_[0]

    for eps in eps_values:
        X_adv = fgsm_attack(X_test, y_test, coef, eps)
        y_pred_adv = clf.predict(X_adv)
        acc = accuracy_score(y_test, y_pred_adv)
        accs.append(acc)
        print(f"Epsilon={eps:.2f} -> adversarial accuracy={acc:.3f}")

    plt.figure()
    plt.plot(eps_values, accs, marker="o")
    plt.xlabel("Epsilon (perturbation size)")
    plt.ylabel("Accuracy on adversarial examples")
    plt.title("Adversarial robustness of security model")
    plt.grid(True)
    out_path = OUTPUT_DIR / "adversarial_accuracy.png"
    plt.savefig(out_path, bbox_inches="tight")
    print(f"Plot saved to {out_path}")


if __name__ == "__main__":
    main()
