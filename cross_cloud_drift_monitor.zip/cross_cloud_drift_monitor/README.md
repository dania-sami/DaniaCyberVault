# Cross Cloud Drift Monitor – Dania

Hi

I am Dania and this drift monitor compares two JSON snapshots of multi cloud resources

It focuses on

* what changed in each provider
* new or removed public endpoints
* changes that might affect security posture

The output is a Markdown and JSON report that makes it easier to talk about configuration drift across AWS Azure and GCP without calling any APIs
