"""
Cross Cloud Drift Monitor – Dania

Compares baseline and current JSON snapshots of resources across multiple cloud providers.
"""

import argparse
import json
from dataclasses import dataclass, asdict
from typing import Dict, List, Tuple


@dataclass
class Resource:
    id: str
    provider: str
    kind: str
    internet_exposed: bool
    config_hash: str


@dataclass
class Drift:
    provider: str
    resource_id: str
    kind: str
    category: str  # added, removed, changed
    details: str


def load_snapshot(path: str) -> Dict[Tuple[str, str], Resource]:
    with open(path, "r", encoding="utf-8") as f:
        raw = json.load(f)
    result: Dict[Tuple[str, str], Resource] = {}
    for r in raw.get("resources", []):
        res = Resource(
            id=r["id"],
            provider=r.get("provider", "unknown"),
            kind=r.get("kind", "unknown"),
            internet_exposed=bool(r.get("internet_exposed", False)),
            config_hash=str(r.get("config_hash", "")),
        )
        key = (res.provider, res.id)
        result[key] = res
    return result


def compare_snapshots(baseline: Dict[Tuple[str, str], Resource], current: Dict[Tuple[str, str], Resource]) -> List[Drift]:
    drifts: List[Drift] = []

    all_keys = set(baseline.keys()) | set(current.keys())

    for key in sorted(all_keys):
        base = baseline.get(key)
        cur = current.get(key)
        if base and not cur:
            drifts.append(
                Drift(
                    provider=base.provider,
                    resource_id=base.id,
                    kind=base.kind,
                    category="removed",
                    details="Resource present in baseline but missing in current snapshot.",
                )
            )
        elif cur and not base:
            det = "New resource appeared in current snapshot."
            if cur.internet_exposed:
                det += " It is internet exposed."
            drifts.append(
                Drift(
                    provider=cur.provider,
                    resource_id=cur.id,
                    kind=cur.kind,
                    category="added",
                    details=det,
                )
            )
        elif base and cur:
            if base.config_hash != cur.config_hash or base.internet_exposed != cur.internet_exposed:
                change_detail = []
                if base.internet_exposed != cur.internet_exposed:
                    if cur.internet_exposed:
                        change_detail.append("now internet exposed")
                    else:
                        change_detail.append("no longer internet exposed")
                if base.config_hash != cur.config_hash:
                    change_detail.append("config hash changed")
                drifts.append(
                    Drift(
                        provider=cur.provider,
                        resource_id=cur.id,
                        kind=cur.kind,
                        category="changed",
                        details=", ".join(change_detail),
                    )
                )

    return drifts


def write_outputs(drifts: List[Drift], md_path: str, json_path: str) -> None:
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump([asdict(d) for d in drifts], f, indent=2)

    by_provider: Dict[str, List[Drift]] = {}
    for d in drifts:
        by_provider.setdefault(d.provider, []).append(d)

    with open(md_path, "w", encoding="utf-8") as f:
        f.write("# Cross cloud drift report\n\n")
        f.write(f"* Total drift items: {len(drifts)}\n\n")
        for provider, items in by_provider.items():
            f.write(f"## {provider}\n\n")
            for d in items:
                f.write(f"- {d.resource_id} ({d.kind}) [{d.category}] – {d.details}\n")
            f.write("\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's cross cloud drift monitor")
    parser.add_argument("--baseline", default="baseline_snapshot.json", help="Baseline snapshot JSON")
    parser.add_argument("--current", default="current_snapshot.json", help="Current snapshot JSON")
    parser.add_argument("--out-prefix", default="drift", help="Output prefix")
    args = parser.parse_args()

    baseline = load_snapshot(args.baseline)
    current = load_snapshot(args.current)
    drifts = compare_snapshots(baseline, current)

    md_path = f"{args.out_prefix}_report.md"
    json_path = f"{args.out_prefix}_drifts.json"
    write_outputs(drifts, md_path, json_path)

    print(f"Found {len(drifts)} drift items.")
    print(f"Wrote Markdown to {md_path}")


if __name__ == "__main__":
    main()
