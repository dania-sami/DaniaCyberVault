
# Secure Boot Verification Engine (Simulation Lab)

Hi, I am Dania and I built this project to practise how **secure boot chains** work.

Instead of flashing firmware on a board, I simulate a boot chain where:

- each stage has an image file
- each image is hashed with SHA-256
- every stage is “signed” using an HMAC with the previous stage’s key
- a verifier walks the chain and checks integrity and signatures before “booting”

This gives me a clean way to reason about root of trust and chain of trust.

---

## What this project does

The main script is `simulate_boot.py`. It supports two modes:

1. **Setup demo boot chain**

   ```bash
   python simulate_boot.py setup
   ```

   - creates a demo directory `images/` with:
     - `stage0_root.bin`
     - `stage1_bootloader.bin`
     - `stage2_kernel.bin`
   - creates a `boot_chain.json` describing:
     - the stages
     - their expected hashes
     - HMAC-based signatures
   - uses a simulated root key to act as the hardware root of trust

2. **Verify boot chain**

   ```bash
   python simulate_boot.py verify
   ```

   - recomputes hashes of each image
   - verifies the HMAC signatures for each stage
   - stops and reports if any stage has been modified
   - prints a clear summary of verification results

---

## Project structure

```text
secure_boot_engine/
  README.md
  requirements.txt
  simulate_boot.py      # setup + verify secure boot chain
  images/               # created by setup
  boot_chain.json       # created by setup
  data/
```

Everything is simulated with the Python standard library.

---

## Installation

```bash
python3 -m venv venv
source venv/bin/activate       # Windows  venv\Scripts\activate
pip install -r requirements.txt
```

`requirements.txt` is empty because the code uses only the standard library.

---

## Step 1  Set up the demo boot chain

```bash
python simulate_boot.py setup
```

This will:

- generate dummy image files
- compute their hashes
- sign each stage with an HMAC using the previous key
- write all metadata to `boot_chain.json`

---

## Step 2  Verify the boot chain

```bash
python simulate_boot.py verify
```

You will see a result like:

```text
[info] Verifying stage 0: stage0_root.bin ... OK
[info] Verifying stage 1: stage1_bootloader.bin ... OK
[info] Verifying stage 2: stage2_kernel.bin ... OK
[info] All stages verified. Secure boot completed successfully.
```

If you manually modify one of the `images/*.bin` files and run `verify` again, you will see a failure at that stage.

---

## Why this project matters to me

Secure boot is a core building block of hardware and platform security.

With this project I can show that I:

- understand the idea of a root of trust
- know how a chain of trust is built stage by stage
- can model integrity checks and signatures
- and can discuss what happens when one stage is compromised

It is a simple but powerful way to visualise secure boot without any special hardware.
