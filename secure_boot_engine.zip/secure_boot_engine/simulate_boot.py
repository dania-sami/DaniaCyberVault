
import argparse
import hashlib
import hmac
import json
import os
from pathlib import Path

ROOT_DIR = Path(".")
IMAGES_DIR = ROOT_DIR / "images"
CHAIN_FILE = ROOT_DIR / "boot_chain.json"

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            h.update(chunk)
    return h.hexdigest()

def setup_chain():
    IMAGES_DIR.mkdir(exist_ok=True)
    # create dummy images
    stages = [
        {"name": "stage0_root", "filename": "stage0_root.bin", "contents": b"ROOT-OF-TRUST"},
        {"name": "stage1_bootloader", "filename": "stage1_bootloader.bin", "contents": b"BOOTLOADER-IMAGE"},
        {"name": "stage2_kernel", "filename": "stage2_kernel.bin", "contents": b"KERNEL-IMAGE"},
    ]
    for s in stages:
        (IMAGES_DIR / s["filename"]).write_bytes(s["contents"])

    # root key simulating hardware root of trust
    root_key = os.urandom(32).hex()

    chain = {
        "root_key": root_key,
        "stages": [],
    }

    prev_key = bytes.fromhex(root_key)
    for s in stages:
        img_path = IMAGES_DIR / s["filename"]
        img_hash = sha256_file(img_path)
        # sign hash with HMAC using previous key
        sig = hmac.new(prev_key, img_hash.encode("utf-8"), hashlib.sha256).hexdigest()
        stage_entry = {
            "name": s["name"],
            "filename": s["filename"],
            "hash": img_hash,
            "signature": sig,
        }
        chain["stages"].append(stage_entry)
        # derive next key (for demo) as HMAC(prev_key, img_hash)
        prev_key = hmac.new(prev_key, img_hash.encode("utf-8"), hashlib.sha256).digest()

    with CHAIN_FILE.open("w", encoding="utf-8") as f:
        json.dump(chain, f, indent=2)

    print(f"[info] Demo boot chain created.")
    print(f"[info] Images directory: {IMAGES_DIR}")
    print(f"[info] Chain file: {CHAIN_FILE}")

def verify_chain():
    if not CHAIN_FILE.is_file():
        raise SystemExit(f"Boot chain file not found. Run 'setup' first ({CHAIN_FILE}).")

    with CHAIN_FILE.open("r", encoding="utf-8") as f:
        chain = json.load(f)

    root_key = bytes.fromhex(chain["root_key"])
    prev_key = root_key

    for idx, stage in enumerate(chain["stages"]):
        name = stage["name"]
        filename = stage["filename"]
        expected_hash = stage["hash"]
        expected_sig = stage["signature"]

        img_path = IMAGES_DIR / filename
        if not img_path.is_file():
            raise SystemExit(f"[error] Missing image file for stage {name}: {img_path}")

        actual_hash = sha256_file(img_path)
        if actual_hash != expected_hash:
            raise SystemExit(
                f"[error] Hash mismatch for stage {name}. Expected {expected_hash}, got {actual_hash}."
            )

        calc_sig = hmac.new(prev_key, expected_hash.encode("utf-8"), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(calc_sig, expected_sig):
            raise SystemExit(
                f"[error] Signature verification failed for stage {name}."
            )

        print(f"[info] Verifying stage {idx}: {filename} ... OK")
        # derive next key
        prev_key = hmac.new(prev_key, expected_hash.encode("utf-8"), hashlib.sha256).digest()

    print("[info] All stages verified. Secure boot completed successfully.")

def main():
    parser = argparse.ArgumentParser(description="Secure Boot Verification Engine (simulation)")
    parser.add_argument("mode", choices=["setup", "verify"], help="setup demo chain or verify existing one")
    args = parser.parse_args()

    if args.mode == "setup":
        setup_chain()
    elif args.mode == "verify":
        verify_chain()

if __name__ == "__main__":
    main()
