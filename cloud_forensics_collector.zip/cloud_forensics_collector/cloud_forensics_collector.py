"""
Cloud Forensics Collector – Dania

Offline tool that reads local JSONL logs and builds a compact bundle
around a given incident time window.
"""

import argparse
import json
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
from typing import List, Dict


TS_FORMAT = "%Y-%m-%dT%H:%M:%S"


@dataclass
class ApiEvent:
    ts: str
    actor: str
    action: str
    resource: str


@dataclass
class FlowEvent:
    ts: str
    src: str
    dst: str
    dst_port: int
    allowed: bool


@dataclass
class IamChange:
    ts: str
    actor: str
    change: str
    target: str


@dataclass
class ForensicBundle:
    api_events: List[ApiEvent]
    flow_events: List[FlowEvent]
    iam_changes: List[IamChange]


def load_jsonl_api(path: str) -> List[ApiEvent]:
    out: List[ApiEvent] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            out.append(
                ApiEvent(
                    ts=obj["ts"],
                    actor=obj.get("actor", ""),
                    action=obj.get("action", ""),
                    resource=obj.get("resource", ""),
                )
            )
    return out


def load_jsonl_flow(path: str) -> List[FlowEvent]:
    out: List[FlowEvent] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            out.append(
                FlowEvent(
                    ts=obj["ts"],
                    src=obj.get("src", ""),
                    dst=obj.get("dst", ""),
                    dst_port=int(obj.get("dst_port", 0)),
                    allowed=bool(obj.get("allowed", True)),
                )
            )
    return out


def load_jsonl_iam(path: str) -> List[IamChange]:
    out: List[IamChange] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            out.append(
                IamChange(
                    ts=obj["ts"],
                    actor=obj.get("actor", ""),
                    change=obj.get("change", ""),
                    target=obj.get("target", ""),
                )
            )
    return out


def parse_ts(ts: str) -> datetime:
    return datetime.strptime(ts, TS_FORMAT)


def filter_by_window(items, start: datetime, end: datetime):
    result = []
    for it in items:
        t = parse_ts(getattr(it, "ts"))
        if start <= t <= end:
            result.append(it)
    return result


def write_outputs(bundle: ForensicBundle, md_path: str, json_path: str) -> None:
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(
            {
                "api_events": [asdict(e) for e in bundle.api_events],
                "flow_events": [asdict(e) for e in bundle.flow_events],
                "iam_changes": [asdict(e) for e in bundle.iam_changes],
            },
            f,
            indent=2,
        )

    with open(md_path, "w", encoding="utf-8") as f:
        f.write("# Cloud forensics bundle\n\n")
        f.write(f"* API events: {len(bundle.api_events)}\n")
        f.write(f"* Flow events: {len(bundle.flow_events)}\n")
        f.write(f"* IAM changes: {len(bundle.iam_changes)}\n\n")

        if bundle.api_events:
            f.write("## API events\n\n")
            for e in bundle.api_events:
                f.write(f"- {e.ts}  {e.actor}  {e.action} on {e.resource}\n")
            f.write("\n")
        if bundle.flow_events:
            f.write("## Network flow events\n\n")
            for e in bundle.flow_events:
                verdict = "allowed" if e.allowed else "blocked"
                f.write(f"- {e.ts}  {e.src} → {e.dst}:{e.dst_port} ({verdict})\n")
            f.write("\n")
        if bundle.iam_changes:
            f.write("## IAM changes\n\n")
            for e in bundle.iam_changes:
                f.write(f"- {e.ts}  {e.actor} changed {e.target}: {e.change}\n")
            f.write("\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's cloud forensics collector")
    parser.add_argument("--incident-ts", required=True, help="Incident timestamp in YYYY-MM-DDTHH:MM:SS")
    parser.add_argument("--window-minutes", type=int, default=60, help="Minutes before and after the incident")
    parser.add_argument("--api-log", default="api_log.jsonl", help="API log JSONL")
    parser.add_argument("--flow-log", default="flow_log.jsonl", help="Network flow log JSONL")
    parser.add_argument("--iam-log", default="iam_log.jsonl", help="IAM change log JSONL")
    parser.add_argument("--out-prefix", default="forensics", help="Output prefix")
    args = parser.parse_args()

    center = parse_ts(args.incident_ts)
    start = center - timedelta(minutes=args.window_minutes)
    end = center + timedelta(minutes=args.window_minutes)

    api_events = filter_by_window(load_jsonl_api(args.api_log), start, end)
    flow_events = filter_by_window(load_jsonl_flow(args.flow_log), start, end)
    iam_changes = filter_by_window(load_jsonl_iam(args.iam_log), start, end)

    bundle = ForensicBundle(api_events=api_events, flow_events=flow_events, iam_changes=iam_changes)

    md_path = f"{args.out_prefix}_bundle.md"
    json_path = f"{args.out_prefix}_bundle.json"
    write_outputs(bundle, md_path, json_path)

    print(f"Wrote forensic bundle to {md_path} and {json_path}")


if __name__ == "__main__":
    main()
