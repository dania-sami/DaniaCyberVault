# Cloud Forensics Collector – Dania

Hi

I am Dania and this collector is my notebook for making incident artefacts easier to review

It takes local log files that represent things like API calls network flows and IAM changes and then

* filters them around an incident time window
* groups interesting events by resource
* writes a compact Markdown and JSON bundle

This is all offline and file based  perfect for explaining how I would structure a forensics collection process
