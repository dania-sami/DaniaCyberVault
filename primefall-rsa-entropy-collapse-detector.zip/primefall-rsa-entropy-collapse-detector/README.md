
# PrimeFall RSA Entropy Collapse Detector

PrimeFall is my way to talk about RSA entropy risk without touching private keys.

I give it metrics like key reuse ratio, shared prime alerts and generator bias
scores and it tells me:
* how close I might be to an entropy collapse scenario
* a risk band, from low to critical
* a few short warnings I can discuss with the team

## Run

```bash
cd backend
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn primefall_engine.main:app --reload --port 9923
```

Then open http://localhost:9923/docs and use `/ecosystems` then `/assess`.
