
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Dict, List

from .engine import PrimeFallBrain, RsaEcosystemProfile, EntropyAssessment


brain = PrimeFallBrain()


class EcoIn(BaseModel):
    name: str = Field(..., example="payment-gateway-rsa")
    meta: Dict[str, str] = Field(default_factory=dict)
    metrics: Dict[str, float] = Field(
        default_factory=dict,
        description=(
            "Metrics: key_reuse_ratio, shared_prime_alerts, generator_bias_score, "
            "entropy_source_health, audit_coverage_score"
        ),
    )


class EcoOut(BaseModel):
    id: int
    name: str
    meta: Dict[str, str]
    metrics: Dict[str, float]


class EntropyOut(BaseModel):
    profile_id: int
    name: str
    collapse_risk: float
    band: str
    warnings: List[str]


app = FastAPI(
    title="PrimeFall RSA Entropy Collapse Detector",
    version="0.1.0",
    description="My reasoning engine for RSA ecosystem entropy collapse risk.",
)


@app.post("/ecosystems", response_model=EcoOut)
def register_ecosystem(payload: EcoIn) -> EcoOut:
    eco: RsaEcosystemProfile = brain.register_ecosystem(
        name=payload.name,
        meta=payload.meta,
        metrics=payload.metrics,
    )
    return EcoOut(
        id=eco.id,
        name=eco.name,
        meta=eco.meta,
        metrics=eco.metrics,
    )


@app.post("/assess", response_model=EntropyOut)
def assess(profile_id: int) -> EntropyOut:
    if profile_id not in brain.ecos:
        raise HTTPException(status_code=404, detail="RSA ecosystem not found")
    res: EntropyAssessment = brain.assess(profile_id)
    return EntropyOut(
        profile_id=res.profile_id,
        name=res.name,
        collapse_risk=res.collapse_risk,
        band=res.band,
        warnings=res.warnings,
    )
