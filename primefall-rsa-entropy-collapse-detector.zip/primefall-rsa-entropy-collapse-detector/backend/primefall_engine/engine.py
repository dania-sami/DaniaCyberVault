
from dataclasses import dataclass
from typing import Dict, List


@dataclass
class RsaEcosystemProfile:
    id: int
    name: str
    meta: Dict[str, str]
    metrics: Dict[str, float]


@dataclass
class EntropyAssessment:
    profile_id: int
    name: str
    collapse_risk: float
    band: str
    warnings: List[str]


class PrimeFallBrain:
    """
    PrimeFall is my entropy collapse detector for RSA ecosystems.

    It does not look at real private keys. Instead it works from high level
    metrics: key reuse ratios, shared prime alerts from scanning tools, bias in
    generators and the health of entropy sources.
    """

    def __init__(self) -> None:
        self._next_id = 1
        self.ecos: Dict[int, RsaEcosystemProfile] = {}

    def register_ecosystem(self, name: str, meta: Dict[str, str], metrics: Dict[str, float]) -> RsaEcosystemProfile:
        eid = self._next_id
        self._next_id += 1
        eco = RsaEcosystemProfile(
            id=eid,
            name=name,
            meta=meta,
            metrics=metrics,
        )
        self.ecos[eid] = eco
        return eco

    def assess(self, profile_id: int) -> EntropyAssessment:
        eco = self.ecos[profile_id]
        m = eco.metrics
        warnings: List[str] = []
        risk = 0.0

        key_reuse = float(m.get("key_reuse_ratio", 0.0))
        shared_prime_alerts = float(m.get("shared_prime_alerts", 0.0))
        generator_bias = float(m.get("generator_bias_score", 0.0))
        entropy_health = float(m.get("entropy_source_health", 0.7))
        audit_coverage = float(m.get("audit_coverage_score", 0.5))

        if key_reuse > 0.05:
            risk += (key_reuse - 0.05) * 600.0
            warnings.append("Non trivial key reuse observed in the ecosystem.")
        if shared_prime_alerts > 0.0:
            risk += min(40.0, shared_prime_alerts * 10.0)
            warnings.append("Shared prime alerts reported by scanning tools.")
        if generator_bias > 0.4:
            risk += (generator_bias - 0.4) * 40.0
            warnings.append("PRNG or key generation bias looks significant.")
        if entropy_health < 0.6:
            risk += (0.6 - entropy_health) * 50.0
            warnings.append("Entropy sources health is questionable.")

        if audit_coverage < 0.4:
            risk += (0.4 - audit_coverage) * 20.0
            warnings.append("Limited independent audit coverage over key generation systems.")

        risk = max(0.0, min(100.0, risk))

        if risk >= 80.0:
            band = "critical_entropy_collapse_risk"
        elif risk >= 60.0:
            band = "high_entropy_collapse_risk"
        elif risk >= 40.0:
            band = "elevated_entropy_risk"
        elif risk >= 20.0:
            band = "moderate_entropy_risk"
        else:
            band = "low_entropy_risk"

        if not warnings:
            warnings.append("Metrics do not show strong signs of entropy collapse under this model.")

        return EntropyAssessment(
            profile_id=eco.id,
            name=eco.name,
            collapse_risk=round(risk, 2),
            band=band,
            warnings=warnings,
        )
