
from pathlib import Path

import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report

DATA_DIR = Path("data")
MODELS_DIR = Path("models")


def main():
    MODELS_DIR.mkdir(exist_ok=True)
    path = DATA_DIR / "training_alerts.csv"
    if not path.is_file():
        raise SystemExit(f"Training data not found. Run prepare_dataset.py first. ({path})")

    df = pd.read_csv(path)
    X = df["message"].astype(str)
    y = df["category"].astype(str)

    vectorizer = TfidfVectorizer(ngram_range=(1, 2), max_features=5000)
    X_vec = vectorizer.fit_transform(X)

    X_train, X_test, y_train, y_test = train_test_split(
        X_vec, y, test_size=0.2, random_state=42, stratify=y
    )

    clf = LogisticRegression(max_iter=200)
    clf.fit(X_train, y_train)

    y_pred = clf.predict(X_test)
    print("Classification report on validation set:")
    print(classification_report(y_test, y_pred, digits=4))

    joblib.dump(vectorizer, MODELS_DIR / "vectorizer.joblib")
    joblib.dump(clf, MODELS_DIR / "model.joblib")

    print(f"[info] Saved vectorizer to {MODELS_DIR / 'vectorizer.joblib'}")
    print(f"[info] Saved model to {MODELS_DIR / 'model.joblib'}")


if __name__ == "__main__":
    main()
