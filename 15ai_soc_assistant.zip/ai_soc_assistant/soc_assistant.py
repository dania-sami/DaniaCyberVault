
import argparse
from pathlib import Path

import joblib
import pandas as pd
from tabulate import tabulate

DATA_DIR = Path("data")
MODELS_DIR = Path("models")


CATEGORY_PRIORITY = {
    "malware": "High",
    "auth_bruteforce": "High",
    "web_attack": "Medium",
    "network_anomaly": "Medium",
    "policy_violation": "Low",
}


CATEGORY_ACTION = {
    "malware": "Isolate the host, run full malware scan, check for lateral movement indicators.",
    "auth_bruteforce": "Temporarily lock or protect the account, review source IP, check for credential stuffing.",
    "web_attack": "Review WAF logs, confirm if requests were fully blocked, check application logs for errors.",
    "network_anomaly": "Inspect firewall logs, verify destination IPs, confirm if traffic is expected for this host.",
    "policy_violation": "Contact user or owner, review policy, consider awareness or further controls.",
}


def short_summary(category: str, row: pd.Series) -> str:
    msg = row.get("message", "")
    src = row.get("source", "unknown source")
    if category == "malware":
        return f"Malware style alert from {src} indicating suspicious file or behaviour."
    if category == "auth_bruteforce":
        return f"Authentication issue suggesting repeated failures or brute force against an account."
    if category == "web_attack":
        return f"Web application attack pattern observed, likely handled by WAF or web logs."
    if category == "network_anomaly":
        return f"Network level anomaly such as unusual traffic, port scan or new device behaviour."
    if category == "policy_violation":
        return f"User or host behaviour that appears to break local security policy."
    return f"General security alert from {src}."


def enrich_alerts(input_path: Path, output_path: Path):
    vec_path = MODELS_DIR / "vectorizer.joblib"
    model_path = MODELS_DIR / "model.joblib"

    if not vec_path.is_file() or not model_path.is_file():
        raise SystemExit("Model or vectorizer not found. Run train_model.py first.")

    vectorizer = joblib.load(vec_path)
    model = joblib.load(model_path)

    df = pd.read_csv(input_path)
    if "message" not in df.columns:
        raise SystemExit("Input CSV must contain a 'message' column.")

    X = df["message"].astype(str)
    X_vec = vectorizer.transform(X)
    preds = model.predict(X_vec)

    categories = []
    priorities = []
    actions = []
    summaries = []

    for idx, cat in enumerate(preds):
        row = df.iloc[idx]
        cat_str = str(cat)
        categories.append(cat_str)
        prio = CATEGORY_PRIORITY.get(cat_str, "Medium")
        priorities.append(prio)
        actions.append(CATEGORY_ACTION.get(cat_str, "Review in context and check related logs."))
        summaries.append(short_summary(cat_str, row))

    df["category_pred"] = categories
    df["priority"] = priorities
    df["suggested_action"] = actions
    df["summary"] = summaries

    output_path.parent.mkdir(exist_ok=True)
    df.to_csv(output_path, index=False)
    return df


def main():
    parser = argparse.ArgumentParser(description="AI powered SOC analyst assistant")
    parser.add_argument(
        "--input",
        type=str,
        default=str(DATA_DIR / "demo_alerts.csv"),
        help="Path to input CSV with at least 'message' column",
    )
    parser.add_argument(
        "--output",
        type=str,
        default=str(DATA_DIR / "enriched_alerts.csv"),
        help="Where to write enriched alerts CSV",
    )
    args = parser.parse_args()

    input_path = Path(args.input)
    output_path = Path(args.output)

    if not input_path.is_file():
        raise SystemExit(f"Input file not found: {input_path}")

    df = enrich_alerts(input_path, output_path)

    print(f"[info] Enriched alerts written to {output_path}")
    print()
    print("Sample of enriched alerts:")
    cols_to_show = ["id"] if "id" in df.columns else []
    for col in ["source", "category_pred", "priority", "summary"]:
        if col in df.columns:
            cols_to_show.append(col)
    if "message" in df.columns:
        cols_to_show.append("message")

    preview = df[cols_to_show].head(10)
    print(tabulate(preview, headers="keys", tablefmt="github", showindex=False))


if __name__ == "__main__":
    main()
