
# AI Powered SOC Analyst Assistant

Hi, I am Dania and I built this project because I wanted something that feels closer to a real security operations center than a single script or toy example.

Instead of just raising alerts, this assistant tries to **help a SOC analyst think**:
- it takes raw alerts as input
- uses a small machine learning model to understand the type of alert
- assigns a priority
- suggests investigation steps and a short summary

It is a compact but realistic way to show how AI can support incident triage and threat hunting work.

---

## What this project does

The assistant supports a simple end to end workflow:

1. **Synthetic training data**  
   I generate a small labelled dataset of example alerts (authentication issues, malware detections, web attacks, network anomalies, policy violations, etc.) in `data/training_alerts.csv`.

2. **Model training**  
   A training script vectorises the alert text and trains a `LogisticRegression` model that predicts an alert category.  
   The model and text vectoriser are saved with `joblib`.

3. **Analyst assistant**  
   A command line tool loads:
   - the trained model
   - the vectoriser
   - a CSV file of new alerts (or a built in demo file)

   For each alert it predicts:
   - a **category** (for example `auth_bruteforce`, `malware`, `web_attack`, `network_anomaly`, `policy_violation`)
   - a **priority level** (High, Medium, Low)
   - a **suggested next step** for the analyst
   - a **short AI style summary** of what is happening

   The enriched alerts are written to `data/enriched_alerts.csv` and also printed in a readable table in the terminal.

Of course this is tiny compared to a production SIEM, but it demonstrates the core idea of an AI powered assistant for SOC triage.

---

## Project structure

```text
ai_soc_assistant/
  README.md
  requirements.txt
  prepare_dataset.py   # create synthetic training data
  train_model.py        # train text classifier
  soc_assistant.py      # AI powered enrichment / triage tool
  data/
```

---

## Installation

```bash
python3 -m venv venv
source venv/bin/activate           # Windows  venv\Scripts\activate
pip install -r requirements.txt
```

---

## Step 1  Prepare the synthetic training dataset

```bash
python prepare_dataset.py
```

This will create:

- `data/training_alerts.csv` — labelled training examples
- `data/demo_alerts.csv` — a small set of “incoming” alerts for testing the assistant

You can open these CSV files to see how the alerts are structured.

---

## Step 2  Train the model

```bash
python train_model.py
```

This will:

- train a text classifier on the synthetic alert messages
- print a classification report on a validation split
- save:
  - `models/vectorizer.joblib`
  - `models/model.joblib`

---

## Step 3  Run the SOC analyst assistant

You can enrich the demo alerts with AI powered categories and suggestions:

```bash
python soc_assistant.py --input data/demo_alerts.csv
```

The script will:

- load the trained model and vectoriser
- classify each alert
- assign a priority
- generate a short “AI style” summary and a recommended next step

The results will be stored in:

- `data/enriched_alerts.csv`

and you will also see a human readable table in the terminal.

If you have your own CSV of alerts with at least a `message` column, you can also pass that file path instead of the demo file.

---

## How the assistant thinks (simplified)

The model itself is intentionally simple and transparent:

- I use `TfidfVectorizer` on the alert text (`message` column)
- I train a `LogisticRegression` classifier to predict the alert `category`
- I keep the label set small but realistic (auth brute force, malware, web attack, etc.)

On top of the model, I add a small layer of logic in Python:

- map each category to a default priority (for example malware is High, policy violation is Medium)
- map each category to a suggested next step (for example “isolate host”, “lock user account”, “check firewall logs”)
- auto generate short summaries based on the category and key fields in the alert

So the “AI assistant” is a mix of a tiny ML model and clear rule based reasoning, which is often how practical security analytics are actually built.

---

## Why I like this project

I wanted a project that

- still fits into a small Python repository
- but feels like something a SOC analyst or security engineer could actually use as a starting point
- and clearly shows interest in **security operations, detection engineering and applied machine learning**

This assistant is my way of practising that mindset and showing that I can think beyond individual tools and towards full workflows like **alert triage and guided investigation**.
