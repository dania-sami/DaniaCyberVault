
from pathlib import Path
import random
import csv

DATA_DIR = Path("data")


def ensure_data_dir():
    DATA_DIR.mkdir(exist_ok=True)


def build_training_examples():
    random.seed(42)
    rows = []

    # category, severity, message templates
    auth_failures = [
        ("auth_bruteforce", "high", "Multiple failed login attempts for user {user} from IP {ip}"),
        ("auth_bruteforce", "medium", "Repeated authentication failures detected from source {ip}"),
        ("auth_bruteforce", "high", "Account lockout triggered after too many failed logins for {user}"),
    ]
    malware = [
        ("malware", "high", "Endpoint {host} detected malware signature {sig} in file {file}"),
        ("malware", "high", "Antivirus on {host} quarantined suspicious file {file}"),
        ("malware", "high", "EDR alert: possible ransomware behaviour observed on {host}"),
    ]
    web_attacks = [
        ("web_attack", "medium", "WAF blocked SQL injection attempt against {url} from IP {ip}"),
        ("web_attack", "medium", "Multiple 404 and suspicious query parameters from IP {ip} targeting {url}"),
        ("web_attack", "high", "Brute force attack detected on /login endpoint from {ip}"),
    ]
    network_anom = [
        ("network_anomaly", "medium", "Unusual outbound traffic volume from host {host} to external IP {ip}"),
        ("network_anomaly", "medium", "Port scan behaviour detected from {ip} against internal network"),
        ("network_anomaly", "low", "New device {host} seen on network segment for the first time"),
    ]
    policy = [
        ("policy_violation", "low", "User {user} downloaded large amount of data from restricted folder"),
        ("policy_violation", "medium", "Unapproved application installed on host {host}"),
        ("policy_violation", "low", "User {user} connected USB storage device to workstation"),
    ]

    all_templates = auth_failures + malware + web_attacks + network_anom + policy

    users = ["dania", "alice", "bob", "service-account", "admin"]
    ips = ["10.0.0.5", "10.0.0.10", "192.168.1.15", "203.0.113.10", "198.51.100.23"]
    hosts = ["win-01", "win-02", "laptop-01", "db-server-01", "web-01"]
    urls = ["/login", "/admin", "/index.php", "/search", "/api/v1/orders"]
    sigs = ["Trojan.Generic.123", "Ransom.Locky.X", "Heuristic.ML.Suspicious"]
    files = ["invoice.pdf.exe", "backup.zip", "document.docm", "temp.bin"]

    for i in range(400):
        template = random.choice(all_templates)
        category, severity, msg_template = template
        msg = msg_template.format(
            user=random.choice(users),
            ip=random.choice(ips),
            host=random.choice(hosts),
            url=random.choice(urls),
            sig=random.choice(sigs),
            file=random.choice(files),
        )
        rows.append(
            {
                "id": i + 1,
                "category": category,
                "severity": severity,
                "message": msg,
                "source": random.choice(["SIEM", "EDR", "WAF", "Firewall", "Cloud"]),
            }
        )

    return rows


def build_demo_alerts(training_rows):
    # create a small subset and modify some messages a bit
    demo = []
    for i, base in enumerate(training_rows[:20]):
        demo.append(
            {
                "id": i + 1,
                "message": base["message"],
                "source": base["source"],
            }
        )

    # add a few extra manual examples
    demo.extend(
        [
            {
                "id": len(demo) + 1,
                "message": "High number of failed VPN logins from 203.0.113.10 for user admin",
                "source": "VPN",
            },
            {
                "id": len(demo) + 2,
                "message": "Web application firewall blocked cross site scripting attempt on /search",
                "source": "WAF",
            },
            {
                "id": len(demo) + 3,
                "message": "EDR detected suspicious PowerShell execution on host win-01",
                "source": "EDR",
            },
        ]
    )
    return demo


def write_csv(path: Path, fieldnames, rows):
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for r in rows:
            writer.writerow(r)


def main():
    ensure_data_dir()
    training_rows = build_training_examples()
    training_path = DATA_DIR / "training_alerts.csv"
    write_csv(training_path, ["id", "category", "severity", "message", "source"], training_rows)
    print(f"[info] Wrote training data to {training_path} ({len(training_rows)} rows)")

    demo_rows = build_demo_alerts(training_rows)
    demo_path = DATA_DIR / "demo_alerts.csv"
    write_csv(demo_path, ["id", "message", "source"], demo_rows)
    print(f"[info] Wrote demo alerts to {demo_path} ({len(demo_rows)} rows)")


if __name__ == "__main__":
    main()
