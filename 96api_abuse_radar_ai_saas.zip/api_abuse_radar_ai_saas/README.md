# API Abuse Radar for AI and SaaS APIs – Dania’s behaviour lens

Hi

I am Dania and this project is my small radar for spotting strange usage patterns in API logs

With more AI and SaaS style APIs everywhere
I wanted something that can look at plain JSON logs and say

* this API key suddenly exploded in volume
* this IP is enumerating resource ids very quickly
* this client keeps getting 401 or 429 responses

The design is intentionally simple and offline

* logs are JSON lines in a file
* the radar computes a few behavioural signals
* it writes a JSON list of anomaly events and a Markdown summary

No production systems are touched
This is a learning and portfolio tool

## Log format

The radar expects JSON lines like:

{"ts": "2025-01-01T10:00:01", "ip": "203.0.113.10", "api_key": "key_a", "user_id": "user_1", "endpoint": "/v1/items/123", "status": 200, "latency_ms": 120, "bytes_out": 2048}

Fields:

* ts          ISO timestamp
* ip          client IP address
* api_key     identifier for the client or integration
* user_id     optional user id behind the key
* endpoint    path that was called
* status      HTTP status code
* latency_ms  approximate latency
* bytes_out   size of the response body

For the demo I include a small sample log in the examples folder.

## What the radar detects

### 1 Request rate spikes

For each `api_key` and `ip` it:

* buckets requests into 1 minute windows
* computes a simple baseline request rate
* flags minutes where the rate is many times above that baseline

This is useful for spotting sudden scraping or runaway loops.

### 2 Enumeration style behaviour

For endpoints that look like `/v1/items/{id}`:

* extracts the numeric id segments
* tracks how many distinct ids are touched per key and per ip in short time windows
* flags excessive enumeration activity

This is typical of “try every id from 1 to N” patterns.

### 3 Repeated failures

For each key and ip it counts:

* sequences of 401 or 403
* sequences of 429 (rate limit) responses

and flags them as possible misuse or broken integrations.

## Output

For each run the radar writes:

* `*_api_anomalies.json`
  * each anomaly with ts, key, ip, reason and basic stats
* `*_api_abuse_report.md`
  * overview of how many requests and clients were analysed
  * top suspicious keys and IPs with reasons
  * a short narrative style summary written in normal language

## How I run it

1 optional create a virtual environment

    python -m venv venv
    source venv_bin_activate

2 install requirements

    pip install -r requirements.txt

3 look at the example log

    examples_api_log_sample.jsonl

4 run the radar

    python api_abuse_radar.py \
        --log examples_api_log_sample.jsonl \
        --out-prefix runs_demo

Then I open `runs_demo_api_abuse_report.md` and see a small story about which simulated clients misbehaved and why.

## Why I like this project

I wanted a concrete way to talk about API abuse and misuse in interviews

With this radar I can show that I

* understand behavioural signals for scraping, enumeration and brute forcing
* can aggregate raw logs into simple per minute metrics and anomaly scores
* think about API security as an ongoing monitoring problem not just static rules

It also connects nicely to AI usage monitoring
especially when API keys represent different applications calling a model endpoint.
