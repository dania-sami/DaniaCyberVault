"""
API Abuse Radar for AI and SaaS APIs – Dania's behaviour lens

Reads JSONL API logs
computes simple behavioural signals
and flags potential abuse or misuse
"""

import argparse
import json
from collections import defaultdict, Counter
from dataclasses import dataclass, asdict
from datetime import datetime
from typing import List, Dict, Any, Tuple
import re


@dataclass
class LogEntry:
    ts: datetime
    ip: str
    api_key: str
    user_id: str
    endpoint: str
    status: int
    latency_ms: int
    bytes_out: int


@dataclass
class Anomaly:
    ts: datetime
    ip: str
    api_key: str
    reason: str
    details: Dict[str, Any]


def parse_time(s: str) -> datetime:
    return datetime.fromisoformat(s)


def load_logs(path: str) -> List[LogEntry]:
    entries: List[LogEntry] = []
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue
            try:
                e = LogEntry(
                    ts=parse_time(obj["ts"]),
                    ip=str(obj.get("ip", "")),
                    api_key=str(obj.get("api_key", "")),
                    user_id=str(obj.get("user_id", "")),
                    endpoint=str(obj.get("endpoint", "")),
                    status=int(obj.get("status", 0)),
                    latency_ms=int(obj.get("latency_ms", 0)),
                    bytes_out=int(obj.get("bytes_out", 0)),
                )
                entries.append(e)
            except Exception:
                continue
    entries.sort(key=lambda e: e.ts)
    return entries


def bucket_minute(ts: datetime) -> datetime:
    return ts.replace(second=0, microsecond=0)


def detect_rate_spikes(entries: List[LogEntry]) -> List[Anomaly]:
    # per key per minute counts
    per_key_minute = defaultdict(int)
    per_key_total = Counter()

    for e in entries:
        m = bucket_minute(e.ts)
        key = (e.api_key, m)
        per_key_minute[key] += 1
        per_key_total[e.api_key] += 1

    anomalies: List[Anomaly] = []
    # baseline: average per minute per key
    minutes_observed = len({bucket_minute(e.ts) for e in entries}) or 1
    for api_key, total in per_key_total.items():
        baseline = total / minutes_observed
        if baseline < 1:
            baseline = 1.0  # minimum

        for (k, minute), count in per_key_minute.items():
            if k != api_key:
                continue
            if count >= baseline * 5 and count >= 10:
                anomalies.append(
                    Anomaly(
                        ts=minute,
                        ip="",
                        api_key=api_key,
                        reason="rate_spike",
                        details={"minute_count": count, "baseline_per_minute": round(baseline, 2)},
                    )
                )
    return anomalies


ID_SEG_RE = re.compile(r"/(\d+)(?:/|$)")


def detect_enumeration(entries: List[LogEntry]) -> List[Anomaly]:
    # per key per short window track distinct ids
    per_key_window_ids = defaultdict(set)
    # define 5 minute windows
    def window_start(ts: datetime) -> datetime:
        return ts.replace(minute=(ts.minute // 5) * 5, second=0, microsecond=0)

    for e in entries:
        m = window_start(e.ts)
        match = ID_SEG_RE.search(e.endpoint)
        if not match:
            continue
        id_val = match.group(1)
        k = (e.api_key, m)
        per_key_window_ids[k].add(id_val)

    anomalies: List[Anomaly] = []
    for (api_key, win), ids in per_key_window_ids.items():
        if len(ids) >= 50:
            anomalies.append(
                Anomaly(
                    ts=win,
                    ip="",
                    api_key=api_key,
                    reason="id_enumeration",
                    details={"distinct_ids": len(ids)},
                )
            )
    return anomalies


def detect_failures(entries: List[LogEntry]) -> List[Anomaly]:
    anomalies: List[Anomaly] = []
    # streaks per api_key and ip
    streaks_key = defaultdict(int)
    last_ts_key = {}

    streaks_ip = defaultdict(int)
    last_ts_ip = {}

    for e in entries:
        is_fail = e.status in (401, 403, 429)
        # per key
        if is_fail:
            streaks_key[e.api_key] += 1
            last_ts_key[e.api_key] = e.ts
            streaks_ip[e.ip] += 1
            last_ts_ip[e.ip] = e.ts
        else:
            streaks_key[e.api_key] = 0
            streaks_ip[e.ip] = 0

        if streaks_key[e.api_key] == 5:
            anomalies.append(
                Anomaly(
                    ts=last_ts_key[e.api_key],
                    ip="",
                    api_key=e.api_key,
                    reason="repeated_failures_key",
                    details={"status": e.status, "streak": streaks_key[e.api_key]},
                )
            )
        if streaks_ip[e.ip] == 5:
            anomalies.append(
                Anomaly(
                    ts=last_ts_ip[e.ip],
                    ip=e.ip,
                    api_key="",
                    reason="repeated_failures_ip",
                    details={"status": e.status, "streak": streaks_ip[e.ip]},
                )
            )

    return anomalies


def summarise_anomalies(anomalies: List[Anomaly]) -> Dict[str, Dict[str, int]]:
    by_key = defaultdict(lambda: defaultdict(int))
    by_reason = Counter()
    for a in anomalies:
        if a.api_key:
            by_key[a.api_key][a.reason] += 1
        by_reason[a.reason] += 1
    return {"by_key": {k: dict(v) for k, v in by_key.items()}, "by_reason": dict(by_reason)}


def write_anomalies(anomalies: List[Anomaly], path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump([{"ts": a.ts.isoformat(), "ip": a.ip, "api_key": a.api_key, "reason": a.reason, "details": a.details} for a in anomalies], f, indent=2)


def write_report(entries: List[LogEntry], anomalies: List[Anomaly], summary: Dict[str, Dict[str, int]], path: str) -> None:
    total_requests = len(entries)
    unique_keys = len({e.api_key for e in entries})
    unique_ips = len({e.ip for e in entries})

    with open(path, "w", encoding="utf-8") as f:
        f.write("# API abuse radar report\n\n")
        f.write(f"* Total requests analysed: {total_requests}\n")
        f.write(f"* Unique API keys: {unique_keys}\n")
        f.write(f"* Unique client IPs: {unique_ips}\n")
        f.write(f"* Total anomaly events: {len(anomalies)}\n\n")

        f.write("## Anomalies by reason\n\n")
        if not summary["by_reason"]:
            f.write("No anomalies were raised with the current thresholds.\n\n")
        else:
            for reason, count in summary["by_reason"].items():
                f.write(f"* {reason}: {count}\n")
            f.write("\n")

        f.write("## Keys with anomalies\n\n")
        if not summary["by_key"]:
            f.write("No specific API keys stood out.\n\n")
        else:
            for key, reasons in summary["by_key"].items():
                f.write(f"### API key {key}\n\n")
                for r, c in reasons.items():
                    f.write(f"* {r}: {c} events\n")
                f.write("\n")

        f.write("## First few anomaly events\n\n")
        for a in sorted(anomalies, key=lambda x: x.ts)[:10]:
            f.write(f"* {a.ts.isoformat()} key `{a.api_key or '- '}` ip `{a.ip or '- '}` reason `{a.reason}`  details {a.details}\n")
        f.write("\n")

        f.write("## Narrative summary\n\n")
        if not anomalies:
            f.write("In this sample log the traffic looks fairly normal with the current simple heuristics. ")
            f.write("Request rates per key are moderate and there are no long streaks of failures.\n")
        else:
            f.write("The radar observed some potentially suspicious behaviour in this log. ")
            if "rate_spike" in summary["by_reason"]:
                f.write("At least one API key showed a sudden spike in request volume which might indicate scraping or a runaway client. ")
            if "id_enumeration" in summary["by_reason"]:
                f.write("There is also enumeration style activity against id based endpoints, suggesting someone or something is iterating through resource identifiers. ")
            if "repeated_failures_key" in summary["by_reason"] or "repeated_failures_ip" in summary["by_reason"]:
                f.write("Repeated authentication or rate limit failures were observed for some keys or IPs, which could mean broken integrations or probing.\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's API abuse radar")
    parser.add_argument("--log", required=True, help="Path to JSONL API log")
    parser.add_argument("--out-prefix", default="api_radar", help="Prefix for output files")
    args = parser.parse_args()

    entries = load_logs(args.log)
    rate_anoms = detect_rate_spikes(entries)
    enum_anoms = detect_enumeration(entries)
    fail_anoms = detect_failures(entries)

    all_anoms = rate_anoms + enum_anoms + fail_anoms
    all_anoms.sort(key=lambda a: a.ts)

    anomalies_path = f"{args.out_prefix}_api_anomalies.json"
    report_path = f"{args.out_prefix}_api_abuse_report.md"

    write_anomalies(all_anoms, anomalies_path)
    summary = summarise_anomalies(all_anoms)
    write_report(entries, all_anoms, summary, report_path)

    print(f"Wrote {len(all_anoms)} anomaly events to {anomalies_path}")
    print(f"Wrote report to {report_path}")


if __name__ == "__main__":
    main()
