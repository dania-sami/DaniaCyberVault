# Exposed Admin Panel Hunter

Hi, I am Dania Sami 👋

Admin panels are often:

- discovered by attackers using simple patterns
- left exposed without strong authentication
- forgotten after migrations

I built this **Exposed Admin Panel Hunter** as a careful, lightweight helper
for security reviews. It is NOT a brute force scanner, just a smart way to
check a small list of URLs for admin-like characteristics.

---

## What this tool does

1. **Takes a list of URLs**

   From command line or from `data/targets.txt` (one URL per line).

2. **Sends a single HTTP GET to each**

   Using `requests` with a friendly timeout and User-Agent.

3. **Looks for admin-like patterns**

   It inspects:

   - URL path (contains `/admin`, `/manage`, `/dashboard`, etc.)
   - HTML `<title>` content
   - presence of `login` forms or the word "admin"

4. **Prints a small report**

   For each URL it prints:

   - status code
   - detected "signals"
   - an overall `LIKELY_ADMIN`, `MAYBE_ADMIN` or `UNLIKELY_ADMIN` label

---

## How to run

```bash
cd exposed_admin_panel_hunter

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt
```

### Scan a single URL

```bash
python -m src.scan --url https://example.com/admin
```

### Scan a list from file

Edit `data/targets.txt`, then:

```bash
python -m src.scan --file data/targets.txt
```

---

## Project structure

```text
exposed_admin_panel_hunter/
  ├─ README.md
  ├─ requirements.txt
  ├─ data/
  │    └─ targets.txt
  └─ src/
       ├─ __init__.py
       └─ scan.py
```

---

## Why I built this

This project gives me a concrete way to discuss:

- common discovery techniques for admin panels
- why "security by obscurity" is not enough
- how to create safe, polite tools for security assessments
