from __future__ import annotations

import argparse
import re
from typing import List

import requests


def analyze_response(url: str, text: str, status: int) -> None:
    signals: List[str] = []

    path = url.lower()
    if any(p in path for p in ["/admin", "/manage", "/dashboard", "/cpanel"]):
        signals.append("admin-looking path")

    title_match = re.search(r"<title>(.*?)</title>", text, re.IGNORECASE | re.DOTALL)
    title = title_match.group(1).strip() if title_match else ""

    if "admin" in title.lower():
        signals.append("title mentions admin")
    if re.search(r"login", text, re.IGNORECASE):
        signals.append("login form or login text found")

    if status in (401, 403):
        signals.append(f"HTTP {status} (auth required)")

    if "admin" in path and status == 200:
        label = "LIKELY_ADMIN"
    elif signals:
        label = "MAYBE_ADMIN"
    else:
        label = "UNLIKELY_ADMIN"

    print(f"URL: {url}")
    print(f"  Status: {status}")
    print(f"  Title: {title!r}")
    print(f"  Signals: {', '.join(signals) if signals else 'none'}")
    print(f"  Verdict: {label}")
    print()


def scan_url(url: str) -> None:
    try:
        resp = requests.get(url, timeout=10)
    except Exception as e:
        print(f"URL: {url}")
        print(f"  ERROR: {e}")
        print()
        return
    analyze_response(url, resp.text, resp.status_code)


def main() -> None:
    parser = argparse.ArgumentParser(description="Exposed admin panel hunter")
    parser.add_argument("--url", type=str, help="Single URL to scan")
    parser.add_argument("--file", type=str, help="File with URLs")
    args = parser.parse_args()

    urls: List[str] = []
    if args.url:
        urls.append(args.url)
    if args.file:
        with open(args.file, "r", encoding="utf-8") as f:
            for line in f:
                u = line.strip()
                if u:
                    urls.append(u)

    if not urls:
        print("No URLs provided. Use --url or --file.")
        return

    for u in urls:
        scan_url(u)


if __name__ == "__main__":
    main()
