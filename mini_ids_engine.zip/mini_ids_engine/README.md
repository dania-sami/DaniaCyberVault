
# Real Time Packet Inspection Engine (Mini IDS Lab)

Hi, I am Dania and I built this project to practise how intrusion detection systems think when they look at live network traffic.

Instead of just dumping packets, this project tries to behave like a tiny IDS:

- it extracts simple features from packets (per time window)
- it trains an anomaly detection model on “normal” traffic
- it runs a live monitor that flags windows that look unusual

It is a small, safe lab version of tools like Suricata or Snort, written in Python.

---

## What this project does

The lab has three main steps.

1. **Capture baseline traffic (safe / normal)**  
   A script uses `scapy` to sniff packets from an interface and aggregates them into rolling time windows (for example 10 seconds).  
   For each window it computes features like:
   - number of packets
   - unique destination IPs
   - unique destination ports
   - mean packet size
   - fraction of TCP vs UDP
   and saves everything to `data/baseline_windows.csv`.

2. **Train an anomaly detection model**  
   A training script reads `baseline_windows.csv`, scales the features and trains an `IsolationForest` model.  
   The model and scaler are saved into the `models/` folder.

3. **Run the mini IDS monitor**  
   A monitor script again uses `scapy` to sniff live traffic.  
   For every window it computes the same features, passes them to the trained model and prints a verdict:
   - Normal
   - Suspicious
   - Highly suspicious

This way I can experiment with behaviour-based network detection in a controlled way.

---

## Project structure

```text
mini_ids_engine/
  README.md
  requirements.txt
  capture_baseline.py   # capture and aggregate baseline windows
  train_model.py        # train anomaly detection model
  live_monitor.py       # run live IDS-style monitoring
  data/
  models/
```

---

## Installation

```bash
python3 -m venv venv
source venv/bin/activate           # Windows  venv\Scripts\activate
pip install -r requirements.txt
```

On Linux or macOS, `scapy` may require you to run the capture scripts with elevated privileges (for example `sudo`) to sniff on an interface.

---

## Step 1  Capture baseline traffic

Choose a network interface that normally has your regular traffic, for example:

- `eth0`
- `wlan0`
- `en0` on macOS

Then run:

```bash
sudo python capture_baseline.py --iface en0 --duration 120 --window 10
```

This example:

- listens for 120 seconds
- builds 10 second windows
- saves the feature table to `data/baseline_windows.csv`

You can inspect this CSV to see what the features look like.

---

## Step 2  Train the anomaly detection model

```bash
python train_model.py
```

This will:

- load `data/baseline_windows.csv`
- fit a scaler and an `IsolationForest` model
- print a small summary of the feature ranges
- save:
  - `models/scaler.joblib`
  - `models/model.joblib`

---

## Step 3  Run the live mini IDS monitor

```bash
sudo python live_monitor.py --iface en0 --window 10
```

The monitor will:

- continuously listen on the interface
- aggregate packets into `window` second windows
- compute the feature vector
- apply the anomaly model
- print output like:

```text
[info] Window starting 2026-02-02 13:45:10  packets=210  unique_dst_ips=12  score=0.08  verdict=Normal
[alert] Window starting 2026-02-02 13:45:20  packets=980  unique_dst_ips=1   score=0.92  verdict=Highly suspicious
```

The anomaly score is between 0 and 1, where higher values indicate more unusual behaviour compared to your baseline.

---

## Features used in the model

Each time window is described by:

- `packet_count`
- `unique_dst_ips`
- `unique_dst_ports`
- `mean_packet_size`
- `tcp_fraction`
- `udp_fraction`

This is intentionally simple, but it shows the idea:
small windows of traffic can be turned into numerical features, and a model can then judge whether a new window “looks like” the baseline.

---

## How I see this project

I wanted a project that:

- touches real network packets (via `scapy`)
- feels like the beginning of an IDS
- and still stays small enough to read and extend

From here it would be natural to extend the engine with:

- per-host features instead of only global windows
- protocol specific breakdowns
- alert forwarding to a SIEM

For now, it works as a clear demonstration that I understand the basics of network feature extraction and anomaly-based detection.
