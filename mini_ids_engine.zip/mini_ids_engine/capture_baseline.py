
import argparse
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path

import pandas as pd
from scapy.all import sniff, IP, TCP, UDP  # type: ignore

DATA_DIR = Path("data")


def build_features(packets):
    packet_count = len(packets)
    if packet_count == 0:
        return {
            "packet_count": 0,
            "unique_dst_ips": 0,
            "unique_dst_ports": 0,
            "mean_packet_size": 0.0,
            "tcp_fraction": 0.0,
            "udp_fraction": 0.0,
        }

    dst_ips = set()
    dst_ports = set()
    sizes = []
    tcp_count = 0
    udp_count = 0

    for p in packets:
        sizes.append(len(p))
        if IP in p:
            dst_ips.add(p[IP].dst)
        if TCP in p:
            tcp_count += 1
            dst_ports.add(p[TCP].dport)
        elif UDP in p:
            udp_count += 1
            dst_ports.add(p[UDP].dport)

    mean_size = sum(sizes) / len(sizes)
    tcp_fraction = tcp_count / packet_count
    udp_fraction = udp_count / packet_count

    return {
        "packet_count": packet_count,
        "unique_dst_ips": len(dst_ips),
        "unique_dst_ports": len(dst_ports),
        "mean_packet_size": mean_size,
        "tcp_fraction": tcp_fraction,
        "udp_fraction": udp_fraction,
    }


def main():
    parser = argparse.ArgumentParser(description="Capture baseline traffic and build time window features")
    parser.add_argument("--iface", required=True, help="Network interface to sniff on (e.g. eth0, wlan0, en0)")
    parser.add_argument("--duration", type=int, default=120, help="Total capture duration in seconds (default 120)")
    parser.add_argument("--window", type=int, default=10, help="Window size in seconds (default 10)")
    args = parser.parse_args()

    DATA_DIR.mkdir(exist_ok=True)

    start_time = datetime.utcnow()
    end_time = start_time + timedelta(seconds=args.duration)
    window_size = timedelta(seconds=args.window)

    windows = defaultdict(list)

    def handle_packet(pkt):
        now = datetime.utcnow()
        if now > end_time:
            return False  # stop sniff
        # assign packet to window start
        window_index = int((now - start_time).total_seconds() // args.window)
        window_start = start_time + window_index * window_size
        windows[window_start].append(pkt)
        return True

    print(f"[info] Capturing on iface={args.iface} for {args.duration} seconds with window={args.window}s")
    sniff(iface=args.iface, prn=handle_packet, store=False, stop_filter=lambda x: datetime.utcnow() > end_time)

    rows = []
    for w_start in sorted(windows.keys()):
        feats = build_features(windows[w_start])
        row = {"window_start": w_start.isoformat()}
        row.update(feats)
        rows.append(row)

    if not rows:
        print("[warn] No packets captured. Check interface name or permissions.")
        return

    df = pd.DataFrame(rows)
    out_path = DATA_DIR / "baseline_windows.csv"
    df.to_csv(out_path, index=False)
    print(f"[info] Wrote {len(df)} windows to {out_path}")


if __name__ == "__main__":
    main()
