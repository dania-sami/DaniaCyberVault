
from pathlib import Path

import joblib
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler

DATA_DIR = Path("data")
MODELS_DIR = Path("models")

FEATURE_COLS = [
    "packet_count",
    "unique_dst_ips",
    "unique_dst_ports",
    "mean_packet_size",
    "tcp_fraction",
    "udp_fraction",
]


def main():
    MODELS_DIR.mkdir(exist_ok=True)
    path = DATA_DIR / "baseline_windows.csv"
    if not path.is_file():
        raise SystemExit(f"Baseline file not found. Run capture_baseline.py first ({path}).")

    df = pd.read_csv(path)
    if df.empty:
        raise SystemExit("Baseline file is empty.")

    X = df[FEATURE_COLS].astype(float).values

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    model = IsolationForest(
        n_estimators=200,
        contamination=0.1,
        random_state=42,
    )
    model.fit(X_scaled)

    joblib.dump(scaler, MODELS_DIR / "scaler.joblib")
    joblib.dump(model, MODELS_DIR / "model.joblib")

    print(f"[info] Trained IsolationForest on {len(df)} windows")
    print(f"[info] Saved scaler to {MODELS_DIR / 'scaler.joblib'}")
    print(f"[info] Saved model to {MODELS_DIR / 'model.joblib'}")


if __name__ == "__main__":
    main()
