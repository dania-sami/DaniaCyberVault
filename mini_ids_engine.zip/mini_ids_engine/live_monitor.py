
import argparse
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path

import joblib
import pandas as pd
from scapy.all import sniff, IP, TCP, UDP  # type: ignore

MODELS_DIR = Path("models")

FEATURE_COLS = [
    "packet_count",
    "unique_dst_ips",
    "unique_dst_ports",
    "mean_packet_size",
    "tcp_fraction",
    "udp_fraction",
]


def build_features(packets):
    packet_count = len(packets)
    if packet_count == 0:
        return {
            "packet_count": 0,
            "unique_dst_ips": 0,
            "unique_dst_ports": 0,
            "mean_packet_size": 0.0,
            "tcp_fraction": 0.0,
            "udp_fraction": 0.0,
        }

    dst_ips = set()
    dst_ports = set()
    sizes = []
    tcp_count = 0
    udp_count = 0

    for p in packets:
        sizes.append(len(p))
        if IP in p:
            dst_ips.add(p[IP].dst)
        if TCP in p:
            tcp_count += 1
            dst_ports.add(p[TCP].dport)
        elif UDP in p:
            udp_count += 1
            dst_ports.add(p[UDP].dport)

    mean_size = sum(sizes) / len(sizes)
    tcp_fraction = tcp_count / packet_count
    udp_fraction = udp_count / packet_count

    return {
        "packet_count": packet_count,
        "unique_dst_ips": len(dst_ips),
        "unique_dst_ports": len(dst_ports),
        "mean_packet_size": mean_size,
        "tcp_fraction": tcp_fraction,
        "udp_fraction": udp_fraction,
    }


def verdict_from_score(score: float) -> str:
    if score < 0.4:
        return "Normal"
    if score < 0.7:
        return "Suspicious"
    return "Highly suspicious"


def main():
    parser = argparse.ArgumentParser(description="Mini IDS live monitor")
    parser.add_argument("--iface", required=True, help="Network interface to sniff on (e.g. eth0, wlan0, en0)")
    parser.add_argument("--window", type=int, default=10, help="Window size in seconds (default 10)")
    args = parser.parse_args()

    scaler_path = MODELS_DIR / "scaler.joblib"
    model_path = MODELS_DIR / "model.joblib"
    if not scaler_path.is_file() or not model_path.is_file():
        raise SystemExit("Model or scaler not found. Run train_model.py first.")

    scaler = joblib.load(scaler_path)
    model = joblib.load(model_path)

    window_size = timedelta(seconds=args.window)
    current_window_start = datetime.utcnow()
    current_packets = []

    print(f"[info] Starting live monitor on iface={args.iface} with window={args.window}s")

    def process_window(start_time, packets):
        feats = build_features(packets)
        df = pd.DataFrame([feats], columns=FEATURE_COLS)
        X_scaled = scaler.transform(df.values)
        # IsolationForest returns negative scores for anomalies; we normalise to 0..1
        raw = model.decision_function(X_scaled)[0]
        # map to 0..1 range (approx) by simple transform
        score = 1.0 / (1.0 + pow(2.71828, raw))  # sigmoid-like
        v = verdict_from_score(score)
        prefix = "[alert]" if v != "Normal" else "[info]"
        print(
            f"{prefix} Window starting {start_time}  packets={feats['packet_count']}  "
            f"unique_dst_ips={feats['unique_dst_ips']}  score={score:.2f}  verdict={v}"
        )

    def handle_packet(pkt):
        nonlocal current_window_start, current_packets
        now = datetime.utcnow()
        if now - current_window_start >= window_size:
            # process current window
            process_window(current_window_start, current_packets)
            current_window_start = now
            current_packets = []
        current_packets.append(pkt)

    sniff(iface=args.iface, prn=handle_packet, store=False)


if __name__ == "__main__":
    main()
