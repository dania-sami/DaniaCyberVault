
import argparse
from pathlib import Path
from typing import Dict, Any, List

import yaml
import pandas as pd

from rules import run_all_checks, Finding


def load_config(path: Path) -> Dict[str, Any]:
    if not path.is_file():
        raise SystemExit(f"Config file not found: {path}")
    with path.open("r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
    return data


def print_findings(findings: List[Finding]) -> None:
    if not findings:
        print("[info] No findings. Configuration looks clean for the current rules.")
        return

    for f in findings:
        prefix = "[warn]" if f.severity in ("High", "Medium") else "[info]"
        print(
            f"{prefix} [{f.resource_type}] {f.resource_name:<20} {f.message}"
        )


def write_findings_csv(findings: List[Finding], out_path: Path) -> None:
    out_path.parent.mkdir(exist_ok=True)
    rows = [
        {
            "resource_type": f.resource_type,
            "resource_name": f.resource_name,
            "severity": f.severity,
            "message": f.message,
        }
        for f in findings
    ]
    df = pd.DataFrame(rows)
    df.to_csv(out_path, index=False)
    print(f"[info] Findings written to {out_path} ({len(df)} rows)")


def main():
    parser = argparse.ArgumentParser(description="Cloud Security Posture Auditor (CSPM-lite)")
    parser.add_argument("config", help="Path to YAML configuration file")
    parser.add_argument(
        "--output",
        default="findings/findings.csv",
        help="Where to store findings CSV (default findings/findings.csv)",
    )
    args = parser.parse_args()

    config_path = Path(args.config)
    print(f"[info] Loaded configuration from {config_path}")
    cfg = load_config(config_path)

    print("[info] Running cloud posture checks...")
    findings = run_all_checks(cfg)
    print_findings(findings)
    if findings:
        write_findings_csv(findings, Path(args.output))


if __name__ == "__main__":
    main()
