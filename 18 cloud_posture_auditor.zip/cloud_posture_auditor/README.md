
# Cloud Security Posture Auditor (CSPM‑Lite)

Hi, I am Dania and I built this project to practise how cloud security posture management tools think.

Instead of only checking one thing, I wanted a small **end to end auditor** that can look at
a cloud style configuration file and tell me:

- which storage buckets are too open
- which security groups are too permissive
- which IAM users are missing basic protections
- which best practices are being ignored

It is not connected to a real cloud provider, but the logic is designed to feel realistic and easy to extend.

---

## What this project does

The tool reads a simple YAML file that describes a “cloud environment” with

- storage buckets
- security groups
- IAM users

Then it runs a set of rules and prints findings such as

- “public bucket without encryption”
- “security group allows 0.0.0.0/0 on port 22”
- “IAM user without MFA enabled”

It also writes all findings to a CSV file so they can be filtered or imported elsewhere.

This is my CSPM‑lite project to show how I think about cloud misconfigurations and best practices.

---

## Project structure

```text
cloud_posture_auditor/
  README.md
  requirements.txt
  sample_config.yaml
  rules.py          # individual checks
  audit.py          # main CLI entry point
  findings/         # generated reports
```

---

## Installation

```bash
python3 -m venv venv
source venv/bin/activate           # Windows  venv\Scripts\activate
pip install -r requirements.txt
```

---

## Quick start with the sample config

I included a small demo configuration file: `sample_config.yaml`

You can run the auditor like this:

```bash
python audit.py sample_config.yaml
```

Example output:

```text
[info] Loaded configuration from sample_config.yaml
[info] Running cloud posture checks...
[warn] [BUCKET] bucket public-logs      public bucket has public_read enabled
[warn] [BUCKET] bucket public-logs      public bucket without default encryption enabled
[warn] [SG]     sg web-open-sg          allows 0.0.0.0/0 on port 22
[info] [SG]     sg internal-only-sg     rules look acceptable
[warn] [IAM]    user legacy-admin       user has console access but no MFA enabled
[info] Findings written to findings/findings.csv (5 rows)
```

All findings are saved to `findings/findings.csv` so I can review them in more detail.

---

## Configuration model

The YAML configuration is kept intentionally simple and human readable.

```yaml
buckets:
  - name: public-logs
    public_read: true
    public_write: false
    encryption_enabled: false
    versioning_enabled: false

security_groups:
  - name: web-open-sg
    rules:
      - description: ssh from anywhere
        protocol: tcp
        port: 22
        cidr: 0.0.0.0/0
      - description: http
        protocol: tcp
        port: 80
        cidr: 0.0.0.0/0

iam_users:
  - username: legacy-admin
    console_access: true
    mfa_enabled: false
    access_keys:
      - active: true
        last_rotated_days_ago: 400
```

The auditor reads these structures and applies rules in `rules.py`.

---

## Checks implemented

Right now the CSPM‑lite includes the following rules:

### Buckets

- Flag buckets with any public access (`public_read` or `public_write` true)
- Flag public buckets that do not have encryption enabled
- Flag buckets without versioning (soft recommendation)

### Security groups

- Flag rules that allow `0.0.0.0/0` (world) on sensitive ports such as 22, 3389, 5432
- Flag “allow all” style rules where the CIDR is `0.0.0.0/0` and the port is `0` or `*`

### IAM users

- Flag users with console access but without MFA enabled
- Flag access keys older than 90 days
- Flag users with multiple active access keys

These are classic examples of misconfigurations that often show up in cloud security incidents, just modelled in a small YAML world.

---

## How I see this project

For me this project is a way to:

- practise writing security rules in clean Python
- think about real misconfigurations instead of only toy problems
- show interest in **cloud security, IAM design and least privilege**

The code is intentionally small and readable, and I can easily extend it with more rules as I keep learning.
