
from dataclasses import dataclass
from typing import List, Dict, Any


@dataclass
class Finding:
    resource_type: str
    resource_name: str
    severity: str
    message: str


SENSITIVE_PORTS = {22, 3389, 5432}


def check_buckets(config: Dict[str, Any]) -> List[Finding]:
    findings: List[Finding] = []
    for bucket in config.get("buckets", []):
        name = bucket.get("name", "<unnamed>")
        public_read = bool(bucket.get("public_read", False))
        public_write = bool(bucket.get("public_write", False))
        encryption_enabled = bool(bucket.get("encryption_enabled", False))
        versioning_enabled = bool(bucket.get("versioning_enabled", False))

        if public_read or public_write:
            findings.append(
                Finding(
                    resource_type="BUCKET",
                    resource_name=name,
                    severity="High",
                    message="bucket has public access enabled (read or write)",
                )
            )
            if not encryption_enabled:
                findings.append(
                    Finding(
                        resource_type="BUCKET",
                        resource_name=name,
                        severity="High",
                        message="public bucket without encryption enabled",
                    )
                )
        if not versioning_enabled:
            findings.append(
                Finding(
                    resource_type="BUCKET",
                    resource_name=name,
                    severity="Medium",
                    message="versioning is disabled; consider enabling for recovery",
                )
            )
    return findings


def check_security_groups(config: Dict[str, Any]) -> List[Finding]:
    findings: List[Finding] = []
    for sg in config.get("security_groups", []):
        name = sg.get("name", "<unnamed>")
        rules = sg.get("rules", [])
        for rule in rules:
            cidr = str(rule.get("cidr", ""))
            port = rule.get("port", 0)
            desc = rule.get("description", "")
            if cidr == "0.0.0.0/0":
                if port in SENSITIVE_PORTS:
                    findings.append(
                        Finding(
                            resource_type="SG",
                            resource_name=name,
                            severity="High",
                            message=f"allows 0.0.0.0/0 on sensitive port {port} ({desc})",
                        )
                    )
                elif port in (0, "*"):
                    findings.append(
                        Finding(
                            resource_type="SG",
                            resource_name=name,
                            severity="High",
                            message="allows 0.0.0.0/0 on all ports",
                        )
                    )
                else:
                    findings.append(
                        Finding(
                            resource_type="SG",
                            resource_name=name,
                            severity="Medium",
                            message=f"allows 0.0.0.0/0 on port {port} ({desc})",
                        )
                    )
    return findings


def check_iam_users(config: Dict[str, Any]) -> List[Finding]:
    findings: List[Finding] = []
    for user in config.get("iam_users", []):
        username = user.get("username", "<unnamed>")
        console_access = bool(user.get("console_access", False))
        mfa_enabled = bool(user.get("mfa_enabled", False))
        access_keys = user.get("access_keys", [])

        if console_access and not mfa_enabled:
            findings.append(
                Finding(
                    resource_type="IAM",
                    resource_name=username,
                    severity="High",
                    message="user has console access but no MFA enabled",
                )
            )

        active_keys = [k for k in access_keys if k.get("active", False)]
        if len(active_keys) > 1:
            findings.append(
                Finding(
                    resource_type="IAM",
                    resource_name=username,
                    severity="Medium",
                    message="user has multiple active access keys",
                )
            )
        for k in active_keys:
            age_days = int(k.get("last_rotated_days_ago", 0))
            if age_days > 90:
                findings.append(
                    Finding(
                        resource_type="IAM",
                        resource_name=username,
                        severity="Medium",
                        message=f"access key older than 90 days (age={age_days} days)",
                    )
                )

    return findings


def run_all_checks(config: Dict[str, Any]) -> List[Finding]:
    all_findings: List[Finding] = []
    all_findings.extend(check_buckets(config))
    all_findings.extend(check_security_groups(config))
    all_findings.extend(check_iam_users(config))
    return all_findings
