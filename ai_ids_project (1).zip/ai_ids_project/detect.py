
import argparse
from pathlib import Path

import joblib
import numpy as np
import pandas as pd


FEATURE_COLUMNS = ["duration", "src_bytes", "dst_bytes", "failed_logins"]


def load_model_and_scaler(model_path: Path, scaler_path: Path):
    if not model_path.exists():
        raise FileNotFoundError(f"Model file not found: {model_path}")
    if not scaler_path.exists():
        raise FileNotFoundError(f"Scaler file not found: {scaler_path}")
    model = joblib.load(model_path)
    scaler = joblib.load(scaler_path)
    return model, scaler


def detect_intrusions(input_csv: Path, model_path: Path, scaler_path: Path):
    model, scaler = load_model_and_scaler(model_path, scaler_path)

    if not input_csv.exists():
        raise FileNotFoundError(f"Input CSV not found: {input_csv}")

    data = pd.read_csv(input_csv)

    missing_cols = [c for c in FEATURE_COLUMNS if c not in data.columns]
    if missing_cols:
        raise ValueError(f"Input CSV is missing required columns: {missing_cols}")

    X = data[FEATURE_COLUMNS].astype(float)
    X_scaled = scaler.transform(X)

    # Predict probabilities if available
    if hasattr(model, "predict_proba"):
        proba = model.predict_proba(X_scaled)[:, 1]  # probability of class 1 (intrusion)
        preds = (proba >= 0.5).astype(int)
        risk_scores = proba
    else:
        preds = model.predict(X_scaled)
        # Map predictions to a dummy risk score (0 or 1)
        risk_scores = np.where(preds == 1, 0.9, 0.1)

    results = data.copy()
    results["prediction"] = preds
    results["risk_score"] = risk_scores

    # Print nice summary
    print(f"Analysing file: {input_csv}")
    print("-" * 60)
    for idx, row in results.iterrows():
        label = "INTRUSION" if row["prediction"] == 1 else "NORMAL"
        print(
            f"Row {idx:03d}: "
            f"duration={row['duration']:.1f}s, "
            f"src_bytes={row['src_bytes']:.0f}, "
            f"dst_bytes={row['dst_bytes']:.0f}, "
            f"failed_logins={row['failed_logins']:.0f} -> "
            f"{label} (risk={row['risk_score']:.2f})"
        )

    # Also save to CSV
    out_path = input_csv.parent / (input_csv.stem + "_with_predictions.csv")
    results.to_csv(out_path, index=False)
    print("-" * 60)
    print(f"Detailed results saved to: {out_path}")


def parse_args():
    parser = argparse.ArgumentParser(
        description="Simple AI powered Intrusion Detection on CSV traffic data."
    )
    parser.add_argument(
        "--input",
        type=str,
        required=True,
        help="Path to input CSV file with columns: duration, src_bytes, dst_bytes, failed_logins",
    )
    parser.add_argument(
        "--model",
        type=str,
        default="model.joblib",
        help="Path to trained model file (joblib).",
    )
    parser.add_argument(
        "--scaler",
        type=str,
        default="scaler.joblib",
        help="Path to trained scaler file (joblib).",
    )
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    detect_intrusions(Path(args.input), Path(args.model), Path(args.scaler))
