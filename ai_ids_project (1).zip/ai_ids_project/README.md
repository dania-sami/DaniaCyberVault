
# AI Powered Intrusion Detection System (IDS)

This is a **toy but fully working** AI powered Intrusion Detection System built in Python.
It simulates a small network intrusion detection pipeline using synthetic data.

The goal is to demonstrate:

- How to generate and preprocess network like data
- How to train a machine learning model for anomaly / intrusion detection
- How to save and load the trained model
- How to run a simple "real time like" detection script on CSV data

This project is designed to be easy to understand and extend so that you can
show it as a portfolio project for cybersecurity or AI related applications.

## Project structure

```text
ai_ids_project/
├── README.md
├── requirements.txt
├── train_model.py
├── detect.py
└── data/
    └── sample_traffic.csv
```

## Setup

1. Create and activate a virtual environment (recommended).

```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

2. Install dependencies.

```bash
pip install -r requirements.txt
```

3. Train the model (this will also generate synthetic training data).

```bash
python train_model.py
```

This will create:

- `model.joblib` – trained RandomForestClassifier
- `scaler.joblib` – StandardScaler for input features

4. Run detection on the sample data.

```bash
python detect.py --input data/sample_traffic.csv
```

You should see output with rows flagged as **NORMAL** or **INTRUSION** with a simple risk score.

## How it works (short overview)

1. **Synthetic data generation**  
   `train_model.py` generates synthetic "network traffic" data with 4 features:

   - `duration` – connection duration in seconds
   - `src_bytes` – bytes sent from source
   - `dst_bytes` – bytes sent from destination
   - `failed_logins` – number of failed login attempts

   It then labels some rows as *normal* and some as *intrusion* based on simple rules
   (for example many failed logins + high bytes = more likely intrusion).

2. **Model training**  
   We use:

   - `StandardScaler` to normalize features
   - `RandomForestClassifier` to learn the boundary between normal and attack traffic

3. **Detection script**  
   `detect.py`:

   - Loads the scaler and model
   - Reads a CSV file with the same 4 features
   - Outputs a prediction and simple risk score per row

## Extending this project

To make this project more impressive for applications:

- Replace the synthetic data with real network datasets (for example NSL-KDD or CICIDS)
- Add more features (protocol, flags, ports, service, etc)
- Create a small web dashboard (FastAPI + simple frontend) to visualize live alerts
- Log alerts to a file or database
- Add evaluation metrics (precision, recall, ROC curves)

## Disclaimer

This is a **learning and demonstration** project and is not intended to protect
real production environments. It is, however, a solid starting point for a
portfolio project in cybersecurity and AI.

