
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
import joblib
from pathlib import Path


RANDOM_STATE = 42


def generate_synthetic_data(n_samples: int = 5000) -> pd.DataFrame:
    """
    Generate synthetic 'network traffic' data for IDS training.

    Features:
    - duration (seconds)
    - src_bytes
    - dst_bytes
    - failed_logins
    """
    rng = np.random.default_rng(RANDOM_STATE)

    # Normal traffic
    normal_duration = rng.normal(loc=30, scale=10, size=n_samples)
    normal_src_bytes = rng.normal(loc=2000, scale=800, size=n_samples)
    normal_dst_bytes = rng.normal(loc=1800, scale=700, size=n_samples)
    normal_failed_logins = rng.poisson(lam=0.2, size=n_samples)

    # Intrusion traffic
    attack_duration = rng.normal(loc=120, scale=40, size=n_samples)
    attack_src_bytes = rng.normal(loc=10000, scale=4000, size=n_samples)
    attack_dst_bytes = rng.normal(loc=9000, scale=3500, size=n_samples)
    attack_failed_logins = rng.poisson(lam=4, size=n_samples)

    normal = pd.DataFrame({
        "duration": normal_duration,
        "src_bytes": normal_src_bytes,
        "dst_bytes": normal_dst_bytes,
        "failed_logins": normal_failed_logins,
        "label": 0,  # 0 = normal
    })

    attack = pd.DataFrame({
        "duration": attack_duration,
        "src_bytes": attack_src_bytes,
        "dst_bytes": attack_dst_bytes,
        "failed_logins": attack_failed_logins,
        "label": 1,  # 1 = intrusion
    })

    data = pd.concat([normal, attack], ignore_index=True)
    # Clean up any negative values
    for col in ["duration", "src_bytes", "dst_bytes", "failed_logins"]:
        data[col] = data[col].clip(lower=0)

    return data


def main():
    out_dir = Path(".")
    data = generate_synthetic_data()

    X = data[["duration", "src_bytes", "dst_bytes", "failed_logins"]]
    y = data["label"]

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y, test_size=0.2, random_state=RANDOM_STATE, stratify=y
    )

    model = RandomForestClassifier(
        n_estimators=200,
        max_depth=None,
        random_state=RANDOM_STATE,
        n_jobs=-1,
    )

    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    print("Classification report on synthetic validation data:")
    print(classification_report(y_test, y_pred, digits=4))

    # Save artefacts
    joblib.dump(model, out_dir / "model.joblib")
    joblib.dump(scaler, out_dir / "scaler.joblib")

    # Also save a small sample CSV for testing detection
    sample = generate_synthetic_data(n_samples=50)
    data_dir = out_dir / "data"
    data_dir.mkdir(exist_ok=True)
    sample.drop(columns=["label"]).to_csv(data_dir / "sample_traffic.csv", index=False)

    print("Model and scaler saved to model.joblib and scaler.joblib")
    print("Sample traffic data saved to data/sample_traffic.csv")


if __name__ == "__main__":
    main()
