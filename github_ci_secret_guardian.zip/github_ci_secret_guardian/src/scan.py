from __future__ import annotations

from pathlib import Path
from typing import List, Dict, Any

import yaml

BASE_DIR = Path(__file__).resolve().parent.parent
WF_DIR = BASE_DIR / ".github" / "workflows"


def load_workflows() -> List[Path]:
    if not WF_DIR.exists():
        return []
    return sorted([p for p in WF_DIR.glob("*.yml")] + [p for p in WF_DIR.glob("*.yaml")])


def check_unpinned_actions(step_uses: str) -> bool:
    # unpinned if there's no '@' or it uses '@master' / '@main'
    if "@" not in step_uses:
        return True
    ref = step_uses.split("@", 1)[1]
    if ref in ("master", "main", "latest"):
        return True
    return False


def scan_workflow(path: Path) -> List[str]:
    findings: List[str] = []
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
    except Exception as e:
        return [f"ERROR: failed to parse YAML: {e}"]

    if not isinstance(data, dict):
        return ["WARN: unexpected workflow structure"]

    # 1) Event: pull_request_target misuse
    on_sec = data.get("on") or data.get("events")
    if isinstance(on_sec, dict) and "pull_request_target" in on_sec:
        findings.append("Potentially risky use of pull_request_target (check permissions).")
    elif isinstance(on_sec, list) and "pull_request_target" in on_sec:
        findings.append("Potentially risky use of pull_request_target (check permissions).")

    jobs = data.get("jobs", {})
    if not isinstance(jobs, dict):
        return findings

    for job_id, job in jobs.items():
        if not isinstance(job, dict):
            continue

        # 2) env-level secrets hardcoded
        env = job.get("env", {})
        if isinstance(env, dict):
            for k, v in env.items():
                if isinstance(v, str) and "token" in v.lower() and "secrets." not in v.lower():
                    findings.append(
                        f"Job {job_id}: env var {k} looks like a hardcoded token ({v[:10]}...)."
                    )

        steps = job.get("steps", [])
        if not isinstance(steps, list):
            continue
        for step in steps:
            if not isinstance(step, dict):
                continue
            uses = step.get("uses")
            if isinstance(uses, str) and check_unpinned_actions(uses):
                findings.append(
                    f"Job {job_id}: step uses '{uses}' without a safe pinned version."
                )

            s_env = step.get("env", {})
            if isinstance(s_env, dict):
                for k, v in s_env.items():
                    if isinstance(v, str) and "token" in v.lower() and "secrets." not in v.lower():
                        findings.append(
                            f"Job {job_id}: step env {k} may contain a hardcoded token ({v[:10]}...)."
                        )
    return findings


def main() -> None:
    paths = load_workflows()
    if not paths:
        print("No workflows found in .github/workflows/")
        return

    print("GitHub CI Secret Exposure Guardian")
    for p in paths:
        print(f"\n=== {p} ===")
        findings = scan_workflow(p)
        if not findings:
            print("No obvious issues found.")
        else:
            for f in findings:
                print(f"- {f}")


if __name__ == "__main__":
    main()
