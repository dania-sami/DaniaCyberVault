# GitHub CI Secret Exposure Guardian

Hi, I am Dania 👋

This project is my **GitHub Actions risk scanner**:

- I parse `.github/workflows/*.yml`.
- I look for dangerous patterns like:
  - unpinned actions,
  - `pull_request_target` misuse,
  - suspicious hardcoded tokens in `env`.

It is a small but very practical demo of **CI/CD security hygiene**.

## How to run

```bash
cd github_ci_secret_guardian

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt

python -m src.scan
```

The scanner prints a readable report with findings per workflow file.
