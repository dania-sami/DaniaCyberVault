
# Anti-Tamper Mechanism Demonstrator (Sensor Logic Lab)

Hi, I am Dania and I built this project to think about **anti-tamper mechanisms** from the logic side.

I model a simple device with sensors:

- `lid_closed` (case switch)
- `light_level` (bright if opened)
- `voltage_ok` (supply within range)
- `temperature_ok` (no heat gun attack)

and then simulate different scenarios like normal use, case opening, drilling and power glitching.

A small rules engine decides when to raise a tamper alarm.

---

## What this project does

The main script is `anti_tamper.py`. It:

1. Defines a `DeviceState` with sensor values and derived flags
2. Provides four scenarios:

   - `normal` — everything stays within expected ranges
   - `lid_open` — lid sensor open + bright light
   - `drill_attack` — lid closed but light spikes and vibration pattern
   - `power_glitch` — rapid voltage fluctuations

3. Runs a detection function that:

   - triggers an alarm when conditions indicate tampering
   - prints a step by step log explaining why the alarm fired

---

## Project structure

```text
anti_tamper_lab/
  README.md
  requirements.txt     # empty, stdlib only
  anti_tamper.py
  data/
```

---

## Installation

```bash
python3 -m venv venv
source venv/bin/activate          # Windows  venv\Scripts\activate
pip install -r requirements.txt
```

---

## Usage

Run all scenarios:

```bash
python anti_tamper.py demo
```

Or a single one:

```bash
python anti_tamper.py normal
python anti_tamper.py lid_open
python anti_tamper.py drill_attack
python anti_tamper.py power_glitch
```

You will see logs like:

```text
[normal] tick 0  lid_closed=True light=10 voltage=3.3 temp=30  -> no alarm
...
[drill] tick 5  lid_closed=True light=200 voltage=3.3 temp=30  -> ALARM (unexpected light spike with lid closed)
```

---

## Why this project matters to me

Anti-tamper is usually presented as hardware only, but logic matters a lot.

With this project I can show that I:

- understand different tamper sensors and signals
- can model how they interact over time
- can design simple but meaningful detection rules

It’s a good starting point for talking about secure hardware modules and physical attack resistance.
