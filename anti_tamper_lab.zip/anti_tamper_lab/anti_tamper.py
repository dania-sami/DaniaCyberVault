
import argparse
from dataclasses import dataclass

@dataclass
class DeviceState:
    lid_closed: bool
    light_level: float
    voltage: float
    temperature: float

def detect_tamper(prev: DeviceState, current: DeviceState):
    reasons = []

    # lid open while environment is bright
    if not current.lid_closed and current.light_level > 50:
        reasons.append("lid opened and high light level")

    # sudden light spike while lid is supposedly closed
    if current.lid_closed and current.light_level > 150:
        reasons.append("sudden high light while lid closed")

    # voltage out of safe range
    if not (3.0 <= current.voltage <= 3.6):
        reasons.append("supply voltage out of range")

    # suspicious overtemperature
    if current.temperature > 70:
        reasons.append("device overheated")

    return reasons

def scenario_normal():
    print("=== Normal scenario ===")
    state = DeviceState(lid_closed=True, light_level=10, voltage=3.3, temperature=30)
    for t in range(5):
        reasons = detect_tamper(state, state)
        msg = f"[normal] tick {t}  lid_closed={state.lid_closed} light={state.light_level} voltage={state.voltage} temp={state.temperature}"
        if reasons:
            print(msg + "  -> ALARM " + "; ".join(reasons))
        else:
            print(msg + "  -> no alarm")
    print()

def scenario_lid_open():
    print("=== Lid open scenario ===")
    state = DeviceState(lid_closed=True, light_level=10, voltage=3.3, temperature=30)
    for t in range(5):
        if t == 2:
            state.lid_closed = False
            state.light_level = 120
        reasons = detect_tamper(state, state)
        msg = f"[lid_open] tick {t}  lid_closed={state.lid_closed} light={state.light_level} voltage={state.voltage} temp={state.temperature}"
        if reasons:
            print(msg + "  -> ALARM " + "; ".join(reasons))
        else:
            print(msg + "  -> no alarm")
    print()

def scenario_drill_attack():
    print("=== Drill attack scenario ===")
    state = DeviceState(lid_closed=True, light_level=10, voltage=3.3, temperature=30)
    for t in range(8):
        if t == 5:
            state.light_level = 200
        reasons = detect_tamper(state, state)
        msg = f"[drill] tick {t}  lid_closed={state.lid_closed} light={state.light_level} voltage={state.voltage} temp={state.temperature}"
        if reasons:
            print(msg + "  -> ALARM " + "; ".join(reasons))
        else:
            print(msg + "  -> no alarm")
    print()

def scenario_power_glitch():
    print("=== Power glitch scenario ===")
    state = DeviceState(lid_closed=True, light_level=10, voltage=3.3, temperature=30)
    voltages = [3.3, 3.3, 2.5, 3.8, 3.3]
    for t, v in enumerate(voltages):
        state.voltage = v
        reasons = detect_tamper(state, state)
        msg = f"[power] tick {t}  lid_closed={state.lid_closed} light={state.light_level} voltage={state.voltage} temp={state.temperature}"
        if reasons:
            print(msg + "  -> ALARM " + "; ".join(reasons))
        else:
            print(msg + "  -> no alarm")
    print()

def main():
    parser = argparse.ArgumentParser(description="Anti-tamper mechanism demonstrator")
    parser.add_argument("mode", choices=["demo", "normal", "lid_open", "drill_attack", "power_glitch"], help="Which scenario to run")
    args = parser.parse_args()

    if args.mode == "demo":
        scenario_normal()
        scenario_lid_open()
        scenario_drill_attack()
        scenario_power_glitch()
    elif args.mode == "normal":
        scenario_normal()
    elif args.mode == "lid_open":
        scenario_lid_open()
    elif args.mode == "drill_attack":
        scenario_drill_attack()
    elif args.mode == "power_glitch":
        scenario_power_glitch()

if __name__ == "__main__":
    main()
