import argparse
import csv
from urllib.parse import urlparse
from collections import Counter

CATEGORY_MAP = {
    "github.com": "dev",
    "stackoverflow.com": "dev",
    "example.com": "work",
    "linkedin.com": "work",
    "twitter.com": "social",
    "facebook.com": "social",
    "youtube.com": "social",
}

def categorize_domain(domain: str) -> str:
    return CATEGORY_MAP.get(domain, "unknown")

def analyse(path: str):
    cat_counter = Counter()
    with open(path, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            url = row.get("url", "")
            if not url:
                continue
            parsed = urlparse(url)
            domain = parsed.hostname or ""
            if not domain:
                continue
            cat = categorize_domain(domain)
            cat_counter[cat] += 1

    print(f"[+] Categories for {path}:")
    for cat, count in cat_counter.most_common():
        print(f"    {cat}: {count}")

def main():
    parser = argparse.ArgumentParser(description="Browser History Domain Categorizer by Dania")
    parser.add_argument("--csv", required=True, help="Path to CSV browser history export")
    args = parser.parse_args()
    analyse(args.csv)

if __name__ == "__main__":
    main()
