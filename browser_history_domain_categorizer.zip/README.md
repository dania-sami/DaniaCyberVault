# Browser History Domain Categorizer

This little tool is something I use to think about user behaviour and security awareness.

It does not read a browser database directly. Instead, it takes a CSV export with:

- `timestamp`
- `url`

The script extracts the domain and categorises it into simple buckets like:

- `work`
- `social`
- `dev`
- `unknown`

based on a small local mapping.

## Files

- `history_categorizer.py` – main script
- `demo_history.csv` – example history

## Usage

```bash
python history_categorizer.py --csv demo_history.csv
```
