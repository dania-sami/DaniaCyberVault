"""
SOC Memory Timeline Generator – Dania

Reads JSONL events and produces per-host timelines.
"""

import argparse
import json
from dataclasses import dataclass
from datetime import datetime
from typing import List, Dict

TS_FORMAT = "%Y-%m-%dT%H:%M:%S"


@dataclass
class Event:
    ts: str
    host: str
    category: str
    detail: str


def parse_ts(ts: str) -> datetime:
    return datetime.strptime(ts, TS_FORMAT)


def load_events(path: str) -> List[Event]:
    events: List[Event] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            events.append(
                Event(
                    ts=obj["ts"],
                    host=obj.get("host", "unknown"),
                    category=obj.get("category", "other"),
                    detail=obj.get("detail", ""),
                )
            )
    events.sort(key=lambda e: e.ts)
    return events


def build_timelines(events: List[Event]) -> Dict[str, List[Event]]:
    by_host: Dict[str, List[Event]] = {}
    for e in events:
        by_host.setdefault(e.host, []).append(e)
    for host, evs in by_host.items():
        evs.sort(key=lambda e: e.ts)
    return by_host


def write_markdown(timelines: Dict[str, List[Event]], path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        f.write("# SOC memory timelines\n\n")
        for host, evs in sorted(timelines.items()):
            f.write(f"## Host {host}\n\n")
            if not evs:
                f.write("No events.\n\n")
                continue
            for e in evs:
                f.write(f"- {e.ts}  [{e.category}]  {e.detail}\n")
            f.write("\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's SOC memory timeline generator")
    parser.add_argument("--events", default="example_events.jsonl", help="Events in JSONL format")
    parser.add_argument("--out", default="timelines.md", help="Output Markdown file")
    args = parser.parse_args()

    events = load_events(args.events)
    timelines = build_timelines(events)
    write_markdown(timelines, args.out)
    print(f"Wrote timelines for {len(timelines)} hosts to {args.out}")


if __name__ == "__main__":
    main()
