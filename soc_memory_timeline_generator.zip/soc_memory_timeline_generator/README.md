# SOC Memory Timeline Generator – Dania

Hi

I am Dania and this tool builds a clean narrative timeline per host for an investigation

It takes JSONL events and sorts them into

* minute by minute lines per host
* grouped categories like auth  process  network

This helps me train how to turn raw event streams into the kind of story a SOC would present in a retrospective
