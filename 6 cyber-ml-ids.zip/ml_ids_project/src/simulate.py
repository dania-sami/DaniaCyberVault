from __future__ import annotations

import time

import joblib
import pandas as pd

from .config import MODEL_FILE, SAMPLE_DATA_FILE


def main() -> None:
    if not MODEL_FILE.exists():
        raise SystemExit(
            f"Model file not found at {MODEL_FILE}. Run 'python -m src.train' first."
        )

    model = joblib.load(MODEL_FILE)
    df = pd.read_csv(SAMPLE_DATA_FILE)

    print("Simulating incoming network events...\n")
    for i, row in df.sample(frac=1.0, random_state=42).iterrows():
        features = row.drop(labels=["label"])
        true_label = row["label"]
        pred = model.predict([features.values])[0]
        proba = model.predict_proba([features.values])[0].max()

        print(
            f"Event {i:03d} | Predicted: {pred:7s} | True: {true_label:7s} | Confidence: {proba:.2f}"
        )
        time.sleep(0.4)


if __name__ == "__main__":
    main()
