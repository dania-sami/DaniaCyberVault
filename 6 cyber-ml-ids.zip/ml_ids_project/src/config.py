from pathlib import Path

# Base project paths
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
MODEL_DIR = BASE_DIR / "models"
REPORT_DIR = BASE_DIR / "reports"

# Files
SAMPLE_DATA_FILE = DATA_DIR / "sample_network_traffic.csv"
MODEL_FILE = MODEL_DIR / "ids_model.joblib"
METRICS_FILE = MODEL_DIR / "metrics.txt"
