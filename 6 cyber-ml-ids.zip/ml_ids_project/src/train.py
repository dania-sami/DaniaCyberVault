from __future__ import annotations

from pathlib import Path

import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from .config import MODEL_DIR, MODEL_FILE, METRICS_FILE
from .data_loader import train_test_split_data


def build_model() -> Pipeline:
    """Create a simple ML pipeline for intrusion detection.

    For simplicity we use:
    - StandardScaler for feature scaling
    - RandomForestClassifier for classification

    This can easily be replaced with more advanced models later.
    """
    clf = Pipeline(
        steps=[
            ("scaler", StandardScaler()),
            ("rf", RandomForestClassifier(n_estimators=150, random_state=42)),
        ]
    )
    return clf


def main() -> None:
    MODEL_DIR.mkdir(parents=True, exist_ok=True)

    X_train, X_test, y_train, y_test = train_test_split_data()

    model = build_model()
    model.fit(X_train, y_train)

    # Save the model
    joblib.dump(model, MODEL_FILE)

    # Create and save a small text report on the training + validation split
    y_pred = model.predict(X_test)
    report = classification_report(y_test, y_pred)
    METRICS_FILE.write_text("Training / validation report\n" + report)

    print("Model trained and saved to:", MODEL_FILE)
    print("Metrics saved to:", METRICS_FILE)


if __name__ == "__main__":
    main()
