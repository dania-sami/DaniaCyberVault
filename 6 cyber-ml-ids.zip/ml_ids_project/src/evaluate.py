from __future__ import annotations

import joblib
from sklearn.metrics import classification_report

from .config import MODEL_FILE
from .data_loader import train_test_split_data


def main() -> None:
    if not MODEL_FILE.exists():
        raise SystemExit(
            f"Model file not found at {MODEL_FILE}. Run 'python -m src.train' first."
        )

    model = joblib.load(MODEL_FILE)
    X_train, X_test, y_train, y_test = train_test_split_data()

    y_pred = model.predict(X_test)
    print("\nEvaluation on held out test data:\n")
    print(classification_report(y_test, y_pred))


if __name__ == "__main__":
    main()
