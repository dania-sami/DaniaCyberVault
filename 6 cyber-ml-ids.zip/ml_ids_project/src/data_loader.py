from __future__ import annotations

from typing import Tuple

import pandas as pd
from sklearn.model_selection import train_test_split

from .config import SAMPLE_DATA_FILE


TARGET_COL = "label"


def load_data(path: str | None = None) -> pd.DataFrame:
    """Load the sample network traffic dataset.

    You can replace this with a loader for a real security dataset later.
    """
    csv_path = SAMPLE_DATA_FILE if path is None else path
    df = pd.read_csv(csv_path)
    return df


def train_test_split_data(
    test_size: float = 0.2, random_state: int = 42
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.Series, pd.Series]:
    """Return X_train, X_test, y_train, y_test."""
    df = load_data()
    X = df.drop(columns=[TARGET_COL])
    y = df[TARGET_COL]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )
    return X_train, X_test, y_train, y_test
