# Minimal ML Intrusion Detection System (IDS)

This is a small but impressive end to end **Machine Learning based Intrusion Detection System (IDS)** project.

It shows how to:
- Prepare simple network like features
- Train a Machine Learning model to classify traffic as **normal** or **attack**
- Evaluate the model and save the results
- Run a tiny "live" simulation using the trained model

The goal is to be:
- Easy to read for recruiters and universities
- Simple to run on any laptop
- A good base that you can extend with real security datasets later

## Quick start

```bash
# 1. Create and activate a virtual environment (optional but recommended)
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Train the IDS model on the sample data
python -m src.train

# 4. Evaluate on the test split
python -m src.evaluate

# 5. Run a simple live style simulation
python -m src.simulate
```

## Project structure

- `src/`
  - `train.py`  train a Random Forest classifier on sample traffic data
  - `evaluate.py`  evaluate the model and print metrics
  - `simulate.py`  simulate incoming traffic and show predictions
  - `data_loader.py`  helper functions for loading and splitting data
  - `config.py`  paths and constants
- `data/sample_network_traffic.csv`  tiny demo dataset included in the repo
- `models/`  saved model and metrics after training
- `reports/`  place for any extra figures or documentation you create

## How to extend this project

To make this project even more impressive you can:

- Replace the sample dataset with a real IDS dataset
  (for example NSL KDD or CIC IDS) and update the loader
- Add more features  protocol type, service, flags, counts, etc.
- Add a small dashboard (Streamlit or Flask) to visualize alerts
- Log metrics and experiments using MLflow or Weights and Biases

This repository is intentionally clean and simple so that someone
reviewing your GitHub profile can quickly understand your thinking,
see your code quality, and imagine how you would scale it up in a real
security environment.
