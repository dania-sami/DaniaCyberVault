# Attack Replay Lab from Incident Stories  Dania s cloud misconfiguration studio

Hi

I am Dania and this project is my small attack replay lab for cloud incidents

I read a lot of threat reports and case studies and many of them start with something like
a misconfigured firewall or an over permissive key
I wanted a safe way to walk through those stories step by step
without touching any real production systems

So this lab does not launch any real infrastructure
Instead it uses

* small infrastructure as code style snippets as examples
* a scenario file that describes the attack path at a high level
* a guide script that shows how different hardening steps would break that path

The focus is learning and explanation
not exploitation

## Structure of the lab

The repository contains

* `scenarios.json`
  * a few sample stories based on common patterns
    * open firewall leads to cryptojacking
    * public storage bucket and data exposure
    * over permissive key used for data download
* `templates`
  * tiny IaC like snippets that represent the misconfigured and fixed versions
  * these are only text examples for discussion
* `lab_guide.py`
  * reads a scenario
  * prints the attacker path step by step
  * simulates applying hardening controls
  * shows which step each control would break

No cloud account is required
The output is just text

## Included scenarios

Right now I include three synthetic but realistic stories

1  `cryptojacking_open_sg`

   * inbound SSH or management port exposed to the entire internet
   * weak default image and no monitoring
   * attacker drops miner and uses compute resources

   Controls you can toggle in the lab

   * restrict source ranges on the security group
   * require key based auth and strong images
   * collect and alert on unusual CPU spikes

2  `public_bucket_data_leak`

   * storage bucket set to public read
   * internal documents stored there by mistake
   * search engines or scanners discover the content

   Controls

   * block public access at the account level
   * use access policies that limit to trusted identities
   * add scanning and labels for sensitive documents

3  `overprivileged_iam_key`

   * long lived access key with wild card permissions
   * key accidentally leaked in a public repository
   * attacker uses it to list and download data

   Controls

   * least privilege policy instead of star actions
   * short lived credentials and rotation
   * detection of leaked keys and anomaly based usage alerts

The lab describes these paths in JSON
and the guide script turns them into a readable story

## How I run it

From the project root

1 optional create a virtual environment

       python -m venv venv
       source venv_bin_activate

2 install requirements

       pip install -r requirements.txt

3 list scenarios

       python lab_guide.py --list

4 replay one scenario  for example the cryptojacking case

       python lab_guide.py --scenario cryptojacking_open_sg

This prints

* the attack path as a numbered list
* the initial misconfiguration
* a set of candidate controls
* a simple simulation that shows

  * what happens with no controls
  * what happens if you enable one control
  * what happens if you combine them

The idea is to ask

* which control is the cheapest and most effective
* which ones are defence in depth versus core fixes
* how quickly we could realistically apply them in a real environment

## Why I built this

I wanted something that lives between slides and real cloud labs

With this project I can

* show that I read and understand cloud threat reports
* turn them into simple attack path descriptions
* reason about which configuration changes actually break the path
* talk through detection ideas without needing a full SIEM

Because everything is expressed as data and plain Python
it is very easy to extend

For example I can add a new scenario from a fresh report
write a tiny template
and then use the same guide engine to explore it
