"""
Attack Replay Lab from Incident Stories

Safe high level replay of cloud incident paths
and simple reasoning about which controls would block which step
"""

import argparse
import json
import os
from typing import Dict, List


def load_scenarios(base_dir: str) -> Dict[str, dict]:
    path = os.path.join(base_dir, "scenarios.json")
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return {s["id"]: s for s in data.get("scenarios", [])}


def print_scenario(s: dict) -> None:
    print("")
    print("Scenario title:", s["title"])
    print("")
    print("Misconfiguration summary:")
    print(" ", s["misconfig_summary"])
    print("")
    print("Attack path steps:")
    for idx, step in enumerate(s["steps"], start=1):
        print(f" {idx}. {step}")
    print("")
    print("Candidate controls:")
    for c in s["controls"]:
        print(f" - {c['id']}: {c['description']}  (breaks step {c['breaks_step']})")
    print("")


def simulate_controls(s: dict, control_ids: List[str]) -> None:
    steps = s["steps"]
    controls = {c["id"]: c for c in s["controls"]}
    blocked_steps = set()

    for cid in control_ids:
        c = controls.get(cid)
        if not c:
            continue
        blocked_steps.add(c["breaks_step"])

    print("Simulation with controls:", ", ".join(control_ids) if control_ids else "none")
    print("")
    for idx, step in enumerate(steps, start=1):
        marker = ""
        for c in controls.values():
            if c["breaks_step"] == idx and c["id"] in control_ids:
                marker = f"(blocked by {c['id']})"
                break
        print(f" Step {idx}: {step} {marker}")
        if marker:
            print("  Path stops here in this simulation.")
            break
    print("")


def main() -> None:
    base_dir = os.path.dirname(os.path.abspath(__file__))
    scenarios = load_scenarios(base_dir)

    parser = argparse.ArgumentParser(description="Dania s attack replay lab guide")
    parser.add_argument("--list", action="store_true", help="List available scenarios")
    parser.add_argument("--scenario", help="Scenario id to replay")
    parser.add_argument("--controls", nargs="*", help="Control ids to apply in the simulation")
    args = parser.parse_args()

    if args.list:
        print("Available scenarios:")
        for sid, s in scenarios.items():
            print(f" - {sid}: {s['title']}")
        return

    if not args.scenario:
        parser.error("Please provide --scenario or --list")

    if args.scenario not in scenarios:
        print(f"Unknown scenario id {args.scenario}")
        print("Use --list to see options.")
        return

    s = scenarios[args.scenario]
    print_scenario(s)
    simulate_controls(s, args.controls or [])


if __name__ == "__main__":
    main()
