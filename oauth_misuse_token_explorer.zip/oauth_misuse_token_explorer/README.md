# OAuth Misuse and Token Leakage Explorer

Hi, I am Dania 👋

This project is my **OAuth misuse and token leakage explorer**:

- I model different OAuth flows and client configs in a JSON "playground".
- I flag common mistakes:
  - implicit flow used by public clients with long-lived tokens,
  - access tokens in URLs,
  - over-scoped tokens on low-sensitivity apps.

It is a small but sharp way to reason about **real-world OAuth risks**.

## How to run

```bash
cd oauth_misuse_token_explorer

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt   # stdlib only

python -m src.analyse --cases data/oauth_cases.json
```

The tool prints each client, its issues, and a short risk summary.
