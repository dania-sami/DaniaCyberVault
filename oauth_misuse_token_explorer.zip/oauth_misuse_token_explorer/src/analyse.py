from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import List, Dict, Any


@dataclass
class OAuthCase:
    client_id: str
    flow: str
    app_type: str
    scopes: List[str]
    token_in_url: bool
    token_lifetime_minutes: int


def load_cases(path: Path) -> List[OAuthCase]:
    raw = json.loads(path.read_text(encoding="utf-8"))
    cases: List[OAuthCase] = []
    for c in raw.get("cases", []):
        cases.append(
            OAuthCase(
                client_id=c["client_id"],
                flow=c["flow"],
                app_type=c["app_type"],
                scopes=list(c.get("scopes", [])),
                token_in_url=bool(c.get("token_in_url", False)),
                token_lifetime_minutes=int(c.get("token_lifetime_minutes", 60)),
            )
        )
    return cases


def analyse_case(case: OAuthCase) -> List[str]:
    issues: List[str] = []

    high_value_scopes = {"payments:write", "admin:all", "accounts:read", "openid", "offline_access"}
    sensitive = any(s in high_value_scopes for s in case.scopes)

    if case.flow == "implicit" and case.app_type in ("spa", "mobile"):
        if case.token_lifetime_minutes > 30:
            issues.append(
                "Implicit flow with long-lived token for public client (prefer PKCE + short-lived code flow)."
            )

    if case.token_in_url:
        issues.append("Access token present in URL (risk of logs, referrer and history leaks).")

    if sensitive and len(case.scopes) > 3:
        issues.append("Over-scoped token for sensitive operations (narrow the scopes).")

    if not issues:
        issues.append("No major misuses detected with current rules.")

    return issues


def risk_level(issues: List[str]) -> str:
    if any("Access token present in URL" in i for i in issues):
        return "HIGH"
    if any("Implicit flow" in i for i in issues):
        return "MEDIUM"
    if any("Over-scoped" in i for i in issues):
        return "MEDIUM"
    return "LOW"


def main() -> None:
    parser = argparse.ArgumentParser(description="OAuth Misuse and Token Leakage Explorer")
    parser.add_argument("--cases", type=str, required=True, help="Path to oauth_cases.json")
    args = parser.parse_args()

    path = Path(args.cases)
    if not path.exists():
        print(f"Cases file not found: {path}")
        return

    cases = load_cases(path)
    print("OAuth Misuse and Token Leakage Report")
    print("====================================\n")

    for c in cases:
        issues = analyse_case(c)
        level = risk_level(issues)
        print(f"Client: {c.client_id}")
        print(f"  flow={c.flow}, app_type={c.app_type}, scopes={c.scopes}, "
              f"token_in_url={c.token_in_url}, token_lifetime_minutes={c.token_lifetime_minutes}")
        print(f"  risk_level={level}")
        print("  issues:")
        for i in issues:
            print(f"    - {i}")
        print()


if __name__ == "__main__":
    main()
