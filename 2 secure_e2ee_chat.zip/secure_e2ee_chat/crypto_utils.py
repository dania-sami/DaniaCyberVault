
import os
from dataclasses import dataclass
from typing import Tuple

from cryptography.hazmat.primitives.asymmetric import x25519
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM


HKDF_INFO = b"secure-e2ee-chat"
AES_KEY_SIZE = 32  # 256 bits
NONCE_SIZE = 12    # 96 bits, recommended for AES GCM


@dataclass
class KeyPair:
    private_key: x25519.X25519PrivateKey
    public_bytes: bytes


def generate_key_pair() -> KeyPair:
    """Generate an ephemeral X25519 key pair."""
    private_key = x25519.X25519PrivateKey.generate()
    public_key = private_key.public_key()
    public_bytes = public_key.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    return KeyPair(private_key=private_key, public_bytes=public_bytes)


def derive_shared_key(
    my_private_key: x25519.X25519PrivateKey,
    peer_public_bytes: bytes,
) -> bytes:
    """Derive a shared symmetric key using X25519 + HKDF."""
    peer_public_key = x25519.X25519PublicKey.from_public_bytes(peer_public_bytes)
    shared_secret = my_private_key.exchange(peer_public_key)

    hkdf = HKDF(
        algorithm=hashes.SHA256(),
        length=AES_KEY_SIZE,
        salt=None,
        info=HKDF_INFO,
    )
    key = hkdf.derive(shared_secret)
    return key


def create_aesgcm(key: bytes) -> AESGCM:
    if len(key) != AES_KEY_SIZE:
        raise ValueError(f"AES key must be {AES_KEY_SIZE} bytes")  # noqa: E501
    return AESGCM(key)


def encrypt(aesgcm: AESGCM, plaintext: str) -> Tuple[bytes, bytes]:
    """Encrypt a UTF 8 string and return (nonce, ciphertext)."""
    nonce = os.urandom(NONCE_SIZE)
    ciphertext = aesgcm.encrypt(nonce, plaintext.encode("utf-8"), None)
    return nonce, ciphertext


def decrypt(aesgcm: AESGCM, nonce: bytes, ciphertext: bytes) -> str:
    """Decrypt and return a UTF 8 string."""
    plaintext = aesgcm.decrypt(nonce, ciphertext, None)
    return plaintext.decode("utf-8")


# Delayed import to avoid circular requirement while typing above
from cryptography.hazmat.primitives import serialization  # noqa: E402
