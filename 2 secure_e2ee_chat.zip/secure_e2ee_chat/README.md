
# Secure End to End Encrypted Chat

This project is a **simple but realistic secure chat system** that uses modern cryptography
to provide **end to end encrypted (E2EE) messaging** between two terminals on the same network.

It is designed as a learning and portfolio project to show genuine enthusiasm for
cyber security, especially for topics like **key exchange, symmetric encryption,
and secure protocol design**.

---

## What this project demonstrates

- Ephemeral **Diffie–Hellman key exchange** using X25519
- Deriving a shared secret key with **HKDF**
- Using **AES GCM** for authenticated encryption (confidentiality + integrity)
- A minimal custom protocol for sending encrypted messages over TCP sockets
- A clear separation between:
  - cryptographic operations
  - network communication
  - simple command line user interface

The goal is not to build a production ready messaging app, but to show that I
can understand and implement the *building blocks* of secure communication.

---

## Project structure

```text
secure_e2ee_chat/
├── README.md
├── requirements.txt
├── crypto_utils.py
├── server.py
└── client.py
```

- `crypto_utils.py` – small wrapper around cryptographic primitives
- `server.py` – starts a TCP server, performs key exchange, and runs encrypted chat
- `client.py` – connects to the server and joins the encrypted chat

Both sides perform a fresh key exchange each time a connection is established.
The shared key is never written to disk.

---

## Installation

Create and activate a virtual environment (recommended).

```bash
python3 -m venv venv
source venv/bin/activate        # On Windows: venv\Scripts\activate
```

Install the dependencies:

```bash
pip install -r requirements.txt
```

---

## How to run the secure chat

You need **two terminals** (two windows or two tabs) on the same machine,
or two machines on the same network.

### 1. Start the secure server

In the first terminal, run:

```bash
python server.py
```

By default it listens on `127.0.0.1` port `5000`. You can change the host/port:

```bash
python server.py --host 0.0.0.0 --port 5000
```

The server will wait for a client to connect and then perform a key exchange.
You will see messages like:

```text
[crypto] Generated ephemeral X25519 key pair
[crypto] Shared secret derived successfully
[server] Secure session established. You can start chatting.
```

### 2. Connect with the client

In the second terminal, run:

```bash
python client.py
```

If you changed the host/port for the server, use the same here:

```bash
python client.py --host 127.0.0.1 --port 5000
```

After the key exchange, both sides now share the **same secret key**, and all
messages are encrypted and authenticated with AES GCM.

You can now type messages in each terminal. Examples:

- Anything you type in the server window is encrypted and sent to the client
- Anything you type in the client window is encrypted and sent to the server

You will see logs similar to:

```text
[send] -> ciphertext length: 128 bytes
[recv] <- decrypted message: hello, this is encrypted!
```

To exit, press `Ctrl+C` in both terminals.

---

## Cryptographic design (high level)

This project uses well established, modern primitives from the Python
`cryptography` library:

1. **Key exchange**
   - Each side generates an ephemeral X25519 key pair
   - They exchange public keys over the TCP connection
   - Each side computes the same 32 byte shared secret

2. **Key derivation**
   - The raw shared secret is passed into HKDF (HMAC based Key Derivation Function)
   - Context string `b"secure-e2ee-chat"` is used as `info` so the key is bound
     to this application

3. **Encryption**
   - For each message:
     - A fresh 12 byte random nonce is generated
     - AES GCM encrypts the plaintext and produces ciphertext + authentication tag
   - The receiver verifies the tag when decrypting, which detects tampering

The actual messages on the network are **base64 encoded** blobs that contain
`nonce || ciphertext`. Anyone capturing the traffic only sees random bytes.

---

## How this relates to cyber security studies

This repository is intentionally small and readable, but it touches on several
core cyber security topics:

- Modern public key cryptography (X25519)
- Symmetric encryption and authenticated encryption (AES GCM)
- Key management and ephemeral keys
- Designing simple, understandable application level protocols
- Secure coding practices (no manual crypto primitives, clear structure)

It represents the type of hands on, curiosity driven project I enjoy building
to deepen my understanding of security concepts and prepare for more advanced
coursework in network security, cryptography, and secure systems engineering.

---

## Possible extensions

To extend and improve this project in the future, I would like to:

- Add support for multiple clients (simple secure group chat)
- Implement message signing with Ed25519 for strong identity
- Persist long term identity keys with a trust on first use model
- Wrap this in a small GUI or web interface for user friendly usage
- Add tests and a more formal protocol description document

These ideas show a clear path for turning a learning project into a more
advanced system while keeping the focus on building secure by design software.
