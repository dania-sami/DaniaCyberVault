
import argparse
import base64
import socket
import threading
from typing import Tuple

from crypto_utils import (
    generate_key_pair,
    derive_shared_key,
    create_aesgcm,
    encrypt,
    decrypt,
)


def send_line(sock: socket.socket, data: bytes) -> None:
    sock.sendall(data + b"\n")


def recv_line(sock: socket.socket) -> bytes:
    buffer = b""
    while True:
        chunk = sock.recv(1)
        if not chunk:
            return b""
        if chunk == b"\n":
            return buffer
        buffer += chunk


def perform_key_exchange(sock: socket.socket) -> Tuple[object, bytes]:
    print("[crypto] Generating ephemeral X25519 key pair (client)...")
    keypair = generate_key_pair()

    # Receive server public key first
    peer_pub_b64 = recv_line(sock)
    if not peer_pub_b64:
        raise RuntimeError("Connection closed during key exchange")
    peer_pub_bytes = base64.b64decode(peer_pub_b64)

    # Send our public key
    send_line(sock, base64.b64encode(keypair.public_bytes))

    shared_key = derive_shared_key(keypair.private_key, peer_pub_bytes)
    print("[crypto] Shared secret derived successfully (client).")

    aesgcm = create_aesgcm(shared_key)
    return aesgcm, shared_key


def receiver_loop(sock: socket.socket, aesgcm) -> None:
    try:
        while True:
            line = recv_line(sock)
            if not line:
                print("[recv] Connection closed by peer.")
                break
            raw = base64.b64decode(line)
            nonce = raw[:12]
            ciphertext = raw[12:]
            try:
                message = decrypt(aesgcm, nonce, ciphertext)
                print(f"\n[peer] {message}")
                print("> ", end="", flush=True)
            except Exception as e:
                print(f"\n[error] Failed to decrypt message: {e}")
    finally:
        sock.close()


def sender_loop(sock: socket.socket, aesgcm) -> None:
    try:
        while True:
            try:
                msg = input("> ")
            except EOFError:
                break
            if not msg:
                continue
            nonce, ciphertext = encrypt(aesgcm, msg)
            payload = base64.b64encode(nonce + ciphertext)
            send_line(sock, payload)
    finally:
        sock.close()


def main():
    parser = argparse.ArgumentParser(description="Secure E2EE chat client")
    parser.add_argument("--host", type=str, default="127.0.0.1")
    parser.add_argument("--port", type=int, default=5000)
    args = parser.parse_args()

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        print(f"[client] Connecting to {args.host}:{args.port} ...")
        sock.connect((args.host, args.port))

        aesgcm, _ = perform_key_exchange(sock)
        print("[client] Secure session established. You can start chatting.")

        recv_thread = threading.Thread(target=receiver_loop, args=(sock, aesgcm), daemon=True)
        recv_thread.start()

        try:
            sender_loop(sock, aesgcm)
        except KeyboardInterrupt:
            print("\n[client] Shutting down...")


if __name__ == "__main__":
    main()
