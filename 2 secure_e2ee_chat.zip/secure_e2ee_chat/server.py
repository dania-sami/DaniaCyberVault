
import argparse
import base64
import socket
import threading
from typing import Tuple

from crypto_utils import (
    generate_key_pair,
    derive_shared_key,
    create_aesgcm,
    encrypt,
    decrypt,
)


def send_line(sock: socket.socket, data: bytes) -> None:
    sock.sendall(data + b"\n")


def recv_line(sock: socket.socket) -> bytes:
    buffer = b""
    while True:
        chunk = sock.recv(1)
        if not chunk:
            return b""
        if chunk == b"\n":
            return buffer
        buffer += chunk


def perform_key_exchange(conn: socket.socket) -> Tuple[object, bytes]:
    print("[crypto] Generating ephemeral X25519 key pair (server)...")
    keypair = generate_key_pair()

    # Send our public key
    send_line(conn, base64.b64encode(keypair.public_bytes))

    # Receive peer public key
    peer_pub_b64 = recv_line(conn)
    if not peer_pub_b64:
        raise RuntimeError("Connection closed during key exchange")

    peer_pub_bytes = base64.b64decode(peer_pub_b64)
    shared_key = derive_shared_key(keypair.private_key, peer_pub_bytes)
    print("[crypto] Shared secret derived successfully (server).")

    aesgcm = create_aesgcm(shared_key)
    return aesgcm, shared_key


def receiver_loop(conn: socket.socket, aesgcm) -> None:
    try:
        while True:
            line = recv_line(conn)
            if not line:
                print("[recv] Connection closed by peer.")
                break
            raw = base64.b64decode(line)
            nonce = raw[:12]
            ciphertext = raw[12:]
            try:
                message = decrypt(aesgcm, nonce, ciphertext)
                print(f"\n[peer] {message}")
                print("> ", end="", flush=True)
            except Exception as e:
                print(f"\n[error] Failed to decrypt message: {e}")
    finally:
        conn.close()


def sender_loop(conn: socket.socket, aesgcm) -> None:
    try:
        while True:
            try:
                msg = input("> ")
            except EOFError:
                break
            if not msg:
                continue
            nonce, ciphertext = encrypt(aesgcm, msg)
            payload = base64.b64encode(nonce + ciphertext)
            send_line(conn, payload)
    finally:
        conn.close()


def main():
    parser = argparse.ArgumentParser(description="Secure E2EE chat server")
    parser.add_argument("--host", type=str, default="127.0.0.1")
    parser.add_argument("--port", type=int, default=5000)
    args = parser.parse_args()

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as srv:
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind((args.host, args.port))
        srv.listen(1)
        print(f"[server] Listening on {args.host}:{args.port} ...")

        conn, addr = srv.accept()
        print(f"[server] Connection from {addr}")

        aesgcm, _ = perform_key_exchange(conn)
        print("[server] Secure session established. You can start chatting.")

        recv_thread = threading.Thread(target=receiver_loop, args=(conn, aesgcm), daemon=True)
        recv_thread.start()

        try:
            sender_loop(conn, aesgcm)
        except KeyboardInterrupt:
            print("\n[server] Shutting down...")


if __name__ == "__main__":
    main()
