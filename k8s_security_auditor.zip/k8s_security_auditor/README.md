# Kubernetes Security Posture Auditor

Hi, I am Dania Sami 👋

This project is a small **static analysis tool for Kubernetes YAML files**.

I wanted something that can:

- scan Kubernetes manifests in a folder
- highlight risky patterns (privileged containers, hostPath mounts, open services)
- give a quick, developer-friendly report in the terminal

It is not a full CSPM product, but it feels like a mini version of what real
security teams run in CI pipelines.

---

## What it checks

In `src/audit.py` I parse `*.yml` / `*.yaml` from the `manifests/` directory
and flag things like:

- `securityContext.privileged: true`
- containers running as root (`runAsNonRoot: false` or absent)
- `hostNetwork: true`
- use of `hostPath` volumes
- `Service` of type `LoadBalancer` or `NodePort`

The findings are printed with a simple severity and a short explanation.

---

## How to run

You need Python 3.10+.

```bash
python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt

python -m src.audit
```

By default it scans the `manifests/` directory shipped with the repo.

You can also point it to another directory:

```bash
python -m src.audit --path path/to/your/manifests
```

---

## Project structure

```text
k8s_security_auditor/
  ├─ README.md
  ├─ requirements.txt
  ├─ manifests/
  │    ├─ insecure_deployment.yaml
  │    └─ secure_deployment.yaml
  └─ src/
       ├─ __init__.py
       ├─ config.py
       └─ audit.py
```

The example manifests show both bad and better practices, so the report is
interesting even on first run.

---

## Why I built this

Kubernetes security is a huge topic, but many weaknesses are simply **YAML
mistakes**. I wanted a project that proves I can:

- read and reason about K8s manifests
- codify security best practices as rules
- build tooling that developers can actually run locally or in CI

This aligns very well with **DevSecOps** and **cloud security engineering** roles.
