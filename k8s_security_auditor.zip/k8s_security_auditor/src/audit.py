from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any, Dict, List

import yaml
from rich import print
from rich.table import Table

from .config import DEFAULT_MANIFEST_DIR


def load_yaml_files(path: Path) -> List[Dict[str, Any]]:
    docs: List[Dict[str, Any]] = []
    for file in path.glob("**/*.y*ml"):
        content = file.read_text(encoding="utf-8")
        for doc in yaml.safe_load_all(content):
            if isinstance(doc, dict):
                doc["_file"] = str(file)
                docs.append(doc)
    return docs


def audit_doc(doc: Dict[str, Any]) -> List[Dict[str, str]]:
    findings: List[Dict[str, str]] = []
    kind = doc.get("kind", "Unknown")
    meta = doc.get("metadata", {})
    name = meta.get("name", "<no-name>")
    file = doc.get("_file", "?")

    def add(severity: str, msg: str):
        findings.append(
            {
                "file": file,
                "kind": kind,
                "name": name,
                "severity": severity,
                "message": msg,
            }
        )

    if kind in {"Deployment", "Pod"}:
        spec = doc.get("spec", {})
        tpl = spec.get("template", {}).get("spec", spec.get("spec", {}))

        if tpl.get("hostNetwork", False):
            add("HIGH", "hostNetwork is true (pod is sharing host network)")

        for vol in tpl.get("volumes", []) or []:
            if "hostPath" in vol:
                add("HIGH", f"hostPath volume used: {vol.get('name', '<no-name>')}")

        for c in tpl.get("containers", []) or []:
            sc = c.get("securityContext", {})
            if sc.get("privileged", False):
                add("HIGH", f"Container {c.get('name', '<noname>')} is privileged")
            if sc.get("runAsNonRoot", None) is False or "runAsNonRoot" not in sc:
                add("MEDIUM", f"Container {c.get('name', '<noname>')} may run as root (runAsNonRoot not true)")

    if kind == "Service":
        spec = doc.get("spec", {})
        stype = spec.get("type", "ClusterIP")
        if stype in {"LoadBalancer", "NodePort"}:
            add("MEDIUM", f"Service type {stype} exposes workload externally")

    return findings


def main() -> None:
    parser = argparse.ArgumentParser(description="Kubernetes security YAML auditor")
    parser.add_argument(
        "--path",
        type=str,
        default=str(DEFAULT_MANIFEST_DIR),
        help="Path to directory with Kubernetes YAML manifests.",
    )
    args = parser.parse_args()
    manifest_dir = Path(args.path)

    print(f"[bold blue]Scanning manifests in:[/bold blue] {manifest_dir}")
    docs = load_yaml_files(manifest_dir)
    print(f"Loaded {len(docs)} Kubernetes manifest objects.")

    all_findings: List[Dict[str, str]] = []
    for doc in docs:
        all_findings.extend(audit_doc(doc))

    if not all_findings:
        print("[bold green]No obvious issues found.[/bold green]")
        return

    table = Table(title="Kubernetes Security Findings")
    table.add_column("File", overflow="fold")
    table.add_column("Kind")
    table.add_column("Name")
    table.add_column("Severity")
    table.add_column("Message", overflow="fold")

    for f in all_findings:
        table.add_row(
            f["file"],
            f["kind"],
            f["name"],
            f["severity"],
            f["message"],
        )

    print(table)


if __name__ == "__main__":
    main()
