
# IronLog Immutable SIEM

I designed IronLog Immutable SIEM as a tiny but honest answer to the question
how do I know my logs have not been tampered with.

In many systems logs are just text files or database rows. Once an attacker has
enough access they can try to erase their own traces. IronLog demonstrates an
approach where every event is bound into a cryptographic hash chain so that
modifications become obvious when we verify the stream.

In this project everything lives in memory because I want to focus on the core
idea rather than heavy infrastructure, but the design is intentionally close to
what I would build on top of a real data store.

## What IronLog does

* accepts log events grouped by stream id
* builds a hash chain inside each stream, linking each event to the previous one
* exposes an endpoint to verify a stream and detect tampering
* returns the stream status with head hash and event count

If a single event is changed, removed, or inserted in the middle the hash chain
breaks and verification fails.

## Project layout

```text
ironlog-immutable-siem
└── backend
    ├── ironlog_siem
    │   ├── __init__.py
    │   ├── engine.py  Immutable log and hash chaining
    │   └── main.py    FastAPI endpoints
    ├── requirements.txt
    └── example_requests.http
```

## How I run it locally

From the backend folder

```bash
python -m venv .venv
source .venv/bin/activate        # On Windows I use .venv\Scripts\activate
pip install -r requirements.txt
uvicorn ironlog_siem.main:app --reload --port 9201
```

Then I visit

* http://localhost:9201/docs to call the endpoints interactively

## How I use it in a demo

I send a few authentication events into a stream

```bash
curl -X POST http://localhost:9201/events   -H "Content-Type: application/json"   -d '{
    "stream_id": "auth-logs",
    "level": "INFO",
    "message": "User dania logged in from 192.0.2.10"
  }'
```

Then I list streams

```bash
curl http://localhost:9201/streams
```

and fetch all events for auth logs

```bash
curl http://localhost:9201/streams/auth-logs/events
```

Finally I verify the stream

```bash
curl http://localhost:9201/streams/auth-logs/verify
```

Because the engine keeps the original events in memory and recomputes hashes
on the fly, the verification will come back as ok.

If I want to simulate tampering for a talk I can temporarily modify an event
inside the process and run verification again to show how the chain breaks.

## Why this matters to me

Log integrity is a core building block for trustworthy incident response. With
IronLog I have a compact educational project that lets me explain hash chains,
tamper evidence, and how I would think about building a more serious immutable
log in a production environment.

Future extensions could include

* persisting events in a database
* exposing proofs for a given time range
* integrating with a SIEM pipeline so that selected streams are stored in an
  immutable way while others follow normal storage paths.
