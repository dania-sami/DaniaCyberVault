
from fastapi import FastAPI
from pydantic import BaseModel, Field
from typing import List, Optional

from .engine import ImmutableLog, LogEvent, StreamStatus, VerificationResult


log = ImmutableLog()


class EventIn(BaseModel):
    stream_id: str = Field(..., example="auth-logs")
    level: str = Field(..., example="INFO")
    message: str = Field(..., example="User login successful")


class EventOut(BaseModel):
    index: int
    stream_id: str
    timestamp: str
    level: str
    message: str
    prev_hash: str
    hash: str


class StreamStatusOut(BaseModel):
    stream_id: str
    event_count: int
    head_hash: str
    created_at: str


class VerifyOut(BaseModel):
    stream_id: str
    ok: bool
    broken_at: Optional[int]
    expected_hash: Optional[str]
    actual_hash: Optional[str]


app = FastAPI(
    title="IronLog Immutable SIEM",
    version="0.1.0",
    description="My append only log service with hash chaining and verification.",
)


@app.post("/events", response_model=EventOut)
def append_event(payload: EventIn) -> EventOut:
    ev: LogEvent = log.append(stream_id=payload.stream_id, level=payload.level, message=payload.message)
    return EventOut(
        index=ev.index,
        stream_id=ev.stream_id,
        timestamp=ev.timestamp.isoformat() + "Z",
        level=ev.level,
        message=ev.message,
        prev_hash=ev.prev_hash,
        hash=ev.hash,
    )


@app.get("/streams", response_model=List[StreamStatusOut])
def get_streams() -> List[StreamStatusOut]:
    items: List[StreamStatusOut] = []
    for s in log.status():
        items.append(
            StreamStatusOut(
                stream_id=s.stream_id,
                event_count=s.event_count,
                head_hash=s.head_hash,
                created_at=s.created_at.isoformat() + "Z",
            )
        )
    return items


@app.get("/streams/{stream_id}/events", response_model=List[EventOut])
def get_events(stream_id: str) -> List[EventOut]:
    out: List[EventOut] = []
    for ev in log.list_events(stream_id):
        out.append(
            EventOut(
                index=ev.index,
                stream_id=ev.stream_id,
                timestamp=ev.timestamp.isoformat() + "Z",
                level=ev.level,
                message=ev.message,
                prev_hash=ev.prev_hash,
                hash=ev.hash,
            )
        )
    return out


@app.get("/streams/{stream_id}/verify", response_model=VerifyOut)
def verify(stream_id: str) -> VerifyOut:
    res: VerificationResult = log.verify(stream_id)
    return VerifyOut(
        stream_id=res.stream_id,
        ok=res.ok,
        broken_at=res.broken_at,
        expected_hash=res.expected_hash,
        actual_hash=res.actual_hash,
    )
