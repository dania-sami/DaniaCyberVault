
from dataclasses import dataclass
from datetime import datetime
from typing import Dict, List, Optional
import hashlib
import json


@dataclass
class LogEvent:
    index: int
    stream_id: str
    timestamp: datetime
    message: str
    level: str
    prev_hash: str
    hash: str


@dataclass
class StreamStatus:
    stream_id: str
    event_count: int
    head_hash: str
    created_at: datetime


@dataclass
class VerificationResult:
    stream_id: str
    ok: bool
    broken_at: Optional[int]
    expected_hash: Optional[str]
    actual_hash: Optional[str]


class ImmutableLog:
    """
    This is my minimal immutable log engine.

    Every event in a stream is chained with a cryptographic hash.
    If someone tampers with stored events the chain verification will fail.
    In this prototype everything is in memory but the design is close to what
    I would build on top of a database in a real SIEM style project.
    """

    def __init__(self) -> None:
        self.streams: Dict[str, List[LogEvent]] = {}

    def _calc_hash(self, stream_id: str, index: int, timestamp: datetime, level: str, message: str, prev_hash: str) -> str:
        payload = {
            "stream_id": stream_id,
            "index": index,
            "timestamp": timestamp.isoformat(),
            "level": level,
            "message": message,
            "prev_hash": prev_hash,
        }
        encoded = json.dumps(payload, sort_keys=True).encode("utf8")
        return hashlib.sha256(encoded).hexdigest()

    def append(self, stream_id: str, level: str, message: str) -> LogEvent:
        chain = self.streams.setdefault(stream_id, [])
        index = len(chain)
        prev_hash = chain[-1].hash if chain else "genesis"
        ts = datetime.utcnow()
        h = self._calc_hash(stream_id, index, ts, level, message, prev_hash)
        event = LogEvent(
            index=index,
            stream_id=stream_id,
            timestamp=ts,
            message=message,
            level=level,
            prev_hash=prev_hash,
            hash=h,
        )
        chain.append(event)
        return event

    def status(self) -> List[StreamStatus]:
        items: List[StreamStatus] = []
        for sid, chain in self.streams.items():
            if chain:
                head = chain[-1]
                created = chain[0].timestamp
                items.append(
                    StreamStatus(
                        stream_id=sid,
                        event_count=len(chain),
                        head_hash=head.hash,
                        created_at=created,
                    )
                )
        return items

    def list_events(self, stream_id: str) -> List[LogEvent]:
        return list(self.streams.get(stream_id, []))

    def verify(self, stream_id: str) -> VerificationResult:
        chain = self.streams.get(stream_id, [])
        prev_hash = "genesis"
        for ev in chain:
            expected = self._calc_hash(ev.stream_id, ev.index, ev.timestamp, ev.level, ev.message, prev_hash)
            if expected != ev.hash:
                return VerificationResult(
                    stream_id=stream_id,
                    ok=False,
                    broken_at=ev.index,
                    expected_hash=expected,
                    actual_hash=ev.hash,
                )
            prev_hash = ev.hash
        return VerificationResult(
            stream_id=stream_id,
            ok=True,
            broken_at=None,
            expected_hash=None,
            actual_hash=None,
        )
