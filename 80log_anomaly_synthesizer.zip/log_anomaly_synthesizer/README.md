# AI-Based Log Anomaly Synthesizer (Synthetic SOC Stress Tester)

Hi, I am Dania Sami 👋

SOC teams often struggle to test their detection pipelines because **real attacks
are rare** and production logs are sensitive.

I built this project as a safe way to **generate synthetic abnormal logs** that
look like:

- brute force attacks
- suspicious admin actions
- data exfil behaviour
- weird application errors

The idea is to **stress-test SIEM rules and detection logic** without touching
real production data.

I call it an "AI-based" synthesizer because the design is deliberately close to
how I would plug in a language model later, but the default implementation
uses local templates so it works everywhere with no API keys.

---

## What this tool does

1. **Loads a base log template**

   Under `data/base_logs.jsonl` I keep a tiny set of "normal" JSON log events
   (login, file access, API calls).

2. **Generates synthetic anomalies**

   In `src/synthesizer.py` I have small pattern generators that create:

   - login brute force sequences
   - mass file read patterns
   - high-volume API error spikes
   - "impossible travel" logins from far locations

   These are simple but realistic enough to test alerting.

3. **Writes a mixed log stream**

   `src/generate.py` writes:

   - `reports/normal_logs.jsonl`
   - `reports/anomaly_logs.jsonl`
   - `reports/mixed_logs.jsonl`

   The mixed file interleaves normal and abnormal events with timestamps.

4. **Optional: AI hook (design only)**

   The code is structured so I could replace the local generators with a call
   to an LLM later, but by default it runs completely offline.

---

## How to run

You need Python 3.10+.

```bash
python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt

python -m src.generate
```

After running, check the `reports/` directory.

You can feed `mixed_logs.jsonl` into other tools such as:

- log parsers
- SIEM rule tests
- my incident responder project

---

## Project structure

```text
log_anomaly_synthesizer/
  ├─ README.md
  ├─ requirements.txt
  ├─ data/
  │    └─ base_logs.jsonl
  ├─ reports/
  │    ├─ normal_logs.jsonl      # generated
  │    ├─ anomaly_logs.jsonl     # generated
  │    └─ mixed_logs.jsonl       # generated
  └─ src/
       ├─ __init__.py
       ├─ config.py
       ├─ loader.py
       ├─ synthesizer.py
       └─ generate.py
```

---

## Why I built this

Detection engineering is not only about writing rules. It is also about:

- generating realistic test data
- thinking like an attacker
- building harnesses to evaluate coverage

This project shows that I can design **synthetic adversarial behaviour** in a
controlled way and integrate it with the rest of my security tooling.
