import json
from typing import List, Dict

from .config import BASE_LOGS


def load_base_logs() -> List[Dict]:
    events: List[Dict] = []
    for line in BASE_LOGS.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        events.append(json.loads(line))
    return events
