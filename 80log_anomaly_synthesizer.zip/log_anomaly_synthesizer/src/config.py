from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
REPORTS_DIR = BASE_DIR / "reports"

DATA_DIR.mkdir(parents=True, exist_ok=True)
REPORTS_DIR.mkdir(parents=True, exist_ok=True)

BASE_LOGS = DATA_DIR / "base_logs.jsonl"
NORMAL_OUT = REPORTS_DIR / "normal_logs.jsonl"
ANOMALY_OUT = REPORTS_DIR / "anomaly_logs.jsonl"
MIXED_OUT = REPORTS_DIR / "mixed_logs.jsonl"
