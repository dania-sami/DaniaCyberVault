from __future__ import annotations

import json
from datetime import datetime, timedelta
from typing import Dict, List

from .config import NORMAL_OUT, ANOMALY_OUT, MIXED_OUT
from .loader import load_base_logs


def generate_bruteforce(start: datetime, user: str, ip: str, attempts: int = 20) -> List[Dict]:
    events: List[Dict] = []
    t = start
    for _ in range(attempts):
        t += timedelta(seconds=5)
        events.append(
            {
                "timestamp": t.isoformat(),
                "source": "auth",
                "user": user,
                "ip": ip,
                "event": "login_failed",
                "reason": "invalid_password",
            }
        )
    t += timedelta(seconds=5)
    events.append(
        {
            "timestamp": t.isoformat(),
            "source": "auth",
            "user": user,
            "ip": ip,
            "event": "login_success",
            "note": "suspicious after many failures",
        }
    )
    return events


def generate_file_exfil(start: datetime, user: str, host: str, files: int = 30) -> List[Dict]:
    events: List[Dict] = []
    t = start
    for i in range(files):
        t += timedelta(seconds=3)
        events.append(
            {
                "timestamp": t.isoformat(),
                "source": "filesystem",
                "user": user,
                "host": host,
                "event": "file_read",
                "path": f"/shared/confidential/doc_{i}.pdf",
            }
        )
    return events


def generate_error_spike(start: datetime, service: str, count: int = 50) -> List[Dict]:
    events: List[Dict] = []
    t = start
    for _ in range(count):
        t += timedelta(seconds=1)
        events.append(
            {
                "timestamp": t.isoformat(),
                "source": "app",
                "service": service,
                "event": "http_500",
                "message": "unexpected error in handler",
            }
        )
    return events


def generate_impossible_travel(start: datetime, user: str) -> List[Dict]:
    events: List[Dict] = []
    t1 = start
    t2 = start + timedelta(hours=1)

    events.append(
        {
            "timestamp": t1.isoformat(),
            "source": "auth",
            "user": user,
            "ip": "192.0.2.10",
            "geo": "Stockholm, SE",
            "event": "login_success",
        }
    )
    events.append(
        {
            "timestamp": t2.isoformat(),
            "source": "auth",
            "user": user,
            "ip": "203.0.113.55",
            "geo": "Sydney, AU",
            "event": "login_success",
            "note": "impossible travel",
        }
    )
    return events


def generate_all() -> None:
    base = load_base_logs()
    normal_events = list(base)

    start = datetime(2025, 1, 1, 10, 0, 0)
    anomalies: List[Dict] = []
    anomalies += generate_bruteforce(start, "alice", "198.51.100.10")
    anomalies += generate_file_exfil(start + timedelta(minutes=10), "bob", "fileserver01")
    anomalies += generate_error_spike(start + timedelta(minutes=30), "payments-api")
    anomalies += generate_impossible_travel(start + timedelta(hours=2), "charlie")

    normal_events.sort(key=lambda e: e["timestamp"])
    anomalies.sort(key=lambda e: e["timestamp"])

    NORMAL_OUT.write_text("\n".join([json.dumps(e) for e in normal_events]) + "\n", encoding="utf-8")
    ANOMALY_OUT.write_text("\n".join([json.dumps(e) for e in anomalies]) + "\n", encoding="utf-8")

    mixed = normal_events + anomalies
    mixed.sort(key=lambda e: e["timestamp"])
    MIXED_OUT.write_text("\n".join([json.dumps(e) for e in mixed]) + "\n", encoding="utf-8")
