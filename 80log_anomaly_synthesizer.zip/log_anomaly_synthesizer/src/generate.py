from .synthesizer import generate_all


def main() -> None:
    generate_all()
    print("Generated normal, anomaly and mixed logs in reports/.")


if __name__ == "__main__":
    main()
