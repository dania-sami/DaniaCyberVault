import argparse
import csv

def report(path: str):
    total = 0
    enabled = 0
    no_mfa_users = []

    with open(path, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            user = row.get("user", "")
            mfa_flag = (row.get("mfa_enabled", "false").lower() == "true")
            total += 1
            if mfa_flag:
                enabled += 1
            else:
                no_mfa_users.append(user)

    if total == 0:
        print("[+] No users found in file.")
        return

    coverage = (enabled / total) * 100.0
    print(f"[+] MFA coverage for {path}: {coverage:.1f}% ({enabled}/{total}) enabled\n")

    if no_mfa_users:
        print("[+] Users without MFA enabled:")
        for u in no_mfa_users:
            print(f"    {u}")

def main():
    parser = argparse.ArgumentParser(description="MFA Coverage Reporter by Dania")
    parser.add_argument("--csv", required=True, help="CSV with user,mfa_enabled")
    args = parser.parse_args()
    report(args.csv)

if __name__ == "__main__":
    main()
