# MFA Coverage Reporter

This project is a simple way for me to talk about MFA coverage in an environment.

It reads a CSV file with:

- `user`
- `mfa_enabled` (true/false)

The script calculates the percentage of accounts with MFA enabled and lists the users who do not have it turned on.

## Files

- `mfa_report.py` – main script
- `demo_users.csv` – example users

## Usage

```bash
python mfa_report.py --csv demo_users.csv
```
