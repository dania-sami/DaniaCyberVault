from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, Any, List

BASE_DIR = Path(__file__).resolve().parent.parent
OUTPUT_DIR = BASE_DIR / "output"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> None:
    parser = argparse.ArgumentParser(description="Secure container baseline generator")
    parser.add_argument("--image", type=str, required=True, help="Path to image package JSON")
    parser.add_argument("--risky", type=str, required=True, help="Path to risky package JSON")
    args = parser.parse_args()

    image = load_json(Path(args.image))
    risky = load_json(Path(args.risky))

    base_image = image.get("base_image", "unknown:latest")
    packages: List[Dict[str, Any]] = image.get("packages", [])
    risky_names = {p["name"] for p in risky.get("packages", [])}

    risky_found = [p for p in packages if p["name"] in risky_names]
    safe_packages = [p for p in packages if p["name"] not in risky_names]

    print("Secure Container Baseline Report")
    print("================================")
    print(f"Base image: {base_image}")
    print(f"Total packages: {len(packages)}")
    print(f"Risky packages found: {len(risky_found)}")
    for p in risky_found:
        print(f"  - {p['name']} {p['version']} ({p.get('reason', 'risky')})")
    print()

    recommended_base = base_image + "-secure"
    print(f"Recommended new base image tag: {recommended_base}")
    print("Recommended packages to keep (high level):")
    for p in safe_packages:
        if p.get("category") in ("runtime", "framework"):
            print(f"  - {p['name']} {p['version']} ({p['category']})")
    print()

    docker_snippet = [
        f"FROM {recommended_base}",
        "# Remove risky packages",
    ]
    for p in risky_found:
        docker_snippet.append(f"#   - {p['name']} {p['version']}")
    docker_snippet.append("# Reinstall only what is needed for the app")

    out_path = OUTPUT_DIR / "baseline_dockerfile.txt"
    out_path.write_text("\n".join(docker_snippet), encoding="utf-8")
    print(f"Dockerfile baseline snippet written to: {out_path}")


if __name__ == "__main__":
    main()
