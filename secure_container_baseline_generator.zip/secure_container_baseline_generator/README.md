# Secure Container Image Baseline Generator

Hi, I am Dania 👋

This project is my **secure container baseline generator**:

- I work on a simple JSON export of an image (base + installed packages).
- I flag risky or outdated packages from a local list.
- I print a recommended **hardened baseline** and a Dockerfile-style snippet.

It is a practical way to talk about **image hardening and baselines**.

## How to run

```bash
cd secure_container_baseline_generator

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt   # stdlib only

python -m src.generate --image data/image_packages.json --risky data/risky_packages.json
```

The tool prints the proposed baseline and writes a small Dockerfile snippet under `output/`.
