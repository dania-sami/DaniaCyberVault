
from typing import Optional, Dict, Any
import requests


class HttpClient:
    """Simple wrapper around requests so it is easy to extend later."""

    def __init__(self, timeout: int = 10):
        self.session = requests.Session()
        self.timeout = timeout

    def get(self, url: str, params: Optional[Dict[str, Any]] = None):
        return self.session.get(url, params=params, timeout=self.timeout, verify=True)

    def post(self, url: str, data: Optional[Dict[str, Any]] = None):
        return self.session.post(url, data=data, timeout=self.timeout, verify=True)
