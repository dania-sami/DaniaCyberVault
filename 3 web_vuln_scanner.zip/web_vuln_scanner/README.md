
# Web Application Vulnerability Scanner

This project is a small but serious **web security scanner** written in Python.  
It sends controlled test requests to a target site and looks for common security issues such as

* possible reflected cross site scripting
* very simple sql injection weaknesses in query parameters
* missing or weak security headers

I created this project to show genuine curiosity and motivation for cyber security and to practice thinking like both a defender and an attacker in a responsible way.

---

## What the scanner does

Given a target address the tool

* crawls a few internal links on the same site
* collects forms and query parameters
* sends safe proof of concept payloads
* inspects the responses
* prints a clear text report of potential problems

The scanner never tries to break anything and does not send destructive payloads.  
It is meant for learning and for scanning test or lab environments that you have permission to examine.

---

## Project structure

```text
web_vuln_scanner/
* README.md
* requirements.txt
* scanner.py         main entry point
* checks.py          individual security checks
* http_client.py     wrapper around the requests library
```

---

## Installation

Create and activate a virtual environment inside the project folder.

```bash
python3 -m venv venv
source venv/bin/activate          # Windows  venv\Scripts\activate
```

Install the required packages.

```bash
pip install -r requirements.txt
```

---

## Basic usage

Run the scanner from the terminal and pass a target address.

```bash
python scanner.py https://example.com
```

You will see output similar to

```text
[info] Starting scan for https://example.com
[info] Collected 7 pages to scan
[ok]   Security headers look fine on https://example.com
[warn] Possible reflected cross site scripting on https://example.com/search
[warn] Very simple sql injection pattern echoed on https://example.com/products
```

At the end you receive a short summary with counts of findings.

---

## What checks are included

Right now the scanner implements three main groups of checks.

1. Security headers  
   For every response it looks for recommended headers such as

   * Content Security Policy
   * X Content Type Options
   * X Frame Options
   * Referrer Policy
   * Strict Transport Security for secure traffic

   Missing headers are reported as areas to improve.

2. Reflected cross site scripting probes  
   The scanner injects a harmless marker string into query parameters and form fields.  
   If the same marker comes back inside the html response in a suspicious context the page is flagged as a possible reflected cross site scripting risk.

3. Very basic sql injection patterns  
   For selected parameters the scanner appends classic patterns such as a single quote and simple true condition fragments.  
   If these patterns are echoed back in error messages or unchanged content it reports a possible sql injection weakness.

None of the payloads aim to cause damage. The goal is to show understanding of typical attack vectors and how automated tools can help find them.

---

## How this connects to cyber security studies

This repository is intentionally easy to read and extend but it already touches several important themes in web security

* input validation and output encoding
* the role of security headers as a defence in depth measure
* risks around user supplied data and query parameters
* the idea of security scanning and automation

Building this kind of project helps develop both coding skills and a mindset that looks for weaknesses in a structured and ethical way.  
It also prepares for more advanced topics such as secure software design, web penetration testing, and secure development life cycles.

---

## Possible future improvements

If I continue to build on this project I would like to

* add a small html or terminal dashboard that groups and filters findings
* support cookie based sessions for authenticated test users
* add more header and configuration checks
* export results to a structured report format for documentation
* plug in more advanced payload libraries while still keeping the focus on responsible use

This creates a clear path for turning a focused learning project into a more complete tool while keeping security and ethics at the centre.
