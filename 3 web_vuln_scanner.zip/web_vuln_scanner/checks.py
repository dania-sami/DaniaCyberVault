
from dataclasses import dataclass
from typing import Dict, List, Tuple
from urllib.parse import urlparse

from bs4 import BeautifulSoup


XSS_MARKER = "XSS_TEST_123456789"
SQL_MARKER = "' OR 1=1 --"


@dataclass
class Finding:
    severity: str
    kind: str
    url: str
    detail: str


def check_security_headers(url: str, headers: Dict[str, str]) -> List[Finding]:
    required = [
        "Content-Security-Policy",
        "X-Content-Type-Options",
        "X-Frame-Options",
        "Referrer-Policy",
    ]
    findings: List[Finding] = []

    scheme = urlparse(url).scheme
    if scheme == "https":
        required.append("Strict-Transport-Security")

    for name in required:
        if name not in headers:
            findings.append(
                Finding(
                    severity="info",
                    kind="missing_header",
                    url=url,
                    detail=f"Header {name} is missing",
                )
            )

    return findings


def check_reflected_xss(url: str, response_text: str) -> List[Finding]:
    findings: List[Finding] = []
    if XSS_MARKER in response_text:
        findings.append(
            Finding(
                severity="warning",
                kind="reflected_xss",
                url=url,
                detail="Marker string was reflected in the response",
            )
        )
    return findings


def check_sql_injection_reflection(url: str, response_text: str) -> List[Finding]:
    findings: List[Finding] = []
    if SQL_MARKER in response_text:
        findings.append(
            Finding(
                severity="warning",
                kind="sql_injection_reflection",
                url=url,
                detail="Very simple sql injection pattern was reflected",
            )
        )
    return findings


def extract_links_and_forms(base_url: str, html: str) -> Tuple[List[str], List[Dict[str, str]]]:
    soup = BeautifulSoup(html, "html.parser")
    links: List[str] = []
    forms: List[Dict[str, str]] = []

    for a in soup.find_all("a", href=True):
        href = a["href"]
        if href.startswith("#"):
            continue
        # skip external links
        parsed = urlparse(href)
        if parsed.scheme and parsed.netloc and base_url not in href:
            continue
        links.append(href)

    for form in soup.find_all("form"):
        method = (form.get("method") or "get").lower()
        action = form.get("action") or ""
        fields: Dict[str, str] = {}
        for inp in form.find_all("input"):
            name = inp.get("name")
            if not name:
                continue
            fields[name] = inp.get("value") or ""
        forms.append({"method": method, "action": action, "fields": fields})

    return links, forms
