
import argparse
import queue
from typing import Set, List, Dict
from urllib.parse import urljoin, urlparse, urlencode

from http_client import HttpClient
from checks import (
    Finding,
    XSS_MARKER,
    SQL_MARKER,
    check_security_headers,
    check_reflected_xss,
    check_sql_injection_reflection,
    extract_links_and_forms,
)


MAX_PAGES = 20


def crawl_and_scan(start_url: str) -> List[Finding]:
    client = HttpClient()
    visited: Set[str] = set()
    to_visit: queue.Queue[str] = queue.Queue()
    to_visit.put(start_url)

    findings: List[Finding] = []

    parsed_start = urlparse(start_url)
    base_domain = parsed_start.netloc

    print(f"[info] Starting scan for {start_url}")

    pages_scanned = 0
    while not to_visit.empty() and pages_scanned < MAX_PAGES:
        url = to_visit.get()
        if url in visited:
            continue
        visited.add(url)

        full_url = url
        if not urlparse(url).netloc:
            full_url = urljoin(start_url, url)

        try:
            resp = client.get(full_url)
        except Exception as e:
            print(f"[error] Request failed for {full_url}  {e}")
            continue

        pages_scanned += 1
        print(f"[info] Scanning {full_url}  status {resp.status_code}")

        # header checks
        header_findings = check_security_headers(full_url, resp.headers)
        findings.extend(header_findings)

        # crawl links and forms
        links, forms = extract_links_and_forms(start_url, resp.text)

        for link in links:
            absolute = urljoin(start_url, link)
            parsed = urlparse(absolute)
            if parsed.netloc == base_domain and absolute not in visited:
                to_visit.put(absolute)

        # xss and sql injection checks on query parameters
        parsed = urlparse(full_url)
        if parsed.query:
            qs_with_xss = parsed.query + f"&xsstest={XSS_MARKER}"
            qs_with_sql = parsed.query + f"&sqltest={SQL_MARKER}"

            url_xss = parsed._replace(query=qs_with_xss).geturl()
            url_sql = parsed._replace(query=qs_with_sql).geturl()

            try:
                resp_xss = client.get(url_xss)
                findings.extend(check_reflected_xss(url_xss, resp_xss.text))
            except Exception:
                pass

            try:
                resp_sql = client.get(url_sql)
                findings.extend(check_sql_injection_reflection(url_sql, resp_sql.text))
            except Exception:
                pass

        # form based checks
        for form in forms:
            method = form["method"]
            action = form["action"] or full_url
            target_url = urljoin(full_url, action)
            fields = form["fields"] or {"test": ""}

            # basic xss probe
            xss_data: Dict[str, str] = {k: XSS_MARKER for k in fields.keys()}
            sql_data: Dict[str, str] = {k: SQL_MARKER for k in fields.keys()}

            try:
                if method == "post":
                    resp_xss = client.post(target_url, data=xss_data)
                    findings.extend(check_reflected_xss(target_url, resp_xss.text))

                    resp_sql = client.post(target_url, data=sql_data)
                    findings.extend(check_sql_injection_reflection(target_url, resp_sql.text))
                else:
                    qs_xss = urlencode(xss_data)
                    qs_sql = urlencode(sql_data)
                    url_xss = target_url + "?" + qs_xss
                    url_sql = target_url + "?" + qs_sql

                    resp_xss = client.get(url_xss)
                    findings.extend(check_reflected_xss(url_xss, resp_xss.text))

                    resp_sql = client.get(url_sql)
                    findings.extend(check_sql_injection_reflection(url_sql, resp_sql.text))
            except Exception:
                continue

    print(f"[info] Finished. Scanned {pages_scanned} pages.")
    return findings


def print_report(findings: List[Finding]) -> None:
    if not findings:
        print("[ok] No findings were recorded for the scanned pages.")
        return

    by_severity = {}
    for f in findings:
        by_severity.setdefault(f.severity, []).append(f)

    for severity, group in by_severity.items():
        print()
        print(f"{severity.upper()}  {len(group)} finding(s)")
        print("-" * 60)
        for f in group:
            print(f"{f.kind:30} {f.url}")
            print(f"  detail  {f.detail}")
    print()
    total = len(findings)
    print(f"[summary] Total findings  {total}")


def main():
    parser = argparse.ArgumentParser(description="Simple web application vulnerability scanner for learning")
    parser.add_argument("url", help="Start address to scan for issues")
    args = parser.parse_args()

    findings = crawl_and_scan(args.url)
    print_report(findings)


if __name__ == "__main__":
    main()
