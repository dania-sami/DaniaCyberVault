# Encrypted Traffic Anomaly Detection with Self‑Supervised Learning

Hi, I am Dania Sami 👋

In this project I wanted to go **beyond a normal IDS** and build something that
looks and feels like a research prototype you would see in a modern paper.

Inspired by recent work on **self‑supervised contrastive learning for encrypted
traffic** (ET‑SSL‑style approaches), I built a small framework that learns
representations of network flows **without using labels first**, and then uses
those representations for anomaly detection.

The focus here is not just “get high accuracy on a toy dataset”, but to show
that I understand

- how to design a **realistic ML pipeline for encrypted traffic**
- how to separate **representation learning** from the downstream detector
- how to write clean, research‑style code that is easy to extend

> ⚠️ This repo is a compact educational version. It is not a drop‑in
> replacement for a production system, but it follows the same ideas that many
> current research projects use.

---

## What this project does

1. **Loads flow‑level network data**

   Each row represents a network flow with statistical features that work even
   when the payload is encrypted, for example:

   - flow duration
   - mean / std of packet sizes
   - mean / std of inter‑arrival times
   - protocol / port metadata

   A tiny synthetic dataset is included so the code runs out‑of‑the‑box. In a
   real experiment I would swap this with a dataset such as CICIDS or a public
   encrypted‑traffic dataset.

2. **Learns embeddings with self‑supervised contrastive learning**

   - Two “views” of each flow are created by simple augmentations
     (noise, masking, small scaling).
   - An encoder network maps each view to an embedding.
   - A contrastive loss (SimCLR‑style) pulls embeddings of the same flow
     together and pushes different flows apart.

3. **Trains a small anomaly detector on top of the embeddings**

   - After pre‑training, I freeze the encoder and compute embeddings.
   - On top of those embeddings I train a simple **Isolation Forest** to rank
     anomalous flows, or a small **logistic regression** if labels are
     available.
   - This mirrors how many papers turn SSL features into practical detectors.

4. **Generates a report**

   - The script writes a small report into `reports/` with
     - top‑N most anomalous flows,
     - basic statistics of the learned embedding space,
     - and evaluation metrics if labels exist.

---

## Quick start

```bash
# 1. Create and activate a virtual environment (recommended)
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Run self‑supervised pre‑training on the sample data
python -m src.train_ssl

# 4. Train a simple anomaly detector on top of the learned embeddings
python -m src.train_detector

# 5. Evaluate and generate a small report
python -m src.evaluate
```

All results and a short text report are saved inside the `models/` and
`reports/` folders.

---

## Project structure

- `src/`
  - `config.py`          basic paths and constants
  - `data.py`            dataset + data augmentations for SSL
  - `models.py`          encoder and projection head
  - `train_ssl.py`       self‑supervised contrastive pre‑training loop
  - `train_detector.py`  trains a simple anomaly detector on embeddings
  - `evaluate.py`        evaluates and writes a small report
- `data/sample_flows.csv`
  - tiny synthetic example dataset so the code works immediately
- `models/`
  - saved encoder and detector after training
- `reports/`
  - simple text summary of the experiment

---

## How I would extend this in a real research setting

To turn this into a more serious experiment, I would:

- Replace the sample CSV with a **real encrypted‑traffic dataset**
  (for example a public HTTPS or VPN traffic dataset).
- Add richer flow features and protocol metadata.
- Run ablation studies comparing
  - different augmentations,
  - different encoder architectures (MLP vs 1D‑CNN vs Transformer),
  - supervised vs self‑supervised baselines.
- Integrate the anomaly scores into a **SIEM‑style dashboard** and correlate
  them with alerts from my other projects (IDS, web scanner, malware toolkit).

The purpose of this repository is to show that I can read recent research,
translate the ideas into working code, and build a clean, extensible prototype
that connects **machine learning** with **cybersecurity** in a realistic way.
