from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
MODEL_DIR = BASE_DIR / "models"
REPORT_DIR = BASE_DIR / "reports"

FLOW_CSV = DATA_DIR / "sample_flows.csv"

ENCODER_FILE = MODEL_DIR / "encoder.pt"
DETECTOR_FILE = MODEL_DIR / "detector.joblib"
REPORT_FILE = REPORT_DIR / "report.txt"

BATCH_SIZE = 64
EPOCHS_SSL = 10
EPOCHS_DETECTOR = 20
EMBED_DIM = 32
