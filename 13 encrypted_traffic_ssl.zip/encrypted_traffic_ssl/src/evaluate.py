from __future__ import annotations

from pathlib import Path

import joblib
import numpy as np
import torch
from sklearn.metrics import classification_report

from .config import DETECTOR_FILE, ENCODER_FILE, EMBED_DIM, REPORT_FILE
from .data import NUMERIC_FEATURES, load_features_and_labels
from .models import Encoder


def main() -> None:
    if not ENCODER_FILE.exists() or not DETECTOR_FILE.exists():
        raise SystemExit(
            "Encoder or detector not found. Run 'python -m src.train_ssl' and 'python -m src.train_detector' first."
        )

    X, y = load_features_and_labels()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    encoder = Encoder(input_dim=len(NUMERIC_FEATURES), embed_dim=EMBED_DIM).to(device)
    encoder.load_state_dict(torch.load(ENCODER_FILE, map_location=device))
    encoder.eval()

    with torch.no_grad():
        embeddings = encoder(torch.from_numpy(X).to(device)).cpu().numpy()

    detector = joblib.load(DETECTOR_FILE)

    # Assume detector is a classifier with predict
    y_pred = detector.predict(embeddings)
    report = classification_report(y, y_pred, target_names=["normal", "anomaly"])
    print(report)

    REPORT_FILE.parent.mkdir(parents=True, exist_ok=True)
    REPORT_FILE.write_text(report, encoding="utf-8")
    print(f"Saved report to {REPORT_FILE}")


if __name__ == "__main__":
    main()
