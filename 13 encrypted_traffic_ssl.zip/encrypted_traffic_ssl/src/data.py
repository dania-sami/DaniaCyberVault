from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader

from .config import FLOW_CSV


NUMERIC_FEATURES = [
    "flow_duration",
    "pkt_size_mean",
    "pkt_size_std",
    "iat_mean",
    "iat_std",
]

LABEL_COL = "label"  # 0 = normal, 1 = anomaly (optional for SSL)


@dataclass
class FlowDatasetConfig:
    batch_size: int = 64
    shuffle: bool = True


class SSLFlowDataset(Dataset):
    """Dataset that returns two augmented 'views' of the same flow.

    This is a simplified version of the type of input used in SSL papers
    for encrypted traffic anomaly detection.
    """

    def __init__(self, df: pd.DataFrame) -> None:
        self.features = df[NUMERIC_FEATURES].to_numpy(dtype=np.float32)

    def __len__(self) -> int:
        return self.features.shape[0]

    def _augment(self, x: np.ndarray) -> np.ndarray:
        # Very small, safe augmentations: gaussian noise + slight scaling
        noise = np.random.normal(loc=0.0, scale=0.01, size=x.shape)
        scale = np.random.normal(loc=1.0, scale=0.02, size=x.shape)
        return (x * scale + noise).astype(np.float32)

    def __getitem__(self, idx: int):
        x = self.features[idx]
        v1 = self._augment(x)
        v2 = self._augment(x)
        return torch.from_numpy(v1), torch.from_numpy(v2)


class LabeledFlowDataset(Dataset):
    """Dataset with embeddings and labels, used for evaluation.

    The labels are optional and mainly for demo metrics on the toy dataset.
    """

    def __init__(self, embeddings: np.ndarray, labels: np.ndarray | None = None):
        self.embeddings = embeddings.astype(np.float32)
        self.labels = labels.astype(int) if labels is not None else None

    def __len__(self) -> int:
        return self.embeddings.shape[0]

    def __getitem__(self, idx: int):
        x = torch.from_numpy(self.embeddings[idx])
        if self.labels is None:
            return x
        return x, int(self.labels[idx])


def load_flow_dataframe() -> pd.DataFrame:
    df = pd.read_csv(FLOW_CSV)
    return df


def make_ssl_dataloader(batch_size: int) -> DataLoader:
    df = load_flow_dataframe()
    ds = SSLFlowDataset(df)
    return DataLoader(ds, batch_size=batch_size, shuffle=True, drop_last=True)


def load_features_and_labels() -> Tuple[np.ndarray, np.ndarray]:
    df = load_flow_dataframe()
    X = df[NUMERIC_FEATURES].to_numpy(dtype=np.float32)
    y = df[LABEL_COL].to_numpy(dtype=np.int64)
    return X, y
