from __future__ import annotations

import math

import torch
import torch.nn.functional as F
from torch import optim

from .config import BATCH_SIZE, EPOCHS_SSL, ENCODER_FILE, EMBED_DIM
from .data import NUMERIC_FEATURES, make_ssl_dataloader
from .models import Encoder, ProjectionHead


def nt_xent_loss(z1, z2, temperature: float = 0.5):
    """Simplified NT-Xent loss from SimCLR for a batch."""
    batch_size = z1.shape[0]
    z1 = F.normalize(z1, dim=1)
    z2 = F.normalize(z2, dim=1)
    representations = torch.cat([z1, z2], dim=0)

    similarity_matrix = torch.matmul(representations, representations.T)
    # Remove self-similarity
    mask = torch.eye(2 * batch_size, dtype=torch.bool, device=similarity_matrix.device)
    similarity_matrix = similarity_matrix[~mask].view(2 * batch_size, -1)

    positives = torch.sum(z1 * z2, dim=-1)
    positives = torch.cat([positives, positives], dim=0)

    logits = similarity_matrix / temperature
    labels = torch.arange(2 * batch_size, device=z1.device)
    loss = F.cross_entropy(logits, labels)
    return loss


def main() -> None:
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    dataloader = make_ssl_dataloader(BATCH_SIZE)
    encoder = Encoder(input_dim=len(NUMERIC_FEATURES), embed_dim=EMBED_DIM).to(device)
    projector = ProjectionHead(embed_dim=EMBED_DIM, proj_dim=EMBED_DIM).to(device)

    params = list(encoder.parameters()) + list(projector.parameters())
    opt = optim.Adam(params, lr=1e-3)

    for epoch in range(1, EPOCHS_SSL + 1):
        encoder.train()
        projector.train()
        epoch_loss = 0.0
        for v1, v2 in dataloader:
            v1 = v1.to(device)
            v2 = v2.to(device)

            z1 = encoder(v1)
            z2 = encoder(v2)
            p1 = projector(z1)
            p2 = projector(z2)

            loss = nt_xent_loss(p1, p2)

            opt.zero_grad()
            loss.backward()
            opt.step()

            epoch_loss += float(loss.item())

        avg_loss = epoch_loss / len(dataloader)
        print(f"[SSL] Epoch {epoch}/{EPOCHS_SSL} - loss: {avg_loss:.4f}")

    ENCODER_FILE.parent.mkdir(parents=True, exist_ok=True)
    torch.save(encoder.state_dict(), ENCODER_FILE)
    print(f"Saved encoder to {ENCODER_FILE}")


if __name__ == "__main__":
    main()
