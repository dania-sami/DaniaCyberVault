from __future__ import annotations

import joblib
import numpy as np
import torch
from sklearn.ensemble import IsolationForest
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

from .config import DETECTOR_FILE, ENCODER_FILE, EMBED_DIM
from .data import NUMERIC_FEATURES, load_features_and_labels
from .models import Encoder


def main() -> None:
    if not ENCODER_FILE.exists():
        raise SystemExit(
            f"Encoder weights not found at {ENCODER_FILE}. Run 'python -m src.train_ssl' first."
        )

    X, y = load_features_and_labels()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    encoder = Encoder(input_dim=len(NUMERIC_FEATURES), embed_dim=EMBED_DIM).to(device)
    encoder.load_state_dict(torch.load(ENCODER_FILE, map_location=device))
    encoder.eval()

    with torch.no_grad():
        embeddings = encoder(torch.from_numpy(X).to(device)).cpu().numpy()

    # Simple demo: try both an unsupervised IsolationForest and a small supervised classifier
    # using the toy labels.
    use_supervised = True

    if use_supervised:
        X_train, X_test, y_train, y_test = train_test_split(
            embeddings, y, test_size=0.3, random_state=42, stratify=y
        )
        clf = LogisticRegression(max_iter=1000)
        clf.fit(X_train, y_train)
        score = clf.score(X_test, y_test)
        print(f"Supervised detector accuracy on toy data: {score:.3f}")
        detector = clf
    else:
        detector = IsolationForest(contamination=0.2, random_state=42)
        detector.fit(embeddings)
        print("Trained IsolationForest on embeddings.")

    DETECTOR_FILE.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(detector, DETECTOR_FILE)
    print(f"Saved detector to {DETECTOR_FILE}")


if __name__ == "__main__":
    main()
