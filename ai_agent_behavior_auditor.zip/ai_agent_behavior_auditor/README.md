# AI Agent Behavior Auditor – Dania

Hi

I am Dania and this project is my auditor for AI agent logs

It reads simple JSONL logs of actions and flags patterns like repeated tool failures access to sensitive paths and unexpected external calls

The idea is to make agent behavior visible explainable and safer
