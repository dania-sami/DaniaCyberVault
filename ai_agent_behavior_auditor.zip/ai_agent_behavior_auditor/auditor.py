"""
AI Agent Behavior Auditor – Dania

Reads JSONL logs of agent actions
flags potentially unsafe or surprising patterns
"""

import argparse
import json
from dataclasses import dataclass, asdict
from typing import List, Dict


@dataclass
class Action:
    ts: str
    agent_id: str
    tool: str
    input: str
    result: str
    success: bool


@dataclass
class Finding:
    agent_id: str
    ts: str
    category: str
    details: str


SENSITIVE_KEYWORDS = [
    "/etc/passwd",
    "secret",
    "api_key",
    "token",
    "credentials",
]


def load_actions(path: str) -> List[Action]:
    out: List[Action] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            out.append(
                Action(
                    ts=obj.get("ts", ""),
                    agent_id=obj.get("agent_id", ""),
                    tool=obj.get("tool", ""),
                    input=obj.get("input", ""),
                    result=obj.get("result", ""),
                    success=bool(obj.get("success", True)),
                )
            )
    return out


def analyse(actions: List[Action]) -> List[Finding]:
    findings: List[Finding] = []
    failures_by_agent: Dict[str, int] = {}

    for a in actions:
        if not a.success:
            failures_by_agent[a.agent_id] = failures_by_agent.get(a.agent_id, 0) + 1
            if failures_by_agent[a.agent_id] >= 3:
                findings.append(
                    Finding(
                        agent_id=a.agent_id,
                        ts=a.ts,
                        category="repeated_failures",
                        details=f"Agent had {failures_by_agent[a.agent_id]} failed tool calls in a row.",
                    )
                )

        lower_input = a.input.lower()
        if any(k in lower_input for k in SENSITIVE_KEYWORDS):
            findings.append(
                Finding(
                    agent_id=a.agent_id,
                    ts=a.ts,
                    category="sensitive_access_attempt",
                    details=f"Tool {a.tool} called with potentially sensitive reference in input.",
                )
            )

        if a.tool == "http" and ("http://" in lower_input or "https://" in lower_input):
            findings.append(
                Finding(
                    agent_id=a.agent_id,
                    ts=a.ts,
                    category="external_call",
                    details="Agent attempted an HTTP call  review if this is expected.",
                )
            )

    return findings


def write_report(findings: List[Finding], md_path: str, json_path: str) -> None:
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump([asdict(fnd) for fnd in findings], f, indent=2)

    with open(md_path, "w", encoding="utf-8") as f:
        f.write("# AI agent behavior audit report\n\n")
        f.write(f"* Total findings: {len(findings)}\n\n")
        for fnd in findings:
            f.write(f"- [{fnd.agent_id}] {fnd.ts}  {fnd.category}  {fnd.details}\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's AI agent behavior auditor")
    parser.add_argument("--log", required=True, help="JSONL log of agent actions")
    parser.add_argument("--out-prefix", default="agent_audit", help="Prefix for output files")
    args = parser.parse_args()

    actions = load_actions(args.log)
    findings = analyse(actions)
    md_path = f"{args.out_prefix}_report.md"
    json_path = f"{args.out_prefix}_findings.json"
    write_report(findings, md_path, json_path)
    print(f"Analysed {len(actions)} actions  found {len(findings)} findings.")
    print(f"Wrote report to {md_path}")


if __name__ == "__main__":
    main()
