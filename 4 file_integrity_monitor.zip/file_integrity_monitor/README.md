
# File Integrity Monitoring Tool

I built this small project to practise thinking like a defender and to have a simple tool that tells me when important files have changed.

It works by taking a **baseline snapshot** of a folder and later comparing the current state to that baseline.  
If any files were added, removed, or modified, the tool prints a clear report.

---

## What this tool does

- Walks through a directory
- Calculates a SHA 256 hash for every file
- Saves a baseline snapshot as a JSON file
- Later re scans the same directory and compares it to the baseline
- Reports
  - new files
  - deleted files
  - modified files
  - unchanged file count

This is a simplified version of what file integrity monitoring systems do as part of host based security.

---

## Project structure

```text
file_integrity_monitor/
* README.md
* requirements.txt
* fim.py              main script with two commands  init and scan
```

The baseline is stored as a JSON file (by default `baseline.json`) that you keep in a safe place.

---

## Installation

Create and activate a virtual environment inside the project folder.

```bash
python3 -m venv venv
source venv/bin/activate          # Windows  venv\Scripts\activate
```

Install dependencies (this project only uses the Python standard library, so this is mostly for consistency).

```bash
pip install -r requirements.txt
```

---

## Usage

### 1. Create a baseline snapshot

Choose a directory you want to monitor, for example a configuration folder or a code project.

```bash
python fim.py init /path/to/folder
```

This will

- walk through the folder
- calculate hashes and metadata
- save a `baseline.json` file in the current directory

You can change the baseline file name with

```bash
python fim.py init /path/to/folder --baseline my_baseline.json
```

### 2. Scan for changes

Later, run a scan against the same folder.

```bash
python fim.py scan /path/to/folder
```

or, if you used a custom baseline file

```bash
python fim.py scan /path/to/folder --baseline my_baseline.json
```

Example output

```text
[info] Loaded baseline from baseline.json
[info] Scanning /path/to/folder
[info] Files unchanged  42
[warn] Modified files   2
  M  config/settings.yaml
  M  src/security_rules.json
[warn] New files        1
  +  logs/new_log.txt
[warn] Deleted files    1
  -  old_config/legacy.conf
```

This gives a quick overview of what has changed since the last snapshot.

---

## How this relates to cyber security

File integrity monitoring is a classic defensive technique.  
It helps detect

- unexpected changes to configuration files
- suspicious modifications of scripts or binaries
- accidental or malicious deletions

By building a small version myself I get to understand

- how hashes can be used as fingerprints for files
- how baselines and comparisons work under the hood
- how security tools can be both simple and useful

This project is intentionally compact, but it shows the mindset of checking for changes and documenting them clearly.
