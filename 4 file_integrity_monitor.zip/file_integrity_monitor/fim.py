
import argparse
import hashlib
import json
import os
from pathlib import Path
from typing import Dict, Tuple


def hash_file(path: Path, chunk_size: int = 65536) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def build_snapshot(root: Path) -> Dict[str, Dict[str, float]]:
    snapshot: Dict[str, Dict[str, float]] = {}
    for dirpath, dirnames, filenames in os.walk(root):
        dirpath_p = Path(dirpath)
        for name in filenames:
            full_path = dirpath_p / name
            if not full_path.is_file():
                continue
            rel_path = str(full_path.relative_to(root))
            try:
                stat = full_path.stat()
                file_hash = hash_file(full_path)
            except (OSError, PermissionError):
                continue
            snapshot[rel_path] = {
                "sha256": file_hash,
                "size": float(stat.st_size),
                "mtime": float(stat.st_mtime),
            }
    return snapshot


def save_snapshot(snapshot: Dict[str, Dict[str, float]], baseline_path: Path) -> None:
    with baseline_path.open("w", encoding="utf-8") as f:
        json.dump(snapshot, f, indent=2)


def load_snapshot(baseline_path: Path) -> Dict[str, Dict[str, float]]:
    with baseline_path.open("r", encoding="utf-8") as f:
        return json.load(f)


def compare_snapshots(
    baseline: Dict[str, Dict[str, float]],
    current: Dict[str, Dict[str, float]],
) -> Tuple[Dict[str, Dict[str, float]], Dict[str, Dict[str, float]], Dict[str, Dict[str, float]], int]:
    modified = {}
    new_files = {}
    deleted_files = {}
    unchanged_count = 0

    for rel, info in current.items():
        if rel not in baseline:
            new_files[rel] = info
        else:
            if info["sha256"] != baseline[rel]["sha256"]:
                modified[rel] = info
            else:
                unchanged_count += 1

    for rel, info in baseline.items():
        if rel not in current:
            deleted_files[rel] = info

    return modified, new_files, deleted_files, unchanged_count


def cmd_init(args) -> None:
    root = Path(args.path).resolve()
    baseline_path = Path(args.baseline)
    if not root.is_dir():
        raise SystemExit(f"Path is not a directory  {root}")

    print(f"[info] Creating baseline for {root}")
    snapshot = build_snapshot(root)
    save_snapshot(snapshot, baseline_path)
    print(f"[info] Baseline saved to {baseline_path}  files recorded  {len(snapshot)}")


def cmd_scan(args) -> None:
    root = Path(args.path).resolve()
    baseline_path = Path(args.baseline)
    if not root.is_dir():
        raise SystemExit(f"Path is not a directory  {root}")
    if not baseline_path.is_file():
        raise SystemExit(f"Baseline file does not exist  {baseline_path}")

    print(f"[info] Loaded baseline from {baseline_path}")
    baseline = load_snapshot(baseline_path)

    print(f"[info] Scanning {root}")
    current = build_snapshot(root)

    modified, new_files, deleted_files, unchanged_count = compare_snapshots(baseline, current)

    print(f"[info] Files unchanged  {unchanged_count}")
    print(f"[info] Modified files  {len(modified)}")
    print(f"[info] New files       {len(new_files)}")
    print(f"[info] Deleted files   {len(deleted_files)}")

    if modified:
        print("[warn] Modified files")
        for rel in sorted(modified.keys()):
            print(f"  M  {rel}")
    if new_files:
        print("[warn] New files")
        for rel in sorted(new_files.keys()):
            print(f"  +  {rel}")
    if deleted_files:
        print("[warn] Deleted files")
        for rel in sorted(deleted_files.keys()):
            print(f"  -  {rel}")


def main():
    parser = argparse.ArgumentParser(description="Simple file integrity monitoring tool")
    subparsers = parser.add_subparsers(dest="command", required=True)

    p_init = subparsers.add_parser("init", help="Create a baseline snapshot for a folder")
    p_init.add_argument("path", help="Folder to snapshot")
    p_init.add_argument(
        "--baseline",
        default="baseline.json",
        help="Where to store the baseline JSON (default baseline.json)",
    )
    p_init.set_defaults(func=cmd_init)

    p_scan = subparsers.add_parser("scan", help="Scan a folder and compare with an existing baseline")
    p_scan.add_argument("path", help="Folder to scan")
    p_scan.add_argument(
        "--baseline",
        default="baseline.json",
        help="Baseline JSON file to compare against (default baseline.json)",
    )
    p_scan.set_defaults(func=cmd_scan)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
