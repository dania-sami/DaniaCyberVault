import argparse
from datetime import datetime
from scapy.all import sniff

def handle_packet(pkt):
    time_str = datetime.now().strftime("%H:%M:%S")
    src = pkt.src if hasattr(pkt, "src") else "?"
    dst = pkt.dst if hasattr(pkt, "dst") else "?"
    proto = pkt.summary().split()[0] if pkt.summary() else "PKT"

    print(f"[{time_str}] {proto} {src} -> {dst}")

def main():
    parser = argparse.ArgumentParser(description="Network Packet Sniffer by Dania")
    parser.add_argument("--iface", required=True, help="Interface to listen on, for example: eth0, wlan0, en0")
    parser.add_argument("--count", type=int, default=0, help="Number of packets to capture (0 = infinite)")
    parser.add_argument("--filter", default="", help="Optional BPF filter, for example: 'tcp', 'port 80'")
    args = parser.parse_args()

    print(f"[+] Sniffing on {args.iface}")
    if args.filter:
        print(f"[+] Filter: {args.filter}")
    if args.count > 0:
        print(f"[+] Packet count: {args.count}")
    else:
        print("[+] Packet count: unlimited (Ctrl+C to stop)")

    sniff(
        iface=args.iface,
        prn=handle_packet,
        filter=args.filter if args.filter else None,
        count=args.count if args.count > 0 else 0,
        store=False,
    )

if __name__ == "__main__":
    main()
