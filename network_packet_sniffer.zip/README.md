# Network Packet Sniffer

This is a small packet sniffer I use to see what is actually moving on the network.

The goal for me was not to recreate Wireshark, but to understand how packets look when they arrive and how to quickly inspect basic information directly in Python.

## Features

- Live capture of packets on a chosen interface
- Shows time, source, destination and protocol
- Optional BPF filter (for example: `tcp`, `port 80`, `host 192.168.1.10`)
- Uses `scapy` to keep things simple and readable

## Usage

Install `scapy` first:

```bash
pip install scapy
```

Run the sniffer (often with sudo depending on your system):

```bash
sudo python sniffer.py --iface eth0 --count 50 --filter "tcp"
```

### Arguments

- `--iface`   Network interface, for example: `eth0`, `wlan0`, `en0`
- `--count`   Number of packets to capture (default 0 means unlimited)
- `--filter`  Optional BPF filter string

## Why I built this

I like to actually see packets and not just rely on tools. Writing this helped me understand:
- What kind of traffic is normal on my own network
- How different protocols show up on the wire
- How easy it is to script small inspection tools in Python
