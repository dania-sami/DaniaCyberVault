import argparse
from collections import Counter
from scapy.all import rdpcap, Dot11, Dot11Deauth

def analyse_pcap(path: str):
    print(f"[+] Analysing capture: {path}\n")
    try:
        packets = rdpcap(path)
    except FileNotFoundError:
        print("[-] File not found")
        return
    except Exception as e:
        print(f"[-] Could not read pcap: {e}")
        return

    deauth_flows = Counter()

    for pkt in packets:
        if pkt.haslayer(Dot11Deauth) and pkt.haslayer(Dot11):
            dot11 = pkt[Dot11]
            src = dot11.addr2 or "unknown"
            dst = dot11.addr1 or "unknown"
            deauth_flows[(src, dst)] += 1

    if not deauth_flows:
        print("[+] No deauthentication frames found.")
        return

    print("[+] Deauthentication summary:")
    for (src, dst), count in deauth_flows.most_common():
        print(f"    {src} -> {dst}  count={count}")

    # Simple heuristic: if any source sends 50+ deauth frames, flag it
    per_source = Counter()
    for (src, _dst), count in deauth_flows.items():
        per_source[src] += count

    print()
    for src, total in per_source.most_common():
        if total >= 50:
            print(f"[!] High number of deauth frames from {src} (total={total}, possible attack)")

def main():
    parser = argparse.ArgumentParser(description="WiFi Deauthentication Detection Demo by Dania")
    parser.add_argument("--pcap", required=True, help="Path to pcap file with 802.11 captures")
    args = parser.parse_args()
    analyse_pcap(args.pcap)

if __name__ == "__main__":
    main()
