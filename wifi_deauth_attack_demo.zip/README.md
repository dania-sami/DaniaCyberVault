# WiFi Deauthentication Attack Demo (Detector)

Hi, I am Dania and this project is a small WiFi security demo focused on **detection**, not attacking.

Instead of sending any packets, this script looks at captured traffic and helps me spot possible deauthentication attacks in a PCAP file. It counts how many deauth frames show up and highlights bursts that look suspicious.

## What this project does

- Reads a `.pcap` file with 802.11 traffic
- Looks for deauthentication frames
- Groups them per source MAC and target MAC
- Prints a short summary that makes it easy to see if someone is trying to kick clients off a WiFi network

It is a simple way for me to connect theory about WiFi deauth attacks with real traces, without doing anything harmful on a live network.

## Requirements

- Python 3
- `scapy`

Install scapy like this:

```bash
pip install scapy
```

## Usage

```bash
python deauth_detector.py --pcap capture.pcap
```

Example output might look like this:

```text
[+] Analysing capture: capture.pcap

[+] Deauthentication summary:
    34:12:98:aa:bb:cc -> ff:ff:ff:ff:ff:ff  count=120
    34:12:98:aa:bb:cc -> 9c:d6:43:11:22:33  count=20

[!] High number of deauth frames from 34:12:98:aa:bb:cc (possible attack)
```

## Notes

- This script is for learning and blue team style analysis.
- I only use it with my own captures or lab material.
- There is no packet injection or jamming here, just offline analysis.
