
# Firmware Static Analyzer (Simulation Lab)

Hi, I am Dania and I built this project to practise **firmware static analysis** without needing vendor tools or real devices.

The idea is simple:

- treat a firmware image as a binary blob
- extract printable strings
- scan for:
  - unsafe C functions (like `strcpy`, `gets`, `sprintf`)
  - hard coded credentials and secrets (`password=`, `token`, `PRIVATE KEY`)
- generate a clear findings report

It is a small but realistic way to talk about firmware security reviews.

---

## What this project does

The main script is `analyze_firmware.py`. It:

1. Reads a firmware file (any binary or even a `.bin` demo file)
2. Extracts printable ASCII strings of length ≥ 4
3. Scans those strings for patterns such as:

   - **Unsafe C functions**
     - `strcpy`
     - `strcat`
     - `gets`
     - `sprintf`
     - `vsprintf`
     - `scanf`
     - `system(`
   - **Potential secrets**
     - `password`
     - `passwd`
     - `secret`
     - `api_key`
     - `token`
     - `PRIVATE KEY`
     - `BEGIN RSA PRIVATE KEY`

4. Prints all findings to the console and writes them to `data/findings.csv` with:

   - `kind` (unsafe_function / possible_secret)
   - `value` (matching string)
   - `offset` (byte offset of the string)
   - `detail` (short explanation)

I also include a tiny demo firmware file so you can run the tool immediately.

---

## Project structure

```text
firmware_static_analyzer/
  README.md
  requirements.txt        # empty, uses only Python standard library
  analyze_firmware.py
  demo_firmware.bin
  data/
```

---

## Installation

```bash
python3 -m venv venv
source venv/bin/activate          # Windows  venv\Scripts\activate
pip install -r requirements.txt
```

---

## Quick demo

From inside `firmware_static_analyzer`:

```bash
python analyze_firmware.py demo_firmware.bin
```

You will see findings printed and a CSV written to `data/findings.csv`.

To analyse another firmware image, just point the script to it:

```bash
python analyze_firmware.py /path/to/firmware.bin
```

---

## Why this project matters to me

When people talk about IoT and embedded security, this is exactly the kind of static triage they often start with.

With this project I can show that I:

- understand typical firmware risks (unsafe code, hard coded secrets)
- can write my own lightweight static analysis pipeline
- can produce clear, human readable findings

It is small by design but connects directly to real firmware review workflows.
