
import argparse
import csv
import os
import string
from pathlib import Path

DATA_DIR = Path("data")

UNSAFE_PATTERNS = [
    "strcpy",
    "strcat",
    "gets",
    "sprintf",
    "vsprintf",
    "scanf",
    "system(",
]

SECRET_PATTERNS = [
    "password",
    "passwd",
    "secret",
    "api_key",
    "token",
    "PRIVATE KEY",
    "BEGIN RSA PRIVATE KEY",
]

PRINTABLE = set(bytes(string.printable, "ascii"))


def extract_strings(data: bytes, min_len: int = 4):
    result = []
    current = bytearray()
    start_offset = None

    for i, b in enumerate(data):
        if b in PRINTABLE and b not in (0x0b, 0x0c):  # filter out vertical tab/formfeed
            if not current:
                start_offset = i
            current.append(b)
        else:
            if len(current) >= min_len:
                result.append((start_offset, current.decode("ascii", errors="ignore")))
            current = bytearray()
            start_offset = None

    if len(current) >= min_len and start_offset is not None:
        result.append((start_offset, current.decode("ascii", errors="ignore")))
    return result


def analyze(path: Path):
    DATA_DIR.mkdir(exist_ok=True)
    data = path.read_bytes()
    strings = extract_strings(data)

    findings = []
    for offset, s in strings:
        lower = s.lower()
        for pat in UNSAFE_PATTERNS:
            if pat in lower:
                findings.append(
                    {
                        "kind": "unsafe_function",
                        "value": s,
                        "offset": offset,
                        "detail": f"String contains unsafe function name '{pat}'",
                    }
                )
        for pat in SECRET_PATTERNS:
            if pat.lower() in lower:
                findings.append(
                    {
                        "kind": "possible_secret",
                        "value": s,
                        "offset": offset,
                        "detail": f"String may contain credential/secret pattern '{pat}'",
                    }
                )

    if not findings:
        print("[info] No suspicious patterns found for current rules.")
        return

    out_path = DATA_DIR / "findings.csv"
    with out_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["kind", "value", "offset", "detail"])
        writer.writeheader()
        for row in findings:
            writer.writerow(row)

    print(f"[info] Analyzed {path} ({len(data)} bytes)")
    print(f"[info] Extracted {len(strings)} printable strings")
    print(f"[info] Found {len(findings)} suspicious strings:")
    for row in findings[:20]:
        print(f"  [{row['kind']}] offset={row['offset']} value={row['value']!r}")
    if len(findings) > 20:
        print(f"  ... and {len(findings) - 20} more")
    print(f"[info] Findings written to {out_path}")


def main():
    parser = argparse.ArgumentParser(description="Firmware static analyzer (simple patterns)")
    parser.add_argument("firmware_path", help="Path to firmware image (binary file)")
    args = parser.parse_args()

    p = Path(args.firmware_path)
    if not p.is_file():
        raise SystemExit(f"Firmware file not found: {p}")

    analyze(p)


if __name__ == "__main__":
    main()
