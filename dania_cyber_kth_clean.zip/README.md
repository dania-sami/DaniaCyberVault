# Dania Cyber Security Portfolio

This project is an interactive page built to showcase Dania’s strengths for Cyber Security at KTH.

It includes:
• An interactive talking avatar
• Skill based storytelling
• Clean UI designed to show curiosity, responsibility and technical skill

