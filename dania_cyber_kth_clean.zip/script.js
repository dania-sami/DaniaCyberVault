// Talking avatar for KTH cyber security focus

const skillCards = document.querySelectorAll('.skill-card');
const avatarText = document.getElementById('avatar-text');
const voiceToggle = document.getElementById('voice-toggle');

let voiceOn = true;

// Messages Dania says for each strength
const messages = {
  mindset:
    "Hi, I am Dania. A security mindset for me means being curious and careful at the same time. I like to ask what could go wrong, how an attacker would think, and what simple steps would remove that opportunity before it reaches real users.",
  coding:
    "Hi, I am Dania. When I write code I try to design for safety from the start. I pay attention to input validation, clear separation of responsibilities and logging so that strange behaviour is easier to detect and understand.",
  cloud:
    "Hi, I am Dania. My background with cloud gives me a good base for security. I like to map threats to concrete controls in Azure and Amazon Web Services for identity, network separation and monitoring, while keeping a good balance between protection and usability.",
  incident:
    "Hi, I am Dania. When something goes wrong I try to stay calm and structured. I want to understand what happened, limit the impact, learn from it and improve the system so that the same situation is less likely to happen again.",
  crypto:
    "Hi, I am Dania. Cryptography for me is not only about formulas. It is about understanding which protocol fits which situation, how keys are handled and how small mistakes in implementation can change the real level of protection.",
  research:
    "Hi, I am Dania. I enjoy reading, testing and learning from experiments. I like to take a clear question, design a small study or lab around it and document the results in a way that others can follow and build on.",
  communication:
    "Hi, I am Dania. Communication is central in cyber security. I want leaders, teachers and students to understand what a risk really means, what their options are and which simple actions will make them safer in their daily work."
};

function getHtmlForMessage(messageKey) {
  const baseIntro = "<b>Hi, I am Dania.</b> ";
  const full = messages[messageKey] || messages.mindset;
  // Avoid repeating the greeting
  const cleaned = full.replace(/^Hi, I am Dania\.?\s*/i, "");
  return baseIntro + cleaned;
}

// Text to speech
function speak(text) {
  if (!voiceOn) return;
  if (!("speechSynthesis" in window)) {
    return;
  }
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.rate = 1.02;
  utterance.pitch = 1.02;
  utterance.lang = "en-US";
  window.speechSynthesis.speak(utterance);
}

// Handle strength card click
skillCards.forEach(card => {
  card.addEventListener("click", () => {
    skillCards.forEach(c => c.classList.remove("active"));
    card.classList.add("active");

    const key = card.getAttribute("data-skill");
    const plainText = messages[key] || messages.mindset;
    avatarText.innerHTML = getHtmlForMessage(key);
    speak(plainText);
  });
});

// Voice toggle button
if (voiceToggle) {
  voiceToggle.addEventListener("click", () => {
    voiceOn = !voiceOn;
    voiceToggle.setAttribute("aria-pressed", String(voiceOn));
    voiceToggle.textContent = voiceOn ? "🔊 Voice on" : "🔈 Voice muted";

    if (!voiceOn && "speechSynthesis" in window) {
      window.speechSynthesis.cancel();
    }
  });
}

// On first load, speak default active card once
window.addEventListener("load", () => {
  const activeCard = document.querySelector(".skill-card.active");
  if (!activeCard) return;
  const key = activeCard.getAttribute("data-skill") || "mindset";
  const text = messages[key];
  speak(text);
});