# IOC Merger (Indicators of Compromise)

This is a small script I use when I have multiple IOC lists that I want to merge into a single deduplicated set.

Each input CSV file can have:

- `type` (ip, domain, hash)
- `value`

The script takes several CSVs, merges them and writes a combined CSV with duplicates removed.

## Files

- `ioc_merger.py` – main script
- `ioc_list1.csv`, `ioc_list2.csv` – example input files

## Usage

```bash
python ioc_merger.py --out merged_iocs.csv ioc_list1.csv ioc_list2.csv
```
