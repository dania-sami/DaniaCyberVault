import argparse
import csv

def merge_iocs(out_path: str, in_paths: list):
    seen = set()
    merged = []

    for path in in_paths:
        with open(path, newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                t = row.get("type", "").strip()
                v = row.get("value", "").strip()
                if not t or not v:
                    continue
                key = (t, v)
                if key in seen:
                    continue
                seen.add(key)
                merged.append({"type": t, "value": v})

    with open(out_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["type", "value"])
        writer.writeheader()
        writer.writerows(merged)

    print(f"[+] Wrote {len(merged)} unique IOCs to {out_path}")

def main():
    parser = argparse.ArgumentParser(description="IOC Merger by Dania")
    parser.add_argument("--out", required=True, help="Output CSV path")
    parser.add_argument("inputs", nargs="+", help="Input IOC CSV files")
    args = parser.parse_args()
    merge_iocs(args.out, args.inputs)

if __name__ == "__main__":
    main()
