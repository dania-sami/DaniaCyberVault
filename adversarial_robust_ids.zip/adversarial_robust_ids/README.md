# Adversarial Robust IDS

Hi, I am Dania Sami 👋

Intrusion Detection Systems often look great on clean benchmark data, but real
attackers do not play fair. They can **slightly modify malicious traffic** to
try to fool ML based detectors.

In this project I built a small but complete pipeline to experiment with this
idea:

- create a synthetic network dataset
- train a baseline ML IDS
- generate simple adversarial variants of the attacks
- measure how badly the model breaks
- retrain with adversarial data and see if robustness improves

It is not meant to be a production NIDS, but a compact **research style lab**
that shows I understand both security and adversarial machine learning.

---

## What the project does

1. **Generate a toy network dataset**

   `src/generate_dataset.py` creates `data/dataset.csv` with features such as:

   - duration
   - packet_count
   - avg_packet_size
   - flag_syn
   - flag_rst
   - label (0 = normal, 1 = attack)

2. **Train a baseline IDS**

   `src/train_baseline.py` trains a `RandomForestClassifier` on this dataset
   and saves it to `models/baseline.joblib`.

3. **Generate adversarial samples**

   `src/generate_adversarial.py` loads the model and dataset, then adds small
   random noise to the numeric features of attack samples to simulate
   evasion-style perturbations. It writes `data/adversarial.csv`.

4. **Evaluate robustness**

   `src/evaluate_robustness.py` compares accuracy on:

   - the clean dataset
   - the adversarially perturbed dataset

   and writes the results into `reports/robustness_report.txt`.

The goal is to show that I can structure an experiment around **evasion
attacks** and **robustness**, not just train a classifier once.

---

## How to run

You need Python 3.10+.

```bash
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

pip install -r requirements.txt

python -m src.generate_dataset
python -m src.train_baseline
python -m src.generate_adversarial
python -m src.evaluate_robustness
```

Check the output in:

- `data/dataset.csv`
- `data/adversarial.csv`
- `reports/robustness_report.txt`

---

## Project structure

```text
adversarial_robust_ids/
  ├─ README.md
  ├─ requirements.txt
  ├─ data/
  │    ├─ dataset.csv
  │    └─ adversarial.csv
  ├─ models/
  │    └─ baseline.joblib
  ├─ reports/
  │    └─ robustness_report.txt
  └─ src/
       ├─ __init__.py
       ├─ config.py
       ├─ generate_dataset.py
       ├─ train_baseline.py
       ├─ generate_adversarial.py
       └─ evaluate_robustness.py
```

---

## Why this is useful for me

This project lets me talk about:

- how ML based IDS can be attacked
- why robustness testing matters
- what adversarial data looks like in practice

It also connects nicely with my other security projects, for example feeding
adversarial detection results into a SIEM or incident responder pipeline.
