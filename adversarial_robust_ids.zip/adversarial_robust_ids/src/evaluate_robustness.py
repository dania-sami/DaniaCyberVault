import joblib
import pandas as pd
from sklearn.metrics import accuracy_score

from .config import DATA_FILE, ADV_FILE, MODEL_FILE, REPORT_FILE


def main() -> None:
    df_clean = pd.read_csv(DATA_FILE)
    df_adv = pd.read_csv(ADV_FILE)

    X_clean = df_clean.drop(columns=["label"])
    y_clean = df_clean["label"]

    X_adv = df_adv.drop(columns=["label"])
    y_adv = df_adv["label"]

    clf = joblib.load(MODEL_FILE)

    y_pred_clean = clf.predict(X_clean)
    y_pred_adv = clf.predict(X_adv)

    acc_clean = accuracy_score(y_clean, y_pred_clean)
    acc_adv = accuracy_score(y_adv, y_pred_adv)

    lines = [
        "Adversarial robustness report:",
        f"Accuracy on clean data: {acc_clean:.3f}",
        f"Accuracy on adversarial data: {acc_adv:.3f}",
        "Note: a large drop indicates the model is vulnerable to simple perturbations.",
    ]

    REPORT_FILE.write_text("\n".join(lines), encoding="utf-8")
    print("\n".join(lines))
    print(f"Report written to {REPORT_FILE}")


if __name__ == "__main__":
    main()
