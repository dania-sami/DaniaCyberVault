from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_FILE = BASE_DIR / "data" / "dataset.csv"
ADV_FILE = BASE_DIR / "data" / "adversarial.csv"
MODEL_FILE = BASE_DIR / "models" / "baseline.joblib"
REPORT_FILE = BASE_DIR / "reports" / "robustness_report.txt"
