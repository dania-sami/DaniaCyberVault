import joblib
import numpy as np
import pandas as pd

from .config import DATA_FILE, ADV_FILE, MODEL_FILE


def main() -> None:
    df = pd.read_csv(DATA_FILE)
    clf = joblib.load(MODEL_FILE)

    X = df.drop(columns=["label"])
    y = df["label"]

    # Only perturb attack samples
    X_adv = X.copy()
    attack_idx = y == 1

    # Small random noise to numeric features
    eps = 0.2
    noise = np.random.normal(0, eps, size=X_adv[attack_idx].shape)
    X_adv.loc[attack_idx, :] = X_adv.loc[attack_idx, :].values + noise

    df_adv = X_adv.copy()
    df_adv["label"] = y

    df_adv.to_csv(ADV_FILE, index=False)
    print(f"Adversarial dataset written to {ADV_FILE} with shape {df_adv.shape}")


if __name__ == "__main__":
    main()
