import numpy as np
import pandas as pd

from .config import DATA_FILE


def main() -> None:
    rng = np.random.default_rng(42)

    n_normal = 500
    n_attack = 200

    # Normal traffic
    duration_n = rng.normal(30, 10, n_normal).clip(1, None)
    packets_n = rng.normal(50, 15, n_normal).clip(1, None)
    avg_size_n = rng.normal(500, 120, n_normal).clip(40, None)
    syn_n = rng.integers(0, 2, n_normal)
    rst_n = rng.integers(0, 2, n_normal)
    label_n = np.zeros(n_normal, dtype=int)

    # Attack traffic (e.g. scans or exfil)
    duration_a = rng.normal(5, 3, n_attack).clip(0.5, None)
    packets_a = rng.normal(200, 60, n_attack).clip(10, None)
    avg_size_a = rng.normal(900, 200, n_attack).clip(40, None)
    syn_a = np.ones(n_attack, dtype=int)
    rst_a = rng.integers(0, 2, n_attack)
    label_a = np.ones(n_attack, dtype=int)

    duration = np.concatenate([duration_n, duration_a])
    packets = np.concatenate([packets_n, packets_a])
    avg_size = np.concatenate([avg_size_n, avg_size_a])
    syn = np.concatenate([syn_n, syn_a])
    rst = np.concatenate([rst_n, rst_a])
    label = np.concatenate([label_n, label_a])

    df = pd.DataFrame(
        {
            "duration": duration,
            "packet_count": packets,
            "avg_packet_size": avg_size,
            "flag_syn": syn,
            "flag_rst": rst,
            "label": label,
        }
    )

    DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(DATA_FILE, index=False)
    print(f"Dataset written to {DATA_FILE} with shape {df.shape}")


if __name__ == "__main__":
    main()
