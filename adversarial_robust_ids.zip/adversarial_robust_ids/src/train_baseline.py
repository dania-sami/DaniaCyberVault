import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

from .config import DATA_FILE, MODEL_FILE, REPORT_FILE


def main() -> None:
    df = pd.read_csv(DATA_FILE)
    X = df.drop(columns=["label"])
    y = df["label"]

    X_train, X_val, y_train, y_val = train_test_split(
        X, y, test_size=0.3, random_state=42, stratify=y
    )

    clf = RandomForestClassifier(
        n_estimators=120,
        random_state=42,
        class_weight="balanced",
    )
    clf.fit(X_train, y_train)

    y_pred = clf.predict(X_val)
    acc = accuracy_score(y_val, y_pred)

    MODEL_FILE.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(clf, MODEL_FILE)

    REPORT_FILE.parent.mkdir(parents=True, exist_ok=True)
    with REPORT_FILE.open("w", encoding="utf-8") as f:
        f.write(f"Baseline validation accuracy: {acc:.3f}\n")

    print(f"Baseline model saved to {MODEL_FILE}")
    print(f"Baseline validation accuracy: {acc:.3f}")


if __name__ == "__main__":
    main()
