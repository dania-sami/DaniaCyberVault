# Directory Bruteforcer (Safe Path Finder)

This is a small directory bruteforcer I wrote to discover interesting paths on web applications where I have permission to test.

It sends simple GET requests for each path in a wordlist and reports responses that are not 404. It is light weight and safe enough for small targets and lab environments.

## Features

- Uses `requests` library
- Ignores 404 responses by default
- Includes a small default wordlist so the script runs immediately
- Clean console output, easy to screenshot or paste in notes

## Usage

```bash
python dir_bruteforce.py --url https://example.com --wordlist paths.txt
```

Example output:

```text
[+] Target: https://example.com
[+] Paths from: paths.txt

[200] /admin
[301] /blog
[403] /config
```

I only run this against sites I own or where I have explicit permission to test.
