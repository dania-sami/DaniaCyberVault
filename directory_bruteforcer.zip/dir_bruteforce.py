import argparse
import requests
from urllib.parse import urljoin

def brute_paths(base_url: str, wordlist_path: str, timeout: float = 5.0):
    print(f"[+] Target: {base_url}")
    print(f"[+] Paths from: {wordlist_path}\n")

    with open(wordlist_path) as f:
        for line in f:
            path = line.strip()
            if not path or path.startswith("#"):
                continue
            if not path.startswith("/"):
                path = "/" + path
            url = urljoin(base_url, path)
            try:
                r = requests.get(url, timeout=timeout, allow_redirects=False)
                if r.status_code != 404:
                    print(f"[{r.status_code}] {path}")
            except KeyboardInterrupt:
                print("\n[!] Stopped by user.")
                break
            except Exception:
                # Network errors etc. are ignored but could be logged
                continue

def main():
    parser = argparse.ArgumentParser(description="Directory Bruteforcer by Dania")
    parser.add_argument("--url", required=True, help="Base URL, for example: https://example.com")
    parser.add_argument("--wordlist", required=True, help="Path to wordlist with paths")
    args = parser.parse_args()
    brute_paths(args.url, args.wordlist)

if __name__ == "__main__":
    main()
