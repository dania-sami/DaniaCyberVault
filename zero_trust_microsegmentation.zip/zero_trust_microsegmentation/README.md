# Zero Trust Microsegmentation Simulator

Hi, I am Dania Sami 👋

Zero trust is a big topic in modern security, but it often stays very abstract.
In this project I wanted to **make it concrete** by building a small simulator.

The **Zero Trust Microsegmentation Simulator** lets me:

- define a tiny organisation network with users, services and devices
- define identity and context based policies
- simulate traffic between entities
- see which flows are allowed or blocked
- measure how policy changes reduce the **blast radius** of a compromise

This is not a real network appliance. It is a **teaching and reasoning tool**
that shows how a zero trust style policy engine can work.

---

## What this project does

1. **Models entities and policies**

   In `src/model.py` I model:

   - `Principal` (user or service identity)
   - `Workload` (an application or service in a segment)
   - `DeviceState` (healthy / compromised)
   - `PolicyRule` (who can talk to which workload under which conditions)

   All of this is in memory and kept intentionally simple.

2. **Simulates traffic flows**

   In `src/simulate.py` I define example scenarios, for example:

   - "Developer laptop to source code repo"
   - "Compromised intern laptop trying to talk to finance database"
   - "Backend service talking to database"

   The simulator asks the policy engine if each flow is allowed or denied and
   prints a small table of decisions.

3. **Shows blast radius with and without microsegmentation**

   By toggling between a relaxed "flat network" mode and a more strict zero
   trust policy set, I can see:

   - which flows would be allowed in a flat network
   - which flows are blocked once microsegmentation is applied

   The result is written to `reports/simulation.txt`.

---

## Quick start

You need Python 3.10 or newer.

```bash
# 1. Create and activate a virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt
```

Then run:

```bash
python -m src.simulate
```

You will see a table of traffic flows and whether they are allowed in:

- a flat network (no segmentation)
- a zero trust microsegmented network

And the same results are written to `reports/simulation.txt`.

---

## Project structure

```text
zero_trust_microsegmentation/
  ├─ README.md
  ├─ requirements.txt
  ├─ reports/
  │    └─ simulation.txt     # generated
  └─ src/
       ├─ __init__.py
       ├─ config.py
       ├─ model.py
       └─ simulate.py
```

---

## How I would extend this

For a bigger thesis or internal tool I would:

- add support for more attributes like device posture, location and time of day
- export the policy graph to a small web UI for visualisation
- import policies from a JSON or YAML file instead of hard coding them
- model simple attack paths and show how segmentation blocks movement

For me this project is a way to show that I understand **zero trust as a
practical policy problem**, not just buzzwords.
