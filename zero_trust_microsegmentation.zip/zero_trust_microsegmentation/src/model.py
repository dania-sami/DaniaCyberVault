from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import List


class DeviceHealth(str, Enum):
    HEALTHY = "healthy"
    COMPROMISED = "compromised"


@dataclass
class Principal:
    name: str
    role: str  # e.g. "developer", "finance", "intern", "service"


@dataclass
class Workload:
    name: str
    segment: str  # e.g. "frontend", "backend", "finance", "dev"
    sensitivity: str  # e.g. "low", "medium", "high"


@dataclass
class Context:
    principal: Principal
    device_health: DeviceHealth
    from_workload: Workload | None  # origin if service-to-service
    to_workload: Workload


@dataclass
class PolicyRule:
    description: str
    allowed_roles: List[str]
    allowed_segments: List[str]
    max_sensitivity: str  # highest sensitivity this rule is OK with
    require_healthy_device: bool

    def matches(self, ctx: Context) -> bool:
        if self.allowed_roles and ctx.principal.role not in self.allowed_roles:
            return False
        if self.allowed_segments and ctx.to_workload.segment not in self.allowed_segments:
            return False

        sensitivity_rank = {"low": 1, "medium": 2, "high": 3}
        if sensitivity_rank[ctx.to_workload.sensitivity] > sensitivity_rank[self.max_sensitivity]:
            return False

        if self.require_healthy_device and ctx.device_health != DeviceHealth.HEALTHY:
            return False

        return True


class PolicyEngine:
    def __init__(self, rules: List[PolicyRule]) -> None:
        self.rules = rules

    def decide(self, ctx: Context) -> bool:
        return any(rule.matches(ctx) for rule in self.rules)
