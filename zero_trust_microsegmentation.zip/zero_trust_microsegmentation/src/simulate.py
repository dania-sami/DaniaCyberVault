from __future__ import annotations

from dataclasses import dataclass
from typing import List

from .config import REPORTS_DIR
from .model import (
    Context,
    DeviceHealth,
    PolicyEngine,
    PolicyRule,
    Principal,
    Workload,
)


@dataclass
class FlowScenario:
    name: str
    principal: Principal
    device_health: DeviceHealth
    from_workload: Workload | None
    to_workload: Workload


def build_flat_policy() -> PolicyEngine:
    # Flat network: everything can talk to everything
    rule = PolicyRule(
        description="Flat allow all",
        allowed_roles=[],
        allowed_segments=[],
        max_sensitivity="high",
        require_healthy_device=False,
    )
    return PolicyEngine([rule])


def build_zero_trust_policy() -> PolicyEngine:
    rules: List[PolicyRule] = [
        PolicyRule(
            description="Developers can reach dev segment services from healthy devices",
            allowed_roles=["developer"],
            allowed_segments=["dev"],
            max_sensitivity="medium",
            require_healthy_device=True,
        ),
        PolicyRule(
            description="Finance role can reach finance DB from healthy devices",
            allowed_roles=["finance"],
            allowed_segments=["finance"],
            max_sensitivity="high",
            require_healthy_device=True,
        ),
        PolicyRule(
            description="Backend services can reach database tier",
            allowed_roles=["service"],
            allowed_segments=["db"],
            max_sensitivity="high",
            require_healthy_device=False,
        ),
    ]
    return PolicyEngine(rules)


def build_environment():
    dev_laptop = Principal(name="alice-laptop", role="developer")
    intern_laptop = Principal(name="intern-laptop", role="intern")
    finance_pc = Principal(name="finance-pc", role="finance")
    backend_service = Principal(name="backend-svc", role="service")

    workloads = {
        "git": Workload(name="git-server", segment="dev", sensitivity="medium"),
        "frontend": Workload(name="frontend-app", segment="frontend", sensitivity="low"),
        "db": Workload(name="customer-db", segment="db", sensitivity="high"),
        "finance": Workload(name="finance-db", segment="finance", sensitivity="high"),
    }

    scenarios: List[FlowScenario] = [
        FlowScenario(
            name="Developer pushing code to Git",
            principal=dev_laptop,
            device_health=DeviceHealth.HEALTHY,
            from_workload=None,
            to_workload=workloads["git"],
        ),
        FlowScenario(
            name="Compromised intern laptop probing finance DB",
            principal=intern_laptop,
            device_health=DeviceHealth.COMPROMISED,
            from_workload=None,
            to_workload=workloads["finance"],
        ),
        FlowScenario(
            name="Backend service reading customer DB",
            principal=backend_service,
            device_health=DeviceHealth.HEALTHY,
            from_workload=workloads["frontend"],
            to_workload=workloads["db"],
        ),
        FlowScenario(
            name="Finance user accessing finance DB from healthy PC",
            principal=finance_pc,
            device_health=DeviceHealth.HEALTHY,
            from_workload=None,
            to_workload=workloads["finance"],
        ),
        FlowScenario(
            name="Finance user accessing finance DB from compromised PC",
            principal=finance_pc,
            device_health=DeviceHealth.COMPROMISED,
            from_workload=None,
            to_workload=workloads["finance"],
        ),
    ]

    return scenarios


def main() -> None:
    flat_engine = build_flat_policy()
    zt_engine = build_zero_trust_policy()
    scenarios = build_environment()

    lines: List[str] = []
    header = f"{'Scenario':40} | {'Flat network':12} | {'Zero trust':12}"
    sep = "-" * len(header)
    print(header)
    print(sep)
    lines.append(header)
    lines.append(sep)

    for s in scenarios:
        ctx = Context(
            principal=s.principal,
            device_health=s.device_health,
            from_workload=s.from_workload,
            to_workload=s.to_workload,
        )
        flat_allowed = flat_engine.decide(ctx)
        zt_allowed = zt_engine.decide(ctx)

        flat_str = "ALLOW" if flat_allowed else "DENY"
        zt_str = "ALLOW" if zt_allowed else "DENY"

        row = f"{s.name:40} | {flat_str:12} | {zt_str:12}"
        print(row)
        lines.append(row)

    report_path = REPORTS_DIR / "simulation.txt"
    report_path.write_text("\n".join(lines), encoding="utf-8")
    print(f"\nSimulation written to {report_path}")


if __name__ == "__main__":
    main()
