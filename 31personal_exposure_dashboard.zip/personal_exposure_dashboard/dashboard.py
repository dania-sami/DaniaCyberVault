import argparse, hashlib, json

def weak_password_check(password):
    sha = hashlib.sha1(password.encode()).hexdigest()
    # fake partial check: if hash starts with '00'
    return sha.startswith("00")

def load_list(path):
    with open(path) as f: return [x.strip() for x in f if x.strip()]

def dummy_breach_lookup(item):
    # fake breach hit if item contains "test"
    return "test" in item.lower()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--emails",required=True)
    ap.add_argument("--usernames",required=True)
    ap.add_argument("--out",default="dashboard.md")
    ap.add_argument("--json",default="dashboard.json")
    a=ap.parse_args()

    emails=load_list(a.emails)
    users=load_list(a.usernames)

    results={"emails":{}, "usernames":{}}

    for e in emails:
        results["emails"][e]={"breached":dummy_breach_lookup(e)}

    for u in users:
        results["usernames"][u]={"exposed":dummy_breach_lookup(u)}

    with open(a.out,"w") as f:
        f.write("# Personal Exposure Dashboard\n\n")
        f.write("## Email Exposure\n")
        for e,v in results["emails"].items():
            f.write(f"* {e}: {'breached' if v['breached'] else 'clean'}\n")
        f.write("\n## Username Exposure\n")
        for u,v in results["usernames"].items():
            f.write(f"* {u}: {'exposed' if v['exposed'] else 'clean'}\n")

    with open(a.json,"w") as f: json.dump(results,f,indent=2)

if __name__=="__main__":
    main()
