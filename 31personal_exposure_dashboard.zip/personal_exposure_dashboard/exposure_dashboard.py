"""
Personal Exposure Dashboard – Dania's digital risk snapshot

Reads a JSON file of exposure records
aggregates per identity
and writes a Markdown report plus optional JSON summary
"""

import argparse
import json
from dataclasses import dataclass, asdict
from typing import List, Dict
from datetime import datetime


CURRENT_YEAR = datetime.utcnow().year


@dataclass
class ExposureRecord:
    source: str
    email: str
    username: str
    breach: str
    data_classes: List[str]
    password_hashed: bool
    password_salted: bool
    first_seen_year: int
    severity: float = 0.0


@dataclass
class IdentitySummary:
    identity: str
    kind: str  # email or username
    exposure_count: int
    max_severity: float
    total_severity: float


def load_records(path: str) -> List[ExposureRecord]:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    records: List[ExposureRecord] = []
    for obj in data:
        records.append(
            ExposureRecord(
                source=str(obj.get("source", "")),
                email=str(obj.get("email", "")),
                username=str(obj.get("username", "")),
                breach=str(obj.get("breach", "")),
                data_classes=list(obj.get("data_classes", [])),
                password_hashed=bool(obj.get("password_hashed", False)),
                password_salted=bool(obj.get("password_salted", False)),
                first_seen_year=int(obj.get("first_seen_year", CURRENT_YEAR)),
            )
        )
    return records


def score_record(rec: ExposureRecord) -> None:
    score = 0.0
    dc_lower = [d.lower() for d in rec.data_classes]

    if any("password" in d for d in dc_lower):
        score += 4.0
        if not rec.password_hashed:
            score += 2.0
        if not rec.password_salted:
            score += 1.0

    if any("phone" in d for d in dc_lower):
        score += 2.0
    if any("address" in d for d in dc_lower):
        score += 1.5
    if any("ip address" in d for d in dc_lower):
        score += 1.0

    if any("email" in d for d in dc_lower):
        score += 0.5
    if any("username" in d for d in dc_lower):
        score += 0.5

    age = max(0, CURRENT_YEAR - rec.first_seen_year)
    if age <= 2:
        score += 0.5  # treat newer exposures as slightly more urgent

    rec.severity = round(score, 2)


def aggregate_identities(records: List[ExposureRecord]) -> List[IdentitySummary]:
    by_identity: Dict[str, IdentitySummary] = {}

    def add(identity: str, kind: str, sev: float):
        if not identity:
            return
        key = f"{kind}:{identity}"
        if key not in by_identity:
            by_identity[key] = IdentitySummary(
                identity=identity,
                kind=kind,
                exposure_count=0,
                max_severity=0.0,
                total_severity=0.0,
            )
        s = by_identity[key]
        s.exposure_count += 1
        s.total_severity += sev
        if sev > s.max_severity:
            s.max_severity = sev

    for rec in records:
        add(rec.email, "email", rec.severity)
        add(rec.username, "username", rec.severity)

    summaries = list(by_identity.values())
    summaries.sort(key=lambda s: (s.total_severity, s.exposure_count), reverse=True)
    return summaries


def write_report(records: List[ExposureRecord], identities: List[IdentitySummary], out_path: str) -> None:
    with open(out_path, "w", encoding="utf-8") as f:
        f.write("# Personal exposure report\n\n")
        if not records:
            f.write("No exposure records were provided.\n")
            return

        f.write(f"Total exposure records: {len(records)}\n\n")
        f.write("## Identities by exposure\n\n")
        f.write("| Identity | Type | Exposures | Total score | Max severity |\n")
        f.write("|----------|------|-----------|-------------|--------------|\n")
        for s in identities:
            f.write(f"| `{s.identity}` | {s.kind} | {s.exposure_count} | {s.total_severity:.1f} | {s.max_severity:.1f} |\n")
        f.write("\n")

        f.write("## Highest severity breaches\n\n")
        top = sorted(records, key=lambda r: r.severity, reverse=True)[:10]
        if not top:
            f.write("No high severity breaches in the data.\n\n")
        else:
            for rec in top:
                f.write(f"### {rec.breach}\n\n")
                ident = rec.email or rec.username or "(identity unknown)"
                f.write(f"* Identity: `{ident}`\n")
                f.write(f"* Severity: `{rec.severity}`\n")
                f.write(f"* Data classes: {', '.join(rec.data_classes) or 'unknown'}\n")
                f.write(f"* First seen around: {rec.first_seen_year}\n")
                f.write("\n")

        f.write("## General recommendations\n\n")
        f.write("* Rotate passwords for accounts that appear in breaches with credential exposure.\n")
        f.write("* Make sure important email and identity provider accounts use strong MFA with security keys.\n")
        f.write("* Consider using a password manager to ensure unique passwords for each service.\n")
        f.write("* Be more careful with phishing on identities that show up in multiple breaches.\n")


def write_summary_json(records: List[ExposureRecord], identities: List[IdentitySummary], out_path: str) -> None:
    obj = {
        "records": [asdict(r) for r in records],
        "identities": [asdict(i) for i in identities],
    }
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2)


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's personal exposure dashboard")
    parser.add_argument("--data", required=True, help="Path to JSON file with exposure records")
    parser.add_argument("--out", default="exposure_report.md", help="Markdown report path")
    parser.add_argument("--json-out", help="Optional JSON output path for summary")
    args = parser.parse_args()

    records = load_records(args.data)
    for r in records:
        score_record(r)
    identities = aggregate_identities(records)
    write_report(records, identities, args.out)
    print(f"Wrote exposure report to {args.out}")
    if args.json_out:
        write_summary_json(records, identities, args.json_out)
        print(f"Wrote exposure summary JSON to {args.json_out}")


if __name__ == "__main__":
    main()
