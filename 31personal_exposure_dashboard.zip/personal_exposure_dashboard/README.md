# Personal Exposure Dashboard – Dania’s digital risk snapshot

Hi

I am Dania and this project is my little dashboard for personal digital exposure

There are many breach search services and OSINT tools out there
but I wanted something that takes the raw findings and turns them into a single clear picture for me

So this tool does not call any live breach APIs by itself
Instead it expects that I export or paste results from the services I use
into a simple JSON file
and then it builds a small report that answers

* which of my identities show up the most
* which data fields have been exposed  emails passwords usernames phone numbers
* which breaches are the most serious for me personally
* what my top action items are

## Input format

The dashboard expects a JSON file with a list of exposure records
Each record can look like this

{
  "source": "breach_service_export",
  "email": "dania@example.com",
  "username": "dania_dev",
  "breach": "ExampleForum 2018",
  "data_classes": ["Email addresses", "Passwords", "Usernames"],
  "password_hashed": true,
  "password_salted": true,
  "first_seen_year": 2019
}

Fields

* source  where the information came from  for my own tracking
* email  one of my email addresses if known
* username  one of my usernames if known
* breach  name or short label of the incident
* data_classes  list of exposed data types
* password_hashed  whether passwords were hashed according to the export
* password_salted  whether they were salted
* first_seen_year  approximate year I first saw this record in a service

I can merge outputs from multiple tools into this single file

## How the dashboard thinks about risk

For each record it computes a simple severity score based on

* whether credentials were involved
* whether phone or address data was exposed
* whether passwords were hashed or not
* how old the breach is

Then it aggregates per identity

* per email address
* per username

and builds a short narrative such as

* this email appears in 5 breaches with password exposure
* this username appears mainly in low risk forum leaks

The final Markdown report has

1 Overview of total records and identities
2 Table of identities ordered by overall exposure score
3 List of the highest severity breaches with suggested actions
4 Checklist style recommendations just for me

## How I run it

1 Optional create and activate a virtual environment

   python3 -m venv venv
   source venv_bin_activate

2 Install requirements

   pip install -r requirements.txt

3 Look at the example file

   examples_exposure_sample.json

4 Run the dashboard

   python exposure_dashboard.py \
       --data examples_exposure_sample.json \
       --out exposure_report.md \
       --json-out exposure_summary.json

Then I open exposure_report.md and I get a human readable summary of where I show up
and which accounts I should probably focus on first

## Important note

This project is intentionally offline and personal

* It does not scrape any sites
* It does not bypass any terms of service
* It assumes I have already and legitimately obtained the data about my own accounts

In a more advanced version I could imagine adding optional API integrations
but I would still keep the same privacy first mindset

