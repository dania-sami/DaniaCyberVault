from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, Any, List


SEVERITY_SCORES = {
    "LOW": 1,
    "MEDIUM": 2,
    "HIGH": 3,
    "CRITICAL": 4,
}


def load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> None:
    parser = argparse.ArgumentParser(description="SBOM-aware dependency risk explorer")
    parser.add_argument("--sbom", type=str, required=True, help="Path to SBOM JSON")
    parser.add_argument("--cves", type=str, required=True, help="Path to CVE snapshot JSON")
    args = parser.parse_args()

    sbom = load_json(Path(args.sbom))
    cves = load_json(Path(args.cves))

    components: List[Dict[str, Any]] = sbom.get("components", [])
    vuln_index = cves.get("vulnerabilities", [])

    print("Dependency Risk Report")
    print("-" * 60)
    for comp in components:
        name = comp.get("name")
        version = comp.get("version")
        matches = [
            v for v in vuln_index
            if v.get("name") == name and (v.get("version") == version or v.get("version") == "*")
        ]
        if not matches:
            print(f"{name} {version}: no known vulns in local snapshot.")
            continue

        max_sev_score = 0
        sev_labels = []
        for v in matches:
            sev = (v.get("severity") or "UNKNOWN").upper()
            sev_labels.append(sev)
            score = SEVERITY_SCORES.get(sev, 0)
            if score > max_sev_score:
                max_sev_score = score

        overall = "LOW"
        for label, thr in [("CRITICAL", 4), ("HIGH", 3), ("MEDIUM", 2), ("LOW", 1)]:
            if max_sev_score >= thr:
                overall = label
                break

        print(f"{name} {version}:")
        print(f"  vulns: {len(matches)} (severities: {', '.join(sev_labels)})")
        print(f"  overall risk: {overall}")
        print("-" * 60)


if __name__ == "__main__":
    main()
