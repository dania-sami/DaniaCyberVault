# SBOM-Aware Dependency Risk Explorer

Hi, I am Dania 👋

This project is my **SBOM risk explorer**:

- I parse a simple CycloneDX-style SBOM JSON.
- I cross-check components against a local CVE snapshot.
- I print a table of components with **severity and risk scores**.

It is a small but very concrete demo of **supply chain visibility and risk**.

## How to run

```bash
cd sbom_dependency_risk_explorer

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt

python -m src.explore --sbom data/sbom.json --cves data/cves.json
```

The script prints each component with known vulnerabilities and an overall risk score.
