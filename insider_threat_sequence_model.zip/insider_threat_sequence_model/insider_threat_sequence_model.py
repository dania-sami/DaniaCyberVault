"""
Insider Threat Sequence Model – Dania

Input: JSONL events:

{"ts":"2025-01-01T09:00:00","user":"alice","event":"login"}
{"ts":"2025-01-01T09:05:00","user":"alice","event":"privilege_change"}
{"ts":"2025-01-01T09:10:00","user":"alice","event":"data_export"}

The model looks for risky sequences defined in code and reports matches per user.
"""

import argparse
import json
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
from typing import List, Dict, Tuple

TS_FORMAT = "%Y-%m-%dT%H:%M:%S"


@dataclass
class UserEvent:
    ts: str
    user: str
    event: str


@dataclass
class SequenceMatch:
    user: str
    start_ts: str
    end_ts: str
    pattern_name: str
    events: List[str]


# Define a few simple insider patterns
# Each pattern is (name, sequence, max_duration_minutes)
PATTERNS: List[Tuple[str, List[str], int]] = [
    ("escalate_then_export", ["login", "privilege_change", "data_export"], 60),
    ("after_hours_export", ["login_after_hours", "data_export"], 120),
    ("mass_deletion", ["login", "bulk_delete"], 30),
]


def load_events(path: str) -> List[UserEvent]:
    events: List[UserEvent] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            events.append(
                UserEvent(
                    ts=obj.get("ts", ""),
                    user=obj.get("user", "unknown"),
                    event=obj.get("event", "unknown"),
                )
            )
    events.sort(key=lambda e: e.ts)
    return events


def parse_ts(ts: str) -> datetime:
    return datetime.strptime(ts, TS_FORMAT)


def tag_after_hours(events: List[UserEvent]) -> List[UserEvent]:
    tagged: List[UserEvent] = []
    for e in events:
        hour = parse_ts(e.ts).hour
        if e.event == "login" and (hour < 7 or hour > 19):
            tagged.append(UserEvent(ts=e.ts, user=e.user, event="login_after_hours"))
        else:
            tagged.append(e)
    tagged.sort(key=lambda e: e.ts)
    return tagged


def find_sequences(events: List[UserEvent]) -> List[SequenceMatch]:
    # group by user
    by_user: Dict[str, List[UserEvent]] = {}
    for e in events:
        by_user.setdefault(e.user, []).append(e)

    matches: List[SequenceMatch] = []

    for user, evs in by_user.items():
        evs.sort(key=lambda e: e.ts)
        # build list of event labels for sliding window
        for pattern_name, seq, max_minutes in PATTERNS:
            seq_len = len(seq)
            if seq_len == 0:
                continue
            for i in range(len(evs) - seq_len + 1):
                window = evs[i : i + seq_len]
                labels = [e.event for e in window]
                if labels == seq:
                    start_t = parse_ts(window[0].ts)
                    end_t = parse_ts(window[-1].ts)
                    if (end_t - start_t) <= timedelta(minutes=max_minutes):
                        matches.append(
                            SequenceMatch(
                                user=user,
                                start_ts=window[0].ts,
                                end_ts=window[-1].ts,
                                pattern_name=pattern_name,
                                events=labels,
                            )
                        )

    return matches


def write_outputs(matches: List[SequenceMatch], md_path: str, json_path: str) -> None:
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump([asdict(m) for m in matches], f, indent=2)

    with open(md_path, "w", encoding="utf-8") as f:
        f.write("# Insider threat sequence model report\n\n")
        f.write(f"* Matched sequences: {len(matches)}\n\n")
        if not matches:
            f.write("No risky sequences were matched with the current simple patterns.\n")
            return

        for m in matches:
            f.write(f"## {m.user} – {m.pattern_name}\n\n")
            f.write(f"* Window: {m.start_ts} → {m.end_ts}\n")
            f.write(f"* Events: {', '.join(m.events)}\n\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's insider threat sequence model")
    parser.add_argument("--events", default="example_events.jsonl", help="User events JSONL")
    parser.add_argument("--out-prefix", default="insider_seq", help="Output prefix")
    args = parser.parse_args()

    events = load_events(args.events)
    events = tag_after_hours(events)
    matches = find_sequences(events)
    md_path = f"{args.out_prefix}_report.md"
    json_path = f"{args.out_prefix}_matches.json"
    write_outputs(matches, md_path, json_path)
    print(f"Analysed {len(events)} user events  matches={len(matches)}")
    print(f"Wrote report to {md_path}")


if __name__ == "__main__":
    main()
