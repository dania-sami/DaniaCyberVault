# Insider Threat Sequence Model – Dania

Hi

I am Dania and this project focuses on insider style exfiltration patterns

Instead of single anomalies it looks at short sequences like login  privilege change  large file export and scores them as risky paths for each user

It is a simple sequence model that helps me talk about insider behaviour using explainable patterns instead of a black box
