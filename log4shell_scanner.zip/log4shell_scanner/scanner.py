
import argparse
import os
import re
from pathlib import Path
from typing import List, Dict

import pandas as pd
import xml.etree.ElementTree as ET

VULN_THRESHOLD = (2, 17, 0)  # treat < 2.17.0 as vulnerable


def parse_version(version: str):
    parts = re.split(r"[.-]", str(version))
    nums = []
    for p in parts[:3]:
        try:
            nums.append(int(p))
        except ValueError:
            nums.append(0)
    while len(nums) < 3:
        nums.append(0)
    return tuple(nums)


def is_vulnerable_version(version: str) -> bool:
    return parse_version(version) < VULN_THRESHOLD


def scan_pom(path: Path) -> List[Dict]:
    findings = []
    try:
        tree = ET.parse(path)
        root = tree.getroot()
    except Exception:
        return findings

    ns = ""
    if "}" in root.tag:
        ns = root.tag.split("}")[0] + "}"

    for dep in root.findall(f".//{ns}dependency"):
        group_id = (dep.find(f"{ns}groupId").text or "").lower() if dep.find(f"{ns}groupId") is not None else ""
        artifact_id = (dep.find(f"{ns}artifactId").text or "").lower() if dep.find(f"{ns}artifactId") is not None else ""
        version = dep.find(f"{ns}version").text if dep.find(f"{ns}version") is not None else None
        if not version:
            continue
        if "log4j" in group_id and artifact_id in ("log4j-core", "log4j-api"):
            if is_vulnerable_version(version):
                findings.append(
                    {
                        "path": str(path),
                        "kind": "DEPENDENCY",
                        "severity": "HIGH",
                        "detail": f"{artifact_id} version {version} is below 2.17.0",
                    }
                )
    return findings


def scan_gradle(path: Path) -> List[Dict]:
    findings = []
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return findings

    pattern = re.compile(r"log4j.*?:log4j-(core|api):([0-9][0-9a-zA-Z.\-+]*)", re.IGNORECASE)
    for m in pattern.finditer(text):
        artifact = f"log4j-{m.group(1)}"
        version = m.group(2)
        if is_vulnerable_version(version):
            findings.append(
                {
                    "path": str(path),
                    "kind": "DEPENDENCY",
                    "severity": "HIGH",
                    "detail": f"{artifact} version {version} is below 2.17.0",
                }
            )
    return findings


def scan_jars(path: Path) -> List[Dict]:
    findings = []
    name = path.name.lower()
    m = re.match(r"log4j-core-([0-9][0-9a-zA-Z.\-+]*)\.jar", name)
    if m:
        version = m.group(1)
        if is_vulnerable_version(version):
            findings.append(
                {
                    "path": str(path),
                    "kind": "JAR",
                    "severity": "HIGH",
                    "detail": f"jar name suggests vulnerable log4j-core version {version}",
                }
            )
    return findings


def scan_java_code(path: Path) -> List[Dict]:
    findings = []
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return findings

    patterns = ["JndiLookup", "ldap://", "java:comp/env"]
    if any(p in text for p in patterns):
        findings.append(
            {
                "path": str(path),
                "kind": "CODE",
                "severity": "MEDIUM",
                "detail": "file contains JndiLookup / ldap JNDI usage",
            }
        )
    return findings


def scan_root(root: Path) -> List[Dict]:
    all_findings: List[Dict] = []
    for dirpath, dirnames, filenames in os.walk(root):
        for fname in filenames:
            full = Path(dirpath) / fname
            lower = fname.lower()
            if lower == "pom.xml":
                all_findings.extend(scan_pom(full))
            elif lower == "build.gradle":
                all_findings.extend(scan_gradle(full))
            elif lower.endswith(".jar"):
                all_findings.extend(scan_jars(full))
            elif lower.endswith(".java"):
                all_findings.extend(scan_java_code(full))
    return all_findings


def main():
    parser = argparse.ArgumentParser(description="Log4Shell style vulnerability scanner (simulation)")
    parser.add_argument("root", help="Root folder with Java projects")
    parser.add_argument(
        "--output",
        default="findings.csv",
        help="CSV file to write findings (default findings.csv)",
    )
    args = parser.parse_args()

    root = Path(args.root)
    if not root.is_dir():
        raise SystemExit(f"Root path is not a directory: {root}")

    print(f"[info] Scanning root {root}")
    findings = scan_root(root)

    if not findings:
        print("[info] No Log4Shell-style issues found for current rules.")
        return

    for f in findings:
        prefix = "[warn]" if f["severity"] in ("HIGH", "MEDIUM") else "[info]"
        print(f"{prefix} [{f['kind']:<10}] {f['path']:<60} {f['detail']}")

    df = pd.DataFrame(findings)
    out_path = Path(args.output)
    df.to_csv(out_path, index=False)
    print()
    print(f"[info] Findings written to {out_path} ({len(df)} rows)")


if __name__ == "__main__":
    main()
