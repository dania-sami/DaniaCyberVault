
# Log4Shell Style Vulnerability Scanner (Simulation Lab)

Hi, I am Dania and I built this project to practise how dependency security scanners look for Log4Shell-style issues in Java projects.

Instead of scanning a whole organisation, this is a **small, safe simulation** that:

- walks a folder of sample Java projects
- looks for vulnerable Log4j versions in poms, Gradle files and jar names
- searches Java code for risky JNDI usage patterns
- generates a simple findings report

It is my way of showing that I understand CVEs, dependency versions and unsafe patterns, in a very concrete way.

---

## What this project does

Given a root folder, the scanner will:

1. Recursively search for Java project artefacts:
   - `pom.xml`
   - `build.gradle`
   - jar files in `libs/` or similar
   - `.java` source files

2. For each project it checks for Log4j-related risks:

   - **Vulnerable dependency versions**
     - `log4j-core` or `log4j-api` with version lower than 2.17.0
     - jar names like `log4j-core-2.14.1.jar` treated as vulnerable
   - **Suspicious JNDI usage in code**
     - references to `JndiLookup`
     - hard coded JNDI URIs like `ldap://` or `java:comp/env`

3. Writes a findings report:

   - human readable output in the terminal
   - `findings.csv` in the project root

Each finding contains: `path`, `kind`, `severity`, and a short `detail` message.

---

## Project structure

```text
log4shell_scanner/
  README.md
  requirements.txt
  scanner.py
  sample_projects/
    vulnerable_pom/pom.xml
    vulnerable_gradle/build.gradle
    shaded_libs/libs/log4j-core-2.14.1.jar   (dummy placeholder)
    safe_project/pom.xml
    jndi_usage/src/Main.java
```

I included a few sample projects that intentionally trigger findings so I can demonstrate the scanner easily.

---

## Installation

```bash
python3 -m venv venv
source venv/bin/activate           # Windows  venv\Scripts\activate
pip install -r requirements.txt
```

The only external dependency is `pandas` for a nice CSV output.

---

## Quick start with the sample projects

From inside `log4shell_scanner` run:

```bash
python scanner.py sample_projects
```

Example style of output:

```text
[info] Scanning root sample_projects
[warn] [DEPENDENCY] sample_projects/vulnerable_pom/pom.xml        log4j-core version 2.14.1 is below 2.17.0
[warn] [DEPENDENCY] sample_projects/vulnerable_gradle/build.gradle  log4j-core version 2.15.0 is below 2.17.0
[warn] [JAR]       sample_projects/shaded_libs/libs/log4j-core-2.14.1.jar  jar name suggests vulnerable log4j-core version 2.14.1
[warn] [CODE]      sample_projects/jndi_usage/src/Main.java       file contains JndiLookup / ldap JNDI usage

[info] Findings written to findings.csv (4 rows)
```

You can open `findings.csv` in Excel or any spreadsheet tool.

---

## How the checks work (simplified)

To keep this clean and explainable, I use simple rules.

- **Version checks**
  - If `groupId` contains `log4j` and `artifactId` is `log4j-core` or `log4j-api`
  - Parse the version string and compare it lexically as `major.minor.patch`
  - Anything below 2.17.0 is treated as vulnerable in this simulation

- **Jar name checks**
  - Look for jar names matching `log4j-core-X.Y.Z.jar`
  - Extract `X.Y.Z` and apply the same threshold

- **Code pattern checks**
  - Scan `.java` files for:
    - `JndiLookup`
    - `ldap://`
    - `java:comp/env`
  - Flag them as potential risky JNDI usage

This is not a full SCA engine, but it shows that I understand how Log4Shell-style scanners reason about dependencies and code.

---

## How I see this project

I wanted a project that lets me talk about:

- CVEs and vulnerable versions
- the difference between dependency level and code level findings
- and how to report issues in a clear way

From here the scanner could be extended with:

- more libraries and CVEs
- SBOM support
- integration into CI pipelines

But even in this small size, it already feels like a real security engineering tool.
