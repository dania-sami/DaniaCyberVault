"""
Social Engineering Simulation Platform  ethical awareness trainer

Reads a simple plan JSON file
and generates a CSV of simulated training emails
plus a Markdown campaign brief

This is strictly for internal training and must not be used for real attacks
"""

import argparse
import csv
import json
from dataclasses import dataclass
from typing import List, Dict


@dataclass
class Target:
    name: str
    department: str


def load_plan(path: str) -> Dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def build_targets(raw_targets: List[Dict]) -> List[Target]:
    return [Target(name=str(t.get("name", "Participant")), department=str(t.get("department", ""))) for t in raw_targets]


def subject_template(theme: str, difficulty: str) -> str:
    if theme == "password_reset":
        return "[Simulation] Security check on your account"
    if theme == "invoice":
        return "[Simulation] Finance approval awareness test"
    if theme == "file_share":
        return "[Simulation] File sharing and link safety exercise"
    return "[Simulation] Security awareness message"


def body_template(theme: str, difficulty: str, name: str, department: str) -> str:
    base_intro = f"Hi {name},\n\n"
    note = (
        "This message is part of an internal security awareness exercise. "
        "There is no real risk or urgency, the goal is to practice how to think when something looks unusual.\n\n"
    )

    if theme == "password_reset":
        core = (
            "Imagine you received a message that claimed your account password needs to be reset immediately. "
            "In a real situation you would not click any unexpected link. "
            "Instead you would go directly to the official portal or contact support.\n\n"
        )
    elif theme == "invoice":
        core = (
            "Imagine this message was asking you to approve an invoice that you did not expect. "
            "A safe response would be to verify the request through a trusted channel before taking any action.\n\n"
        )
    elif theme == "file_share":
        core = (
            "Imagine this message invited you to open a shared document from an unknown sender. "
            "You would first check if you recognise the context and avoid opening files from untrusted links.\n\n"
        )
    else:
        core = (
            "This exercise is about pausing for a moment when something feels a bit off in email. "
            "Small checks can prevent many incidents.\n\n"
        )

    closing = (
        "After this campaign your security team can walk through a short debrief together with you. "
        "You can ask questions and share what made you suspicious or what felt confusing.\n"
    )

    return base_intro + note + core + closing


def generate_emails(plan: Dict) -> List[Dict[str, str]]:
    targets = build_targets(plan.get("targets", []))
    themes = plan.get("themes", ["password_reset"])
    difficulty = str(plan.get("difficulty", "medium"))
    emails: List[Dict[str, str]] = []

    # simple rule  create one mail per target per theme
    for t in targets:
        for theme in themes:
            subject = subject_template(theme, difficulty)
            body = body_template(theme, difficulty, t.name, t.department)
            emails.append(
                {
                    "recipient_name": t.name,
                    "department": t.department,
                    "theme": theme,
                    "difficulty": difficulty,
                    "subject": subject,
                    "body": body,
                }
            )
    return emails


def write_emails_csv(emails: List[Dict[str, str]], path: str) -> None:
    if not emails:
        return
    fieldnames = list(emails[0].keys())
    with open(path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(emails)


def write_brief(plan: Dict, emails: List[Dict[str, str]], path: str) -> None:
    total = len(emails)
    themes_count: Dict[str, int] = {}
    for e in emails:
        themes_count[e["theme"]] = themes_count.get(e["theme"], 0) + 1

    with open(path, "w", encoding="utf-8") as f:
        f.write("# Social engineering awareness campaign brief\n\n")
        f.write(f"* Campaign name: {plan.get('campaign_name', 'unnamed campaign')}\n")
        f.write(f"* Difficulty: {plan.get('difficulty', 'medium')}\n")
        f.write(f"* Total simulated messages: {total}\n\n")

        f.write("## Messages by theme\n\n")
        for theme, count in themes_count.items():
            f.write(f"* {theme}: {count}\n")
        f.write("\n")

        if emails:
            sample = emails[0]
            f.write("## Example message\n\n")
            f.write(f"Subject: {sample['subject']}\n\n")
            f.write("Body:\n\n")
            f.write("```text\n")
            f.write(sample["body"])
            f.write("\n```\n\n")

        f.write("## Reflection questions for debrief\n\n")
        f.write("* What details in the messages made them look suspicious or unusual\n")
        f.write("* Which security habits helped participants feel more confident\n")
        f.write("* Are there processes we can simplify so that verifying requests is easier\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania s social engineering simulation platform")
    parser.add_argument("--plan", required=True, help="Path to JSON file with training plan")
    parser.add_argument("--out-prefix", default="sim_run", help="Prefix for output files")
    args = parser.parse_args()

    plan = load_plan(args.plan)
    emails = generate_emails(plan)

    csv_path = f"{args.out_prefix}_simulated_emails.csv"
    brief_path = f"{args.out_prefix}_campaign_brief.md"

    write_emails_csv(emails, csv_path)
    write_brief(plan, emails, brief_path)

    print(f"Wrote {len(emails)} simulated emails to {csv_path}")
    print(f"Wrote campaign brief to {brief_path}")


if __name__ == "__main__":
    main()
