# Social Engineering Simulation Platform with AI style Emails  Dania s awareness trainer

Hi

I am Dania and this project is a small simulation platform I use for social engineering awareness training

The goal is to help teams practice spotting suspicious messages in a safe way

This project does not send any real email on its own
It simply generates

* scenario descriptions
* example training messages that are clearly marked as simulations
* a simple schedule file that can be imported into internal tools

All of this is meant for internal education and practice
never for real world abuse

## Input format

The simulator reads a small JSON configuration file with

* a list of fictional or anonymised targets
* themes for the training such as
  * password reset awareness
  * invoice and finance checks
  * file sharing and link safety
* difficulty levels such as easy medium hard

For example `examples_training_plan.json` contains

{
  "targets": [
    {"name": "Alex", "department": "Finance"},
    {"name": "Sam", "department": "Engineering"}
  ],
  "themes": ["password_reset", "invoice", "file_share"],
  "difficulty": "medium",
  "campaign_name": "Quarterly awareness run"
}

## What the simulator generates

The script builds

1  `simulated_emails.csv`

   * one row per planned message
   * columns such as recipient name theme difficulty subject body

   The bodies are natural language templates that always include

   * a clear note that this is a simulation
   * hints that trainers can use in debrief sessions

2  `campaign_brief.md`

   * a human readable summary of the training run
   * how many messages per theme
   * example messages
   * reflection questions to ask participants

There is no integration with mail servers in this portfolio version
It is focused on content and structure

## How the email text is created

In a full platform this could be backed by an AI model
For this project I keep everything local and transparent

* a small library of templates for each theme and difficulty
* placeholders for names and departments
* a clear sentence in every message that reminds the reader
  that this is part of a company security awareness exercise

The idea is to keep the simulation realistic enough to practice
but still clearly educational and respectful

## How I run it

From the project root

1 optional create and activate a virtual environment

       python -m venv venv
       source venv_bin_activate

2 install requirements

       pip install -r requirements.txt

3 inspect the example plan

       examples_training_plan.json

4 generate a campaign

       python sim_platform.py \
           --plan examples_training_plan.json \
           --out-prefix runs_q1

This creates

* `runs_q1_simulated_emails.csv`
* `runs_q1_campaign_brief.md`

The CSV can be imported into internal tools or used by trainers
The Markdown brief is handy for debrief sessions or documentation

## Why I built this

Social engineering is still one of the biggest attack paths
and I think security culture has to be built gently and repeatedly

With this simulator I can show that I

* understand common social engineering themes
* think about ethics and clear separation from real email abuse
* can turn a short plan file into content and structure for a full awareness run
* care about debrief and learning not just scoring people

If I extend this in the future
I might add more templates more languages and better analytics
but this base already demonstrates the idea very clearly
