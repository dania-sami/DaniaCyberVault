
import json, argparse
from collections import defaultdict

def load_calls(path):
    out=[]
    with open(path,"r",encoding="utf-8") as f:
        for line in f:
            line=line.strip()
            if not line: continue
            out.append(json.loads(line))
    return out

def analyse(calls):
    attempts=defaultdict(lambda:{"count":0,"endpoints":set()})
    findings=[]
    for c in calls:
        cid=c.get("client","unknown")
        ep=c.get("endpoint","/")
        attempts[cid]["count"]+=1
        attempts[cid]["endpoints"].add(ep)

    for cid,data in attempts.items():
        reasons=[]
        if data["count"]>100:
            reasons.append("high_volume")
        if len(data["endpoints"])>30:
            reasons.append("enumeration_like")
        if reasons:
            findings.append({"client":cid,"count":data["count"],"unique_endpoints":len(data["endpoints"]), "reasons":reasons})
    return findings

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--log",required=True)
    p.add_argument("--out",default="abuse_report.json")
    a=p.parse_args()
    calls=load_calls(a.log)
    fin=analyse(calls)
    with open(a.out,"w",encoding="utf-8") as f:
        json.dump(fin,f,indent=2)
    print("Wrote",a.out)

if __name__=="__main__":
    main()
