"""
API Gateway Abuse Radar – Dania

Offline analysis of API gateway style logs.
Input format: JSONL where each line has at least

{
  "ts": "2025-01-01T10:00:00",
  "client_id": "web-app-1",
  "ip": "203.0.113.5",
  "method": "GET",
  "path": "/v1/items/123",
  "status": 200,
  "bytes": 1234
}
"""

import argparse
import json
from dataclasses import dataclass, asdict
from typing import List, Dict, Tuple
from collections import defaultdict


@dataclass
class LogEvent:
    ts: str
    client_id: str
    ip: str
    method: str
    path: str
    status: int
    bytes: int


@dataclass
class ClientAbuseScore:
    client_id: str
    ip_set: List[str]
    total_requests: int
    auth_failures: int
    distinct_404s: int
    large_responses: int
    score: int
    reasons: List[str]


def load_events(path: str) -> List[LogEvent]:
    events: List[LogEvent] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            events.append(
                LogEvent(
                    ts=obj.get("ts", ""),
                    client_id=str(obj.get("client_id", obj.get("ip", "unknown"))),
                    ip=str(obj.get("ip", "")),
                    method=str(obj.get("method", "")),
                    path=str(obj.get("path", "")),
                    status=int(obj.get("status", 0)),
                    bytes=int(obj.get("bytes", 0)),
                )
            )
    return events


def score_clients(events: List[LogEvent]) -> List[ClientAbuseScore]:
    by_client: Dict[str, List[LogEvent]] = defaultdict(list)
    ip_sets: Dict[str, set] = defaultdict(set)
    for e in events:
        by_client[e.client_id].append(e)
        if e.ip:
            ip_sets[e.client_id].add(e.ip)

    results: List[ClientAbuseScore] = []
    for client_id, evs in by_client.items():
        total = len(evs)
        auth_fail = 0
        paths_404 = set()
        large_resps = 0

        for e in evs:
            if e.status in (401, 403):
                # crude: anything under /login or /auth that fails counts harder
                if "/login" in e.path or "/auth" in e.path:
                    auth_fail += 2
                else:
                    auth_fail += 1
            if e.status == 404:
                paths_404.add(e.path)
            if e.bytes > 500_000:
                large_resps += 1

        score = 0
        reasons: List[str] = []

        if auth_fail >= 10:
            score += 3
            reasons.append("repeated_auth_failures")
        elif auth_fail >= 3:
            score += 1
            reasons.append("some_auth_failures")

        distinct_404s = len(paths_404)
        if distinct_404s >= 20:
            score += 3
            reasons.append("path_enumeration")
        elif distinct_404s >= 5:
            score += 1
            reasons.append("possible_path_discovery")

        if total >= 500:
            score += 3
            reasons.append("high_volume_client")
        elif total >= 100:
            score += 1
            reasons.append("busy_client")

        if large_resps >= 10:
            score += 2
            reasons.append("large_responses_maybe_scraping")

        results.append(
            ClientAbuseScore(
                client_id=client_id,
                ip_set=sorted(list(ip_sets[client_id])),
                total_requests=total,
                auth_failures=auth_fail,
                distinct_404s=distinct_404s,
                large_responses=large_resps,
                score=score,
                reasons=reasons,
            )
        )

    results.sort(key=lambda c: c.score, reverse=True)
    return results


def write_outputs(scores: List[ClientAbuseScore], md_path: str, json_path: str) -> None:
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump([asdict(s) for s in scores], f, indent=2)

    with open(md_path, "w", encoding="utf-8") as f:
        f.write("# API gateway abuse radar report\n\n")
        if not scores:
            f.write("No clients were found in the log.\n")
            return

        f.write("| client_id | score | total_requests | auth_failures | distinct_404s | reasons |\n")
        f.write("|-----------|-------|----------------|---------------|---------------|---------|\n")
        for s in scores:
            reasons = ", ".join(s.reasons) if s.reasons else ""
            f.write(
                f"| {s.client_id} | {s.score} | {s.total_requests} | {s.auth_failures} | {s.distinct_404s} | {reasons} |\n"
            )
        f.write("\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's API gateway abuse radar")
    parser.add_argument("--log", default="example_log.jsonl", help="API gateway log in JSONL format")
    parser.add_argument("--out-prefix", default="abuse_radar", help="Output prefix")
    args = parser.parse_args()

    events = load_events(args.log)
    scores = score_clients(events)
    md_path = f"{args.out_prefix}_report.md"
    json_path = f"{args.out_prefix}_scores.json"
    write_outputs(scores, md_path, json_path)
    print(f"Analysed {len(events)} events  clients={len(scores)}")
    print(f"Wrote report to {md_path}")


if __name__ == "__main__":
    main()
