# API Gateway Abuse Radar – Dania

Hi

I am Dania and this project is my small radar for weird behaviour at an API gateway

It reads JSONL request logs and scores each client for

* brute force style auth failures
* enumeration of many missing paths
* scraping  heavy high volume access

The idea is to quickly highlight risky clients in a human readable report without touching any real production system from this code
