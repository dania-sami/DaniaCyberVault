# VPN Traffic Visualizer

Hi, I am Dania and this tool helps me get a quick breakdown of VPN vs normal traffic in a pcap file.
