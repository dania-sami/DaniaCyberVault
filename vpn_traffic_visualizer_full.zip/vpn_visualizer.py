import argparse
from collections import Counter
from scapy.all import rdpcap, IP, UDP, TCP, ESP

def classify_packet(pkt):
    if not pkt.haslayer(IP):
        return "Other_nonIP"
    ip = pkt[IP]
    sport = getattr(ip.payload, "sport", None)
    dport = getattr(ip.payload, "dport", None)
    if pkt.haslayer(ESP):
        return "VPN_IPsec_ESP"
    if sport == 1194 or dport == 1194:
        return "VPN_OpenVPN"
    if sport == 51820 or dport == 51820:
        return "VPN_WireGuard"
    if pkt.haslayer(UDP) and ((sport and sport > 1024) or (dport and dport > 1024)):
        return "VPN_Generic_UDP"
    return "Other_IP"

def analyse(path):
    packets = rdpcap(path)
    counts = Counter(classify_packet(pkt) for pkt in packets)
    print("[+] Summary:")
    for k, v in counts.items():
        print(f"{k}: {v}")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pcap", required=True)
    args = ap.parse_args()
    analyse(args.pcap)

if __name__ == "__main__":
    main()
