# Inter Host Correlation Engine – Dania

Hi

I am Dania and this engine looks for lateral movement patterns by correlating events across hosts

It tracks user activity over time and flags fast jumps between hosts as potential movement paths

This is perfect for building intuition on how to connect many small login events into one attacker story
