"""
Inter-Host Correlation Engine – Dania

Reads JSONL events of the form:

{"ts": "...", "host": "host1", "user": "alice", "action": "login_success"}

and detects quick jumps of a user between hosts that might indicate lateral movement.
"""

import argparse
import json
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
from typing import List, Dict

TS_FORMAT = "%Y-%m-%dT%H:%M:%S"


@dataclass
class Event:
    ts: str
    host: str
    user: str
    action: str


@dataclass
class MovementPath:
    user: str
    from_host: str
    to_host: str
    first_ts: str
    second_ts: str
    delta_seconds: int
    reason: str


def parse_ts(ts: str) -> datetime:
    return datetime.strptime(ts, TS_FORMAT)


def load_events(path: str) -> List[Event]:
    evs: List[Event] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            evs.append(
                Event(
                    ts=obj["ts"],
                    host=obj.get("host", "unknown"),
                    user=obj.get("user", "unknown"),
                    action=obj.get("action", "other"),
                )
            )
    evs.sort(key=lambda e: e.ts)
    return evs


def detect_movements(events: List[Event], window_minutes: int = 10) -> List[MovementPath]:
    by_user: Dict[str, List[Event]] = {}
    for e in events:
        by_user.setdefault(e.user, []).append(e)

    results: List[MovementPath] = []
    window = timedelta(minutes=window_minutes)

    for user, evs in by_user.items():
        evs.sort(key=lambda e: e.ts)
        for i in range(len(evs) - 1):
            a = evs[i]
            b = evs[i + 1]
            if a.host == b.host:
                continue
            t1 = parse_ts(a.ts)
            t2 = parse_ts(b.ts)
            delta = t2 - t1
            if timedelta(0) <= delta <= window:
                reason = "user_moved_between_hosts_quickly"
                results.append(
                    MovementPath(
                        user=user,
                        from_host=a.host,
                        to_host=b.host,
                        first_ts=a.ts,
                        second_ts=b.ts,
                        delta_seconds=int(delta.total_seconds()),
                        reason=reason,
                    )
                )

    return results


def write_outputs(paths: List[MovementPath], md_path: str, json_path: str) -> None:
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump([asdict(p) for p in paths], f, indent=2)

    with open(md_path, "w", encoding="utf-8") as f:
        f.write("# Inter host correlation report\n\n")
        f.write(f"* Potential movement paths: {len(paths)}\n\n")
        for p in paths:
            f.write(
                f"- user {p.user} moved {p.from_host} → {p.to_host} in {p.delta_seconds}s "
                f"({p.first_ts} → {p.second_ts})  reason={p.reason}\n"
            )


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's inter host correlation engine")
    parser.add_argument("--events", default="example_events.jsonl", help="Events in JSONL format")
    parser.add_argument("--window-minutes", type=int, default=10, help="Max minutes between hops")
    parser.add_argument("--out-prefix", default="correlation", help="Output prefix")
    args = parser.parse_args()

    events = load_events(args.events)
    paths = detect_movements(events, window_minutes=args.window_minutes)
    md_path = f"{args.out_prefix}_report.md"
    json_path = f"{args.out_prefix}_paths.json"
    write_outputs(paths, md_path, json_path)
    print(f"Analysed {len(events)} events  movement_paths={len(paths)}")
    print(f"Wrote report to {md_path}")


if __name__ == "__main__":
    main()
