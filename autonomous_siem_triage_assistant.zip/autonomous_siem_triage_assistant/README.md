# Autonomous SIEM Triage Assistant – Dania

Hi

I am Dania and this project is my small triage assistant for SIEM alerts

It reads JSONL alerts and automatically groups them into incidents by host and time window then gives each incident a quick score and short summary

The idea is to practise how I would think when clustering noisy alerts into cleaner incidents before a human analyst reviews them
