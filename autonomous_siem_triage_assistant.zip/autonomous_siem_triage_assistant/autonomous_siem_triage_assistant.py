"""
Autonomous SIEM Triage Assistant – Dania

Reads a JSONL file with alerts and groups them into incidents by:

* host
* rolling time window
"""

import argparse
import json
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
from typing import List, Dict

TS_FORMAT = "%Y-%m-%dT%H:%M:%S"


@dataclass
class Alert:
    ts: str
    host: str
    source: str
    rule: str
    severity: int
    message: str


@dataclass
class Incident:
    id: int
    host: str
    start_ts: str
    end_ts: str
    alert_count: int
    max_severity: int
    rules: List[str]
    sources: List[str]
    summary: str


def parse_ts(ts: str) -> datetime:
    return datetime.strptime(ts, TS_FORMAT)


def load_alerts(path: str) -> List[Alert]:
    alerts: List[Alert] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            alerts.append(
                Alert(
                    ts=obj["ts"],
                    host=obj.get("host", "unknown"),
                    source=obj.get("source", ""),
                    rule=obj.get("rule", ""),
                    severity=int(obj.get("severity", 1)),
                    message=obj.get("message", ""),
                )
            )
    alerts.sort(key=lambda a: a.ts)
    return alerts


def group_incidents(alerts: List[Alert], window_minutes: int = 15) -> List[Incident]:
    incidents: List[Incident] = []
    if not alerts:
        return incidents

    current_id = 1
    window = timedelta(minutes=window_minutes)

    # group by host then by time window
    alerts_by_host: Dict[str, List[Alert]] = {}
    for a in alerts:
        alerts_by_host.setdefault(a.host, []).append(a)

    for host, host_alerts in alerts_by_host.items():
        host_alerts.sort(key=lambda a: a.ts)
        bucket: List[Alert] = []
        bucket_start: datetime = None  # type: ignore

        for a in host_alerts:
            t = parse_ts(a.ts)
            if not bucket:
                bucket = [a]
                bucket_start = t
                continue
            if t - bucket_start <= window:
                bucket.append(a)
            else:
                incidents.append(build_incident(current_id, host, bucket))
                current_id += 1
                bucket = [a]
                bucket_start = t

        if bucket:
            incidents.append(build_incident(current_id, host, bucket))
            current_id += 1

    return incidents


def build_incident(incident_id: int, host: str, alerts: List[Alert]) -> Incident:
    start_ts = alerts[0].ts
    end_ts = alerts[-1].ts
    alert_count = len(alerts)
    max_sev = max(a.severity for a in alerts)
    rules = sorted({a.rule for a in alerts if a.rule})
    sources = sorted({a.source for a in alerts if a.source})

    if max_sev >= 8 or alert_count > 10:
        summary = "High priority incident with many or high severity alerts."
    elif max_sev >= 5:
        summary = "Medium priority incident with notable alerts."
    else:
        summary = "Lower priority incident that still deserves a look."

    return Incident(
        id=incident_id,
        host=host,
        start_ts=start_ts,
        end_ts=end_ts,
        alert_count=alert_count,
        max_severity=max_sev,
        rules=rules,
        sources=sources,
        summary=summary,
    )


def write_outputs(incidents: List[Incident], md_path: str, json_path: str) -> None:
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump([asdict(i) for i in incidents], f, indent=2)

    with open(md_path, "w", encoding="utf-8") as f:
        f.write("# Autonomous SIEM triage incidents\n\n")
        f.write(f"* Total incidents: {len(incidents)}\n\n")
        for inc in incidents:
            f.write(f"## Incident {inc.id} on {inc.host}\n\n")
            f.write(f"* Time window: {inc.start_ts} → {inc.end_ts}\n")
            f.write(f"* Alerts: {inc.alert_count}\n")
            f.write(f"* Max severity: {inc.max_severity}\n")
            if inc.rules:
                f.write(f"* Rules: {', '.join(inc.rules)}\n")
            if inc.sources:
                f.write(f"* Sources: {', '.join(inc.sources)}\n")
            f.write(f"* Summary: {inc.summary}\n\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's autonomous SIEM triage assistant")
    parser.add_argument("--alerts", default="example_alerts.jsonl", help="Alerts in JSONL format")
    parser.add_argument("--window-minutes", type=int, default=15, help="Incident time window per host")
    parser.add_argument("--out-prefix", default="triage", help="Output prefix")
    args = parser.parse_args()

    alerts = load_alerts(args.alerts)
    incidents = group_incidents(alerts, window_minutes=args.window_minutes)
    md_path = f"{args.out_prefix}_incidents.md"
    json_path = f"{args.out_prefix}_incidents.json"
    write_outputs(incidents, md_path, json_path)
    print(f"Grouped {len(alerts)} alerts into {len(incidents)} incidents.")
    print(f"Wrote report to {md_path}")


if __name__ == "__main__":
    main()
