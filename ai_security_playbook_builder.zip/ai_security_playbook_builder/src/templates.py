from __future__ import annotations

from typing import Dict, Any


def base_playbook(incident_type: str) -> Dict[str, Any]:
    return {
        "metadata": {
            "name": f"{incident_type.title()} Incident Response Playbook",
            "owner": "SOC Team",
            "created_by": "Dania Sami",
            "severity": "high" if incident_type in {"ransomware", "webshell"} else "medium",
        },
        "steps": {
            "detection": [],
            "containment": [],
            "eradication": [],
            "recovery": [],
            "lessons_learned": [],
        },
    }


def ransomware() -> Dict[str, Any]:
    pb = base_playbook("ransomware")
    s = pb["steps"]
    s["detection"] = [
        "Identify suspicious encryption activity on file shares.",
        "Correlate EDR alerts about mass file modifications.",
        "Check for ransom notes on endpoints and servers.",
    ]
    s["containment"] = [
        "Isolate affected endpoints from the network.",
        "Disable compromised user accounts.",
        "Block known C2 domains and IPs at the firewall.",
    ]
    s["eradication"] = [
        "Remove malicious binaries and scheduled tasks.",
        "Rotate credentials used on affected systems.",
        "Hunt for persistence mechanisms (services, registry, cron).",
    ]
    s["recovery"] = [
        "Restore from last known-good backups.",
        "Verify integrity and functionality of restored systems.",
        "Gradually reconnect systems to the network with monitoring.",
    ]
    s["lessons_learned"] = [
        "Review backup coverage and RPO/RTO targets.",
        "Improve email and endpoint hardening for initial access vectors.",
        "Update detection rules based on indicators from this incident.",
    ]
    return pb


def phishing() -> Dict[str, Any]:
    pb = base_playbook("phishing")
    s = pb["steps"]
    s["detection"] = [
        "Identify reported phishing emails in the mail gateway.",
        "Search for similar emails across all mailboxes.",
        "Check for suspicious login activity from targeted users.",
    ]
    s["containment"] = [
        "Quarantine malicious emails.",
        "Block sender domains and URLs at the proxy.",
        "Force password reset for users who clicked or entered credentials.",
    ]
    s["eradication"] = [
        "Remove malicious add-ins, rules or OAuth grants.",
        "Clear unauthorized sessions from identity provider.",
    ]
    s["recovery"] = [
        "Restore any impacted mailboxes or files if needed.",
        "Re-enable access with stronger MFA policies.",
    ]
    s["lessons_learned"] = [
        "Update phishing simulations and user training.",
        "Refine URL and attachment scanning policies.",
    ]
    return pb


def credential_leak() -> Dict[str, Any]:
    pb = base_playbook("credential_leak")
    s = pb["steps"]
    s["detection"] = [
        "Confirm leak via threat intel or monitoring tools.",
        "Identify accounts and systems potentially impacted.",
    ]
    s["containment"] = [
        "Force immediate password resets for affected accounts.",
        "Invalidate API tokens and refresh tokens.",
        "Tighten conditional access policies temporarily.",
    ]
    s["eradication"] = [
        "Remove any backdoors or unauthorized access created using leaked credentials.",
        "Audit recent admin and high-privilege actions.",
    ]
    s["recovery"] = [
        "Re-issue new secrets and rotate keys.",
        "Restore normal access patterns with improved monitoring.",
    ]
    s["lessons_learned"] = [
        "Review secret management practices.",
        "Introduce passwordless or stronger MFA where possible.",
    ]
    return pb


def webshell() -> Dict[str, Any]:
    pb = base_playbook("webshell")
    s = pb["steps"]
    s["detection"] = [
            "Identify suspicious web requests and unusual URLs.",
            "Look for unexpected files or modified scripts on the web server.",
            "Check web server logs for command execution patterns.",
    ]
    s["containment"] = [
        "Isolate the web server from the internet if necessary.",
        "Block attacker IPs at WAF or firewall.",
        "Disable vulnerable functionality or endpoints.",
    ]
    s["eradication"] = [
        "Remove webshell files and any related malware.",
        "Patch the underlying vulnerability (RCE, upload bug, etc.).",
        "Rotate credentials used by the web application.",
    ]
    s["recovery"] = [
        "Restore clean web content from trusted backups if needed.",
        "Re-enable access behind WAF with tighter rules.",
    ]
    s["lessons_learned"] = [
        "Improve web application security testing.",
        "Enhance logging and WAF rules for early detection.",
    ]
    return pb


TEMPLATES = {
    "ransomware": ransomware,
    "phishing": phishing,
    "credential_leak": credential_leak,
    "webshell": webshell,
}
