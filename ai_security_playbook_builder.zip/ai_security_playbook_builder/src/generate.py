from __future__ import annotations

import argparse
from pathlib import Path

import yaml

from .templates import TEMPLATES


def main() -> None:
    parser = argparse.ArgumentParser(description="Security playbook generator")
    parser.add_argument(
        "--type",
        type=str,
        required=True,
        choices=sorted(TEMPLATES.keys()),
        help="Incident type to generate playbook for",
    )
    args = parser.parse_args()

    playbooks_dir = Path(__file__).resolve().parent.parent / "playbooks"
    playbooks_dir.mkdir(parents=True, exist_ok=True)

    pb = TEMPLATES[args.type]()
    out_path = playbooks_dir / f"{args.type}_playbook.yaml"
    with out_path.open("w", encoding="utf-8") as f:
        yaml.safe_dump(pb, f, sort_keys=False)

    print(f"Generated playbook for '{args.type}' at {out_path}")


if __name__ == "__main__":
    main()
