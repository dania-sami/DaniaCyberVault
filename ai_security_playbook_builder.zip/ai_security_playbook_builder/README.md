# AI-Inspired Security Playbook Builder (Template-Based)

Hi, I am Dania Sami 👋

In many SOCs, response playbooks live in PowerPoints or forgotten wikis.
I wanted a small, **developer-friendly playbook builder** that can generate
structured incident response playbooks as YAML based on an incident type.

I call it "AI-inspired" because the design is close to how I would plug in
a language model later, but the current implementation uses local templates
and logic so it is deterministic and easy to run anywhere.

---

## What this tool does

1. **Takes an incident type**

   For example:

   - `ransomware`
   - `phishing`
   - `credential_leak`
   - `webshell`

2. **Generates a YAML playbook**

   `src/generate.py` builds a playbook with sections:

   - metadata (name, owner, severity, created_by)
   - detection
   - containment
   - eradication
   - recovery
   - lessons_learned

   and writes it to `playbooks/<incident_type>_playbook.yaml`.

3. **Keeps everything transparent**

   All logic lives in `src/templates.py` where I define the patterns for
   each incident type.

---

## How to run

```bash
cd ai_security_playbook_builder

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt   # PyYAML only
```

### Generate a playbook

```bash
python -m src.generate --type ransomware
```

This will write:

```text
playbooks/ransomware_playbook.yaml
```

You can open it in any text editor, or feed it into other tooling.

---

## Project structure

```text
ai_security_playbook_builder/
  ├─ README.md
  ├─ requirements.txt
  ├─ playbooks/
  │    └─ (generated yaml files)
  └─ src/
       ├─ __init__.py
       ├─ templates.py
       └─ generate.py
```

---

## Why I built this

Incident response is as much about **process** as it is about tools.
This project shows that I can:

- think in structured steps (detect, contain, eradicate, recover, learn)
- encode this as data (YAML playbooks)
- build a foundation that could later be powered by an LLM for more dynamic content
