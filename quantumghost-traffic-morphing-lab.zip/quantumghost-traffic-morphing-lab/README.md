
# QuantumGhost Traffic Morphing Lab

QuantumGhost is my thinking space for traffic fingerprinting and morphing.

I do not capture or store real user traffic in this project. Instead I work
with abstract metrics that describe how predictable and unique a traffic
profile looks.

The goal is to answer a simple question: under a basic model, how easy would
it be for an observer to recognise or track this pattern, and what small
changes can we try.

## What this project does

* registers traffic profiles with
  * name
  * system type, for example `vpn` or `tor-bridge`
  * metadata such as provider or region
  * metrics like
    * `vpn_fingerprint_consistency`
    * `burstiness_score`
    * `packet_size_diversity`
    * `timing_randomness`
    * `cover_traffic_ratio`
* calculates
  * a deanonymisation risk score between zero and one hundred
  * a band such as `very_low_deanonymisation_risk` or `high_deanonymisation_risk`
  * a list of reasons that explain the score
  * a list of high level suggestions for morphing

All the logic is in `engine.py` and deliberately easy to follow.

## Project layout

```text
quantumghost-traffic-morphing-lab
└── backend
    ├── quantumghost_lab
    │   ├── __init__.py
    │   ├── engine.py  Traffic profile model and risk scoring
    │   └── main.py    FastAPI HTTP API
    ├── requirements.txt
    └── example_requests.http
```

## How I run it locally

From the backend folder

```bash
python -m venv .venv
source .venv/bin/activate        # On Windows I use .venv\Scripts\activate
pip install -r requirements.txt
uvicorn quantumghost_lab.main:app --reload --port 9912
```

Then I open

* http://localhost:9912/docs to create profiles and run assessments

## A story I like to walk through

I describe a VPN profile that looks very distinctive

```bash
curl -X POST http://localhost:9912/profiles   -H "Content-Type: application/json"   -d '{
    "name": "home-vpn-profile",
    "system_type": "vpn",
    "meta": {
      "provider": "example-vpn"
    },
    "metrics": {
      "vpn_fingerprint_consistency": 0.8,
      "burstiness_score": 0.7,
      "packet_size_diversity": 0.2,
      "timing_randomness": 0.3,
      "cover_traffic_ratio": 0.1
    }
  }'
```

Then I ask QuantumGhost for an assessment

```bash
curl -X POST "http://localhost:9912/assess?profile_id=1"
```

The answer gives me

* a deanonymisation risk score
* a band such as `high_deanonymisation_risk`
* reasons talking about strong fingerprint consistency and low diversity
* suggestions like adding padding, jitter and a little cover traffic

This gives me a concrete way to talk about traffic morphing ideas without
touching real flows.

## Future expansions

If I want to grow QuantumGhost later I can

* plug in metrics produced by offline traffic analysis tools
* experiment with different observer models
* connect this to a simple UI where I can tweak sliders live

Right now it already captures how I think about fingerprinting risk and
practical counter moves.
