
from dataclasses import dataclass
from typing import Dict, List


@dataclass
class Profile:
    id: int
    name: str
    system_type: str
    meta: Dict[str, str]
    metrics: Dict[str, float]


@dataclass
class MorphingAssessment:
    profile_id: int
    name: str
    deanonymisation_risk: float
    band: str
    suggestions: List[str]
    reasons: List[str]


class QuantumGhostBrain:
    """
    QuantumGhost is my lab for thinking about traffic fingerprinting and
    morphing.

    Instead of capturing real VPN flows, I model high level metrics that
    describe how unique and predictable traffic looks and then estimate how
    easy it would be for an observer to recognise or track it.
    """

    def __init__(self) -> None:
        self._next_id = 1
        self.profiles: Dict[int, Profile] = {}

    def register_profile(self, name: str, system_type: str, meta: Dict[str, str], metrics: Dict[str, float]) -> Profile:
        pid = self._next_id
        self._next_id += 1
        prof = Profile(
            id=pid,
            name=name,
            system_type=system_type,
            meta=meta,
            metrics=metrics,
        )
        self.profiles[pid] = prof
        return prof

    def assess(self, profile_id: int) -> MorphingAssessment:
        prof = self.profiles[profile_id]
        m = prof.metrics
        reasons: List[str] = []
        suggestions: List[str] = []
        risk = 0.0

        fingerprint_consistency = float(m.get("vpn_fingerprint_consistency", 0.0))
        burstiness = float(m.get("burstiness_score", 0.0))
        size_diversity = float(m.get("packet_size_diversity", 0.0))
        timing_randomness = float(m.get("timing_randomness", 0.0))
        cover_ratio = float(m.get("cover_traffic_ratio", 0.0))

        if fingerprint_consistency > 0.5:
            risk += (fingerprint_consistency - 0.5) * 60.0
            reasons.append("Connection fingerprint looks very stable and easy to match.")
            suggestions.append("Introduce small random variations in cipher suite and handshake patterns where safe.")
        if burstiness > 0.6:
            risk += (burstiness - 0.6) * 40.0
            reasons.append("Traffic bursts are highly distinctive.")
            suggestions.append("Use traffic shaping to smooth very sharp bursts.")
        if size_diversity < 0.3:
            risk += (0.3 - size_diversity) * 50.0
            reasons.append("Packet sizes are too uniform, which helps fingerprinting.")
            suggestions.append("Add padding or chunking so packet sizes are less predictable.")
        if timing_randomness < 0.4:
            risk += (0.4 - timing_randomness) * 50.0
            reasons.append("Timing patterns are very regular.")
            suggestions.append("Introduce controlled jitter on non critical flows.")

        if cover_ratio > 0.3:
            risk -= (cover_ratio - 0.3) * 40.0
            reasons.append("Some cover traffic is present, which helps hide patterns.")
            suggestions.append("Maintain or slightly increase cover traffic during sensitive sessions.")

        risk = max(0.0, min(100.0, risk))

        if risk >= 80.0:
            band = "high_deanonymisation_risk"
        elif risk >= 60.0:
            band = "elevated_deanonymisation_risk"
        elif risk >= 40.0:
            band = "moderate_deanonymisation_risk"
        elif risk >= 20.0:
            band = "low_deanonymisation_risk"
        else:
            band = "very_low_deanonymisation_risk"

        if not reasons:
            reasons.append("Metrics do not show strong fingerprinting risk drivers under this model.")
        if not suggestions:
            suggestions.append("Maintain current configuration and monitor research on traffic analysis attacks.")

        return MorphingAssessment(
            profile_id=prof.id,
            name=prof.name,
            deanonymisation_risk=round(risk, 2),
            band=band,
            suggestions=suggestions,
            reasons=reasons,
        )
