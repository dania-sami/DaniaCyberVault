
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Dict, List

from .engine import QuantumGhostBrain, Profile, MorphingAssessment


brain = QuantumGhostBrain()


class ProfileIn(BaseModel):
    name: str = Field(..., example="home-vpn-profile")
    system_type: str = Field(..., example="vpn")
    meta: Dict[str, str] = Field(default_factory=dict)
    metrics: Dict[str, float] = Field(
        default_factory=dict,
        description=(
            "Metrics like vpn_fingerprint_consistency, burstiness_score, packet_size_diversity, "
            "timing_randomness, cover_traffic_ratio"
        ),
    )


class ProfileOut(BaseModel):
    id: int
    name: str
    system_type: str
    meta: Dict[str, str]
    metrics: Dict[str, float]


class MorphingOut(BaseModel):
    profile_id: int
    name: str
    deanonymisation_risk: float
    band: str
    suggestions: List[str]
    reasons: List[str]


app = FastAPI(
    title="QuantumGhost Traffic Morphing Lab",
    version="0.1.0",
    description="My reasoning engine for traffic fingerprinting and morphing strategies.",
)


@app.post("/profiles", response_model=ProfileOut)
def register_profile(payload: ProfileIn) -> ProfileOut:
    prof: Profile = brain.register_profile(
        name=payload.name,
        system_type=payload.system_type,
        meta=payload.meta,
        metrics=payload.metrics,
    )
    return ProfileOut(
        id=prof.id,
        name=prof.name,
        system_type=prof.system_type,
        meta=prof.meta,
        metrics=prof.metrics,
    )


@app.post("/assess", response_model=MorphingOut)
def assess(profile_id: int) -> MorphingOut:
    if profile_id not in brain.profiles:
        raise HTTPException(status_code=404, detail="Profile not found")
    res: MorphingAssessment = brain.assess(profile_id)
    return MorphingOut(
        profile_id=res.profile_id,
        name=res.name,
        deanonymisation_risk=res.deanonymisation_risk,
        band=res.band,
        suggestions=res.suggestions,
        reasons=res.reasons,
    )
