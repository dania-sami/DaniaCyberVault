
# SkyWatch Drone Security Grid

SkyWatch Drone Security Grid is my lab project for thinking about drone
security in a structured way.

Instead of trying to jam real radio hardware and air space rules into one
demo I focus on the core idea. We look at clean telemetry points from a
flight and decide how risky that flight looks based on simple rules that
still feel realistic.

The engine takes

* latitude and longitude
* altitude and speed
* RF profile label
* optional pilot id

and combines that with simple no fly zone definitions to produce a score and
a list of reasons.

## What this project does

* lets me register rectangular no fly zones with a name
* accepts a list of telemetry points for a flight
* checks for
  * altitude above a common legal limit
  * high speed that might indicate aggressive manoeuvres
  * entry into any defined zone
  * missing pilot information
  * unknown RF profile labels
* calculates a score and assigns a level low, medium, high, or critical
* returns human readable reasons that match the score

All of this logic is visible in one file so it is easy to extend with more
domain knowledge later.

## Project layout

```text
skywatch-drone-security-grid
└── backend
    ├── skywatch_grid
    │   ├── __init__.py
    │   ├── engine.py  Telemetry model and scoring logic
    │   └── main.py    FastAPI HTTP API
    ├── requirements.txt
    └── example_requests.http
```

## How I run it locally

From the backend folder

```bash
python -m venv .venv
source .venv/bin/activate        # On Windows I use .venv\Scripts\activate
pip install -r requirements.txt
uvicorn skywatch_grid.main:app --reload --port 9706
```

Then I open

* http://localhost:9706/docs to try the endpoints

## A scenario I like to demo

First I register a no fly zone for example around a hospital or another
sensitive location.

```bash
curl -X POST http://localhost:9706/zones   -H "Content-Type: application/json"   -d '{
    "name": "hospital-zone",
    "min_lat": 59.3000,
    "max_lat": 59.3100,
    "min_lon": 18.0500,
    "max_lon": 18.0600
  }'
```

Then I send a small flight path that

* starts in the zone
* climbs above 120 meters
* briefly reaches a higher speed
* broadcasts an unknown RF profile
* loses pilot id for one point

```bash
curl -X POST http://localhost:9706/assess   -H "Content-Type: application/json"   -d '[
    {
      "timestamp": "2026-02-02T10:00:00Z",
      "drone_id": "drone-001",
      "lat": 59.3050,
      "lon": 18.0550,
      "altitude_m": 150.0,
      "speed_m_s": 18.0,
      "rf_signal": "standard",
      "pilot_id": "pilot-123"
    },
    {
      "timestamp": "2026-02-02T10:01:00Z",
      "drone_id": "drone-001",
      "lat": 59.3060,
      "lon": 18.0560,
      "altitude_m": 80.0,
      "speed_m_s": 30.0,
      "rf_signal": "unknown",
      "pilot_id": null
    }
  ]'
```

The response gives me a score, a level, and clear reasons that point to the
altitude violation, the entry into the zone, the speed, and the RF profile
concern.

## Why I like SkyWatch

Drone security touches many disciplines radio, aviation rules, privacy, and
critical infrastructure protection. With SkyWatch I have a compact project
that lets me talk about these topics using data structures and code without
needing hardware in the room.

It is a good starting point for future experiments such as

* connecting to real telemetry feeds
* drawing flight paths and zones on a map
* alerting when flights cross into sensitive areas.
