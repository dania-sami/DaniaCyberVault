"""SkyWatch Drone Security Grid backend package."""
