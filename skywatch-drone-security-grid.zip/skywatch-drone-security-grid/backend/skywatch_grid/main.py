
from fastapi import FastAPI
from pydantic import BaseModel, Field
from typing import List

from .engine import SkyWatchBrain, TelemetryPoint, FlightAssessment


brain = SkyWatchBrain()


class NoFlyZoneIn(BaseModel):
    name: str = Field(..., example="hospital-zone")
    min_lat: float
    max_lat: float
    min_lon: float
    max_lon: float


class TelemetryIn(BaseModel):
    timestamp: str = Field(..., example="2026-02-02T10:00:00Z")
    drone_id: str = Field(..., example="drone-001")
    lat: float
    lon: float
    altitude_m: float
    speed_m_s: float
    rf_signal: str = Field(..., example="standard" )
    pilot_id: str | None = Field(None, example="pilot-123")


class AssessmentOut(BaseModel):
    drone_id: str
    score: float
    level: str
    reasons: List[str]


app = FastAPI(
    title="SkyWatch Drone Security Grid",
    version="0.1.0",
    description="My drone telemetry assessment core for lab style scenarios.",
)


@app.post("/zones")
def add_zone(payload: NoFlyZoneIn) -> dict:
    brain.add_no_fly_zone(payload.name, payload.min_lat, payload.max_lat, payload.min_lon, payload.max_lon)
    return {"status": "ok"}


@app.post("/assess", response_model=AssessmentOut)
def assess(points: List[TelemetryIn]) -> AssessmentOut:
    parsed: List[TelemetryPoint] = []
    from datetime import datetime

    for p in points:
        ts = datetime.fromisoformat(p.timestamp.replace("Z", "+00:00"))
        parsed.append(
            TelemetryPoint(
                timestamp=ts,
                drone_id=p.drone_id,
                lat=p.lat,
                lon=p.lon,
                altitude_m=p.altitude_m,
                speed_m_s=p.speed_m_s,
                rf_signal=p.rf_signal,
                pilot_id=p.pilot_id,
            )
        )
    assessment: FlightAssessment = brain.assess(parsed)
    return AssessmentOut(
        drone_id=assessment.drone_id,
        score=assessment.score,
        level=assessment.level,
        reasons=assessment.reasons,
    )
