
from dataclasses import dataclass
from typing import List
from datetime import datetime


@dataclass
class TelemetryPoint:
    timestamp: datetime
    drone_id: str
    lat: float
    lon: float
    altitude_m: float
    speed_m_s: float
    rf_signal: str
    pilot_id: str | None


@dataclass
class FlightAssessment:
    drone_id: str
    score: float
    level: str
    reasons: List[str]


class SkyWatchBrain:
    """
    This is my lab friendly drone security brain.

    It looks at small telemetry summaries for a drone flight and checks for
    signals such as

    * violation of altitude limits
    * fast approach into a protected zone
    * missing pilot or registration
    * strange RF profile label

    The result is a simple score and text reasons that can be used in a report
    or a live monitoring dashboard.
    """

    def __init__(self) -> None:
        self.no_fly_zones = []  # each zone is (name, min_lat, max_lat, min_lon, max_lon)

    def add_no_fly_zone(self, name: str, min_lat: float, max_lat: float, min_lon: float, max_lon: float) -> None:
        self.no_fly_zones.append((name, min_lat, max_lat, min_lon, max_lon))

    def _in_zone(self, lat: float, lon: float) -> str | None:
        for name, min_lat, max_lat, min_lon, max_lon in self.no_fly_zones:
            if min_lat <= lat <= max_lat and min_lon <= lon <= max_lon:
                return name
        return None

    def assess(self, points: List[TelemetryPoint]) -> FlightAssessment:
        if not points:
            return FlightAssessment(drone_id="unknown", score=0.0, level="low", reasons=["No telemetry provided."])

        drone_id = points[0].drone_id
        max_alt = max(p.altitude_m for p in points)
        max_speed = max(p.speed_m_s for p in points)
        any_missing_pilot = any(p.pilot_id is None or p.pilot_id == "" for p in points)
        reasons: List[str] = []
        score = 0.0

        # Simple altitude rule
        if max_alt > 120.0:
            score += 30.0
            reasons.append(f"Maximum altitude {max_alt:.1f} m is above a typical legal limit of 120 m.")

        # Speed spike
        if max_speed > 25.0:
            score += 20.0
            reasons.append(f"Maximum speed {max_speed:.1f} m per second is quite high for a typical small drone.")

        # No fly zones
        zones_hit = set()
        for p in points:
            zone_name = self._in_zone(p.lat, p.lon)
            if zone_name:
                zones_hit.add(zone_name)
        if zones_hit:
            score += 35.0
            zone_list = ", ".join(sorted(zones_hit))
            reasons.append(f"Flight path entered protected zones: {zone_list}.")

        # Pilot information
        if any_missing_pilot:
            score += 15.0
            reasons.append("Some telemetry points have no pilot id associated with them.")

        # RF profile heuristic
        if any(p.rf_signal.lower() == "unknown" for p in points):
            score += 10.0
            reasons.append("Observed unknown RF signal profile, which may indicate an unregistered link.")

        score = min(100.0, score)

        if score < 25.0:
            level = "low"
        elif score < 50.0:
            level = "medium"
        elif score < 75.0:
            level = "high"
        else:
            level = "critical"

        if not reasons:
            reasons.append("No significant risk signals detected in this flight.")

        return FlightAssessment(
            drone_id=drone_id,
            score=float(round(score, 1)),
            level=level,
            reasons=reasons,
        )
