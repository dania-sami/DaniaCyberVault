
import sys, joblib
b=joblib.load("model.joblib")
vec,clf=b["vec"],b["clf"]
X=vec.transform([sys.argv[1]])
pred=clf.predict_proba(X)[0][1]
print("Injection risk:",pred)
