from __future__ import annotations

import argparse
from pathlib import Path

import joblib

BASE_DIR = Path(__file__).resolve().parent.parent
MODELS_DIR = BASE_DIR / "models"


def main() -> None:
    parser = argparse.ArgumentParser(description="Prompt injection detector demo")
    parser.add_argument("--text", type=str, required=True, help="Prompt text to analyse")
    args = parser.parse_args()

    model = joblib.load(MODELS_DIR / "prompt_detector.joblib")

    proba = model.predict_proba([args.text])[0]
    labels = model.classes_.tolist()
    idx_max = int(proba.argmax())
    predicted = labels[idx_max]
    confidence = float(proba[idx_max])

    print(f"Input: {args.text}")
    print(f"Prediction: {predicted} (confidence={confidence:.2f})")
    print("Class probabilities:")
    for label, p in zip(labels, proba):
        print(f"  {label}: {p:.2f}")


if __name__ == "__main__":
    main()
