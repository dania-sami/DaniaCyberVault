
# Wireless Security Analyzer (WPA2 / WPA3 Handshake Simulation)

Hi, I am Dania and I built this project to think about **Wi Fi security** and handshake analysis without touching real captures.

I simulate:

- WPA2 and WPA3 handshakes
- password strength and reuse
- nonce reuse and replay events
- unsafe configurations (open networks, WEP like)

Then I run a small analyzer that flags risky access points and clients.

---

## What this project does

The main script is `wifi_analyzer.py`. It can:

1. Generate a demo dataset `data/handshakes.csv` with columns:
   - `bssid`
   - `ssid`
   - `client_mac`
   - `protocol` (WPA2, WPA3, OPEN)
   - `pmk_derived_from` (short_password, long_password, unknown)
   - `nonce_reuse` (True/False)
   - `replay_detected` (True/False)
2. Analyse each row and produce findings like:
   - weak PSK based on length category
   - nonce reuse (potential cryptographic weakness)
   - replay behaviour (attack or buggy implementation)
   - open networks with sensitive looking SSIDs
3. Write a report to:
   - `data/wifi_findings.csv`
   - and print a console summary

Everything is self contained so I can explain the logic very clearly.

---

## Project structure

```text
wireless_security_analyzer/
  README.md
  requirements.txt
  wifi_analyzer.py
  data/
```

---

## Installation

```bash
python3 -m venv venv
source venv/bin/activate            # Windows  venv\Scripts\activate
pip install -r requirements.txt
```

`requirements.txt` is empty because I only use the Python standard library.

---

## Usage

```bash
python wifi_analyzer.py demo
```

This will:

- generate synthetic handshake data
- analyse security posture
- write `data/handshakes.csv` and `data/wifi_findings.csv`
- print a list of the most worrying access points

---

## Why this project matters to me

Wi Fi and wireless security are everywhere in real life.

With this project I can show that I:

- understand key risk factors for WPA2/WPA3
- can model handshake metadata
- can turn those checks into a clean analyzer

It’s also a nice way to talk about what real tools like `airmon` or Wi Fi auditors look for.
