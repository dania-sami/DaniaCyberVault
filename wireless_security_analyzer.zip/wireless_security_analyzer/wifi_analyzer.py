
import argparse
import csv
import random
from collections import defaultdict
from pathlib import Path

DATA_DIR = Path("data")


def gen_demo_handshakes():
    random.seed(42)
    DATA_DIR.mkdir(exist_ok=True)
    rows = []
    bssids = ["aa:bb:cc:dd:ee:01", "aa:bb:cc:dd:ee:02", "aa:bb:cc:dd:ee:03"]
    ssids = ["Office-WiFi", "Guest-WiFi", "Legacy-Devices"]
    protocols = ["WPA2", "WPA3", "OPEN"]
    pw_strengths = ["short_password", "long_password", "unknown"]

    for i in range(120):
        b = random.choice(bssids)
        s = ssids[bssids.index(b)]
        client = f"de:ad:be:ef:00:{i:02x}"
        proto = random.choice(protocols if s != "Legacy-Devices" else ["WPA2", "OPEN"])
        if proto == "OPEN":
            pmk = "unknown"
        else:
            pmk = random.choices(pw_strengths, weights=[0.4, 0.4, 0.2])[0]
        nonce_reuse = random.random() < (0.2 if s == "Legacy-Devices" else 0.05)
        replay = random.random() < 0.1

        rows.append({
            "bssid": b,
            "ssid": s,
            "client_mac": client,
            "protocol": proto,
            "pmk_derived_from": pmk,
            "nonce_reuse": nonce_reuse,
            "replay_detected": replay,
        })

    out_path = DATA_DIR / "handshakes.csv"
    with out_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    print(f"[info] Demo handshakes written to {out_path}")


def analyze():
    in_path = DATA_DIR / "handshakes.csv"
    if not in_path.is_file():
        raise SystemExit(f"Handshake file not found: {in_path} (run demo first)")

    with in_path.open("r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    findings = []
    ap_risk = defaultdict(float)

    for r in rows:
        bssid = r["bssid"]
        ssid = r["ssid"]
        proto = r["protocol"]
        pmk = r["pmk_derived_from"]
        nonce_reuse = r["nonce_reuse"] == "True"
        replay = r["replay_detected"] == "True"

        if proto == "OPEN" and "Guest" not in ssid:
            ap_risk[bssid] += 0.5
            findings.append({
                "bssid": bssid,
                "ssid": ssid,
                "issue": "open_network",
                "detail": "Open network on non-guest SSID",
                "severity": "high",
            })
        if proto == "WPA2" and pmk == "short_password":
            ap_risk[bssid] += 0.3
            findings.append({
                "bssid": bssid,
                "ssid": ssid,
                "issue": "weak_psk",
                "detail": "WPA2 with short password",
                "severity": "medium",
            })
        if nonce_reuse:
            ap_risk[bssid] += 0.3
            findings.append({
                "bssid": bssid,
                "ssid": ssid,
                "issue": "nonce_reuse",
                "detail": "Nonce reuse observed",
                "severity": "high",
            })
        if replay:
            ap_risk[bssid] += 0.2
            findings.append({
                "bssid": bssid,
                "ssid": ssid,
                "issue": "replay_detected",
                "detail": "Replay like behaviour detected",
                "severity": "medium",
            })

    out_path = DATA_DIR / "wifi_findings.csv"
    if findings:
        with out_path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(findings[0].keys()))
            writer.writeheader()
            writer.writerows(findings)
        print(f"[info] Wrote {len(findings)} findings to {out_path}")
    else:
        print("[info] No issues detected with current rules.")

    if ap_risk:
        print("[info] Access points sorted by risk:")
        for bssid, score in sorted(ap_risk.items(), key=lambda kv: kv[1], reverse=True):
            print(f"  {bssid}  risk_score={score:.2f}")
    else:
        print("[info] No risky access points identified.")


def main():
    parser = argparse.ArgumentParser(description="Wireless security analyzer (simulated)")
    parser.add_argument("mode", choices=["demo"], help="Run demo generation and analysis")
    args = parser.parse_args()

    if args.mode == "demo":
        gen_demo_handshakes()
        analyze()


if __name__ == "__main__":
    import argparse
    main()
