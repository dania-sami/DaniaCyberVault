# API Endpoint Security Checklist Reporter

This project is a small script that turns a JSON description of API endpoints into a quick security checklist.

Each endpoint in the JSON file has fields like:

- `path`
- `method`
- `requires_auth`
- `uses_https_only`

The script prints any endpoints that do not require auth or are not marked as HTTPS only. It is a simple way to discuss basic API security expectations.

## Files

- `api_security_report.py` – main script
- `api_example.json` – example endpoints

## Usage

```bash
python api_security_report.py --config api_example.json
```
