import argparse
import json

def report(path: str):
    with open(path) as f:
        endpoints = json.load(f)

    print(f"[+] API security report for {path}\n")
    for ep in endpoints:
        p = ep.get("path", "")
        m = ep.get("method", "GET")
        auth = ep.get("requires_auth", False)
        https_only = ep.get("uses_https_only", False)

        issues = []
        if not auth:
            issues.append("no auth required")
        if not https_only:
            issues.append("not restricted to HTTPS")

        if issues:
            issues_txt = ", ".join(issues)
            print(f"    {m} {p} -> {issues_txt}")
    print()

def main():
    parser = argparse.ArgumentParser(description="API Endpoint Security Checklist Reporter by Dania")
    parser.add_argument("--config", required=True, help="JSON file with endpoint descriptions")
    args = parser.parse_args()
    report(args.config)

if __name__ == "__main__":
    main()
