from __future__ import annotations

import argparse
from collections import Counter, defaultdict

import joblib
import pandas as pd

from .config import MODEL_PATH


def main() -> None:
    parser = argparse.ArgumentParser(description="Summarise alerts by cluster")
    parser.add_argument("--path", type=str, required=True, help="Path to alerts CSV")
    args = parser.parse_args()

    df = pd.read_csv(args.path)
    texts = df["message"].fillna("")

    pipe = joblib.load(MODEL_PATH)
    labels = pipe.predict(texts)

    df["cluster"] = labels
    counts = Counter(labels)

    print("Cluster distribution:")
    for c, n in sorted(counts.items()):
        print(f"  Cluster {c}: {n} alerts")

    reps = defaultdict(list)
    for _, row in df.iterrows():
        reps[row["cluster"]].append(row)

    print("\nRepresentative alerts:")
    for c in sorted(reps.keys()):
        sample = reps[c][0]
        print(f"--- Cluster {c} ---")
        print(f"id={sample['id']} severity={sample['severity']} rule={sample['rule']}")
        print(f"message={sample['message']}")
        print()


if __name__ == "__main__":
    main()
