from __future__ import annotations

import joblib
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import Pipeline


from .config import ALERTS_CSV, MODEL_PATH


def main() -> None:
    df = pd.read_csv(ALERTS_CSV)
    texts = df["message"].fillna("")

    tfidf = TfidfVectorizer(max_features=500, ngram_range=(1, 2))

    # For simplicity we just cluster on message text
    kmeans = KMeans(n_clusters=4, random_state=42, n_init=10)

    pipe = Pipeline(
        steps=[
            ("tfidf", tfidf),
            ("kmeans", kmeans),
        ]
    )

    pipe.fit(texts)
    joblib.dump(pipe, MODEL_PATH)
    print(f"Cluster model saved to {MODEL_PATH}")


if __name__ == "__main__":
    main()
