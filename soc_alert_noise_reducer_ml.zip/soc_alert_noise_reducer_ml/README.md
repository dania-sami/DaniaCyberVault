# SOC Alert Noise Reducer (ML Clustering)

Hi, I am Dania Sami 👋

Real SOCs are noisy. The same type of alert can be generated thousands of times
with tiny differences. Analysts then drown in repeated information.

This project is my compact **SOC alert noise reducer**:

- ingests a CSV of alerts
- vectorises alert messages
- clusters similar alerts together
- prints a small "representative" alert per cluster

It is not a replacement for a full SIEM, but it clearly shows how ML can
help reduce noise for human analysts.

---

## What this project does

1. **Loads alert data**

   From `data/alerts.csv`, with columns:

   - `id`
   - `source`
   - `severity`
   - `rule`
   - `message`

2. **Vectorises alerts**

   In `src/train.py` I use `TfidfVectorizer` on the `message` field and
   concatenate `severity` as a simple numeric feature.

3. **Clusters with KMeans**

   The script trains a `KMeans` model and stores it together with the TF–IDF
   vectoriser in `models/cluster_model.joblib`.

4. **Summarises alert batches**

   `src/summarise.py` loads new alerts, assigns each to a cluster, and prints:

   - how many alerts fell into each cluster
   - one "representative" message for that cluster

This gives a flavour of how you might convert 10 000 alerts into a small
set of **cluster summaries**.

---

## How to run

```bash
cd soc_alert_noise_reducer_ml

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt
```

### Train the clustering model

```bash
python -m src.train
```

### Summarise a batch of alerts

```bash
python -m src.summarise --path data/alerts.csv
```

---

## Project structure

```text
soc_alert_noise_reducer_ml/
  ├─ README.md
  ├─ requirements.txt
  ├─ data/
  │    └─ alerts.csv
  ├─ models/
  │    └─ cluster_model.joblib
  └─ src/
       ├─ __init__.py
       ├─ config.py
       ├─ train.py
       └─ summarise.py
```

---

## Why I built this

Noise reduction is a very real problem in SOCs and detection engineering.
With this project I can talk about:

- text feature extraction
- unsupervised learning for alert triage
- "representative alert" ideas for analyst workflows
