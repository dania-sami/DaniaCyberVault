
async function fetchJson(url) {
  const res = await fetch(url);
  if (!res.ok) {
    throw new Error("Request failed " + res.status);
  }
  return res.json();
}

function formatTime(iso) {
  try {
    const d = new Date(iso);
    return d.toLocaleString();
  } catch {
    return iso;
  }
}

async function refresh() {
  const base = document.getElementById("backend-url").value.trim().replace(/\/$/, "");
  const alertsContainer = document.getElementById("alerts-container");
  const devicesBody = document.querySelector("#devices-table tbody");

  alertsContainer.innerHTML = "Loading alerts...";
  devicesBody.innerHTML = "";

  try {
    const [alerts, devices] = await Promise.all([
      fetchJson(base + "/alerts"),
      fetchJson(base + "/devices"),
    ]);

    // Alerts
    alertsContainer.innerHTML = "";
    if (!alerts.length) {
      const empty = document.createElement("div");
      empty.textContent = "No alerts yet. Feed some traffic into the system.";
      empty.style.fontSize = "12px";
      empty.style.color = "#c5c8ff";
      alertsContainer.appendChild(empty);
    } else {
      alerts.forEach((a) => {
        const card = document.createElement("div");
        card.className = "alert-card";

        const header = document.createElement("div");
        header.className = "alert-header";
        header.innerHTML = `<span>${a.src_ip} → ${a.dst_ip} (${a.protocol.toUpperCase()})</span>
          <span class="alert-score">Score ${a.score.toFixed(2)}</span>`;

        const meta = document.createElement("div");
        meta.className = "alert-meta";
        meta.textContent = `${a.bytes} bytes at ${formatTime(a.timestamp)}`;

        const reason = document.createElement("div");
        reason.className = "alert-reason";
        reason.textContent = a.reason;

        card.appendChild(header);
        card.appendChild(meta);
        card.appendChild(reason);
        alertsContainer.appendChild(card);
      });
    }

    // Devices
    devices.forEach((d) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${d.src_ip}</td>
        <td>${d.event_count}</td>
        <td>${d.total_bytes}</td>
        <td>${d.avg_bytes.toFixed(1)}</td>
        <td>${d.last_seen ? formatTime(d.last_seen) : ""}</td>
      `;
      devicesBody.appendChild(tr);
    });
  } catch (err) {
    alertsContainer.innerHTML = "";
    const error = document.createElement("div");
    error.textContent = "Could not reach backend. Check that the API is running on " + base;
    error.style.fontSize = "12px";
    error.style.color = "#ff9f9f";
    alertsContainer.appendChild(error);
    console.error(err);
  }
}

document.getElementById("refresh-btn").addEventListener("click", () => {
  refresh();
});

window.addEventListener("load", () => {
  refresh();
});
