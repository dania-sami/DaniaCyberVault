
from fastapi import FastAPI
from pydantic import BaseModel
from .model import analyze_traffic

app=FastAPI(title="ShadowNet Sentinel",version="0.1")

class TrafficInput(BaseModel):
    src_ip:str
    dst_ip:str
    bytes:int
    protocol:str

@app.post("/analyze")
def analyze(data:TrafficInput):
    score,explain = analyze_traffic(data.dict())
    return {"anomaly_score":score,"explanation":explain}
