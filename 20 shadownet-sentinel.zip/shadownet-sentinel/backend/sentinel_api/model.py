
import random

def analyze_traffic(sample):
    score=random.uniform(0,1)
    explanation="Synthetic placeholder model. High score indicates unusual behavior."
    return score, explanation
