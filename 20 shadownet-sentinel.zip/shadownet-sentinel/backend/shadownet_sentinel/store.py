
from .models import AnomalyEngine


engine = AnomalyEngine()
