
from fastapi import FastAPI
from pydantic import BaseModel, Field
from typing import List, Literal
from datetime import datetime

from .store import engine
from .models import TrafficEvent


class TrafficEventIn(BaseModel):
    src_ip: str = Field(..., example="10.0.0.12")
    dst_ip: str = Field(..., example="192.168.0.5")
    protocol: Literal["tcp", "udp", "icmp", "other"] = "tcp"
    bytes: int = Field(..., ge=0, example=2048)
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class IngestResponse(BaseModel):
    ingested: int
    new_alerts: int


class AlertOut(BaseModel):
    id: int
    src_ip: str
    dst_ip: str
    protocol: str
    bytes: int
    timestamp: datetime
    score: float
    reason: str


class DeviceProfileOut(BaseModel):
    src_ip: str
    total_bytes: int
    event_count: int
    avg_bytes: float
    last_seen: datetime | None


app = FastAPI(
    title="ShadowNet Sentinel",
    version="0.1.0",
    description="Network behaviour anomaly radar for your lab traffic.",
)


@app.post("/ingest_events", response_model=IngestResponse)
def ingest_events(events: List[TrafficEventIn]) -> IngestResponse:
    new_alerts = 0
    for item in events:
        event = TrafficEvent(
            src_ip=item.src_ip,
            dst_ip=item.dst_ip,
            protocol=item.protocol,
            bytes=item.bytes,
            timestamp=item.timestamp,
        )
        alert = engine.observe(event)
        if alert is not None:
            new_alerts += 1

    return IngestResponse(ingested=len(events), new_alerts=new_alerts)


@app.get("/alerts", response_model=List[AlertOut])
def get_alerts() -> List[AlertOut]:
    alerts = engine.list_alerts()
    return [
        AlertOut(
            id=a.id,
            src_ip=a.src_ip,
            dst_ip=a.dst_ip,
            protocol=a.protocol,
            bytes=a.bytes,
            timestamp=a.timestamp,
            score=a.score,
            reason=a.reason,
        )
        for a in alerts
    ]


@app.get("/devices", response_model=List[DeviceProfileOut])
def get_devices() -> List[DeviceProfileOut]:
    devices = engine.list_devices()
    return [
        DeviceProfileOut(
            src_ip=d.src_ip,
            total_bytes=d.total_bytes,
            event_count=d.event_count,
            avg_bytes=d.avg_bytes,
            last_seen=d.last_seen,
        )
        for d in devices
    ]
