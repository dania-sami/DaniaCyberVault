"""ShadowNet Sentinel backend package."""
