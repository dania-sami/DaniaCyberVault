
from dataclasses import dataclass
from typing import Dict, List
from datetime import datetime


@dataclass
class TrafficEvent:
    src_ip: str
    dst_ip: str
    protocol: str
    bytes: int
    timestamp: datetime


@dataclass
class DeviceProfile:
    src_ip: str
    total_bytes: int = 0
    event_count: int = 0
    avg_bytes: float = 0.0
    last_seen: datetime | None = None


@dataclass
class AnomalyAlert:
    id: int
    src_ip: str
    dst_ip: str
    protocol: str
    bytes: int
    timestamp: datetime
    score: float
    reason: str


class AnomalyEngine:
    """
    Simple behaviour based anomaly engine.

    This is intentionally transparent and small for a prototype.
    It keeps a running average of bytes per event for each source address
    and scores new events by how far they are from the usual size.
    """

    def __init__(self) -> None:
        self.devices: Dict[str, DeviceProfile] = {}
        self.alerts: List[AnomalyAlert] = []
        self._next_alert_id: int = 1

    def observe(self, event: TrafficEvent) -> AnomalyAlert | None:
        profile = self.devices.get(event.src_ip)
        if not profile:
            profile = DeviceProfile(src_ip=event.src_ip)
            self.devices[event.src_ip] = profile

        prev_avg = profile.avg_bytes
        prev_count = profile.event_count

        # Update profile
        profile.total_bytes += event.bytes
        profile.event_count += 1
        profile.avg_bytes = profile.total_bytes / max(1, profile.event_count)
        profile.last_seen = event.timestamp

        # If we do not have enough history yet treat as no anomaly
        if prev_count < 10:
            return None

        # Simple distance based score
        # score near 0 means very normal
        # score above about 2 looks suspicious
        diff = abs(event.bytes - prev_avg)
        score = diff / (prev_avg + 1.0)

        if score < 2.0:
            return None

        reason_parts = [
            f"Device {event.src_ip} usually sends about {int(prev_avg)} bytes per flow.",
            f"This event sent {event.bytes} bytes which is far from the usual size.",
            f"Relative distance score is {score:.2f}.",
        ]
        reason = " ".join(reason_parts)

        alert = AnomalyAlert(
            id=self._next_alert_id,
            src_ip=event.src_ip,
            dst_ip=event.dst_ip,
            protocol=event.protocol,
            bytes=event.bytes,
            timestamp=event.timestamp,
            score=float(round(score, 3)),
            reason=reason,
        )
        self._next_alert_id += 1
        self.alerts.append(alert)
        return alert

    def list_alerts(self) -> List[AnomalyAlert]:
        # Newest first
        return sorted(self.alerts, key=lambda a: a.timestamp, reverse=True)

    def list_devices(self) -> List[DeviceProfile]:
        return sorted(self.devices.values(), key=lambda d: d.src_ip)
