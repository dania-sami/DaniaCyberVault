
# ShadowNet Sentinel

ShadowNet Sentinel is a network behaviour radar for your lab.  
Instead of matching traffic against static signatures it learns how each device usually behaves and raises alerts when a flow looks very far from normal.

You can feed it synthetic flows from scripts or plug it into a mirror of real traffic later. The focus here is a clean working prototype that you can extend with more advanced models.

---

## What is included

The project has two main parts

* A Python FastAPI backend that receives traffic events keeps device profiles and produces anomaly alerts
* A small web dashboard that visualises alerts and profiles in real time

The anomaly logic is intentionally simple but realistic. It builds a running profile of average bytes per flow for each source address and computes a distance score for each new event. When the score is high enough an alert is created with a human readable reason.

---

## Folder layout

```text
shadownet-sentinel
├── backend
│   ├── shadownet_sentinel
│   │   ├── __init__.py
│   │   ├── main.py        FastAPI app and HTTP endpoints
│   │   ├── models.py      Behaviour profiles and anomaly engine
│   │   └── store.py       Simple shared engine instance
│   ├── requirements.txt
│   └── example_requests.http
└── dashboard
    ├── index.html         Simple front end
    ├── style.css          Visual styling
    └── script.js          Fetches data from the backend
```

---

## Running the backend

From the `backend` folder

```bash
python -m venv .venv
source .venv/bin/activate        # On Windows use .venv\Scripts\activate
pip install -r requirements.txt
uvicorn shadownet_sentinel.main:app --reload --port 9200
```

The API will be available on

* http://localhost:9200
* interactive docs at http://localhost:9200/docs

---

## Feeding traffic into the radar

You can use the file `example_requests.http` with an HTTP client or send a request manually with curl.

### Step one let a device build a normal profile

Send several normal looking flows from the same source

```bash
curl -X POST http://localhost:9200/ingest_events   -H "Content-Type: application/json"   -d '[
    {"src_ip": "10.0.0.12", "dst_ip": "10.0.0.1", "protocol": "tcp", "bytes": 2100},
    {"src_ip": "10.0.0.12", "dst_ip": "10.0.0.2", "protocol": "tcp", "bytes": 1900},
    {"src_ip": "10.0.0.12", "dst_ip": "10.0.0.3", "protocol": "tcp", "bytes": 2050},
    {"src_ip": "10.0.0.12", "dst_ip": "10.0.0.4", "protocol": "tcp", "bytes": 1980},
    {"src_ip": "10.0.0.12", "dst_ip": "10.0.0.5", "protocol": "tcp", "bytes": 2030},
    {"src_ip": "10.0.0.12", "dst_ip": "10.0.0.6", "protocol": "tcp", "bytes": 1950},
    {"src_ip": "10.0.0.12", "dst_ip": "10.0.0.7", "protocol": "tcp", "bytes": 2000},
    {"src_ip": "10.0.0.12", "dst_ip": "10.0.0.8", "protocol": "tcp", "bytes": 2070},
    {"src_ip": "10.0.0.12", "dst_ip": "10.0.0.9", "protocol": "tcp", "bytes": 2020},
    {"src_ip": "10.0.0.12", "dst_ip": "10.0.0.10", "protocol": "tcp", "bytes": 1990}
  ]'
```

This gives the engine enough history to understand what is normal for this host.

### Step two send a suspicious spike

```bash
curl -X POST http://localhost:9200/ingest_events   -H "Content-Type: application/json"   -d '[
    {"src_ip": "10.0.0.12", "dst_ip": "10.0.0.99", "protocol": "tcp", "bytes": 25000}
  ]'
```

Now you can query the alerts

```bash
curl http://localhost:9200/alerts
```

Each alert includes

* address pair
* protocol
* bytes
* score for how unusual it is
* explanation that refers to the past behaviour of that device

You can also list device profiles

```bash
curl http://localhost:9200/devices
```

This shows totals average bytes per event and last seen time for each device.

---

## Using the dashboard

Open `dashboard/index.html` directly in a browser.  
At the bottom you will see a field with the backend URL and a refresh button. By default it points to `http://localhost:9200`.

Click **Refresh now** after you feed some traffic and you will see

* cards for recent alerts with score and explanation
* a table of device profiles that shows how they normally behave

This simple view already feels like a miniature network operations room for your lab.

---

## Ideas for extending ShadowNet Sentinel

This repository is a foundation. Here are clear next steps you can take

* Add persistence for alerts and profiles so that data survives restarts
* Introduce more features into the behaviour profile such as port distribution connection rate and protocol mix
* Replace the simple distance score with a more advanced model such as Isolation Forest or an autoencoder
* Add support for reading from PCAP or NetFlow so that you can replay real capture files
* Group alerts into incidents so that many small anomalies for the same host become a single story for the analyst
* Build a timeline view in the front end that lets you scroll through activity for one device

By adding these features you can grow ShadowNet Sentinel into a serious research or portfolio project that shows real understanding of network security and behavioural analytics.
