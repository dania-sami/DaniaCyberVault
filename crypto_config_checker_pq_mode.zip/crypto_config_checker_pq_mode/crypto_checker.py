"""
Cryptography configuration checker with post quantum mode – Dania's crypto sanity check

Walks a directory
scans common config and code files
flags weak crypto usage
and writes JSON + Markdown reports
"""

import argparse
import json
import os
from dataclasses import dataclass, asdict
from typing import List, Dict


@dataclass
class Finding:
    file: str
    line_no: int
    category: str
    level: str
    message: str
    suggestion: str


WEAK_TLS = ["tlsv1", "tlsv1.0", "tlsv1.1", "ssl3", "sslv3"]
WEAK_CIPHERS = ["rc4", "3des", "des", "null", "export"]
WEAK_HASHES = ["md5", "sha1"]


def should_scan(path: str) -> bool:
    exts = (".conf", ".cnf", ".ini", ".cfg", ".txt", ".py", ".js", ".ts")
    return path.lower().endswith(exts)


def scan_file(path: str, root: str) -> List[Finding]:
    findings: List[Finding] = []
    rel_path = os.path.relpath(path, root)
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()
    except Exception:
        return findings

    for idx, line in enumerate(lines, start=1):
        lower = line.lower()

        # TLS versions
        if any(t in lower for t in WEAK_TLS):
            findings.append(
                Finding(
                    file=rel_path,
                    line_no=idx,
                    category="tls_version",
                    level="warning",
                    message="Possible use of obsolete or weak TLS / SSL version.",
                    suggestion="Prefer TLS 1.2 or 1.3 only, and disable older protocols.",
                )
            )

        # weak ciphers
        if any(c in lower for c in WEAK_CIPHERS):
            findings.append(
                Finding(
                    file=rel_path,
                    line_no=idx,
                    category="cipher",
                    level="warning",
                    message="Cipher list may include weak or obsolete algorithms.",
                    suggestion="Remove RC4, 3DES, DES, NULL and EXPORT ciphers. Use modern AEAD suites where possible.",
                )
            )

        # weak hashes
        if any(h in lower for h in WEAK_HASHES):
            findings.append(
                Finding(
                    file=rel_path,
                    line_no=idx,
                    category="hash",
                    level="warning",
                    message="Possible use of weak hash function (MD5 or SHA1).",
                    suggestion="Use SHA256 or stronger for integrity, and dedicated password hashing functions for passwords.",
                )
            )

        # obvious mention of 1024 bit rsa keys
        if "rsa" in lower and "1024" in lower:
            findings.append(
                Finding(
                    file=rel_path,
                    line_no=idx,
                    category="key_size",
                    level="warning",
                    message="Reference to 1024 bit RSA key – considered weak by modern standards.",
                    suggestion="Use at least 2048 bit RSA keys, or elliptic curve keys with comparable strength.",
                )
            )

    return findings


def walk_root(root: str) -> List[str]:
    all_files: List[str] = []
    for dirpath, _, filenames in os.walk(root):
        for name in filenames:
            full = os.path.join(dirpath, name)
            if should_scan(full):
                all_files.append(full)
    return all_files


def write_json(findings: List[Finding], path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump([asdict(fnd) for fnd in findings], f, indent=2)


def write_report(findings: List[Finding], path: str, post_quantum: bool) -> None:
    by_file: Dict[str, List[Finding]] = {}
    for fnd in findings:
        by_file.setdefault(fnd.file, []).append(fnd)

    with open(path, "w", encoding="utf-8") as f:
        f.write("# Cryptography configuration report\n\n")
        f.write(f"* Total findings: {len(findings)}\n")
        f.write(f"* Files with findings: {len(by_file)}\n\n")

        if not findings:
            f.write("The checker did not flag any weak algorithms or versions with the current simple rules.\n\n")
        else:
            for file, items in sorted(by_file.items()):
                f.write(f"## {file}\n\n")
                for fnd in items:
                    f.write(f"- Line {fnd.line_no}  [{fnd.category}]  {fnd.message}\n")
                    f.write(f"  - Suggestion: {fnd.suggestion}\n")
                f.write("\n")

        if post_quantum:
            f.write("## Post quantum friendly posture\n\n")
            f.write("* Prefer TLS 1.2 and 1.3 only and keep cipher configuration as simple and modern as possible.\n")
            f.write("* Plan for migration to hybrid or post quantum ready key exchange as platforms standardise it.\n")
            f.write("* Avoid hardcoding algorithm names in many different places  centralise them so policy updates are easier.\n\n")

            f.write("### Very small comparison table (illustrative only)\n\n")
            f.write("| Family | Example today | Rough security level | Notes |\n")
            f.write("|--------|---------------|----------------------|-------|\n")
            f.write("| RSA    | 2048 bit      | ~112 bit             | Common baseline, larger keys for long term secrets. |\n")
            f.write("| ECC    | P 256         | ~128 bit             | Shorter keys, good modern default in many stacks. |\n")
            f.write("| Hybrid | TLS 1.3 + future PQ KEM | depends on choice | Plan so that swapping or adding PQ algorithms is easy. |\n\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's cryptography configuration checker")
    parser.add_argument("--root", required=True, help="Root directory to scan")
    parser.add_argument("--out-prefix", default="crypto_run", help="Prefix for output files")
    parser.add_argument("--post-quantum", action="store_true", help="Add post quantum friendly posture section")
    args = parser.parse_args()

    root = os.path.abspath(args.root)
    files = walk_root(root)

    all_findings: List[Finding] = []
    for path in files:
        all_findings.extend(scan_file(path, root))

    json_path = f"{args.out_prefix}_crypto_findings.json"
    md_path = f"{args.out_prefix}_crypto_report.md"

    write_json(all_findings, json_path)
    write_report(all_findings, md_path, args.post_quantum)

    print(f"Scanned {len(files)} file(s).")
    print(f"Wrote JSON findings to {json_path}")
    print(f"Wrote Markdown report to {md_path}")


if __name__ == "__main__":
    main()
