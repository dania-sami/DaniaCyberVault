# Example application code with legacy hash and key size

import hashlib

def legacy_hash(data):
    return hashlib.md5(data).hexdigest()

RSA_KEY_BITS = 1024  # too small by modern standards
