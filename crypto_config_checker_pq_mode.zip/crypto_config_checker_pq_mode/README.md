# Cryptography Configuration Checker with Post Quantum Mode – Dania’s crypto sanity check

Hi

I am Dania and this project is my small command line helper for thinking about crypto configurations in a more structured way

It does not try to be a full scanner or a replacement for serious audits
Instead it focuses on three things

* spotting obviously weak or obsolete algorithms in config and code snippets
* giving a small readable summary of where modern defaults are missing
* offering a **post quantum friendly profile** with suggestions you can aim for next

Everything is file based and uses simple pattern checks
so it is transparent and easy to discuss in an interview

## What it checks

The checker walks a directory and looks at text files that typically contain crypto settings
for example

* web server configs like `nginx.conf` or `apache.conf`
* TLS or OpenSSL like files
* application code in Python or JavaScript

It flags things such as

* TLS versions
  * mentions of `TLSv1` or `TLSv1.1`
* cipher keywords
  * `RC4`, `3DES`, `DES`, `NULL`, `EXPORT`
* hash algorithms
  * `MD5`, `SHA1`
* key sizes
  * obvious references to 1024 bit RSA keys

Each finding includes

* file path
* line number
* a short description
* a hint for a better default

## Post quantum mode

When you enable `--post-quantum` the tool also prints a section in the report with

* a reminder to prefer modern TLS 1.2 or 1.3 only
* a small comparison table for a few algorithm families
  * classic RSA and ECC
  * space reserved for hybrid or post quantum ready key exchange
* suggestions like
  * plan for hybrid key exchange where your platform supports it
  * keep keys and protocols easily upgradeable

The goal is not to implement post quantum algorithms here
but to show that I am consciously thinking about the migration path.

## Inputs and outputs

Input

* a directory path such as `examples`
* the script inspects files with extensions
  * `.conf`, `.cnf`, `.ini`, `.cfg`, `.txt`
  * `.py`, `.js`, `.ts`

Outputs

1. A JSON file with all findings

   * file
   * line number
   * risk level
   * category (tls_version, cipher, hash, key_size, other)

2. A Markdown report

   * quick stats
   * list of findings grouped by file
   * a short section on post quantum friendly posture if enabled

## How I run it

From the project root

1. Optional  create a virtual environment

       python -m venv venv
       source venv_bin_activate

2. Install requirements (only standard library is used  this is for structure)

       pip install -r requirements.txt

3. Inspect the example configs

       examples_nginx.conf
       examples_app_crypto.py

4. Run the checker

   Basic mode

       python crypto_checker.py \
           --root examples \
           --out-prefix runs_basic

   With post quantum section

       python crypto_checker.py \
           --root examples \
           --out-prefix runs_pq \
           --post-quantum

This will produce for example

* `runs_basic_crypto_findings.json`
* `runs_basic_crypto_report.md`

## Why I built this

Crypto discussions can quickly become abstract

I wanted a small tool that lets me say

* here is the config
* here is where we are obviously behind the times
* here is a direction we can move towards  including post quantum thinking

With this project I can show that I

* recognise weak algorithms and versions
* think about modern TLS practices and post quantum migration at a high level
* prefer explanations and readable reports over black box scoring

It also gives me a nice way to discuss follow up ideas like
automated pull request comments or integration with CI later.
