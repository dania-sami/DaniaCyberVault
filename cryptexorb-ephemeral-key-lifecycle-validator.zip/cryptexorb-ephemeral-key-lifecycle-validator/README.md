# cryptexorb-ephemeral-key-lifecycle-validator
I built cryptexorb-ephemeral-key-lifecycle-validator as a simple working prototype.
Run it and check /status.
