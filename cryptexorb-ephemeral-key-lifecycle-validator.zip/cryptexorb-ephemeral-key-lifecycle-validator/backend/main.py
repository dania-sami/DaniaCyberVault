
from fastapi import FastAPI
app=FastAPI(title="cryptexorb-ephemeral-key-lifecycle-validator")
@app.get("/status")
def status():
    return {"project":"cryptexorb-ephemeral-key-lifecycle-validator","status":"working"}
