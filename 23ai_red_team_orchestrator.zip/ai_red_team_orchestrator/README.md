# AI Red Team Orchestrator

Hi

This is a small project I built to automate red teaming for LLM based applications

It lets you define a bunch of attack prompts and test cases
sends them to a target API endpoint
records the responses
and scores how risky each one is based on simple rules

It is not a heavy or fancy framework
It is just a clean portfolio project that shows I understand automated testing for AI security

## Features

* Load attack scenarios from a JSON file
* Send them to any HTTP endpoint that behaves like an LLM
* Detect unsafe outputs based on keywords and patterns
* Produce a JSON report with scores
* Produce a Markdown summary

## How to run

1 Unzip the project
2 Install Python 3
3 Install requests

   pip install requests

4 Put your target LLM endpoint in the config file config.json

Example

   {
     "endpoint": "http://localhost:8000/api/chat"
   }

5 Run

   python orchestrator.py --out report.md --json report.json

## Why this project is useful

Security testing for LLM apps is becoming very important
This tool shows that I can

* build small automated pipelines
* understand prompt injection and unsafe output detection
* produce reports you can share in a security review

