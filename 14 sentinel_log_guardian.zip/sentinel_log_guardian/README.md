# Sentinel Log Guardian

Hi

This is a small security project that I built to make log files a bit less boring and a bit more useful

The idea is simple

* You give the tool one or more log files
* It learns what looks normal in those logs
* It highlights the strange lines and gives you a short human summary

It is not meant to replace a full SIEM or an enterprise tool
It is a clean portfolio project that shows that I understand how logs work and how to do basic anomaly detection in Python

## Features

* Works on any plain text log file
* Extracts simple patterns from each line and learns which ones are common
* Flags rare and suspicious patterns as anomalies
* Detects simple brute force style behavior like many failed logins from the same source
* Produces a JSON report plus a human friendly summary

## How to run

1 Clone this project or unzip it somewhere
2 Make sure you have Python 3 installed
3 Install the requirements

   pip install -r requirements.txt

4 Run the tool on a log file

   python log_guardian.py examples_sample_logs.txt

You will see

* A short summary in the terminal
* A JSON report file next to your log with the word report in the file name

## Why this project is interesting

I wanted something small that still feels close to real work
This project shows that I can

* Parse and normalise log lines
* Build a simple statistical model of normal behavior
* Detect unusual patterns and present them in a way a human analyst can understand
* Write clear and readable Python code with structure and docstrings

If you want to go further this project can be extended with

* Support for specific log formats such as nginx or SSH
* A simple web dashboard to explore anomalies
* Integration with streaming sources like syslog or Kafka

Thanks for reading