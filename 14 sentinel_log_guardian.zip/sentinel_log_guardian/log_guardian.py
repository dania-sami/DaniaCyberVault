"""
Sentinel Log Guardian

A small log analysis helper for security minded people

The tool reads one or more log files
learns what normal lines look like
and then points out the unusual ones

Usage
    python log_guardian.py path_to_log_file

The logic is intentionally simple and fully based on the standard library
so that it is easy to understand and extend
"""

import argparse
import collections
import json
import os
import re
from dataclasses import dataclass, asdict
from typing import List, Dict, Iterable


TEMPLATE_NUMBER = "<NUM>"
TEMPLATE_IP = "<IP>"
TEMPLATE_QUOTED = "<STR>"


ip_pattern = re.compile(
    r"(?:\d{1,3}\.){3}\d{1,3}"
)

number_pattern = re.compile(
    r"(?<![\w.])(\d+)(?![\w.])"
)

quoted_pattern = re.compile(
    r"".*?"|\'.*?\'"
)


@dataclass
class ParsedLine:
    index: int
    raw: str
    template: str
    level: str
    has_failed_login: bool
    source_ip: str


@dataclass
class Anomaly:
    index: int
    raw: str
    reason: str
    score: float


def build_template(text: str) -> str:
    """
    Replace numbers
    quoted strings
    and IP addresses
    with simple tokens
    """

    def replace_ip(match: re.Match) -> str:
        return TEMPLATE_IP

    def replace_number(match: re.Match) -> str:
        return TEMPLATE_NUMBER

    def replace_quoted(match: re.Match) -> str:
        return TEMPLATE_QUOTED

    text = ip_pattern.sub(replace_ip, text)
    text = quoted_pattern.sub(replace_quoted, text)
    text = number_pattern.sub(replace_number, text)
    # normalise whitespace
    text = " ".join(text.split())
    return text


def guess_level(text: str) -> str:
    lower = text.lower()
    if "error" in lower:
        return "error"
    if "warn" in lower:
        return "warning"
    if "fail" in lower:
        return "failure"
    if "info" in lower:
        return "info"
    return "unknown"


def first_ip(text: str) -> str:
    m = ip_pattern.search(text)
    return m.group(0) if m else ""


def parse_lines(lines: Iterable[str]) -> List[ParsedLine]:
    parsed = []
    for idx, raw in enumerate(lines):
        stripped = raw.rstrip("\n")
        if not stripped:
            continue
        template = build_template(stripped)
        level = guess_level(stripped)
        has_failed = "failed login" in stripped.lower() or "authentication failure" in stripped.lower()
        src_ip = first_ip(stripped)
        parsed.append(
            ParsedLine(
                index=idx,
                raw=stripped,
                template=template,
                level=level,
                has_failed_login=has_failed,
                source_ip=src_ip,
            )
        )
    return parsed


def score_anomalies(parsed: List[ParsedLine]) -> List[Anomaly]:
    template_counts = collections.Counter(p.template for p in parsed)
    anomalies: List[Anomaly] = []

    for p in parsed:
        count = template_counts[p.template]
        # rare templates receive a higher score
        rarity_score = 1.0 / count
        reasons = []
        if count == 1:
            reasons.append("line uses a pattern that appears only once")
        elif count <= 3:
            reasons.append("line uses a pattern that appears very few times")

        if p.level in {"error", "failure", "warning"}:
            rarity_score += 0.5
            reasons.append(f"log level suggests a problem level={p.level}")

        if p.has_failed_login:
            rarity_score += 1.0
            reasons.append("contains a failed login message")

        if rarity_score >= 1.0:
            anomalies.append(
                Anomaly(
                    index=p.index,
                    raw=p.raw,
                    reason="; ".join(reasons) if reasons else "unusual pattern",
                    score=round(rarity_score, 3),
                )
            )

    # brute force style detection
    failed_by_ip: Dict[str, int] = collections.Counter(
        p.source_ip for p in parsed if p.has_failed_login and p.source_ip
    )
    for ip, count in failed_by_ip.items():
        if count >= 5:
            reasons = f"many failed logins from the same address ip={ip} count={count}"
            # pick all lines from that ip with failed login
            for p in parsed:
                if p.source_ip == ip and p.has_failed_login:
                    anomalies.append(
                        Anomaly(
                            index=p.index,
                            raw=p.raw,
                            reason=reasons,
                            score=2.0,
                        )
                    )

    # sort by score then by index
    anomalies.sort(key=lambda a: (-a.score, a.index))
    return anomalies


def summarise(anomalies: List[Anomaly]) -> str:
    if not anomalies:
        return "No strong anomalies were found in these logs based on simple pattern analysis"

    total = len(anomalies)
    top = anomalies[:5]
    lines = []
    lines.append(f"I found {total} lines that look unusual")
    lines.append("Here are a few examples")
    for a in top:
        lines.append(f"line {a.index}: {a.reason}")
    return "\n".join(lines)


def analyse_file(path: str) -> Dict:
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        parsed = parse_lines(f)

    anomalies = score_anomalies(parsed)
    summary = summarise(anomalies)

    return {
        "file": os.path.abspath(path),
        "summary": summary,
        "anomaly_count": len(anomalies),
        "anomalies": [asdict(a) for a in anomalies],
    }


def write_report(path: str, report: Dict) -> str:
    base, ext = os.path.splitext(path)
    out_path = base + "_report.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
    return out_path


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Simple log anomaly helper for security work"
    )
    parser.add_argument(
        "paths",
        nargs="+",
        help="One or more log files to inspect",
    )
    args = parser.parse_args()

    for path in args.paths:
        if not os.path.isfile(path):
            print(f"Skipping {path} because it is not a file")
            continue
        report = analyse_file(path)
        out_path = write_report(path, report)
        print()
        print(f"Analysed {report['file']}")
        print(report["summary"])
        print(f"Full report written to {out_path}")


if __name__ == "__main__":
    main()
