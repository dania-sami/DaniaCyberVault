
# Agent Firewall Courtroom

An experimental **firewall and courtroom** for autonomous AI agents.

Instead of blindly letting an agent call tools like "delete user", "read secrets" or "reconfigure cluster",
you send every proposed action through this service. It will:

1. **Simulate** possible consequences of the action.
2. Ask a **Prosecutor** model to argue why the action is dangerous.
3. Ask a **Defender** model to argue why it is safe and useful.
4. Apply explicit **security policies**.
5. Let a **Judge** combine all of that into a verdict:

   - `allow`
   - `deny`
   - `require_human_approval`

This repository is a compact but opinionated starting point that you can extend into a real
production-grade "agent firewall" for your own tools.

---

## High level architecture

This prototype is intentionally simple so you can read it in one sitting.

```text
┌────────────┐      HTTP       ┌──────────────────────┐
│  AI Agent  │ ─────────────▶ │ Agent Firewall API    │
└────────────┘                │  (FastAPI)            │
                              │                      │
                              │  • simulate_consequences()   ← sandbox / heuristics
                              │  • prosecutor()              ← argue against action
                              │  • defender()                ← argue for action
                              │  • evaluate_policies()       ← explicit rules
                              │  • judge()                   ← final verdict
                              └──────────────────────┘
```

In a serious deployment you would:
- Replace the heuristic simulator with a real sandbox or "shadow" environment.
- Plug real language models into `prosecutor` and `defender`.
- Replace the simple Python policies with OPA, Rego or your own DSL.
- Store every trial in a database for forensics and audits.

---

## Quick start

### 1. Create and activate a virtual environment

```bash
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Run the API

```bash
uvicorn agent_firewall.main:app --reload
```

The API will be available on `http://localhost:8000`.

- Swagger UI: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`

---

## Trying the courtroom

You can use the included `example_requests.http` file with an HTTP client such as VS Code REST Client,
or just use curl.

### Safe looking sandbox read

```bash
curl -X POST http://localhost:8000/tool_call       -H "Content-Type: application/json"       -d '{
    "agent_id": "agent-123",
    "action": "read logs",
    "resource": "sandbox-logs-bucket",
    "context": "Debugging a non critical feature in staging.",
    "risk_level": "low"
  }'
```

This should usually be **allowed**, with rationale highlighting:

- low declared risk
- read style action
- sandbox resource
- low simulated impact

### Suspicious destructive production action

```bash
curl -X POST http://localhost:8000/tool_call       -H "Content-Type: application/json"       -d '{
    "agent_id": "agent-ops-bot",
    "action": "delete user records",
    "resource": "prod-user-db",
    "context": "Cleanup requested by unknown operator.",
    "risk_level": "high"
  }'
```

This should either be **denied** or marked as **require_human_approval**, with rationale like:

- destructive verb "delete"
- production database
- high declared risk
- high simulated impact
- policy `no_destructive_actions_in_production_without_human` applied

---

## Files and layout

```text
agent-firewall-courtroom/
├── agent_firewall/
│   ├── __init__.py            # Package marker
│   ├── main.py                # FastAPI app and HTTP entrypoint
│   ├── courtroom.py           # Prosecutor, defender, judge, and trial orchestration
│   ├── policies.py            # Simple, explicit policies with a tiny rule engine
│   └── simulator.py           # Heuristic "simulation" of consequences
├── requirements.txt           # Python dependencies
└── example_requests.http      # Ready to fire example HTTP calls
```

---

## How to plug this into a real agent

In your autonomous agent framework you usually have a function like `call_tool(...)` or
`execute_action(...)`. Instead of calling the tool directly, you:

1. Build a JSON payload that matches `ToolCall`.
2. POST it to `POST /tool_call` on this service.
3. Inspect the verdict.

Pseudocode:

```python
import httpx

def guarded_tool_call(agent_id, action, resource, context, risk_level="medium"):
    payload = {
        "agent_id": agent_id,
        "action": action,
        "resource": resource,
        "context": context,
        "risk_level": risk_level,
    }
    resp = httpx.post("http://localhost:8000/tool_call", json=payload, timeout=10.0)
    resp.raise_for_status()
    verdict = resp.json()

    if verdict["verdict"] == "allow":
        return actually_call_the_tool(...)
    elif verdict["verdict"] == "require_human_approval":
        raise RuntimeError("Agent action requires human approval: \n" + verdict["rationale"])
    else:
        raise RuntimeError("Agent action denied by firewall: \n" + verdict["rationale"])
```

This simple pattern gives you:

- A single, auditable choke point for every dangerous thing an agent might do.
- Space to layer more and more sophisticated checks without changing your agents.
- The option to require human approval for certain classes of actions.

---

## Extending the system

Here are some ideas for making this **portfolio level insane**:

1. **Real sandbox simulation**
   - Run the proposed action in a disposable container or shadow environment.
   - Compare before and after state to estimate real impact.
   - Feed that into `simulate_consequences` instead of heuristics.

2. **Multi model courtroom**
   - Use different language models as prosecutor, defender and judge.
   - Log all the "arguments" as structured text for auditing and research.

3. **Policy as code**
   - Replace `policies.py` with a dedicated policy engine.
   - Store policies in version controlled files, test them, review them like code.

4. **Verdict dashboard**
   - Build a small web UI that shows a feed of recent trials, filters by agent, action, verdict.
   - Use it as a control center for your autonomous agents.

5. **Formal guarantees**
   - For some classes of actions (like "cannot write outside /sandbox"), enforce them with
     technical controls as well as policies.
   - Document these guarantees clearly in your README and UI.

---

## Why this is interesting for cyber security

As more organisations plug agents into sensitive systems (cloud consoles, CI CD, ticketing, databases),
the attack surface explodes.

This project turns the usual "just add some if statements" approach into a **first class security control**:

- Every risky action becomes a **case**.
- You have a **trail of arguments and policies** behind every allow deny decision.
- You can show auditors and security teams exactly how the system reasons.

Use this repo as your starting point, then iterate:
do not just build agents, build a courtroom around them.
