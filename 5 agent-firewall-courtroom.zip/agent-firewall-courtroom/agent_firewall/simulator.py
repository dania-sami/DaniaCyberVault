
from typing import Dict
import math


def simulate_consequences(case: Dict) -> Dict:
    """
    Extremely lightweight "simulator" to estimate impact/benefit of an action.

    In a serious implementation this would run the tool call in a sandbox
    or shadow environment. Here we just derive some heuristic scores based on
    keywords so you can see the full pipeline working.
    """
    action = case.get("action", "").lower()
    resource = case.get("resource", "").lower()
    risk = case.get("risk_level", "medium")

    impact = 0.3
    benefit = 0.5

    # Rough impact heuristics.
    if any(word in action for word in ["delete", "drop", "shutdown"]):
        impact += 0.4
    if any(word in resource for word in ["prod", "production", "customer", "payment"]):
        impact += 0.3
    if risk == "high":
        impact += 0.2

    # Rough benefit heuristics.
    if any(word in action for word in ["backup", "patch", "migrate", "scale"]):
        benefit += 0.3
    if "sandbox" in resource:
        benefit += 0.1

    impact = max(0.0, min(1.0, impact))
    benefit = max(0.0, min(1.0, benefit))

    # Safety score: lower impact and higher benefit is safer.
    safety_score = max(0.0, min(1.0, 1.0 - 0.7 * impact + 0.3 * benefit))

    # Uncertainty: we pretend destructive or production actions are more uncertain.
    uncertainty = 0.2
    if any(word in action for word in ["delete", "drop"]) or "prod" in resource:
        uncertainty = 0.6

    return {
        "impact_score": float(impact),
        "benefit_score": float(benefit),
        "safety_score": float(safety_score),
        "uncertainty": float(uncertainty),
    }
