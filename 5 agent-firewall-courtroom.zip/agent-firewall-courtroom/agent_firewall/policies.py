
from typing import Dict, List


def evaluate_policies(case: Dict, simulation: Dict) -> Dict:
    """
    Evaluate simple, explicit policies over the case and simulation results.

    This is deliberately transparent and easy to extend. In a real system you
    could plug in something like OPA, Rego, or your own DSL here.
    """
    applied: List[str] = []
    modifier = 0.0
    recommendation = "none"  # "allow", "deny", "require_human_approval"

    action = case.get("action", "").lower()
    resource = case.get("resource", "").lower()
    risk = case.get("risk_level", "medium")

    # Policy 1: Never allow destructive actions in production without human approval.
    if any(word in action for word in ["delete", "drop", "remove"]) and any(
        word in resource for word in ["prod", "production"]
    ):
        applied.append("no_destructive_actions_in_production_without_human")
        recommendation = "require_human_approval"
        modifier -= 0.2

    # Policy 2: For high risk actions on any sensitive resource, lean towards denial.
    if risk == "high" and any(word in resource for word in ["secret", "credential", "key", "privacy"]):
        applied.append("high_risk_on_sensitive_resource")
        recommendation = "deny"
        modifier -= 0.3

    # Policy 3: Sandbox reads are generally safe.
    if "sandbox" in resource and any(word in action for word in ["read", "list", "get", "describe"]):
        applied.append("sandbox_read_looks_safe")
        if recommendation == "none":
            recommendation = "allow"
        modifier += 0.2

    # Policy 4: Very high simulated impact always reduces score.
    if simulation.get("impact_score", 0.0) > 0.8:
        applied.append("very_high_simulated_impact")
        modifier -= 0.3

    return {
        "applied_policies": applied,
        "score_modifier": modifier,
        "policy_recommendation": recommendation,
    }
