
from dataclasses import dataclass
from typing import List, Dict, Literal, Tuple

from .policies import evaluate_policies
from .simulator import simulate_consequences


VerdictType = Literal["allow", "deny", "require_human_approval"]


@dataclass
class TrialResult:
    verdict: VerdictType
    score: float
    rationale: str
    prosecutor_arguments: List[str]
    defender_arguments: List[str]
    applied_policies: List[str]


def prosecutor(case: Dict, simulation: Dict) -> List[str]:
    """Generate arguments against allowing the action."""
    args: List[str] = []

    risk = case.get("risk_level", "medium")
    if risk == "high":
        args.append("Declared risk level is high.")

    if "delete" in case.get("action", "").lower():
        args.append("Action contains a destructive verb 'delete'.")

    if any(word in case.get("resource", "").lower() for word in ["prod", "production"]):
        args.append("Target resource appears to be production.")

    impact = simulation.get("impact_score", 0.0)
    if impact >= 0.7:
        args.append(f"Simulated potential impact is high ({impact:.2f}).")

    if simulation.get("uncertainty", 0.0) > 0.5:
        args.append("Simulation is highly uncertain; safest to be conservative.")

    return args


def defender(case: Dict, simulation: Dict) -> List[str]:
    """Generate arguments in favour of allowing the action."""
    args: List[str] = []

    if case.get("risk_level") == "low":
        args.append("Declared risk level is low.")

    if any(word in case.get("action", "").lower() for word in ["read", "get", "list", "describe"]):
        args.append("Action appears to be read-only.")

    if "sandbox" in case.get("resource", "").lower():
        args.append("Resource looks like a sandbox environment.")

    benefit = simulation.get("benefit_score", 0.0)
    if benefit >= 0.6:
        args.append(f"Simulated benefit of the action is significant ({benefit:.2f}).")

    if simulation.get("uncertainty", 0.0) < 0.3:
        args.append("Simulation is confident about low risk.")

    return args


def judge(case: Dict, sim: Dict, pros: List[str], defs: List[str], policy_result: Dict) -> TrialResult:
    """Combine everything into a final verdict."""
    base_score = sim.get("safety_score", 0.5)
    policy_modifier = policy_result["score_modifier"]
    policy_leaning = policy_result["policy_recommendation"]

    # Simple scoring: positive means allow, negative means deny
    score = base_score + policy_modifier

    # Arguments balance
    score += 0.05 * (len(defs) - len(pros))

    rationale_parts: List[str] = []
    rationale_parts.append(f"Base safety score from simulation: {base_score:.2f}.")
    if policy_modifier != 0:
        rationale_parts.append(f"Policies adjusted score by {policy_modifier:+.2f}.")
    rationale_parts.append(f"Prosecutor raised {len(pros)} concerns; defender raised {len(defs)} mitigating points.")

    verdict: VerdictType

    if policy_leaning == "deny":
        verdict = "deny"
        rationale_parts.append("Policies strongly recommend denial.")
    elif policy_leaning == "require_human_approval":
        verdict = "require_human_approval"
        rationale_parts.append("Policies require human approval for this type of action.")
    else:
        # No strong policy preference, decide from score
        if score >= 0.6:
            verdict = "allow"
            rationale_parts.append("Overall score is high, allowing action.")
        elif score <= 0.3:
            verdict = "deny"
            rationale_parts.append("Overall score is low, denying action.")
        else:
            verdict = "require_human_approval"
            rationale_parts.append("Score is ambiguous; escalating to human.")

    rationale = " ".join(rationale_parts)

    return TrialResult(
        verdict=verdict,
        score=float(max(0.0, min(1.0, score))),
        rationale=rationale,
        prosecutor_arguments=pros,
        defender_arguments=defs,
        applied_policies=policy_result["applied_policies"],
    )


def hold_trial(case: Dict) -> TrialResult:
    """Run a full trial for a proposed tool call."""
    sim = simulate_consequences(case)
    policy_result = evaluate_policies(case, sim)
    pros = prosecutor(case, sim)
    defs = defender(case, sim)
    return judge(case, sim, pros, defs, policy_result)
