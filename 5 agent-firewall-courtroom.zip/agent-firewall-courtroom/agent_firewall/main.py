
from fastapi import FastAPI
from pydantic import BaseModel
from typing import List, Optional, Literal

from .courtroom import hold_trial, TrialResult

class ToolCall(BaseModel):
    agent_id: str
    action: str
    resource: str
    context: Optional[str] = None
    risk_level: Literal["low", "medium", "high"] = "medium"


class VerdictResponse(BaseModel):
    verdict: Literal["allow", "deny", "require_human_approval"]
    score: float
    rationale: str
    prosecutor_arguments: List[str]
    defender_arguments: List[str]
    applied_policies: List[str]


app = FastAPI(
    title="Agent Firewall Courtroom",
    version="0.1.0",
    description="Prototype firewall and courtroom for autonomous AI tool calls.",
)


@app.post("/tool_call", response_model=VerdictResponse)
def evaluate_tool_call(call: ToolCall) -> VerdictResponse:
    """Entry point: evaluate a proposed tool call through the courtroom."""
    case = {
        "agent_id": call.agent_id,
        "action": call.action,
        "resource": call.resource,
        "context": call.context or "",
        "risk_level": call.risk_level,
    }

    result: TrialResult = hold_trial(case)

    return VerdictResponse(
        verdict=result.verdict,
        score=result.score,
        rationale=result.rationale,
        prosecutor_arguments=result.prosecutor_arguments,
        defender_arguments=result.defender_arguments,
        applied_policies=result.applied_policies,
    )
