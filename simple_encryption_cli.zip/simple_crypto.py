import argparse
from cryptography.fernet import Fernet

def gen_key(out_path: str):
    key = Fernet.generate_key()
    with open(out_path, "wb") as f:
        f.write(key)
    print(f"[+] Key written to {out_path}")

def load_key(path: str) -> Fernet:
    with open(path, "rb") as f:
        key = f.read().strip()
    return Fernet(key)

def encrypt_file(key_path: str, in_path: str, out_path: str):
    f = load_key(key_path)
    with open(in_path, "rb") as src:
        data = src.read()
    token = f.encrypt(data)
    with open(out_path, "wb") as dst:
        dst.write(token)
    print(f"[+] Encrypted {in_path} -> {out_path}")

def decrypt_file(key_path: str, in_path: str, out_path: str):
    f = load_key(key_path)
    with open(in_path, "rb") as src:
        token = src.read()
    data = f.decrypt(token)
    with open(out_path, "wb") as dst:
        dst.write(data)
    print(f"[+] Decrypted {in_path} -> {out_path}")

def main():
    parser = argparse.ArgumentParser(description="Simple Encryption / Decryption CLI by Dania")
    sub = parser.add_subparsers(dest="command", required=True)

    p_gen = sub.add_parser("gen-key", help="Generate a new key file")
    p_gen.add_argument("--out", required=True, help="Path to key file")

    p_enc = sub.add_parser("encrypt", help="Encrypt a file")
    p_enc.add_argument("--key", required=True, help="Path to key file")
    p_enc.add_argument("--in", dest="infile", required=True, help="Plaintext input file")
    p_enc.add_argument("--out", required=True, help="Ciphertext output file")

    p_dec = sub.add_parser("decrypt", help="Decrypt a file")
    p_dec.add_argument("--key", required=True, help="Path to key file")
    p_dec.add_argument("--in", dest="infile", required=True, help="Ciphertext input file")
    p_dec.add_argument("--out", required=True, help="Plaintext output file")

    args = parser.parse_args()

    if args.command == "gen-key":
        gen_key(args.out)
    elif args.command == "encrypt":
        encrypt_file(args.key, args.infile, args.out)
    elif args.command == "decrypt":
        decrypt_file(args.key, args.infile, args.out)

if __name__ == "__main__":
    main()
