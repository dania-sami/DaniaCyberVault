# Simple Encryption / Decryption CLI

This is a small command line tool I wrote to practice basic applied cryptography in a safe way.

It uses Python's `cryptography` library and symmetric encryption (Fernet) to:

- Generate a random key
- Encrypt a text file
- Decrypt it back again with the same key

The goal is not to invent new crypto, but to show that I know how to use existing libraries correctly.

## Requirements

- Python 3
- `cryptography` library

Install:

```bash
pip install cryptography
```

## Usage

Generate a key:

```bash
python simple_crypto.py gen-key --out key.key
```

Encrypt a file:

```bash
python simple_crypto.py encrypt --key key.key --in plaintext.txt --out ciphertext.bin
```

Decrypt:

```bash
python simple_crypto.py decrypt --key key.key --in ciphertext.bin --out decrypted.txt
```

This is a neat little project to talk about key management, symmetric crypto and file handling.
