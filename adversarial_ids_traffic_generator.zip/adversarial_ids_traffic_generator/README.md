# Adversarial Traffic Lab for IDS Benchmarking – Dania’s testing playground

Hi

I am Dania and this project is my small lab for poking at intrusion detection systems

I wanted something that feels like a mini red team tool but still stays safe and offline
So this project takes a set of attack payloads and a simple IDS rule set
then generates mutated versions of each payload and checks which ones get detected

It is a light weight way to explore questions like

* what happens if an attacker adds spaces or comments
* what if they encode parts of the payload
* which rules are fragile and which are robust

## Concept

The lab consists of three pieces

* a base payload file  JSON lines with attack like strings and a label
* a rule file  JSON describing which substrings count as detection for each rule
* a generator script that
  * mutates each payload in several simple ways
  * runs the rules on each variant
  * records whether it was detected or not
  * writes both a JSON file and a Markdown summary

This is obviously not a drop in replacement for Snort or Suricata
It is a clean playground that shows how adversarial thinking fits into IDS design

## Data model

Base payloads live in a JSON lines file
For example

{"id": "sql_1", "label": "sql_injection", "payload": "GET /item?id=1 OR 1=1 HTTP/1.1"}

Detection rules live in a small JSON file
For example

{
  "rules": [
    {
      "id": "rule_sql_or_1_1",
      "label": "SQL OR 1=1 pattern",
      "pattern": "or 1=1"
    }
  ]
}

The built in detector only uses simple substring matching
That keeps the whole lab very explainable

## Mutations

For each payload the generator creates a few variants
such as

* extra white space and line breaks
* mixed or upper case on keywords
* URL style encoding of some characters
* comment insertion in the middle of keywords

The idea is not to be exhaustive
The idea is to show how surprisingly small changes can defeat basic rules

## How I run it

1 Optional create and activate a virtual environment

   python3 -m venv venv
   source venv_bin_activate

2 Install requirements

   pip install -r requirements.txt

3 Check the example files in the examples folder

   * base_payloads_sample.jsonl
   * rules_sample.json

4 Run the lab

   python traffic_lab.py \
       --payloads examples_base_payloads_sample.jsonl \
       --rules examples_rules_sample.json \
       --out-prefix runs_sql_demo

This will produce

* runs_sql_demo_variants.json
* runs_sql_demo_report.md

The report shows

* how many variants were generated
* detection rate per base payload and per rule
* examples of variants that bypassed the simple rules

## Why I built this

A lot of research talks about adversarial examples for machine learning based IDS
I wanted a very small version of that idea that I can fully control and explain

With this project I can talk about

* how simple pattern based IDS rules can fail under minor obfuscation
* how to organise experiments with payload variants and detection results
* why robust detection often needs normalisation and deeper parsing

It is a small testing playground that fits nicely with my interest in cyber security and AI

