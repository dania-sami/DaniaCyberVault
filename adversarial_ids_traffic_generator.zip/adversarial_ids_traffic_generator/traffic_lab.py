"""
Adversarial Traffic Lab for IDS Benchmarking – Dania's playground

Generates mutated payload variants
runs simple substring based IDS rules
and reports which variants were detected
"""

import argparse
import json
import random
import urllib.parse
from dataclasses import dataclass, asdict
from typing import List, Dict


@dataclass
class Payload:
    id: str
    label: str
    payload: str


@dataclass
class Rule:
    id: str
    label: str
    pattern: str


@dataclass
class VariantResult:
    base_id: str
    base_label: str
    variant_id: str
    mutation: str
    payload: str
    detected_by: List[str]


def load_payloads(path: str) -> List[Payload]:
    items: List[Payload] = []
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue
            items.append(
                Payload(
                    id=str(obj.get("id", "")),
                    label=str(obj.get("label", "")),
                    payload=str(obj.get("payload", "")),
                )
            )
    return items


def load_rules(path: str) -> List[Rule]:
    with open(path, "r", encoding="utf-8") as f:
        obj = json.load(f)
    rules: List[Rule] = []
    for r in obj.get("rules", []):
        rules.append(
            Rule(
                id=str(r.get("id", "")),
                label=str(r.get("label", "")),
                pattern=str(r.get("pattern", "")).lower(),
            )
        )
    return rules


def mutate_whitespace(s: str) -> str:
    # insert extra spaces around = and keywords
    s = s.replace("=", " = ")
    s = s.replace(" OR ", "  OR   ")
    return s


def mutate_case(s: str) -> str:
    # random upper or lower for each character in keywords OR and AND
    out = []
    for ch in s:
        if ch.isalpha() and random.random() < 0.5:
            out.append(ch.upper())
        else:
            out.append(ch.lower())
    return "".join(out)


def mutate_url_encode(s: str) -> str:
    # encode some characters commonly used in payloads
    to_encode = [" ", "'", "\"", "=", "<", ">", ";"]
    out = []
    for ch in s:
        if ch in to_encode:
            out.append(urllib.parse.quote(ch))
        else:
            out.append(ch)
    return "".join(out)


def mutate_comment_split(s: str) -> str:
    # split common keywords with comment markers
    s = s.replace("OR", "O/**/R")
    s = s.replace("SELECT", "SEL/**/ECT")
    return s


def generate_variants(payload: Payload) -> List[VariantResult]:
    base = payload.payload
    variants: List[VariantResult] = []

    mutations = {
        "whitespace": mutate_whitespace(base),
        "case_shuffle": mutate_case(base),
        "url_encoding": mutate_url_encode(base),
        "comment_split": mutate_comment_split(base),
    }

    for name, text in mutations.items():
        variants.append(
            VariantResult(
                base_id=payload.id,
                base_label=payload.label,
                variant_id=f"{payload.id}_{name}",
                mutation=name,
                payload=text,
                detected_by=[],
            )
        )

    return variants


def apply_rules(variants: List[VariantResult], rules: List[Rule]) -> None:
    for v in variants:
        lower_payload = v.payload.lower()
        for r in rules:
            if r.pattern and r.pattern in lower_payload:
                v.detected_by.append(r.id)


def build_report(variants: List[VariantResult], rules: List[Rule]) -> str:
    # detection statistics per base payload
    per_base: Dict[str, Dict[str, int]] = {}
    for v in variants:
        d = per_base.setdefault(v.base_id, {"total": 0, "detected": 0})
        d["total"] += 1
        if v.detected_by:
            d["detected"] += 1

    # detection statistics per rule
    per_rule: Dict[str, Dict[str, int]] = {}
    for r in rules:
        per_rule[r.id] = {"label": r.label, "hits": 0}
    for v in variants:
        for r_id in v.detected_by:
            per_rule.setdefault(r_id, {"label": r_id, "hits": 0})
            per_rule[r_id]["hits"] += 1

    lines: List[str] = []
    lines.append("# Adversarial traffic lab report")
    lines.append("")
    lines.append(f"Total variants generated: {len(variants)}")
    lines.append("")

    lines.append("## Detection by base payload")
    lines.append("")
    for base_id, stats in per_base.items():
        total = stats["total"]
        detected = stats["detected"]
        rate = (detected / total * 100.0) if total else 0.0
        lines.append(f"* {base_id}: {detected} of {total} variants detected  about {rate:.1f} percent")
    lines.append("")

    lines.append("## Detection by rule")
    lines.append("")
    for r_id, stats in per_rule.items():
        lines.append(f"* {r_id}  {stats['label']}  hits {stats['hits']}")
    lines.append("")

    lines.append("## Examples of bypassed variants")
    lines.append("")
    count = 0
    for v in variants:
        if v.detected_by:
            continue
        lines.append(f"### {v.variant_id} from {v.base_id}  mutation {v.mutation}")
        lines.append("")
        lines.append("```")
        lines.append(v.payload)
        lines.append("```")
        lines.append("")
        count += 1
        if count >= 5:
            break

    if count == 0:
        lines.append("All variants were detected with the current simple rules.")

    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's adversarial IDS traffic lab")
    parser.add_argument("--payloads", required=True, help="JSONL file with base payloads")
    parser.add_argument("--rules", required=True, help="JSON file with detection rules")
    parser.add_argument(
        "--out-prefix", default="traffic_lab", help="Prefix for output paths"
    )
    args = parser.parse_args()

    payloads = load_payloads(args.payloads)
    rules = load_rules(args.rules)

    all_variants: List[VariantResult] = []
    for p in payloads:
        all_variants.extend(generate_variants(p))

    apply_rules(all_variants, rules)

    json_path = f"{args.out_prefix}_variants.json"
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump([asdict(v) for v in all_variants], f, indent=2)
    print(f"Wrote {len(all_variants)} variants to {json_path}")

    report = build_report(all_variants, rules)
    md_path = f"{args.out_prefix}_report.md"
    with open(md_path, "w", encoding="utf-8") as f:
        f.write(report)
    print(f"Wrote Markdown report to {md_path}")


if __name__ == "__main__":
    main()
