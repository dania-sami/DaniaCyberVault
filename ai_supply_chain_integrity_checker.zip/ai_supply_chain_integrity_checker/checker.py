"""
AI Supply Chain Integrity Checker – Dania

Compares local model artifacts to a registry of expected hashes and metadata
"""

import argparse
import json
import hashlib
import os
from dataclasses import dataclass, asdict
from typing import List, Dict


@dataclass
class ArtifactCheck:
    path: str
    expected_sha256: str
    actual_sha256: str
    status: str  # match, mismatch, missing
    metadata: Dict[str, str]


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def load_registry(path: str) -> List[Dict]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def check_artifacts(root: str, registry: List[Dict]) -> List[ArtifactCheck]:
    results: List[ArtifactCheck] = []
    for entry in registry:
        rel_path = entry["path"]
        expected = entry["sha256"]
        full = os.path.join(root, rel_path)
        meta = entry.get("metadata", {})
        if not os.path.exists(full):
            results.append(
                ArtifactCheck(
                    path=rel_path,
                    expected_sha256=expected,
                    actual_sha256="",
                    status="missing",
                    metadata=meta,
                )
            )
            continue
        actual = sha256_file(full)
        status = "match" if actual == expected else "mismatch"
        results.append(
            ArtifactCheck(
                path=rel_path,
                expected_sha256=expected,
                actual_sha256=actual,
                status=status,
                metadata=meta,
            )
        )
    return results


def write_report(checks: List[ArtifactCheck], md_path: str, json_path: str) -> None:
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump([asdict(c) for c in checks], f, indent=2)

    total = len(checks)
    matches = sum(1 for c in checks if c.status == "match")
    mismatches = sum(1 for c in checks if c.status == "mismatch")
    missing = sum(1 for c in checks if c.status == "missing")

    with open(md_path, "w", encoding="utf-8") as f:
        f.write("# AI supply chain integrity report\n\n")
        f.write(f"* Total artifacts in registry: {total}\n")
        f.write(f"* Matches: {matches}\n")
        f.write(f"* Mismatches: {mismatches}\n")
        f.write(f"* Missing: {missing}\n\n")

        for c in checks:
            f.write(f"- {c.path}: {c.status}\n")
        f.write("\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's AI supply chain integrity checker")
    parser.add_argument("--root", required=True, help="Root directory with model artifacts")
    parser.add_argument("--registry", required=True, help="JSON registry with expected hashes")
    parser.add_argument("--out-prefix", default="supply_chain", help="Prefix for output files")
    args = parser.parse_args()

    registry = load_registry(args.registry)
    checks = check_artifacts(args.root, registry)
    md_path = f"{args.out_prefix}_integrity_report.md"
    json_path = f"{args.out_prefix}_integrity_checks.json"
    write_report(checks, md_path, json_path)
    print(f"Wrote report to {md_path}")
    print(f"Wrote JSON details to {json_path}")


if __name__ == "__main__":
    main()
