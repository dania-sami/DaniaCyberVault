# AI Supply Chain Integrity Checker – Dania

Hi

I am Dania and this tool is my small integrity checker for AI model artifacts

It reads a registry of expected hashes and metadata and then walks a directory  hashing local model files and checking for tampering mismatches or missing pieces

The idea is to make the AI supply chain more visible and verifiable with a simple command
