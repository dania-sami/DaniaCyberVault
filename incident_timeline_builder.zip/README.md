# Incident Timeline Builder

This is a small tool I use to practise documenting incidents.

It takes a CSV file where each row is an event with:

- `incident_id`
- `timestamp`
- `source`
- `description`

The script groups events per incident and prints a clean timeline for each one in chronological order.

## Files

- `incident_timeline.py` – main script
- `demo_incidents.csv` – example data

## Usage

```bash
python incident_timeline.py --csv demo_incidents.csv
```
