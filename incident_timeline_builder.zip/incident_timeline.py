import argparse
import csv
from collections import defaultdict

def build_timelines(path: str):
    incidents = defaultdict(list)
    with open(path, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            iid = row.get("incident_id", "unknown")
            incidents[iid].append(row)

    for iid, events in incidents.items():
        events.sort(key=lambda e: e.get("timestamp", ""))
        print(f"[+] Incident {iid}")
        for e in events:
            ts = e.get("timestamp", "")
            src = e.get("source", "")
            desc = e.get("description", "")
            print(f"    {ts}  [{src}]  {desc}")
        print()

def main():
    parser = argparse.ArgumentParser(description="Incident Timeline Builder by Dania")
    parser.add_argument("--csv", required=True, help="Path to CSV file")
    args = parser.parse_args()
    build_timelines(args.csv)

if __name__ == "__main__":
    main()
