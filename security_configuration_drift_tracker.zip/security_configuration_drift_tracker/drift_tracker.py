"""
Security Configuration Drift Tracker  Dania s snapshot watcher

Compares baseline and current JSON snapshots of

- firewall rules
- IAM policies
- registry keys

and marks drifts and their risk impact
"""

import argparse
import json
from typing import Dict, Any, List, Tuple


def load_snapshot(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def index_by_id(items: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    return {str(it.get("id")): it for it in items if "id" in it}


def assess_firewall_change(old: Dict[str, Any], new: Dict[str, Any]) -> str:
    # very simple CIDR based risk evaluation
    old_cidr = str(old.get("cidr", "")).strip()
    new_cidr = str(new.get("cidr", "")).strip()
    if old_cidr == new_cidr:
        return "neutral"

    if old_cidr != "0.0.0.0/0" and new_cidr == "0.0.0.0/0":
        return "risk_increase_open_to_world"
    if old_cidr == "0.0.0.0/0" and new_cidr != "0.0.0.0/0":
        return "risk_decrease_narrowed_range"
    return "needs_review_cidr_changed"


def assess_iam_change(old: Dict[str, Any], new: Dict[str, Any]) -> str:
    old_action = str(old.get("action", ""))
    new_action = str(new.get("action", ""))
    old_res = str(old.get("resource", ""))
    new_res = str(new.get("resource", ""))
    old_effect = str(old.get("effect", ""))
    new_effect = str(new.get("effect", ""))

    if old_effect == "Deny" and new_effect == "Allow":
        return "risk_increase_deny_to_allow"
    if "*" not in old_action and "*" in new_action:
        return "risk_increase_broader_actions"
    if "*" not in old_res and "*" in new_res:
        return "risk_increase_broader_resources"
    if "*" in old_action and "*" not in new_action:
        return "risk_decrease_narrow_actions"
    if "*" in old_res and "*" not in new_res:
        return "risk_decrease_narrow_resources"
    return "needs_review_changed"


def assess_registry_change(old: Dict[str, Any], new: Dict[str, Any]) -> str:
    old_val = str(old.get("value", ""))
    new_val = str(new.get("value", ""))
    if old_val == new_val:
        return "neutral"
    return "changed"


def diff_section(
    name: str,
    baseline_items: List[Dict[str, Any]],
    current_items: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    baseline_index = index_by_id(baseline_items)
    current_index = index_by_id(current_items)
    out: List[Dict[str, Any]] = []

    all_ids = set(baseline_index.keys()) | set(current_index.keys())
    for id_ in sorted(all_ids):
        base = baseline_index.get(id_)
        curr = current_index.get(id_)
        if base and not curr:
            out.append(
                {"section": name, "id": id_, "kind": "removed", "baseline": base, "current": None, "risk": "unknown"}
            )
        elif curr and not base:
            out.append(
                {"section": name, "id": id_, "kind": "added", "baseline": None, "current": curr, "risk": "unknown"}
            )
        else:
            if base == curr:
                continue
            # changed
            risk = "needs_review"
            if name == "firewall_rules":
                risk = assess_firewall_change(base, curr)
            elif name == "iam_policies":
                risk = assess_iam_change(base, curr)
            elif name == "registry_keys":
                risk = assess_registry_change(base, curr)

            out.append(
                {
                    "section": name,
                    "id": id_,
                    "kind": "changed",
                    "baseline": base,
                    "current": curr,
                    "risk": risk,
                }
            )
    return out


def summarise(drifts: List[Dict[str, Any]]) -> Dict[str, Any]:
    summary = {
        "total_drifts": len(drifts),
        "by_section": {},
        "by_risk": {},
    }
    for d in drifts:
        section = d["section"]
        risk = d.get("risk", "unknown")
        summary["by_section"].setdefault(section, 0)
        summary["by_section"][section] += 1
        summary["by_risk"].setdefault(risk, 0)
        summary["by_risk"][risk] += 1
    return summary


def write_json(drifts: List[Dict[str, Any]], summary: Dict[str, Any], path: str) -> None:
    obj = {"drifts": drifts, "summary": summary}
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2)


def write_report(summary: Dict[str, Any], drifts: List[Dict[str, Any]], path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        f.write("# Security configuration drift report\n\n")
        f.write(f"* Total drifts detected: {summary['total_drifts']}\n\n")

        f.write("## Drifts by section\n\n")
        if summary["by_section"]:
            for sec, count in summary["by_section"].items():
                f.write(f"* {sec}: {count}\n")
        else:
            f.write("No differences between baseline and current snapshots.\n")
        f.write("\n")

        f.write("## Drifts by risk classification\n\n")
        if summary["by_risk"]:
            for risk, count in summary["by_risk"].items():
                f.write(f"* {risk}: {count}\n")
        else:
            f.write("No risk classifications were applied.\n")
        f.write("\n")

        f.write("## Selected details\n\n")
        for d in drifts[:20]:
            f.write(f"* [{d['section']}] id {d['id']}  kind {d['kind']}  risk {d.get('risk', 'unknown')}\n")
        f.write("\n")

        f.write("## Narrative summary\n\n")
        if not drifts:
            f.write("The current snapshot matches the baseline with the current heuristics. ")
            f.write("There is no obvious configuration drift to investigate.\n")
        else:
            risky = sum(
                1
                for d in drifts
                if str(d.get("risk", "")).startswith("risk_increase")
            )
            safer = sum(
                1
                for d in drifts
                if str(d.get("risk", "")).startswith("risk_decrease")
            )
            if risky == 0:
                f.write("There are some changes between baseline and current configuration but none were flagged as clear risk increases. ")
                f.write("They still deserve a quick review to confirm they are intentional.\n")
            else:
                f.write(
                    f"The tracker found {risky} change or changes that clearly increase exposure according to the simple rules. "
                )
                if safer:
                    f.write(f"It also noticed {safer} change or changes that reduced risk, which is a good sign. ")
                f.write("The riskiest changes should be reviewed and either rolled back or compensated with additional controls.\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania s security configuration drift tracker")
    parser.add_argument("--baseline", required=True, help="Baseline snapshot JSON path")
    parser.add_argument("--current", required=True, help="Current snapshot JSON path")
    parser.add_argument("--out", default="drift_report.md", help="Markdown report output path")
    parser.add_argument("--json-out", help="Optional JSON output path for drift details")
    args = parser.parse_args()

    baseline = load_snapshot(args.baseline)
    current = load_snapshot(args.current)

    drifts: List[Dict[str, Any]] = []
    for section in ["firewall_rules", "iam_policies", "registry_keys"]:
        drifts.extend(
            diff_section(section, baseline.get(section, []), current.get(section, []))
        )

    summary = summarise(drifts)
    write_report(summary, drifts, args.out)
    print(f"Wrote drift report to {args.out}")
    if args.json_out:
        write_json(drifts, summary, args.json_out)
        print(f"Wrote drift details to {args.json_out}")


if __name__ == "__main__":
    main()
