# Security Configuration Drift Tracker  Dania s snapshot watcher

Hi

I am Dania and this project is a small service style script that helps me keep an eye on configuration drift

Many breaches start with a slow quiet change

* a firewall rule that becomes a bit more open
* an identity policy that gains one extra star permission
* a registry key that gets flipped from safe to risky

I wanted something light that could run as a scheduled job
take snapshots of important settings
and tell me

* what changed since the last known good baseline
* which changes clearly increase exposure
* which changes look harmless or even safer

For this portfolio version everything is driven by JSON files
so it is easy to understand and demo

## Input format

The tracker expects two JSON files

* a baseline snapshot
* a current snapshot

Each file looks like

{
  "firewall_rules": [
    {"id": "fw1", "resource": "web_sg", "direction": "ingress", "cidr": "0.0.0.0/0", "port": "80", "action": "allow"}
  ],
  "iam_policies": [
    {"id": "iam1", "principal": "app_role", "action": "s3:GetObject", "resource": "bucket_a/*", "effect": "Allow"}
  ],
  "registry_keys": [
    {"id": "reg1", "path": "HKLM\\Software\\Example", "name": "SecureMode", "value": "1"}
  ]
}

You can change these structures for your environment
as long as ids remain stable across snapshots

I also include small demo snapshots under `examples`
so the tool runs immediately

## What the tracker does

For each section it

1  Matches items by id between baseline and current

2  Classifies each id as

   * added
   * removed
   * changed
   * unchanged

3  For changed items it applies simple risk heuristics
   for example

   * firewall rule that moves from small CIDR to global  more risky
   * rule that gains a wider port range  more risky
   * IAM action moving from specific resource to star resource  more risky
   * effect changing from Deny to Allow  more risky

Changes that clearly reduce exposure are also noted as safe improvements

At the end it writes

* a JSON file with all detected drifts
* a Markdown report saying which changes you probably want to review first

## How I run it

From the project root

1 optional create a virtual environment

       python -m venv venv
       source venv_bin_activate

2 install requirements

       pip install -r requirements.txt

3 inspect the example snapshots

   * `examples_baseline_sample.json`
   * `examples_current_sample.json`

4 run the tracker

       python drift_tracker.py \
           --baseline examples_baseline_sample.json \
           --current examples_current_sample.json \
           --out drift_report.md \
           --json-out drift_findings.json

The report shows

* added or removed rules and policies
* which changes increased risk and why
* which changes reduced risk
* a short narrative summary that reads like a human wrote it

## How I imagine using this

In a real environment

* a small job would build these snapshots on a schedule
* each new snapshot would be compared to the last known safe one
* risky drifts would create a ticket or a message for the security team

With this project I can show that I

* understand that drift is a big part of security incidents
* can encode a few simple but meaningful risk heuristics
* can present the results in a way that non security teammates can still follow

It is a compact pattern that could live inside a bigger platform later
but even alone it is already useful as a teaching and interview piece
