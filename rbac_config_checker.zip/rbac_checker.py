import argparse
import json

def load_config(path: str):
    with open(path) as f:
        return json.load(f)

def analyse(cfg):
    roles = cfg.get("roles", {})
    users = cfg.get("users", {})

    print("[+] Roles:")
    for role, perms in roles.items():
        print(f"    {role}: {len(perms)} permissions")
    print()

    print("[+] Users:")
    for user, user_roles in users.items():
        print(f"    {user}: roles={', '.join(user_roles)}")
    print()

    print("[+] Potentially risky roles:")
    for role, perms in roles.items():
        if "*" in perms or len(perms) > 8:
            print(f"    {role}: wildcard or many permissions")

def main():
    parser = argparse.ArgumentParser(description="RBAC Config Checker by Dania")
    parser.add_argument("--config", required=True, help="Path to RBAC JSON config")
    args = parser.parse_args()
    cfg = load_config(args.config)
    analyse(cfg)

if __name__ == "__main__":
    main()
