# Role-based Access Config Checker

This project is a small helper script I use to reason about RBAC (role-based access control).

The idea is:

- I describe roles and permissions in a JSON file.
- The script loads the config and looks for very broad roles that might be too powerful.

## Example checks

- Roles that have `*` in their permissions
- Roles that have more than a given number of permissions
- A quick overview of which users have which roles

## Files

- `rbac_checker.py` – main script
- `rbac_example.json` – example configuration

## Usage

```bash
python rbac_checker.py --config rbac_example.json
```
