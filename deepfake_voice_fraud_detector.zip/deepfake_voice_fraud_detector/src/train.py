from __future__ import annotations

from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
MODELS_DIR = BASE_DIR / "models"

for d in (DATA_DIR, MODELS_DIR):
    d.mkdir(parents=True, exist_ok=True)


def generate_synthetic_voice_features(n: int = 200) -> pd.DataFrame:
    rng = np.random.RandomState(7)
    rows = []
    for i in range(n):
        # label: 0 = human, 1 = deepfake
        label = rng.binomial(1, 0.5)
        if label == 0:
            pitch_var = rng.normal(0.12, 0.03)  # more natural variation
            mfcc1 = rng.normal(0.0, 0.4)
            mfcc2 = rng.normal(-0.1, 0.4)
            mfcc3 = rng.normal(0.2, 0.3)
        else:
            pitch_var = rng.normal(0.03, 0.01)  # too "flat" voice
            mfcc1 = rng.normal(0.6, 0.3)
            mfcc2 = rng.normal(0.4, 0.3)
            mfcc3 = rng.normal(-0.4, 0.3)
        rows.append(
            {
                "pitch_var": float(pitch_var),
                "mfcc1": float(mfcc1),
                "mfcc2": float(mfcc2),
                "mfcc3": float(mfcc3),
                "label": int(label),
            }
        )
    return pd.DataFrame(rows)


def main() -> None:
    data_path = DATA_DIR / "voice_features.csv"
    if data_path.exists():
        df = pd.read_csv(data_path)
    else:
        df = generate_synthetic_voice_features()
        df.to_csv(data_path, index=False)

    X = df[["pitch_var", "mfcc1", "mfcc2", "mfcc3"]]
    y = df["label"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    clf = LogisticRegression(max_iter=500)
    clf.fit(X_train_scaled, y_train)

    y_pred = clf.predict(X_test_scaled)
    print("Validation report:")
    print(classification_report(y_test, y_pred, target_names=["human", "deepfake"]))

    joblib.dump(
        {"model": clf, "scaler": scaler, "feature_names": list(X.columns), "data": df},
        MODELS_DIR / "voice_model.joblib",
    )
    print(f"Saved model bundle to {MODELS_DIR/'voice_model.joblib'}")


if __name__ == "__main__":
    main()
