from __future__ import annotations

import argparse
from pathlib import Path
from typing import Dict, Any

import joblib
import numpy as np
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent.parent
MODELS_DIR = BASE_DIR / "models"


def load_bundle() -> Dict[str, Any]:
    return joblib.load(MODELS_DIR / "voice_model.joblib")


def pretty_print(score: float) -> None:
    risk = "LOW"
    if score >= 0.8:
        risk = "HIGH"
    elif score >= 0.5:
        risk = "MEDIUM"
    print(f"Deepfake probability: {score:.2f} -> fraud risk: {risk}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Deepfake voice fraud risk scorer")
    parser.add_argument("--sample", type=int, default=None, help="Sample index from training data")
    parser.add_argument("--pitch_var", type=float, default=None)
    parser.add_argument("--mfcc1", type=float, default=None)
    parser.add_argument("--mfcc2", type=float, default=None)
    parser.add_argument("--mfcc3", type=float, default=None)
    args = parser.parse_args()

    bundle = load_bundle()
    model = bundle["model"]
    scaler = bundle["scaler"]
    feature_names = bundle["feature_names"]
    df: pd.DataFrame = bundle["data"]

    if args.sample is not None:
        idx = max(0, min(args.sample, len(df) - 1))
        row = df.iloc[idx][feature_names]
        print(f"Using sample #{idx} from dataset:")
        print(row.to_string())
        X = row.to_numpy().reshape(1, -1)
    else:
        values = {
            "pitch_var": args.pitch_var,
            "mfcc1": args.mfcc1,
            "mfcc2": args.mfcc2,
            "mfcc3": args.mfcc3,
        }
        if any(v is None for v in values.values()):
            parser.error("Either --sample or all feature flags (--pitch_var, --mfcc1, --mfcc2, --mfcc3) must be provided.")
        X = np.array([[values[k] for k in feature_names]], dtype=float)
        print("Using custom features:")
        print(dict(zip(feature_names, X[0].tolist())))

    X_scaled = scaler.transform(X)
    prob = float(model.predict_proba(X_scaled)[0, 1])
    pretty_print(prob)


if __name__ == "__main__":
    main()
