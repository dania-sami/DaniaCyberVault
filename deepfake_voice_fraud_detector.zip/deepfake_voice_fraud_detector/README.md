# Deepfake Voice Fraud Detector (Feature Demo)

Hi, I am Dania 👋

This is my **deepfake voice fraud detector** in a lightweight, feature-based lab:

- I work on pre-extracted voice features (pitch variance, MFCC-like values, etc.).
- I train a classifier to distinguish **human vs cheap synthetic** speech.
- I expose a simple CLI that prints a **fraud risk score**.

The project is small but it shows how I think about **voice security and fraud**.

## How to run

```bash
cd deepfake_voice_fraud_detector

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt

# Train the model
python -m src.train

# Score a sample from the dataset
python -m src.score --sample 0

# Or score custom features
python -m src.score --pitch_var 0.05 --mfcc1 0.1 --mfcc2 -0.2 --mfcc3 0.3
```

The training script prints validation metrics, and the scoring script prints
a human-friendly fraud risk verdict.
