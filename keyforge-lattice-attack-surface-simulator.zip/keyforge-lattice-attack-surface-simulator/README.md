
# KeyForge Lattice Attack Surface Simulator

KeyForge is my lattice parameter conversation starter.

It takes simple parameters like dimension, modulus bits, noise ratio, an
estimated security margin and implementation maturity. Then it gives back:
* an attack surface score (0–100)
* a band such as wide, elevated or limited
* a few short notes I can use in discussions

## Run

```bash
cd backend
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn keyforge_engine.main:app --reload --port 9924
```

Open http://localhost:9924/docs and call `/schemes` then `/assess`.
