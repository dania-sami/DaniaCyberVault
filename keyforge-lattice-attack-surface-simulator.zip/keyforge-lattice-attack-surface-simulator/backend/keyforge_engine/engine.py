
from dataclasses import dataclass
from typing import Dict, List


@dataclass
class LatticeSchemeProfile:
    id: int
    name: str
    meta: Dict[str, str]
    params: Dict[str, float]


@dataclass
class LatticeAssessment:
    profile_id: int
    name: str
    attack_surface: float
    band: str
    notes: List[str]


class KeyForgeBrain:
    """
    KeyForge is my lattice attack surface simulator.

    It does not break anything. Instead it looks at approximate parameter
    choices and implementation maturity to estimate how much attack surface
    we might be exposing to future cryptanalysis work.
    """

    def __init__(self) -> None:
        self._next_id = 1
        self.schemes: Dict[int, LatticeSchemeProfile] = {}

    def register_scheme(self, name: str, meta: Dict[str, str], params: Dict[str, float]) -> LatticeSchemeProfile:
        sid = self._next_id
        self._next_id += 1
        prof = LatticeSchemeProfile(
            id=sid,
            name=name,
            meta=meta,
            params=params,
        )
        self.schemes[sid] = prof
        return prof

    def assess(self, profile_id: int) -> LatticeAssessment:
        prof = self.schemes[profile_id]
        p = prof.params
        notes: List[str] = []
        surface = 0.0

        dim = float(p.get("dimension", 0.0))
        q_bits = float(p.get("modulus_bits", 0.0))
        noise_ratio = float(p.get("noise_ratio", 0.0))
        sec_margin = float(p.get("security_margin_estimate", 0.5))
        impl_maturity = float(p.get("implementation_maturity", 0.5))

        if dim < 500:
            surface += 30.0
            notes.append("Low lattice dimension compared to many conservative parameter sets.")
        elif dim < 800:
            surface += 15.0
            notes.append("Medium dimension; reasonable but not very conservative.")

        if q_bits < 12.0:
            surface += 25.0
            notes.append("Small modulus size may reduce effective security margin.")
        if noise_ratio < 0.2:
            surface += 20.0
            notes.append("Low noise ratio, might open extra structure to attackers.")
        elif noise_ratio > 0.6:
            notes.append("Higher noise ratio increases robustness at the cost of performance.")

        if sec_margin < 0.5:
            surface += (0.5 - sec_margin) * 40.0
            notes.append("Security margin estimate is on the low side.")
        elif sec_margin > 0.7:
            surface -= (sec_margin - 0.7) * 20.0
            notes.append("Security margin estimate is on the conservative side.")

        if impl_maturity < 0.4:
            surface += (0.4 - impl_maturity) * 30.0
            notes.append("Implementation maturity is low; risk of engineering flaws is higher.")
        elif impl_maturity > 0.7:
            surface -= (impl_maturity - 0.7) * 15.0
            notes.append("Implementation has seen more maturity and review.")

        surface = max(0.0, min(100.0, surface))

        if surface >= 80.0:
            band = "wide_attack_surface"
        elif surface >= 60.0:
            band = "elevated_attack_surface"
        elif surface >= 40.0:
            band = "moderate_attack_surface"
        elif surface >= 20.0:
            band = "limited_attack_surface"
        else:
            band = "low_attack_surface_under_model"

        if not notes:
            notes.append("Parameters do not show strong attack surface drivers under this model.")

        return LatticeAssessment(
            profile_id=prof.id,
            name=prof.name,
            attack_surface=round(surface, 2),
            band=band,
            notes=notes,
        )
