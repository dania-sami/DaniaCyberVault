
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Dict, List

from .engine import KeyForgeBrain, LatticeSchemeProfile, LatticeAssessment


brain = KeyForgeBrain()


class SchemeIn(BaseModel):
    name: str = Field(..., example="kyber-like-768")
    meta: Dict[str, str] = Field(default_factory=dict)
    params: Dict[str, float] = Field(
        default_factory=dict,
        description=(
            "Params: dimension, modulus_bits, noise_ratio, security_margin_estimate, implementation_maturity"
        ),
    )


class SchemeOut(BaseModel):
    id: int
    name: str
    meta: Dict[str, str]
    params: Dict[str, float]


class LatticeOut(BaseModel):
    profile_id: int
    name: str
    attack_surface: float
    band: str
    notes: List[str]


app = FastAPI(
    title="KeyForge Lattice Attack Surface Simulator",
    version="0.1.0",
    description="My engine for reasoning about lattice parameter attack surface at a high level.",
)


@app.post("/schemes", response_model=SchemeOut)
def register_scheme(payload: SchemeIn) -> SchemeOut:
    prof: LatticeSchemeProfile = brain.register_scheme(
        name=payload.name,
        meta=payload.meta,
        params=payload.params,
    )
    return SchemeOut(
        id=prof.id,
        name=prof.name,
        meta=prof.meta,
        params=prof.params,
    )


@app.post("/assess", response_model=LatticeOut)
def assess(profile_id: int) -> LatticeOut:
    if profile_id not in brain.schemes:
        raise HTTPException(status_code=404, detail="Scheme not found")
    res: LatticeAssessment = brain.assess(profile_id)
    return LatticeOut(
        profile_id=res.profile_id,
        name=res.name,
        attack_surface=res.attack_surface,
        band=res.band,
        notes=res.notes,
    )
