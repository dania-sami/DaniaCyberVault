# Web Login Bruteforce Trainer (Offline Password Demo)

This project is my safe way to talk about bruteforce and weak passwords without touching any real websites.

Instead of sending login requests, the script works completely offline. It reads a small config file with a username and a SHA-256 hash of the real password, then tries a list of candidate passwords from a wordlist and shows how quickly a weak password can be found.

## What it does

- Uses SHA-256 hashing
- Compares each candidate in the wordlist against the stored hash
- Shows how many attempts were needed
- Helps me explain why short and common passwords are dangerous

## Files

- `offline_bruteforce_trainer.py` – main script
- `config.json` – contains username and hashed password
- `passwords.txt` – example wordlist with some common weak passwords

## Usage

```bash
python offline_bruteforce_trainer.py --config config.json --wordlist passwords.txt
```

Example output:

```text
[+] Loaded hash for user: dania
[+] Trying 10 candidate passwords...

[+] Match found!
    password: sunshine123
    attempts: 4
```

This is for learning and explaining concepts only. It never talks to the network and does not attack any real login page.
