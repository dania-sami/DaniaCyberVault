import argparse
import hashlib
import json

def sha256_hex(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()

def load_config(path: str):
    with open(path) as f:
        data = json.load(f)
    username = data.get("username", "user")
    stored_hash = data.get("password_hash", "")
    return username, stored_hash

def bruteforce(config_path: str, wordlist_path: str):
    username, stored_hash = load_config(config_path)
    if not stored_hash:
        print("[-] No password_hash found in config.")
        return

    print(f"[+] Loaded hash for user: {username}")
    print(f"[+] Using wordlist: {wordlist_path}\n")

    attempts = 0
    with open(wordlist_path) as f:
        for line in f:
            candidate = line.strip()
            if not candidate:
                continue
            attempts += 1
            if sha256_hex(candidate) == stored_hash:
                print("[+] Match found!")
                print(f"    password: {candidate}")
                print(f"    attempts: {attempts}")
                return

    print("[+] No match found in this wordlist.")
    print(f"    total attempts: {attempts}")

def main():
    parser = argparse.ArgumentParser(description="Offline Web Login Bruteforce Trainer by Dania")
    parser.add_argument("--config", required=True, help="Path to JSON config with username and password_hash")
    parser.add_argument("--wordlist", required=True, help="Path to password wordlist")
    args = parser.parse_args()
    bruteforce(args.config, args.wordlist)

if __name__ == "__main__":
    main()
