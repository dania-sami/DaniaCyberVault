import json, argparse
from dataclasses import dataclass, asdict

@dataclass
class Account:
    name: str
    mfa_enabled: bool
    methods: list
    backup_codes: bool
    recovery_email: str

PHISHING_RESISTANT = {"webauthn","u2f","passkey"}

def grade(account: Account):
    score=0
    reasons=[]
    if account.mfa_enabled: 
        score+=2
    else:
        reasons.append("MFA disabled")

    if account.backup_codes:
        score+=1
    else:
        reasons.append("No backup codes")

    if any(m in PHISHING_RESISTANT for m in account.methods):
        score+=3
    else:
        reasons.append("No phishing resistant factor")

    if "sms" in account.methods:
        reasons.append("Using SMS (weak)")

    if "totp" in account.methods:
        score+=1

    return score,reasons

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--input",required=True)
    ap.add_argument("--out",default="mfa_report.md")
    ap.add_argument("--json",default="mfa_results.json")
    a=ap.parse_args()

    with open(a.input) as f: data=json.load(f)

    accounts=[Account(**acct) for acct in data]
    results=[]
    for acc in accounts:
        score,reasons=grade(acc)
        results.append({"account":acc.name,"score":score,"reasons":reasons})

    # write markdown
    with open(a.out,"w") as f:
        f.write("# MFA Strength Report\n\n")
        for r in results:
            f.write(f"## {r['account']}\n")
            f.write(f"* Score: **{r['score']}**\n")
            if r["reasons"]:
                f.write("* Issues:\n")
                for x in r["reasons"]:
                    f.write(f"  * {x}\n")
            f.write("\n")

    with open(a.json,"w") as f: json.dump(results,f,indent=2)

if __name__=="__main__":
    main()
