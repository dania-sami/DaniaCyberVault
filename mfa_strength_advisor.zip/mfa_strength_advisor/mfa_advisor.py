"""
MFA Strength Advisor – Dania's personal security coach

Reads a JSON list of account MFA settings
scores each account
and produces a Markdown report plus optional JSON
"""

import argparse
import json
from dataclasses import dataclass, asdict
from datetime import datetime
from typing import List


CURRENT_YEAR = datetime.utcnow().year


@dataclass
class Account:
    service: str
    username: str
    mfa_method: str
    backup_codes: bool
    security_keys: int
    phone_sms_enabled: bool
    email_only: bool
    last_review_year: int
    strength: str = ""
    score: float = 0.0
    notes: str = ""


def load_accounts(path: str) -> List[Account]:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    accounts: List[Account] = []
    for obj in data:
        accounts.append(
            Account(
                service=str(obj.get("service", "")),
                username=str(obj.get("username", "")),
                mfa_method=str(obj.get("mfa_method", "none")).lower(),
                backup_codes=bool(obj.get("backup_codes", False)),
                security_keys=int(obj.get("security_keys", 0)),
                phone_sms_enabled=bool(obj.get("phone_sms_enabled", False)),
                email_only=bool(obj.get("email_only", False)),
                last_review_year=int(obj.get("last_review_year", CURRENT_YEAR)),
            )
        )
    return accounts


def score_account(acc: Account) -> None:
    score = 0.0
    notes = []

    strong_factor = False

    if acc.security_keys >= 1:
        score += 4.0
        notes.append("has hardware security key")
        strong_factor = True
        if acc.security_keys >= 2:
            score += 1.0
            notes.append("has more than one security key")
    if acc.mfa_method in {"totp", "app", "push", "mixed"}:
        score += 3.0
        notes.append(f"uses {acc.mfa_method} based MFA")
        strong_factor = True
    if acc.mfa_method in {"sms"}:
        score += 1.0
        notes.append("uses SMS MFA which is better than nothing but still weak")
    if acc.mfa_method in {"none"} or acc.email_only:
        notes.append("MFA appears to be off or only email based")

    if acc.backup_codes:
        score += 1.0
        notes.append("backup codes configured")

    if acc.phone_sms_enabled and acc.security_keys >= 1:
        notes.append("SMS is still enabled as backup consider limiting for phishing resistance")

    # review age
    age = max(0, CURRENT_YEAR - acc.last_review_year)
    if age >= 3:
        score -= 1.0
        notes.append(f"settings not reviewed since around {acc.last_review_year}")

    # strength label
    if strong_factor and acc.backup_codes and acc.security_keys >= 1:
        strength = "Strong"
    elif strong_factor:
        strength = "Medium"
    elif acc.mfa_method == "sms":
        strength = "Weak"
    else:
        strength = "Very weak"

    acc.score = round(score, 2)
    acc.strength = strength
    acc.notes = "; ".join(notes)


def score_all(accounts: List[Account]) -> None:
    for a in accounts:
        score_account(a)
    accounts.sort(key=lambda a: a.score, reverse=True)


def write_report(accounts: List[Account], out_path: str) -> None:
    # summary
    strength_counts = {}
    for a in accounts:
        strength_counts[a.strength] = strength_counts.get(a.strength, 0) + 1

    with open(out_path, "w", encoding="utf-8") as f:
        f.write("# MFA strength advisor report\n\n")
        if not accounts:
            f.write("No accounts were provided.\n")
            return

        f.write("## Overview\n\n")
        f.write("Accounts by strength level\n\n")
        for level in sorted(strength_counts.keys()):
            f.write(f"* {level}: {strength_counts[level]}\n")
        f.write("\n")

        f.write("## Recommended priority fixes\n\n")
        for a in accounts:
            if a.strength in {"Very weak", "Weak"}:
                f.write(f"* `{a.service}` account `{a.username}` is **{a.strength}**  notes {a.notes}\n")
        f.write("\n")

        f.write("## Details per account\n\n")
        for a in accounts:
            f.write(f"### {a.service}  ({a.username})\n\n")
            f.write(f"* Strength: **{a.strength}**\n")
            f.write(f"* Score: `{a.score}`\n")
            f.write(f"* MFA method: `{a.mfa_method}`\n")
            f.write(f"* Security keys: `{a.security_keys}`\n")
            f.write(f"* Backup codes: `{a.backup_codes}`\n")
            f.write(f"* Phone SMS enabled: `{a.phone_sms_enabled}`\n")
            f.write(f"* Email only: `{a.email_only}`\n")
            f.write(f"* Last review year: `{a.last_review_year}`\n")
            if a.notes:
                f.write(f"* Notes: {a.notes}\n")
            f.write("\n")


def write_json_scores(accounts: List[Account], out_path: str) -> None:
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump([asdict(a) for a in accounts], f, indent=2)


def main() -> None:
    parser = argparse.ArgumentParser(description="Dania's MFA strength advisor")
    parser.add_argument("--accounts", required=True, help="Path to JSON file with account list")
    parser.add_argument("--out", default="mfa_report.md", help="Markdown report path")
    parser.add_argument("--json-out", help="Optional JSON output path for scores")
    args = parser.parse_args()

    accounts = load_accounts(args.accounts)
    score_all(accounts)
    write_report(accounts, args.out)
    print(f"Wrote MFA report to {args.out}")

    if args.json_out:
        write_json_scores(accounts, args.json_out)
        print(f"Wrote JSON scores to {args.json_out}")


if __name__ == "__main__":
    main()
