# MFA Strength Advisor – Dania’s personal security coach

Hi

I am Dania and this is a small assistant I built to review my own multi factor authentication setup

Instead of just ticking the box that MFA is on
I wanted a script that takes a simple export of my account settings
and tells me in plain language

* which accounts are strong
* which ones are weak or missing backup options
* what I should fix first if I have limited time

Everything is file based and offline
There are no direct connections to real providers or APIs in this project

## Input format

The advisor expects a JSON file with a list of accounts
Each account has fields like

{
  "service": "github",
  "username": "dania_dev",
  "mfa_method": "totp",
  "backup_codes": true,
  "security_keys": 1,
  "phone_sms_enabled": false,
  "email_only": false,
  "last_review_year": 2025
}

Fields

* service  name of the service or site
* username  account name or email
* mfa_method  none sms totp push security_key mixed
* backup_codes  whether backup codes are configured and stored safely
* security_keys  number of hardware keys registered
* phone_sms_enabled  whether SMS is enabled as a factor
* email_only  true if the account effectively uses only email as a factor
* last_review_year  when you last reviewed the security settings

You can build this file manually or from your own notes and exports

## How the advisor scores accounts

The scoring is deliberately simple and transparent

* Strongest setup
  * at least one security key
  * plus TOTP or app based factor
  * backup codes present
* Medium
  * TOTP or app based factor
  * no security key yet
* Weak
  * SMS only
  * or email only
  * or MFA turned off completely

The advisor also adds extra hints such as

* suggest adding a second hardware key for important services
* warn when SMS is still enabled as a backup on critical accounts
* remind me to review settings that I have not looked at for several years

The output is both

* a JSON file with scores per account
* a Markdown report that reads like a checklist

## How I run it

1 Optional create and activate a virtual environment

   python3 -m venv venv
   source venv_bin_activate

2 Install requirements

   pip install -r requirements.txt

3 Look at the example file

   examples_accounts_sample.json

4 Run the advisor

   python mfa_advisor.py \
       --accounts examples_accounts_sample.json \
       --out mfa_report.md \
       --json-out mfa_scores.json

Then I open mfa_report.md and I get

* a quick overview of how many accounts are in each strength level
* a section for high value accounts that need attention
* clear recommendations in normal language instead of just numbers

## Why I like this project

For me this sits nicely between personal security hygiene and automation

With this advisor I can talk about

* why phishing resistant factors such as security keys matter
* why SMS and email only setups are still risky
* how to translate technical settings into a clear personal to do list
* how I would extend this to read real provider exports or APIs in a safe way

Right now it is a simple offline coach for my MFA posture
and that already makes it useful to run from time to time

